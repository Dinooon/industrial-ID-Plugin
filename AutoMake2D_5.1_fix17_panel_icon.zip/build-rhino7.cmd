@echo off
setlocal
cd /d "%~dp0"
where dotnet >nul 2>nul
if errorlevel 1 (
  echo [ERROR] dotnet SDK was not found.
  exit /b 1
)
echo Restoring Rhino 7 project...
dotnet restore "src\AutoMake2D.Rhino7.csproj"
if errorlevel 1 exit /b 1
echo Building Rhino 7 / .NET Framework 4.8...
dotnet build "src\AutoMake2D.Rhino7.csproj" -c Release --no-restore
if errorlevel 1 exit /b 1
if exist "dist\Rhino7" rmdir /s /q "dist\Rhino7"
mkdir "dist\Rhino7"
copy /y "src\bin\Release\net48\AutoMake2D.rhp" "dist\Rhino7\AutoMake2D.rhp" >nul
if errorlevel 1 (
  echo [ERROR] Rhino 7 output file was not found.
  exit /b 1
)
echo Done: dist\Rhino7\AutoMake2D.rhp
endlocal
