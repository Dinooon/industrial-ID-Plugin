# AutoMake2D 4.0

> Rhino 3D 专利图纸自动生成插件 4.0 — 含 Creo 导入功能

---

## 版本说明

AutoMake2D 4.0 在 3.0 (V8) 基础上进行以下升级：

1. **PatentCore 模块化重构**：将 1355 行的 PatentCore.cs 拆分为 7 个独立模块
2. **新增 Creo 导入功能**：参照 CreoImporter.py，用 C# 实现固定路径文件导入
3. **新增视图标注功能**：可选功能，在各视图旁添加中文名称标注
4. **RhinoCommon 升级至 8.x**：兼容 Rhino 7 SR35+ 和 Rhino 8
5. **统一日志系统**：新增 Common/Logger.cs

## 项目结构

```
src/
├── AutoMake2DPlugin.cs           — 插件入口 (72行)
├── AutoMake2DCommand.cs          — 命令定义 (28行)
├── PatentUiPanel.cs              — UI 面板 (346行，含 Creo 导入功能区)
├── AutoMake2D.csproj             — 项目配置 (RhinoCommon 8.x)
├── icon1.ico                     — 插件图标 (需从 3.0 复制)
├── PatentCore/                   — 核心引擎 (模块化)
│   ├── PatentCore.cs             — 门面类 (259行)
│   ├── PatentProjector.cs        — 视图投影 + HLD (228行)
│   ├── CurveFusionEngine.cs      — 曲线融合 (381行)
│   ├── LayerDispatcher.cs        — 图层分发 (78行)
│   ├── LayoutComposer.cs         — 排版引擎 (88行)
│   ├── RenderCaptureEngine.cs    — 渲染捕获 (284行)
│   ├── AnnotationEngine.cs       — 视图标注 (88行)
│   └── CreoImporter.cs           — Creo 导入 (176行)
└── Common/
    └── Logger.cs                 — 统一日志 (73行)
```

## 编译方法

### 环境要求
- .NET SDK (含 .NET Framework 4.8 Targeting Pack)
- MSBuild 16.x+ (Visual Studio 2019+ 自带)
- Rhino 7 SR35+ 或 Rhino 8

### 编译步骤

```bash
cd src/
dotnet restore AutoMake2D.csproj
dotnet build AutoMake2D.csproj -c Release
# 产物: src/bin/Release/net48/AutoMake2D.rhp
```

### 注意事项
- 编译前需将 3.0 版本的 `icon1.ico` 复制到 `src/` 目录
- TargetExt 已设为 `.rhp`，编译产物直接为 Rhino 插件格式
- 如使用 Visual Studio，可直接打开 `.csproj` 编译

## 新功能使用说明

### Creo 导入
1. 在 Creo 中将模型导出为 STEP 文件，保存到 `C:\Temp\creo_sync.step`
2. 在 AutoMake2D 面板顶部"Creo 导入"区域，确认文件路径
3. 点击"从 Creo 导入模型"按钮
4. 等待导入完成，状态显示"导入成功，共 N 个对象"
5. 导入与生成专利图是独立操作，用户自行决定何时生成

### 视图标注
1. 勾选"视图标注（各视图名称）"开关
2. 点击"生成专利图"正常生成
3. 各视图旁会自动出现中文名称标注（Patent_Annotation 图层）

## CreoImporter.py 对照

| 对比项 | CreoImporter.py | AutoMake2D 4.0 C# 实现 |
|--------|-----------------|----------------------|
| 语言 | Python | C# (RhinoCommon) |
| 集成方式 | 独立脚本 | 插件 UI 面板一键点击 |
| 文件路径 | 硬编码 | UI 可配置 |
| 导入后操作 | 无 | 仅反馈结果，不自动衔接 |
| 图层 | Creo_Live_Import | 相同 |
| 错误处理 | 弹窗 | 面板状态 + 日志 |

## 许可证

本项目源码仅供授权使用，未经许可不得分发。

## 4.1 相切边过滤改进

- HiddenLineDrawing 继续保留候选相切边，先由 Rhino 完成遮挡和轮廓分段。
- 通过 `SourceObjectComponentIndex` 回溯原始 `BrepEdge`。
- 对双面内部边在 5 个位置采样法线，按 1°/3° 双阈值识别精确及模糊相切边。
- 外轮廓、裸边、非流形边、硬边和无法可靠判断的边均保留。
- 删除旧版“圆弧或多段曲线即相切边”的二维猜测。
- 外轮廓与内部线分组融合，避免跨语义 Join。

## 4.1 fix3 filtering correction

The tangent filter is now conservative. It no longer removes every tangent edge. It suppresses only small projected tangent segments relative to the current view bounding-box diagonal. Exact tangent segments use a 6% limit; fuzzy tangent segments use a 1.5% limit. Silhouettes, naked edges, sharp edges, unknown edges, and long tangent structure lines remain preserved.

## fix4 说明
相切边过滤由“按 HLD 可见短片段长度”改为“按完整源 BrepEdge 投影总长度”。
同一条三维边被 HLD 拆成多个可见片段时，现在统一保留或统一删除，避免主结构线在遮挡交界处出现断口。


## fix5
Tangent suppression is evaluated on projected tangent-edge chains rather than isolated BrepEdges. This prevents long visual structure lines split by Creo/STEP topology from losing short intermediate edge pieces.


## fix6：红色审核图层

智能筛选命中的小圆角/相切候选线不再从输出中删除，而是写入 `Filtered_TangentEdges` 红色图层。用户可关闭图层查看最终线稿，或在复核后选择性删除图层中的对象。正式黑线仍位于 `Patent_Drawings_2D`。

## fix7 优化

- 保留 fix6 的三维 BrepEdge 法线/边链筛选。
- 新增二维“跨带短线”补充检测：识别两个端点分别贴近两条较长、局部近似平行曲线，且自身横跨窄带的短线。
- 补充识别结果标记为 `FilterReason=TwoDimensionalBridge`，仍只放入红色 `Filtered_TangentEdges` 审核图层，不自动删除。
- 外轮廓始终保护；已识别候选不会重复分类。

## fix8 渲染输出优化
- 强制使用 Rhino `Rendered` 显示模式，并打开曲面边缘、裸边、相切边和网格边显示。
- 关闭等参线，避免渲染图出现密集 UV 网格。
- 修正临时视口缩放：直接使用世界坐标模型包围盒，不再把变换后的包围盒错误传入视口。
- 每张渲染图自动裁除空白背景，物体在各自排版单元格中居中。
- 根据各视角投影世界尺寸采用统一比例尺，保持正投影视图之间尺寸关系一致。
- 六视图位置与线框排版一致：Right–Front–Left–Back 横排，Bottom 位于 Front 上方，Top 位于 Front 下方。


## 双框架构建（fix10）

项目现在同时构建：

- `net7.0-windows`：用于 Rhino 8 默认 .NET 运行时。
- `net48`：用于 Rhino 7，或 Rhino 8 的 .NET Framework 兼容模式。

在项目根目录运行：

```powershell
.\build-release.cmd
```

构建完成后优先从以下目录安装：

```text
dist\net7.0-windows\AutoMake2D.rhp
```

只有在 Rhino 7 或 Rhino 8 已切换到 .NET Framework 模式时，才使用：

```text
dist\net48\AutoMake2D.rhp
```

不要混装两个版本。更换版本前应关闭 Rhino，并在插件管理器中卸载旧路径。
