# AutoMake2D Rhino 7 / Rhino 8 独立构建

解压后无需进入子目录。请在本目录直接运行：

- `build-all.cmd`：同时编译 Rhino 7 与 Rhino 8
- `build-rhino7.cmd`：仅编译 Rhino 7（.NET Framework 4.8）
- `build-rhino8.cmd`：仅编译 Rhino 8（.NET 7）

输出文件：

- `dist\Rhino7\AutoMake2D.rhp`
- `dist\Rhino8\AutoMake2D.rhp`

所有脚本都会自动切换到脚本自身所在目录，因此可以从 PowerShell、CMD 或资源管理器双击运行。
