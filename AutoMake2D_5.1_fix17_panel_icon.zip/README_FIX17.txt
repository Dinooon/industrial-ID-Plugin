AutoMake2D 4.1 fix17 - panel icon fix

Changes:
- Give icon1.ico a fixed manifest logical name in both Rhino 7 and Rhino 8 projects.
- Add a fallback manifest-resource lookup for project-specific namespaces.
- Clone the System.Drawing.Icon before panel registration so its lifetime is independent of the resource stream.

Build:
  build-all.cmd

Outputs:
  dist\Rhino7\AutoMake2D.rhp
  dist\Rhino8\AutoMake2D.rhp
