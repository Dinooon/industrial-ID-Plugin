@echo off
setlocal
cd /d "%~dp0"
call "%~dp0build-rhino7.cmd"
if errorlevel 1 exit /b 1
call "%~dp0build-rhino8.cmd"
if errorlevel 1 exit /b 1
echo.
echo Both builds completed.
echo Rhino 7: dist\Rhino7\AutoMake2D.rhp
echo Rhino 8: dist\Rhino8\AutoMake2D.rhp
endlocal
