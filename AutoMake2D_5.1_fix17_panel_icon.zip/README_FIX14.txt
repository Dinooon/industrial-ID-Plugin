AutoMake2D 4.1 fix14 - Render framing and layout correction

Changes:
1. Render capture isolates only the objects selected in the current command.
2. Camera fitting uses the selected-object bounding box, not all visible document objects.
3. Capture explicitly uses the Rendered display-mode overload first to avoid wireframe fallback.
4. Rendered surface/tangent edges remain enabled with Rhino 7/8-compatible optional properties.
5. Content cropping ignores viewport background gradients so objects fill each layout cell.
6. Layout uses the same engineering-view order/alignment as the 2D line drawing and larger image occupancy.
7. PictureFrame uses an embedded, persistent image file. The image is no longer deleted after creation.
8. Rhino 7 and Rhino 8 remain separate build targets.

Build:
  build-all.cmd
or:
  build-rhino7.cmd
  build-rhino8.cmd

Outputs:
  dist\Rhino7\AutoMake2D.rhp
  dist\Rhino8\AutoMake2D.rhp
