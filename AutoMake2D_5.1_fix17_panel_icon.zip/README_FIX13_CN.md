# Fix13：Rhino 7 / Rhino 8 显示属性兼容修复

Rhino 7 的 `DisplayPipelineAttributes` 不公开部分 Rhino 8 属性：

- `ShowSurfaceEdge`
- `ShowSurfaceNakedEdge`
- `SurfaceEdgeColor`

本版将这些非共同 API 改为运行时能力检测；共同属性仍直接设置。这样 Rhino 7 与 Rhino 8 两个独立项目可以共用同一份源码。

解压后运行：

```powershell
.\build-all.cmd
```

输出：

- `dist\Rhino7\AutoMake2D.rhp`
- `dist\Rhino8\AutoMake2D.rhp`
