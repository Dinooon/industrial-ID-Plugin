@echo off
setlocal
cd /d "%~dp0"
where dotnet >nul 2>nul
if errorlevel 1 (
  echo [ERROR] dotnet SDK was not found.
  exit /b 1
)
echo Restoring Rhino 8 project...
dotnet restore "src\AutoMake2D.Rhino8.csproj"
if errorlevel 1 exit /b 1
echo Building Rhino 8 / .NET 7...
dotnet build "src\AutoMake2D.Rhino8.csproj" -c Release --no-restore
if errorlevel 1 exit /b 1
if exist "dist\Rhino8" rmdir /s /q "dist\Rhino8"
mkdir "dist\Rhino8"
copy /y "src\bin\Release\net7.0-windows\AutoMake2D.rhp" "dist\Rhino8\AutoMake2D.rhp" >nul
if errorlevel 1 (
  echo [ERROR] Rhino 8 output file was not found.
  exit /b 1
)
echo Done: dist\Rhino8\AutoMake2D.rhp
endlocal
