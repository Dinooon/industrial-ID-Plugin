using System;
using System.IO;
using Rhino;
using AutoMake2D.Common;

namespace AutoMake2D.PatentCore
{
    /// <summary>
    /// Rhino 选中对象导出结果。
    /// </summary>
    public class ExportResult
    {
        public bool Success { get; set; }
        public int ObjectCount { get; set; }
        public string FilePath { get; set; } = "";
        public string Message { get; set; } = "";
    }

    /// <summary>
    /// 将 Rhino 当前选中的物体导出为 STEP，供 Creo 后续导入。
    /// </summary>
    public static class CreoExporter
    {
        public static string DefaultExportFilePath = @"C:\Temp\rhino_to_creo.stp";

        public static ExportResult ExportSelected(string filePath)
        {
            var result = new ExportResult { FilePath = filePath ?? "" };

            try
            {
                RhinoDoc doc = RhinoDoc.ActiveDoc;
                if (doc == null)
                {
                    result.Message = "无活动 Rhino 文档。";
                    return result;
                }

                var selected = doc.Objects.GetSelectedObjects(false, false);
                int selectedCount = 0;
                foreach (var obj in selected)
                {
                    if (obj != null && !obj.IsDeleted)
                        selectedCount++;
                }

                if (selectedCount == 0)
                {
                    result.Message = "请先在 Rhino 中选择需要导出到 Creo 的物体。";
                    return result;
                }

                if (string.IsNullOrWhiteSpace(filePath))
                {
                    result.Message = "导出文件路径不能为空。";
                    return result;
                }

                string fullPath = Path.GetFullPath(filePath);
                string directory = Path.GetDirectoryName(fullPath) ?? "";
                if (!string.IsNullOrEmpty(directory))
                    Directory.CreateDirectory(directory);

                // 先删除旧文件，避免 Rhino 弹出覆盖确认窗口而中断自动流程。
                if (File.Exists(fullPath))
                    File.Delete(fullPath);

                // _Export 在已有选择集时仅导出选中对象；下划线保证中英文 Rhino 均可执行。
                string command = $"_-Export \"{fullPath}\" _Enter _Enter";
                bool commandSuccess = RhinoApp.RunScript(command, false);
                bool fileCreated = File.Exists(fullPath);

                result.Success = commandSuccess && fileCreated;
                result.ObjectCount = selectedCount;
                result.FilePath = fullPath;
                result.Message = result.Success
                    ? $"导出成功：{selectedCount} 个选中物体已保存到 {fullPath}"
                    : "STEP 导出失败，请检查对象类型、文件权限或 Rhino 命令行提示。";

                if (result.Success)
                {
                    Logger.Info($"Creo STEP 导出完成: {fullPath} | {selectedCount} objects");
                    RhinoApp.WriteLine("✅ " + result.Message);
                }
                else
                {
                    Logger.Warn(result.Message);
                }

                return result;
            }
            catch (Exception ex)
            {
                result.Success = false;
                result.Message = "导出失败: " + ex.Message;
                Logger.Error("Creo 导出异常", ex);
                return result;
            }
        }
    }
}
