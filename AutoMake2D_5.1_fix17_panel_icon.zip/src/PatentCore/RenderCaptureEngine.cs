using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using Rhino;
using Rhino.Display;
using Rhino.Geometry;

namespace AutoMake2D.PatentCore
{
    /// <summary>
    /// 渲染捕获引擎：使用 Rendered 显示模式、强制显示曲面边缘，
    /// 并按照线框视图相同的工程排版规则进行居中和等比例排版。
    /// </summary>
    public static class RenderCaptureEngine
    {
        public class RenderViewInfo
        {
            public string Name { get; set; } = "";
            public Plane Plane { get; set; }
            public double WorldWidth { get; set; }
            public double WorldHeight { get; set; }
        }

        public static List<RenderViewInfo> DetermineRenderViews(
            bool wantSix, bool wantIsoFront, bool wantIsoBack, bool wantCurrent,
            BoundingBox modelBox, RhinoView currentView)
        {
            var views = new List<RenderViewInfo>();
            Point3d center = modelBox.IsValid ? modelBox.Center : Point3d.Origin;

            Action<string, Plane> add = (name, plane) =>
            {
                var size = GetProjectedSize(modelBox, plane);
                views.Add(new RenderViewInfo
                {
                    Name = name,
                    Plane = plane,
                    WorldWidth = size.Item1,
                    WorldHeight = size.Item2
                });
            };

            if (wantSix)
            {
                add("Front", PatentProjector.GetViewPlane("Front", center));
                add("Top", PatentProjector.GetViewPlane("Top", center));
                add("Bottom", PatentProjector.GetViewPlane("Bottom", center));
                add("Left", PatentProjector.GetViewPlane("Left", center));
                add("Right", PatentProjector.GetViewPlane("Right", center));
                add("Back", PatentProjector.GetViewPlane("Back", center));
            }

            if (wantIsoFront)
                add("IsoFront", PatentProjector.GetIsoPlane(center, isFront: true, isDown: false));

            if (wantIsoBack)
                add("IsoBack", PatentProjector.GetIsoPlane(center, isFront: false, isDown: true));

            if (wantCurrent && currentView != null)
            {
                var vp = currentView.ActiveViewport;
                add("CurrentView", new Plane(center, vp.CameraX, vp.CameraY));
            }

            return views;
        }

        private static Tuple<double, double> GetProjectedSize(BoundingBox box, Plane plane)
        {
            if (!box.IsValid)
                return Tuple.Create(1.0, 1.0);

            Transform toView = Transform.PlaneToPlane(plane, Plane.WorldXY);
            BoundingBox projected = BoundingBox.Empty;
            foreach (Point3d corner in box.GetCorners())
            {
                Point3d p = corner;
                p.Transform(toView);
                projected.Union(p);
            }

            double width = Math.Max(projected.Max.X - projected.Min.X, RhinoMath.ZeroTolerance);
            double height = Math.Max(projected.Max.Y - projected.Min.Y, RhinoMath.ZeroTolerance);
            return Tuple.Create(width, height);
        }

        /// <summary>
        /// 在平行投影视口中使用 Rendered 模式捕获，并强制显示曲面边缘。
        /// </summary>
        public static Bitmap CaptureViewRender(
            RhinoDoc doc,
            Plane viewPlane,
            string viewName,
            Size imageSize,
            BoundingBox selectedModelBox)
        {
            Bitmap result = null;
            RhinoView tempView = null;

            try
            {
                tempView = doc.Views.Add(viewName, DefinedViewportProjection.Perspective,
                    new Rectangle(0, 0, imageSize.Width, imageSize.Height), false);

                if (tempView == null)
                {
                    RhinoApp.WriteLine($"⚠️ 无法创建临时视口 [{viewName}]，跳过渲染。");
                    return null;
                }

                RhinoViewport vp = tempView.ActiveViewport;
                vp.SetProjection(DefinedViewportProjection.Perspective, viewName, false);
                vp.ChangeToParallelProjection(true);

                Point3d target = viewPlane.Origin;
                BoundingBox modelBox = selectedModelBox.IsValid ? selectedModelBox : GetModelBoundingBox(doc);
                double diagonal = modelBox.IsValid ? modelBox.Diagonal.Length : 1.0;
                double cameraDistance = Math.Max(diagonal * 4.0, 100.0);
                vp.SetCameraLocation(target + viewPlane.ZAxis * cameraDistance, false);
                vp.SetCameraDirection(-viewPlane.ZAxis, false);
                vp.CameraUp = viewPlane.YAxis;
                vp.SetCameraTarget(target, true);

                // 只按用户本次选择对象的包围盒构图，避免文档内其他模型、旧输出线稿、
                // PictureFrame 或辅助对象把视图范围撑大。
                if (modelBox.IsValid)
                {
                    vp.ZoomBoundingBox(modelBox);
                    // ZoomBoundingBox 默认留白偏大；轻微放大，使物体占单图约 80%～90%。
                    TryMagnifyViewport(vp, 1.12);
                }

                DisplayModeDescription renderMode = DisplayModeDescription.FindByName("Rendered")
                    ?? DisplayModeDescription.FindByName("Shaded");

                if (renderMode != null)
                {
                    ConfigureRenderedEdges(renderMode);
                    vp.DisplayMode = renderMode;
                }

                tempView.Redraw();

                // 优先使用显式传入 DisplayModeDescription 的捕获重载。
                // 部分 Rhino 7/8 版本中 ViewCaptureSettings 会退回线框模式。
                if (renderMode != null)
                    result = tempView.CaptureToBitmap(imageSize, renderMode);

                if (result == null)
                {
                    var settings = new ViewCaptureSettings(tempView, imageSize, 96.0)
                    {
                        DrawGrid = false,
                        DrawAxis = false,
                        DrawBackground = true,
                        RasterMode = true
                    };
                    result = ViewCapture.CaptureToBitmap(settings);
                }

                // Rhino 7/8 的 Rendered 背景设置接口不完全一致。捕获后从画布边界
                // 对背景做连通区域替换，可稳定得到纯白背景，同时不改动物体内部灰色材质。
                if (result != null)
                    ForceWhiteBackground(result);

                return result;
            }
            catch (Exception ex)
            {
                RhinoApp.WriteLine($"⚠️ 渲染捕获 [{viewName}] 异常: {ex.Message}");
                return null;
            }
            finally
            {
                if (tempView != null)
                    tempView.Close();
            }
        }

        private static void TryMagnifyViewport(RhinoViewport viewport, double factor)
        {
            try
            {
                // Rhino 7/8 的公开成员存在差异，反射调用 Magnify，缺失时保持 ZoomBoundingBox 结果。
                var method = viewport.GetType().GetMethod("Magnify", new[] { typeof(double), typeof(bool) });
                if (method != null)
                {
                    method.Invoke(viewport, new object[] { factor, false });
                    return;
                }

                method = viewport.GetType().GetMethod("Magnify", new[] { typeof(double) });
                if (method != null)
                    method.Invoke(viewport, new object[] { factor });
            }
            catch { }
        }

        private static void ConfigureRenderedEdges(DisplayModeDescription mode)
        {
            try
            {
                DisplayPipelineAttributes a = mode.DisplayAttributes;
                a.ShadingEnabled = true;
                a.ShowSurfaceEdges = true;
                a.ShowTangentEdges = true;
                a.ShowTangentSeams = true;
                a.SurfaceEdgeThickness = 1;

                // Rhino 7 与 Rhino 8 的 DisplayPipelineAttributes API 不完全一致。
                // 以下属性只在部分 RhinoCommon 版本中公开，使用反射按能力设置，
                // 避免 Rhino 7 项目因编译期找不到成员而失败。
                TrySetDisplayAttribute(a, "ShowSurfaceEdge", true);
                TrySetDisplayAttribute(a, "ShowSurfaceNakedEdge", true);
                TrySetDisplayAttribute(a, "SurfaceEdgeColor", Color.Black);

                // Rendered 模式下专利图需要的是 Brep/曲面边缘。

                // 只显示真实曲面/多重曲面边缘，不显示密集的等参线。
                a.ShowIsoCurves = false;
            }
            catch (Exception ex)
            {
                RhinoApp.WriteLine($"⚠️ 设置渲染边缘显示失败，将继续使用 Rendered 默认设置: {ex.Message}");
            }
        }

        private static void TrySetDisplayAttribute(
            DisplayPipelineAttributes attributes,
            string propertyName,
            object value)
        {
            try
            {
                var property = attributes.GetType().GetProperty(propertyName);
                if (property == null || !property.CanWrite)
                    return;

                object convertedValue = value;
                if (value != null && !property.PropertyType.IsInstanceOfType(value))
                    convertedValue = Convert.ChangeType(value, property.PropertyType);

                property.SetValue(attributes, convertedValue, null);
            }
            catch
            {
                // 可选显示属性设置失败不应阻止插件输出渲染图。
            }
        }

        public static BoundingBox GetModelBoundingBox(RhinoDoc doc)
        {
            BoundingBox bbox = BoundingBox.Empty;
            foreach (var obj in doc.Objects)
            {
                if (obj == null || !obj.Visible) continue;
                GeometryBase geo = obj.Geometry;
                if (geo != null)
                    bbox.Union(geo.GetBoundingBox(true));
            }
            return bbox;
        }

        /// <summary>
        /// 使用与线框图相同的视图位置规则排版。每张图先自动裁除空白，
        /// 再按照模型的投影世界尺寸使用统一比例尺放入单元格并居中。
        /// </summary>
        public static Bitmap ComposeRenderLayout(
            Dictionary<string, Bitmap> viewBitmaps,
            IList<RenderViewInfo> viewInfos)
        {
            if (viewBitmaps == null || viewBitmaps.Count == 0)
                return null;

            var infoMap = new Dictionary<string, RenderViewInfo>(StringComparer.OrdinalIgnoreCase);
            if (viewInfos != null)
                foreach (RenderViewInfo info in viewInfos)
                    infoMap[info.Name] = info;

            var cropped = new Dictionary<string, Bitmap>(StringComparer.OrdinalIgnoreCase);
            foreach (var kvp in viewBitmaps)
                cropped[kvp.Key] = CropToObject(kvp.Value, 28);

            if (cropped.Count == 1)
            {
                foreach (Bitmap bmp in cropped.Values)
                    return PlaceSingleCentered(bmp);
            }

            // 紧凑工程排版：保持与线框图相同的视图相对位置，减少单元格空白和间距。
            const int cellW = 820;
            const int cellH = 600;
            const int gapX = 24;
            const int gapY = 20;

            double maxWorldW = 1.0;
            double maxWorldH = 1.0;
            foreach (var kvp in cropped)
            {
                RenderViewInfo info;
                if (infoMap.TryGetValue(kvp.Key, out info))
                {
                    maxWorldW = Math.Max(maxWorldW, info.WorldWidth);
                    maxWorldH = Math.Max(maxWorldH, info.WorldHeight);
                }
            }

            if (IsSixStandardViews(cropped))
            {
                var canvas = NewCanvas(4 * cellW + 3 * gapX, 3 * cellH + 2 * gapY);
                using (Graphics g = Graphics.FromImage(canvas))
                {
                    ConfigureGraphics(g);
                    int cx = cellW + gapX;
                    int cy = cellH + gapY;
                    DrawCell(g, cropped, infoMap, "Front", cx, cy, cellW, cellH, maxWorldW, maxWorldH);
                    // 与 LayoutComposer 的模型坐标排版一致：Top 在 Front 下方，Bottom 在上方。
                    // 图像坐标 Y 向下，因此 Top 使用更大的 Y。
                    DrawCell(g, cropped, infoMap, "Top", cx, cy + cellH + gapY, cellW, cellH, maxWorldW, maxWorldH);
                    DrawCell(g, cropped, infoMap, "Bottom", cx, cy - cellH - gapY, cellW, cellH, maxWorldW, maxWorldH);
                    DrawCell(g, cropped, infoMap, "Right", cx - cellW - gapX, cy, cellW, cellH, maxWorldW, maxWorldH);
                    DrawCell(g, cropped, infoMap, "Left", cx + cellW + gapX, cy, cellW, cellH, maxWorldW, maxWorldH);
                    DrawCell(g, cropped, infoMap, "Back", cx + 2 * (cellW + gapX), cy, cellW, cellH, maxWorldW, maxWorldH);
                }
                DisposeAll(cropped);
                Bitmap compact = TrimWhiteCanvas(canvas, 28);
                canvas.Dispose();
                return compact;
            }

            // 其他用户选择组合按 LayoutComposer 的同一优先顺序排列。
            string[] preferred = { "Right", "Front", "Left", "Back", "Bottom", "Top", "IsoFront", "IsoBack", "CurrentView" };
            var ordered = new List<string>();
            foreach (string name in preferred)
                if (cropped.ContainsKey(name)) ordered.Add(name);
            foreach (string name in cropped.Keys)
                if (!ordered.Contains(name)) ordered.Add(name);

            int cols = Math.Min(4, Math.Max(1, ordered.Count));
            int rows = (int)Math.Ceiling(ordered.Count / (double)cols);
            var generic = NewCanvas(cols * cellW + (cols - 1) * gapX, rows * cellH + (rows - 1) * gapY);
            using (Graphics g = Graphics.FromImage(generic))
            {
                ConfigureGraphics(g);
                for (int i = 0; i < ordered.Count; i++)
                {
                    int col = i % cols;
                    int row = i / cols;
                    DrawCell(g, cropped, infoMap, ordered[i], col * (cellW + gapX), row * (cellH + gapY),
                        cellW, cellH, maxWorldW, maxWorldH);
                }
            }
            DisposeAll(cropped);
            Bitmap compactGeneric = TrimWhiteCanvas(generic, 28);
            generic.Dispose();
            return compactGeneric;
        }

        private static bool IsSixStandardViews(Dictionary<string, Bitmap> images)
        {
            string[] required = { "Front", "Top", "Bottom", "Left", "Right", "Back" };
            foreach (string name in required)
                if (!images.ContainsKey(name)) return false;
            return images.Count == 6;
        }

        private static Bitmap NewCanvas(int width, int height)
        {
            var bitmap = new Bitmap(width, height);
            using (Graphics g = Graphics.FromImage(bitmap)) g.Clear(Color.White);
            return bitmap;
        }

        private static void ConfigureGraphics(Graphics g)
        {
            g.Clear(Color.White);
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;
            g.SmoothingMode = SmoothingMode.HighQuality;
        }

        private static void DrawCell(Graphics g,
            Dictionary<string, Bitmap> images,
            Dictionary<string, RenderViewInfo> infos,
            string name, int x, int y, int cellW, int cellH,
            double maxWorldW, double maxWorldH)
        {
            Bitmap bmp;
            if (!images.TryGetValue(name, out bmp) || bmp == null) return;

            double worldW = maxWorldW;
            double worldH = maxWorldH;
            RenderViewInfo info;
            if (infos.TryGetValue(name, out info))
            {
                worldW = Math.Max(info.WorldWidth, RhinoMath.ZeroTolerance);
                worldH = Math.Max(info.WorldHeight, RhinoMath.ZeroTolerance);
            }

            double commonScale = Math.Min(cellW * 0.98 / maxWorldW, cellH * 0.98 / maxWorldH);
            double targetW = Math.Max(1.0, worldW * commonScale);
            double targetH = Math.Max(1.0, worldH * commonScale);

            // 兼顾投影世界比例与实际裁剪图片宽高比，防止非正方像素式拉伸。
            double imageAspect = bmp.Width / (double)Math.Max(1, bmp.Height);
            double targetAspect = targetW / Math.Max(1.0, targetH);
            if (imageAspect > targetAspect)
                targetH = targetW / imageAspect;
            else
                targetW = targetH * imageAspect;

            float dx = (float)(x + (cellW - targetW) * 0.5);
            float dy = (float)(y + (cellH - targetH) * 0.5);
            g.DrawImage(bmp, dx, dy, (float)targetW, (float)targetH);
        }

        private static Bitmap CropToObject(Bitmap source, int padding)
        {
            if (source == null) return null;
            Rectangle bounds = FindContentBounds(source);
            if (bounds.Width <= 1 || bounds.Height <= 1)
                return new Bitmap(source);

            bounds.Inflate(padding, padding);
            bounds.Intersect(new Rectangle(0, 0, source.Width, source.Height));
            return source.Clone(bounds, source.PixelFormat);
        }

        private static Rectangle FindContentBounds(Bitmap bmp)
        {
            Color bg = AverageCornerColor(bmp);
            double bgLum = 0.299 * bg.R + 0.587 * bg.G + 0.114 * bg.B;
            int minX = bmp.Width, minY = bmp.Height, maxX = -1, maxY = -1;

            // Rendered 背景可能有渐变，不能仅按“与角点颜色不同”判断，否则整张灰色视口
            // 都会被当成内容。以明显深于背景的像素为主体，并辅以较大的颜色差。
            for (int y = 0; y < bmp.Height; y += 2)
            {
                for (int x = 0; x < bmp.Width; x += 2)
                {
                    Color c = bmp.GetPixel(x, y);
                    double lum = 0.299 * c.R + 0.587 * c.G + 0.114 * c.B;
                    int diff = Math.Abs(c.R - bg.R) + Math.Abs(c.G - bg.G) + Math.Abs(c.B - bg.B);
                    bool isForeground = lum < bgLum - 30.0 || diff > 105;
                    if (!isForeground) continue;

                    if (x < minX) minX = x;
                    if (x > maxX) maxX = x;
                    if (y < minY) minY = y;
                    if (y > maxY) maxY = y;
                }
            }

            if (maxX < minX || maxY < minY)
                return new Rectangle(0, 0, bmp.Width, bmp.Height);

            return Rectangle.FromLTRB(Math.Max(0, minX - 2), Math.Max(0, minY - 2),
                Math.Min(bmp.Width, maxX + 3), Math.Min(bmp.Height, maxY + 3));
        }

        private static Color AverageCornerColor(Bitmap bmp)
        {
            System.Drawing.Point[] points =
            {
                new System.Drawing.Point(2, 2),
                new System.Drawing.Point(Math.Max(0, bmp.Width - 3), 2),
                new System.Drawing.Point(2, Math.Max(0, bmp.Height - 3)),
                new System.Drawing.Point(Math.Max(0, bmp.Width - 3), Math.Max(0, bmp.Height - 3))
            };
            int r = 0, g = 0, b = 0;
            foreach (System.Drawing.Point p in points)
            {
                Color c = bmp.GetPixel(p.X, p.Y);
                r += c.R; g += c.G; b += c.B;
            }
            return Color.FromArgb(r / points.Length, g / points.Length, b / points.Length);
        }

        private static Bitmap PlaceSingleCentered(Bitmap source)
        {
            var canvas = NewCanvas(1100, 820);
            using (Graphics g = Graphics.FromImage(canvas))
            {
                ConfigureGraphics(g);
                double scale = Math.Min(1040.0 / source.Width, 760.0 / source.Height);
                int w = Math.Max(1, (int)Math.Round(source.Width * scale));
                int h = Math.Max(1, (int)Math.Round(source.Height * scale));
                g.DrawImage(source, (canvas.Width - w) / 2, (canvas.Height - h) / 2, w, h);
            }
            source.Dispose();
            return canvas;
        }


        private static void ForceWhiteBackground(Bitmap bitmap)
        {
            if (bitmap == null || bitmap.Width < 2 || bitmap.Height < 2) return;

            Color background = AverageCornerColor(bitmap);
            int width = bitmap.Width;
            int height = bitmap.Height;
            var visited = new bool[width * height];
            var queue = new Queue<System.Drawing.Point>();

            Action<int, int> enqueue = (x, y) =>
            {
                if (x < 0 || y < 0 || x >= width || y >= height) return;
                int index = y * width + x;
                if (visited[index]) return;
                visited[index] = true;
                queue.Enqueue(new System.Drawing.Point(x, y));
            };

            for (int x = 0; x < width; x++)
            {
                enqueue(x, 0);
                enqueue(x, height - 1);
            }
            for (int y = 0; y < height; y++)
            {
                enqueue(0, y);
                enqueue(width - 1, y);
            }

            while (queue.Count > 0)
            {
                System.Drawing.Point point = queue.Dequeue();
                Color current = bitmap.GetPixel(point.X, point.Y);
                if (!IsBackgroundPixel(current, background))
                    continue;

                bitmap.SetPixel(point.X, point.Y, Color.White);
                enqueue(point.X - 1, point.Y);
                enqueue(point.X + 1, point.Y);
                enqueue(point.X, point.Y - 1);
                enqueue(point.X, point.Y + 1);
            }
        }

        private static bool IsBackgroundPixel(Color color, Color background)
        {
            int maxChannelDifference = Math.Max(
                Math.Abs(color.R - background.R),
                Math.Max(Math.Abs(color.G - background.G), Math.Abs(color.B - background.B)));
            int chroma = Math.Max(color.R, Math.Max(color.G, color.B)) -
                         Math.Min(color.R, Math.Min(color.G, color.B));

            // 允许 Rendered 背景的轻微渐变和抗锯齿，但不会吞掉黄色选择高亮、
            // 黑色曲面边缘或与边界不连通的灰色实体材质。
            return maxChannelDifference <= 48 && chroma <= 24;
        }

        private static Bitmap TrimWhiteCanvas(Bitmap source, int padding)
        {
            if (source == null) return null;
            int minX = source.Width, minY = source.Height, maxX = -1, maxY = -1;

            for (int y = 0; y < source.Height; y += 2)
            {
                for (int x = 0; x < source.Width; x += 2)
                {
                    Color c = source.GetPixel(x, y);
                    if (c.R > 248 && c.G > 248 && c.B > 248) continue;
                    if (x < minX) minX = x;
                    if (x > maxX) maxX = x;
                    if (y < minY) minY = y;
                    if (y > maxY) maxY = y;
                }
            }

            if (maxX < minX || maxY < minY)
                return new Bitmap(source);

            Rectangle bounds = Rectangle.FromLTRB(
                Math.Max(0, minX - padding),
                Math.Max(0, minY - padding),
                Math.Min(source.Width, maxX + padding + 1),
                Math.Min(source.Height, maxY + padding + 1));
            return source.Clone(bounds, source.PixelFormat);
        }

        private static void DisposeAll(Dictionary<string, Bitmap> images)
        {
            foreach (Bitmap bmp in images.Values)
                if (bmp != null) bmp.Dispose();
        }
    }
}
