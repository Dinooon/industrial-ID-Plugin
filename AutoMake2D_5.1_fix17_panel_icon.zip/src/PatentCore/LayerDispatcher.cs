using System;
using System.Collections.Generic;
using Rhino;
using Rhino.Geometry;
using Rhino.DocObjects;

namespace AutoMake2D.PatentCore
{
    /// <summary>
    /// 图层分发模块 — 图层创建 + 曲线烘焙 + 分组管理
    /// 从 PatentCore.cs 提取，负责将投影后的曲线烘焙到 Rhino 文档
    /// </summary>
    public static class LayerDispatcher
    {
        /// <summary>
        /// 将投影后的曲线按零件分组烘焙到 Rhino 文档
        /// 外轮廓/结构线分发到不同图层
        /// </summary>
        public static void BakeToRhinoGrouped(RhinoDoc doc, Dictionary<string, Dictionary<string, List<Curve>>> viewsData)
        {
            string layerName = "Patent_Drawings_2D";
            var existingLayer = doc.Layers.FindName(layerName);
            int layerIndex = (existingLayer != null) ? existingLayer.Index : -1;

            if (layerIndex < 0)
            {
                var newLayer = new Layer { Name = layerName, Color = System.Drawing.Color.Black };
                layerIndex = doc.Layers.Add(newLayer);
            }

            string tangentLayerName = "TangentEdges";
            var existingTangentLayer = doc.Layers.FindName(tangentLayerName);
            int tangentLayerIndex = (existingTangentLayer != null) ? existingTangentLayer.Index : -1;

            if (tangentLayerIndex < 0)
            {
                var tangentLayer = new Layer { Name = tangentLayerName, Color = System.Drawing.Color.Blue };
                tangentLayerIndex = doc.Layers.Add(tangentLayer);
            }

            // 智能筛选命中的候选线不删除，统一放入红色审核图层。
            string filteredLayerName = "Filtered_TangentEdges";
            var existingFilteredLayer = doc.Layers.FindName(filteredLayerName);
            int filteredLayerIndex = (existingFilteredLayer != null) ? existingFilteredLayer.Index : -1;
            if (filteredLayerIndex < 0)
            {
                var filteredLayer = new Layer
                {
                    Name = filteredLayerName,
                    Color = System.Drawing.Color.Red
                };
                filteredLayerIndex = doc.Layers.Add(filteredLayer);
            }
            else if (existingFilteredLayer.Color != System.Drawing.Color.Red)
            {
                existingFilteredLayer.Color = System.Drawing.Color.Red;
                existingFilteredLayer.CommitChanges();
            }

            foreach (var kvpView in viewsData)
            {
                string viewName = kvpView.Key;
                foreach (var kvpComp in kvpView.Value)
                {
                    string componentName = kvpComp.Key;
                    List<Curve> curves = kvpComp.Value;
                    if (curves.Count == 0) continue;

                    string groupName = componentName + "_" + viewName;
                    int groupIndex = doc.Groups.Add(groupName);

                    foreach (var crv in curves)
                    {
                        bool isFilteredTangent = crv.GetUserString("IsFilteredTangent") == "true";
                        bool isTangent = crv.GetUserString("IsTangent") == "true";
                        int targetLayerIndex = isFilteredTangent
                            ? filteredLayerIndex
                            : (isTangent ? tangentLayerIndex : layerIndex);

                        var attributes = new ObjectAttributes { LayerIndex = targetLayerIndex };
                        attributes.AddToGroup(groupIndex);
                        doc.Objects.AddCurve(crv, attributes);
                    }
                }
            }
        }

        /// <summary>
        /// 创建或获取指定名称的图层
        /// </summary>
        public static int EnsureLayer(RhinoDoc doc, string name, System.Drawing.Color color)
        {
            var existing = doc.Layers.FindName(name);
            if (existing != null) return existing.Index;

            var layer = new Layer { Name = name, Color = color };
            return doc.Layers.Add(layer);
        }
    }
}
