using System;
using System.Collections.Generic;
using Rhino;
using Rhino.Geometry;
using Rhino.DocObjects;
using Rhino.Display;

namespace AutoMake2D.PatentCore
{
    /// <summary>
    /// 视图投影模块 — 视图平面计算 + HiddenLineDrawing 隐线计算引擎。
    /// 4.1：增加基于原始 Brep 拓扑与多点法线夹角的相切边过滤。
    /// fix7：在三维相切边识别之外增加二维“跨带短线”补充检测，减少 Creo/STEP 导入模型的漏筛。
    /// </summary>
    public static class PatentProjector
    {
        private const double ExactTangentAngleDegrees = 1.0;
        private const double FuzzyTangentAngleDegrees = 3.0;
        // 仅删除投影尺寸较小的相切片段。上一版直接删除全部相切边，会误删圆角两侧需要保留的主结构线。
        private const double ExactTangentMaxProjectedRatio = 0.045;
        private const double FuzzyTangentMaxProjectedRatio = 0.012;
        private static readonly double[] EdgeSamples = { 0.15, 0.35, 0.50, 0.65, 0.85 };

        private sealed class HldSourceTag
        {
            public HldSourceTag(int geometryIndex, string componentName, GeometryBase geometry)
            {
                GeometryIndex = geometryIndex;
                ComponentName = componentName ?? "未知组件";
                Geometry = geometry;
            }

            public int GeometryIndex { get; }
            public string ComponentName { get; }
            public GeometryBase Geometry { get; }

            public override string ToString() => ComponentName;
        }

        private enum EdgeSmoothness
        {
            Unknown,
            Naked,
            NonManifold,
            Sharp,
            FuzzyTangent,
            ExactTangent
        }

        public static Plane GetViewPlane(string name, Point3d origin)
        {
            name = name.Trim().ToLower();
            switch (name)
            {
                case "top": return new Plane(origin, Vector3d.XAxis, Vector3d.YAxis);
                case "bottom": return new Plane(origin, -Vector3d.XAxis, Vector3d.YAxis);
                case "front": return new Plane(origin, Vector3d.XAxis, Vector3d.ZAxis);
                case "back": return new Plane(origin, -Vector3d.XAxis, Vector3d.ZAxis);
                case "left": return new Plane(origin, -Vector3d.YAxis, Vector3d.ZAxis);
                case "right": return new Plane(origin, Vector3d.YAxis, Vector3d.ZAxis);
                default: return new Plane(origin, Vector3d.XAxis, Vector3d.YAxis);
            }
        }

        public static Plane GetIsoPlane(Point3d origin, bool isFront, bool isDown)
        {
            Vector3d normal;
            if (isFront)
            {
                normal = new Vector3d(1, -1, 1);
            }
            else
            {
                normal = isDown ? new Vector3d(-1, 1, -1) : new Vector3d(-1, 1, 1);
            }

            normal.Unitize();
            Vector3d planeX = Vector3d.CrossProduct(Vector3d.ZAxis, normal);
            planeX.Unitize();

            Vector3d planeY = Vector3d.CrossProduct(normal, planeX);
            planeY.Unitize();

            return new Plane(origin, planeX, planeY);
        }

        /// <summary>
        /// 对一组几何体执行单视图投影，返回按零件名分组的曲线集合。
        /// HLD 负责遮挡与轮廓；输出后利用 SourceObjectComponentIndex 回溯 BrepEdge，
        /// 对双面内部边执行多点法线夹角检测，过滤精确/模糊相切边。
        /// </summary>
        public static Dictionary<string, List<Curve>> ComputeSingleView(
            List<GeometryBase> geos, List<string> names, Plane viewPlane, double tolerance)
        {
            var rawGrouped = new Dictionary<string, List<Curve>>(StringComparer.OrdinalIgnoreCase);
            foreach (var name in names) rawGrouped[name] = new List<Curve>();

            // 保留全部候选线，让 Rhino 先完成可靠的可见性和轮廓分段；随后做 3D 语义过滤。
            var paramsHld = new HiddenLineDrawingParameters
            {
                AbsoluteTolerance = tolerance,
                IncludeHiddenCurves = false,
                IncludeTangentEdges = true,
                IncludeTangentSeams = true
            };

            Transform xformP2P = Transform.PlaneToPlane(viewPlane, Plane.WorldXY);
            BoundingBox transformedBbox = BoundingBox.Empty;

            for (int i = 0; i < geos.Count; i++)
            {
                string componentName = i < names.Count ? names[i] : $"组件_{i + 1}";
                paramsHld.AddGeometry(geos[i], xformP2P, new HldSourceTag(i, componentName, geos[i]));

                var dup = geos[i].Duplicate();
                dup.Transform(xformP2P);
                transformedBbox.Union(dup.GetBoundingBox(true));
            }

            var vp = new RhinoViewport();
            vp.ChangeToParallelProjection(true);
            double camZ = transformedBbox.IsValid ? transformedBbox.Max.Z + 1000 : 1000;
            vp.SetCameraLocation(new Point3d(0, 0, camZ), false);
            vp.SetCameraDirection(-Vector3d.ZAxis, false);
            vp.CameraUp = Vector3d.YAxis;
            vp.SetCameraTarget(Point3d.Origin, false);
            paramsHld.SetViewport(vp);

            double viewDiagonal = transformedBbox.IsValid ? transformedBbox.Diagonal.Length : 0.0;

            var hld = HiddenLineDrawing.Compute(paramsHld, true);
            if (hld != null)
            {
                // HLD 会把同一条三维边按遮挡关系切成多个短 segment。
                // 过滤决定必须基于完整源 BrepEdge，而不能基于单个 segment 的长度，
                // 否则长结构线在遮挡交界处的短片段会被误删，形成断线。
                var sourceEdgeSuppressionCache = new Dictionary<string, bool>();
                var sourceEdgeSmoothnessCache = new Dictionary<string, EdgeSmoothness>();
                // 同一条视觉主线在 STEP/Creo 拓扑中常被拆成多个短 BrepEdge。
                // 先按端点相接且投影切向连续建立“相切边链”，再用整条链的投影长度判断。
                var tangentChainLengthCache = new Dictionary<int, Dictionary<int, double>>();
                Transform xformFlatten = Transform.PlanarProjection(Plane.WorldXY);
                foreach (var seg in hld.Segments)
                {
                    if (seg == null || seg.CurveGeometry == null ||
                        seg.SegmentVisibility != HiddenLineDrawingSegment.Visibility.Visible)
                    {
                        continue;
                    }

                    string belongingComponent = "未知组件";
                    bool isOuterContour = seg.IsSceneSilhouette;
                    bool suppressAsTangent = false;
                    EdgeSmoothness smoothness = EdgeSmoothness.Unknown;

                    var hldCurve = seg.ParentCurve;
                    var hldObj = hldCurve?.SourceObject;
                    var sourceTag = hldObj?.Tag as HldSourceTag;

                    if (sourceTag != null)
                    {
                        belongingComponent = sourceTag.ComponentName;
                    }
                    else if (hldObj?.Tag != null)
                    {
                        belongingComponent = hldObj.Tag.ToString();
                    }

                    if (hldCurve != null)
                    {
                        // 双重保护：场景轮廓或 HLD 明确标识的投影/边界轮廓永不删除。
                        if (hldCurve.SilhouetteType == SilhouetteType.Projecting ||
                            hldCurve.SilhouetteType == SilhouetteType.Boundary)
                        {
                            isOuterContour = true;
                        }

                        if (!isOuterContour && sourceTag != null)
                        {
                            ComponentIndex sourceComponent = hldCurve.SourceObjectComponentIndex;
                            if (TryGetSourceBrepEdge(sourceTag.Geometry, sourceComponent, out Brep brep, out BrepEdge edge))
                            {
                                string edgeKey = sourceTag.GeometryIndex.ToString() + ":" + sourceComponent.Index.ToString();

                                if (!sourceEdgeSmoothnessCache.TryGetValue(edgeKey, out smoothness))
                                {
                                    smoothness = EvaluateEdgeSmoothness(brep, edge);
                                    sourceEdgeSmoothnessCache[edgeKey] = smoothness;
                                }

                                if (!sourceEdgeSuppressionCache.TryGetValue(edgeKey, out suppressAsTangent))
                                {
                                    if (!tangentChainLengthCache.TryGetValue(sourceTag.GeometryIndex, out Dictionary<int, double> chainLengths))
                                    {
                                        chainLengths = BuildTangentChainProjectedLengths(
                                            brep, xformP2P, sourceEdgeSmoothnessCache,
                                            sourceTag.GeometryIndex, tolerance);
                                        tangentChainLengthCache[sourceTag.GeometryIndex] = chainLengths;
                                    }

                                    double chainProjectedLength = 0.0;
                                    chainLengths.TryGetValue(sourceComponent.Index, out chainProjectedLength);

                                    suppressAsTangent = ShouldSuppressTangentEdge(
                                        edge, xformP2P, smoothness, viewDiagonal,
                                        chainProjectedLength, tolerance);
                                    sourceEdgeSuppressionCache[edgeKey] = suppressAsTangent;
                                }
                            }
                        }
                    }

                    // fix6：筛选命中的线不再丢弃。将其标记为审核候选，后续烘焙到红色图层，
                    // 用户可以目视复核后选择性删除。无法可靠判断的边仍按普通结构线保留。
                    if (!rawGrouped.ContainsKey(belongingComponent))
                    {
                        rawGrouped[belongingComponent] = new List<Curve>();
                    }

                    var crv = seg.CurveGeometry.DuplicateCurve();
                    crv.Transform(xformFlatten);

                    if (isOuterContour)
                    {
                        crv.SetUserString("IsOuter", "true");
                    }

                    if (suppressAsTangent)
                    {
                        crv.SetUserString("IsFilteredTangent", "true");
                        crv.SetUserString("FilterReason", "SmallTangentChain");
                    }

                    crv.SetUserString("EdgeSmoothness", smoothness.ToString());
                    rawGrouped[belongingComponent].Add(crv);
                }
            }

            var finalCleanedGrouped = new Dictionary<string, List<Curve>>(StringComparer.OrdinalIgnoreCase);
            foreach (var kvp in rawGrouped)
            {
                var list = kvp.Value;
                if (list.Count == 0) continue;

                list = CurveFusionEngine.CleanRawCurves(list, tolerance);

                // 第二层补充识别：有些 Creo/STEP 修剪边并不会被 Rhino 标记为相切边，
                // 但在二维投影中表现为横跨两条邻近、近似平行主线的短“桥接线”。
                // 这类线只进入红色审核图层，不自动删除。
                MarkTwoDimensionalBridgeCandidates(list, tolerance);

                var outerCurves = new List<Curve>();
                var innerCurves = new List<Curve>();
                var filteredCurves = new List<Curve>();
                foreach (var c in list)
                {
                    if (c.GetUserString("IsFilteredTangent") == "true") filteredCurves.Add(c);
                    else if (c.GetUserString("IsOuter") == "true") outerCurves.Add(c);
                    else innerCurves.Add(c);
                }

                // 三类曲线必须分别融合，防止红色候选线与正式黑线 Join 后丢失审核属性。
                outerCurves = JoinAndPropagate(outerCurves, tolerance, true);
                innerCurves = CurveFusionEngine.JoinTangentCurvesPrioritized(innerCurves, tolerance, 0.08);
                innerCurves = JoinAndPropagate(innerCurves, tolerance, false);
                filteredCurves = JoinAndPropagate(filteredCurves, tolerance, false);
                foreach (var curve in filteredCurves)
                {
                    curve.SetUserString("IsFilteredTangent", "true");
                    curve.SetUserString("FilterReason", "SmallTangentChain");
                }

                var finalList = new List<Curve>(outerCurves.Count + innerCurves.Count + filteredCurves.Count);
                finalList.AddRange(outerCurves);
                finalList.AddRange(innerCurves);
                finalList.AddRange(filteredCurves);
                finalCleanedGrouped[kvp.Key] = finalList;
            }

            return finalCleanedGrouped;
        }

        private static List<Curve> JoinAndPropagate(List<Curve> curves, double tolerance, bool markOuter)
        {
            if (curves.Count == 0) return curves;

            Curve[] joined = Curve.JoinCurves(curves, tolerance);
            if (joined == null) return curves;

            var result = new List<Curve>(joined.Length);
            foreach (var curve in joined)
            {
                CurveFusionEngine.PropagateUserStrings(curves.ToArray(), curve);
                if (markOuter) curve.SetUserString("IsOuter", "true");
                result.Add(curve);
            }
            return result;
        }



        /// <summary>
        /// 二维桥接线补充检测。目标是捕获三维拓扑/法线分类漏掉的短横线：
        /// 候选线的两个端点分别贴近两条较长曲线，两条支撑曲线局部近似平行，
        /// 且候选线总体方向与支撑线明显横交。只做审核标记，不删除。
        /// </summary>
        private static void MarkTwoDimensionalBridgeCandidates(List<Curve> curves, double tolerance)
        {
            if (curves == null || curves.Count < 3) return;

            BoundingBox bbox = BoundingBox.Empty;
            foreach (Curve curve in curves)
            {
                if (curve != null) bbox.Union(curve.GetBoundingBox(true));
            }
            if (!bbox.IsValid) return;

            double diagonal = bbox.Diagonal.Length;
            if (!RhinoMath.IsValidDouble(diagonal) || diagonal <= tolerance) return;

            // 审核层以召回率为优先，但仍限制为较小的跨带线。
            double maxCandidateLength = diagonal * 0.035;
            double endpointSearchDistance = Math.Max(tolerance * 12.0, diagonal * 0.0025);
            double parallelAngle = RhinoMath.ToRadians(18.0);
            double transverseAngle = RhinoMath.ToRadians(48.0);

            for (int i = 0; i < curves.Count; i++)
            {
                Curve candidate = curves[i];
                if (candidate == null) continue;
                if (candidate.GetUserString("IsOuter") == "true") continue;
                if (candidate.GetUserString("IsFilteredTangent") == "true") continue;

                double candidateLength = candidate.GetLength();
                if (!RhinoMath.IsValidDouble(candidateLength) ||
                    candidateLength <= tolerance || candidateLength > maxCandidateLength)
                {
                    continue;
                }

                // 排除高度回折或闭合的小环；桥接线通常接近直线或单调短弧。
                double chordLength = candidate.PointAtStart.DistanceTo(candidate.PointAtEnd);
                if (chordLength <= tolerance || chordLength / candidateLength < 0.72) continue;

                if (!TryFindBridgeSupport(curves, i, candidate.PointAtStart, candidateLength,
                        endpointSearchDistance, out int supportStart, out Vector3d tangentStart))
                {
                    continue;
                }

                if (!TryFindBridgeSupport(curves, i, candidate.PointAtEnd, candidateLength,
                        endpointSearchDistance, out int supportEnd, out Vector3d tangentEnd))
                {
                    continue;
                }

                if (supportStart == supportEnd) continue;

                double supportAngle = AcuteAngle(tangentStart, tangentEnd);
                if (!RhinoMath.IsValidDouble(supportAngle) || supportAngle > parallelAngle) continue;

                Vector3d bridgeDirection = candidate.PointAtEnd - candidate.PointAtStart;
                bridgeDirection.Z = 0.0;
                if (!bridgeDirection.Unitize()) continue;

                double crossStart = AcuteAngle(bridgeDirection, tangentStart);
                double crossEnd = AcuteAngle(bridgeDirection, tangentEnd);
                if (crossStart < transverseAngle || crossEnd < transverseAngle) continue;

                // 支撑曲线在候选端点附近必须确实位于不同位置，防止把同一主线的分段接缝误判。
                Point3d nearStart = ClosestPointOnCurve(curves[supportStart], candidate.PointAtStart);
                Point3d nearEnd = ClosestPointOnCurve(curves[supportEnd], candidate.PointAtEnd);
                double supportGap = nearStart.DistanceTo(nearEnd);
                if (supportGap <= tolerance) continue;

                double gapRatio = candidateLength / supportGap;
                if (gapRatio < 0.55 || gapRatio > 1.80) continue;

                candidate.SetUserString("IsFilteredTangent", "true");
                candidate.SetUserString("FilterReason", "TwoDimensionalBridge");
            }
        }

        private static bool TryFindBridgeSupport(
            List<Curve> curves,
            int candidateIndex,
            Point3d endpoint,
            double candidateLength,
            double searchDistance,
            out int supportIndex,
            out Vector3d supportTangent)
        {
            supportIndex = -1;
            supportTangent = Vector3d.Unset;
            double bestDistance = double.MaxValue;

            for (int j = 0; j < curves.Count; j++)
            {
                if (j == candidateIndex || curves[j] == null) continue;
                Curve support = curves[j];
                if (support.GetLength() < candidateLength * 1.8) continue;

                double t;
                if (!support.ClosestPoint(endpoint, out t, searchDistance)) continue;
                Point3d closest = support.PointAt(t);
                double distance = endpoint.DistanceTo(closest);
                if (distance > searchDistance || distance >= bestDistance) continue;

                Vector3d tangent = support.TangentAt(t);
                tangent.Z = 0.0;
                if (!tangent.Unitize()) continue;

                bestDistance = distance;
                supportIndex = j;
                supportTangent = tangent;
            }

            return supportIndex >= 0;
        }

        private static Point3d ClosestPointOnCurve(Curve curve, Point3d point)
        {
            if (curve != null && curve.ClosestPoint(point, out double t))
                return curve.PointAt(t);
            return point;
        }

        private static double AcuteAngle(Vector3d a, Vector3d b)
        {
            if (!a.Unitize() || !b.Unitize()) return double.NaN;
            double angle = Vector3d.VectorAngle(a, b);
            if (!RhinoMath.IsValidDouble(angle)) return double.NaN;
            return Math.Min(angle, Math.PI - angle);
        }

        /// <summary>
        /// 相切并不等于应删除。过滤尺度必须基于完整的源 BrepEdge，而不是 HLD segment。
        /// HLD 会在遮挡交界处把一条长边切成多个短片段；按 segment 长度删除会造成主线断裂。
        /// 这里将完整三维边投影到当前视图后计算总长度，同一源边的所有可见片段统一保留或统一压制。
        /// </summary>
        private static bool ShouldSuppressTangentEdge(
            BrepEdge sourceEdge,
            Transform projectionTransform,
            EdgeSmoothness smoothness,
            double viewDiagonal,
            double chainProjectedLength,
            double tolerance)
        {
            if (sourceEdge == null || viewDiagonal <= tolerance)
                return false;

            if (smoothness != EdgeSmoothness.ExactTangent &&
                smoothness != EdgeSmoothness.FuzzyTangent)
            {
                return false;
            }

            Curve projectedEdge = sourceEdge.DuplicateCurve();
            if (projectedEdge == null)
                return false;

            projectedEdge.Transform(projectionTransform);
            projectedEdge.Transform(Transform.PlanarProjection(Plane.WorldXY));

            double length = projectedEdge.GetLength();
            projectedEdge.Dispose();

            if (!RhinoMath.IsValidDouble(length) || length <= tolerance)
                return false;

            // 优先使用连续相切边链的总投影长度。单个 BrepEdge 长度仅作为无法建链时的保底。
            double effectiveLength = chainProjectedLength > tolerance ? chainProjectedLength : length;
            double ratio = effectiveLength / viewDiagonal;
            double threshold = smoothness == EdgeSmoothness.ExactTangent
                ? ExactTangentMaxProjectedRatio
                : FuzzyTangentMaxProjectedRatio;

            return ratio <= threshold;
        }


        /// <summary>
        /// 把端点相接、均为相切边且在当前视图中的切向连续的 BrepEdge 合并为视觉链。
        /// Creo/STEP 模型常在修剪面边界处把一条连续主线拆成多个 BrepEdge；
        /// 如果逐边按长度过滤，就会把主线中间的短拓扑片段误删。
        /// </summary>
        private static Dictionary<int, double> BuildTangentChainProjectedLengths(
            Brep brep,
            Transform projectionTransform,
            Dictionary<string, EdgeSmoothness> smoothnessCache,
            int geometryIndex,
            double tolerance)
        {
            var result = new Dictionary<int, double>();
            if (brep == null || brep.Edges.Count == 0) return result;

            int count = brep.Edges.Count;
            int[] parent = new int[count];
            double[] projectedLengths = new double[count];
            bool[] isTangent = new bool[count];
            for (int i = 0; i < count; i++) parent[i] = i;

            Func<int, int> find = null;
            find = x => parent[x] == x ? x : (parent[x] = find(parent[x]));
            Action<int, int> unite = (a, b) =>
            {
                int ra = find(a), rb = find(b);
                if (ra != rb) parent[rb] = ra;
            };

            for (int i = 0; i < count; i++)
            {
                BrepEdge edge = brep.Edges[i];
                string key = geometryIndex.ToString() + ":" + i.ToString();
                if (!smoothnessCache.TryGetValue(key, out EdgeSmoothness smoothness))
                {
                    smoothness = EvaluateEdgeSmoothness(brep, edge);
                    smoothnessCache[key] = smoothness;
                }

                isTangent[i] = smoothness == EdgeSmoothness.ExactTangent ||
                               smoothness == EdgeSmoothness.FuzzyTangent;
                if (!isTangent[i]) continue;

                Curve projected = edge.DuplicateCurve();
                if (projected == null) continue;
                projected.Transform(projectionTransform);
                projected.Transform(Transform.PlanarProjection(Plane.WorldXY));
                projectedLengths[i] = projected.GetLength();
                projected.Dispose();
            }

            // 通过共享 BrepVertex 建立候选连接；只合并投影切线基本共线的边。
            const double chainAngleDegrees = 12.0;
            double chainAngle = RhinoMath.ToRadians(chainAngleDegrees);
            foreach (BrepVertex vertex in brep.Vertices)
            {
                int[] edgeIndices = vertex.EdgeIndices();
                if (edgeIndices == null || edgeIndices.Length < 2) continue;

                for (int a = 0; a < edgeIndices.Length; a++)
                {
                    int ia = edgeIndices[a];
                    if (ia < 0 || ia >= count || !isTangent[ia]) continue;
                    for (int b = a + 1; b < edgeIndices.Length; b++)
                    {
                        int ib = edgeIndices[b];
                        if (ib < 0 || ib >= count || !isTangent[ib]) continue;

                        if (AreProjectedTangentsContinuousAtVertex(
                            brep.Edges[ia], brep.Edges[ib], vertex.Location,
                            projectionTransform, tolerance, chainAngle))
                        {
                            unite(ia, ib);
                        }
                    }
                }
            }

            var totals = new Dictionary<int, double>();
            for (int i = 0; i < count; i++)
            {
                if (!isTangent[i]) continue;
                int root = find(i);
                if (!totals.ContainsKey(root)) totals[root] = 0.0;
                totals[root] += projectedLengths[i];
            }

            for (int i = 0; i < count; i++)
            {
                if (!isTangent[i]) continue;
                int root = find(i);
                result[i] = totals.TryGetValue(root, out double total) ? total : projectedLengths[i];
            }

            return result;
        }

        private static bool AreProjectedTangentsContinuousAtVertex(
            BrepEdge edgeA,
            BrepEdge edgeB,
            Point3d vertexPoint,
            Transform projectionTransform,
            double tolerance,
            double maxAngle)
        {
            Vector3d tangentA = GetOutgoingProjectedTangent(edgeA, vertexPoint, projectionTransform, tolerance);
            Vector3d tangentB = GetOutgoingProjectedTangent(edgeB, vertexPoint, projectionTransform, tolerance);
            if (!tangentA.Unitize() || !tangentB.Unitize()) return false;

            // 两条边都从共享顶点向外，连续直线的方向应相反。
            double angle = Vector3d.VectorAngle(tangentA, -tangentB);
            return RhinoMath.IsValidDouble(angle) && angle <= maxAngle;
        }

        private static Vector3d GetOutgoingProjectedTangent(
            BrepEdge edge,
            Point3d vertexPoint,
            Transform projectionTransform,
            double tolerance)
        {
            bool atStart = edge.PointAtStart.DistanceTo(vertexPoint) <=
                           edge.PointAtEnd.DistanceTo(vertexPoint);
            Vector3d tangent = atStart ? edge.TangentAtStart : -edge.TangentAtEnd;
            tangent.Transform(projectionTransform);
            tangent.Z = 0.0;
            return tangent;
        }

        private static bool TryGetSourceBrepEdge(
            GeometryBase geometry,
            ComponentIndex componentIndex,
            out Brep brep,
            out BrepEdge edge)
        {
            brep = geometry as Brep;
            edge = null;

            if (brep == null || componentIndex.ComponentIndexType != ComponentIndexType.BrepEdge)
            {
                return false;
            }

            int index = componentIndex.Index;
            if (index < 0 || index >= brep.Edges.Count)
            {
                return false;
            }

            edge = brep.Edges[index];
            return edge != null;
        }

        private static EdgeSmoothness EvaluateEdgeSmoothness(Brep brep, BrepEdge edge)
        {
            int[] adjacentFaces = edge.AdjacentFaces();
            if (adjacentFaces == null || adjacentFaces.Length == 0)
                return EdgeSmoothness.Unknown;
            if (adjacentFaces.Length == 1)
                return EdgeSmoothness.Naked;
            if (adjacentFaces.Length != 2)
                return EdgeSmoothness.NonManifold;

            BrepFace face0 = brep.Faces[adjacentFaces[0]];
            BrepFace face1 = brep.Faces[adjacentFaces[1]];
            double maxAngle = 0.0;
            int validCount = 0;

            foreach (double normalizedParameter in EdgeSamples)
            {
                double edgeParameter = edge.Domain.ParameterAt(normalizedParameter);
                Point3d point = edge.PointAt(edgeParameter);

                double u0, v0, u1, v1;
                if (!face0.ClosestPoint(point, out u0, out v0) ||
                    !face1.ClosestPoint(point, out u1, out v1))
                {
                    continue;
                }

                Vector3d normal0 = face0.NormalAt(u0, v0);
                Vector3d normal1 = face1.NormalAt(u1, v1);
                if (!normal0.Unitize() || !normal1.Unitize())
                {
                    continue;
                }

                double angle = Vector3d.VectorAngle(normal0, normal1);
                if (double.IsNaN(angle)) continue;

                // 兼容导入模型中面方向反转，仅比较几何法线的最小夹角。
                angle = Math.Min(angle, Math.PI - angle);
                maxAngle = Math.Max(maxAngle, angle);
                validCount++;
            }

            if (validCount < 3)
                return EdgeSmoothness.Unknown;

            double exactThreshold = RhinoMath.ToRadians(ExactTangentAngleDegrees);
            double fuzzyThreshold = RhinoMath.ToRadians(FuzzyTangentAngleDegrees);

            if (maxAngle <= exactThreshold)
                return EdgeSmoothness.ExactTangent;
            if (maxAngle <= fuzzyThreshold)
                return EdgeSmoothness.FuzzyTangent;
            return EdgeSmoothness.Sharp;
        }
    }
}
