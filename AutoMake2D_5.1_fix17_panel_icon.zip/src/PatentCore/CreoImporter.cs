using System;
using System.IO;
using System.Collections.Generic;
using Rhino;
using Rhino.DocObjects;
using AutoMake2D.Common;

namespace AutoMake2D.PatentCore
{
    /// <summary>
    /// Creo 导入结果
    /// </summary>
    public class ImportResult
    {
        public bool Success { get; set; }
        public int ObjectCount { get; set; }
        public string Message { get; set; } = "";
    }

    /// <summary>
    /// Creo 文件导入模块 — 参照 CreoImporter.py 用 C# 重写
    /// 独立模块，不依赖 PatentCore，也不被 PatentCore 依赖
    /// 仅负责：清空旧模型 → 静默导入 STEP → 自动缩放 → 反馈结果
    /// </summary>
    public static class CreoImporter
    {
        /// <summary>
        /// 专用导入图层名
        /// </summary>
        public const string LayerName = "Creo_Live_Import";

        /// <summary>
        /// 默认中转文件路径
        /// </summary>
        public static string DefaultSyncFilePath = @"C:\Temp\creo_sync.stp";

        /// <summary>
        /// 执行导入：清空旧模型 → 静默导入 → 自动缩放
        /// 仅返回导入结果（成功/失败 + 消息），不与 PatentCore 交互
        /// </summary>
        public static ImportResult Import(string filePath)
        {
            var result = new ImportResult();

            try
            {
                // 1. 检查文件存在
                if (!File.Exists(filePath))
                {
                    result.Success = false;
                    result.Message = $"未找到同步文件: {filePath}，请先在 Creo 中导出。";
                    Logger.Warn(result.Message);
                    return result;
                }

                RhinoDoc doc = RhinoDoc.ActiveDoc;
                if (doc == null)
                {
                    result.Success = false;
                    result.Message = "无活动 Rhino 文档。";
                    return result;
                }

                // 2. 记录导入前的对象数量
                int beforeCount = doc.Objects.Count;

                // 3. 关闭屏幕重绘以加快运行速度
                doc.Views.RedrawEnabled = false;

                // 4. 确保专用图层存在（浅灰色）
                int layerIndex = EnsureImportLayer(doc);

                // 5. 清空该图层上的旧几何体，实现"刷新/更新"的效果
                int deletedCount = DeleteObjectsOnLayer(doc, LayerName);
                if (deletedCount > 0)
                {
                    Logger.Info($"已清空 {LayerName} 图层上的 {deletedCount} 个旧对象");
                }

                // 6. 切换到该图层作为当前工作图层
                doc.Layers.SetCurrentLayerIndex(layerIndex, true);

                // 7. 利用 Rhino 原生命令进行静默导入
                //    _-Import 用于跳过弹窗设置，全部默认
                string command = $"_-Import \"{filePath}\" _Enter";
                bool importSuccess = RhinoApp.RunScript(command, false);

                // 8. 恢复屏幕重绘
                doc.Views.RedrawEnabled = true;

                if (!importSuccess)
                {
                    result.Success = false;
                    result.Message = "导入命令执行失败，请检查文件格式是否正确。";
                    Logger.Error(result.Message);
                    return result;
                }

                // 9. 自动缩放视图
                RhinoApp.RunScript("_Zoom _All _Extents", false);

                // 10. 计算导入的对象数量
                int afterCount = doc.Objects.Count;
                int importedCount = afterCount - beforeCount;
                if (importedCount < 0) importedCount = 0;

                result.Success = true;
                result.ObjectCount = importedCount;
                result.Message = $"导入成功，共 {importedCount} 个对象。";

                Logger.Info($"Creo 模型导入完成: {filePath} | {result.Message}");
                RhinoApp.WriteLine($"✅ {result.Message}");

                return result;
            }
            catch (Exception ex)
            {
                result.Success = false;
                result.Message = $"导入失败: {ex.Message}";
                Logger.Error("Creo 导入异常", ex);

                // 确保恢复重绘
                try
                {
                    var activeDoc = RhinoDoc.ActiveDoc;
                    if (activeDoc != null)
                        activeDoc.Views.RedrawEnabled = true;
                }
                catch { }

                return result;
            }
        }

        /// <summary>
        /// 确保导入专用图层存在，返回图层索引
        /// </summary>
        private static int EnsureImportLayer(RhinoDoc doc)
        {
            var existingLayer = doc.Layers.FindName(LayerName);
            if (existingLayer != null)
                return existingLayer.Index;

            var newLayer = new Layer
            {
                Name = LayerName,
                Color = System.Drawing.Color.FromArgb(200, 200, 200) // 浅灰色
            };
            return doc.Layers.Add(newLayer);
        }

        /// <summary>
        /// 删除指定图层上的所有对象
        /// </summary>
        private static int DeleteObjectsOnLayer(RhinoDoc doc, string layerName)
        {
            int count = 0;
            var layer = doc.Layers.FindName(layerName);
            if (layer == null) return 0;

            int layerIdx = layer.Index;
            var toDelete = new List<Guid>();

            foreach (var obj in doc.Objects)
            {
                if (obj == null) continue;
                if (obj.Attributes.LayerIndex == layerIdx)
                {
                    toDelete.Add(obj.Id);
                }
            }

            foreach (var id in toDelete)
            {
                if (doc.Objects.Delete(id, true))
                    count++;
            }

            return count;
        }
    }
}
