using System;
using System.Threading.Tasks;
using Rhino.UI;
using AutoMake2D.PatentCore;
using AutoMake2D.Common;

// 强力别名锁定，彻底物理屏蔽 System.Windows.Forms 的命名空间污染
using Panel = Eto.Forms.Panel;
using Label = Eto.Forms.Label;
using RadioButton = Eto.Forms.RadioButton;
using CheckBox = Eto.Forms.CheckBox;
using Button = Eto.Forms.Button;
using TextBox = Eto.Forms.TextBox;
using ProgressBar = Eto.Forms.ProgressBar;
using DynamicLayout = Eto.Forms.DynamicLayout;
using TextAlignment = Eto.Forms.TextAlignment;
using Size = Eto.Drawing.Size;
using Padding = Eto.Drawing.Padding;
using Font = Eto.Drawing.Font;
using FontStyle = Eto.Drawing.FontStyle;
using Colors = Eto.Drawing.Colors;
using StackLayout = Eto.Forms.StackLayout;
using StackLayoutItem = Eto.Forms.StackLayoutItem;
using SaveFileDialog = Eto.Forms.SaveFileDialog;
using OpenFileDialog = Eto.Forms.OpenFileDialog;
using FileFilter = Eto.Forms.FileFilter;
using DialogResult = Eto.Forms.DialogResult;

namespace AutoMake2D
{
    [System.Runtime.InteropServices.Guid("8C2EFA41-B3D7-4982-A1E4-F6C7D8E9A0B2")]
    public class PatentUiPanel : Panel, IPanel
    {
        private Label _infoLabel;
        private Label _warningLabel;

        // Creo 导入功能区控件
        private TextBox _tbCreoSyncPath;
        private Button _btnCreoBrowse;
        private Button _btnCreoImport;
        private Button _btnCreoExportSelected;
        private Label _creoStatusLabel;

        // 精度选择
        private RadioButton _rbPrecisionHigh;
        private RadioButton _rbPrecisionMed;
        private RadioButton _rbPrecisionLow;

        // 视图模式
        private CheckBox _cbModeSix;
        private CheckBox _cbModeIsoFront;
        private CheckBox _cbModeIsoBack;
        private CheckBox _cbModeCurrent;

        // 渲染输出
        private CheckBox _cbRenderOutput;
        private TextBox _tbRenderPath;
        private Button _btnRenderBrowse;

        // 视图标注（可选）
        private CheckBox _cbAnnotation;

        private Button _generateBtn;

        private ProgressBar _progressBar;
        private Label _statusLabel;

        public static Guid PanelId
        {
            get { return typeof(PatentUiPanel).GUID; }
        }

        public PatentUiPanel()
        {
            _infoLabel = new Label
            {
                Text = "请配置参数后点击下方按钮生成图纸",
                TextAlignment = TextAlignment.Center
            };

            _warningLabel = new Label
            {
                Text = "温馨提示：尽量不要带内部看不到的零件一起生成，否则计算时间会很长！！",
                TextAlignment = TextAlignment.Center,
                TextColor = Colors.DarkOrange,
                Font = new Font("Arial", 8, FontStyle.None)
            };

            // ============================================================
            // Creo 导入功能区
            // ============================================================
            _tbCreoSyncPath = new TextBox
            {
                Text = CreoImporter.DefaultSyncFilePath
            };
            _btnCreoBrowse = new Button { Text = "浏览..." };
            _btnCreoBrowse.Click += OnCreoBrowseClick;

            _btnCreoImport = new Button { Text = "🔗 从 Creo 导入模型" };
            _btnCreoImport.Click += OnCreoImportClick;

            _btnCreoExportSelected = new Button { Text = "📤 导出选中物体到 Creo" };
            _btnCreoExportSelected.Click += OnCreoExportSelectedClick;

            _creoStatusLabel = new Label
            {
                Text = "等待导入...",
                TextAlignment = TextAlignment.Center,
                Font = new Font("Arial", 9)
            };

            // ============================================================
            // 精度选择
            // ============================================================
            _rbPrecisionHigh = new RadioButton { Text = "高精度 (0.001) - 保留极小细节" };
            _rbPrecisionMed = new RadioButton(_rbPrecisionHigh) { Text = "中精度 (0.01) - 推荐默认", Checked = true };
            _rbPrecisionLow = new RadioButton(_rbPrecisionHigh) { Text = "低精度 (0.1) - 仅大轮廓" };

            // ============================================================
            // 视图模式
            // ============================================================
            _cbModeSix = new CheckBox { Text = "标准工程六视图 (长对正/高平齐)", Checked = true };
            _cbModeIsoFront = new CheckBox { Text = "前45°轴测图 (立体正视角展示)", Checked = true };
            _cbModeIsoBack = new CheckBox { Text = "后45°轴测图 (底面正视角展示)", Checked = true };
            _cbModeCurrent = new CheckBox { Text = "当前视角线框图 (屏幕所见即所得)" };

            // ============================================================
            // 渲染输出
            // ============================================================
            _cbRenderOutput = new CheckBox { Text = "渲染输出（与视图模式联动）", Checked = false };
            _tbRenderPath = new TextBox
            {
                Text = System.IO.Path.Combine(
                    System.Environment.GetFolderPath(System.Environment.SpecialFolder.Desktop),
                    "AutoMake2D_Render.png")
            };
            _btnRenderBrowse = new Button { Text = "浏览..." };
            _btnRenderBrowse.Click += OnRenderBrowseClick;
            UpdateRenderPathEnabled();
            _cbRenderOutput.CheckedChanged += (s, e) => UpdateRenderPathEnabled();

            // ============================================================
            // 视图标注（可选，默认关闭）
            // ============================================================
            _cbAnnotation = new CheckBox { Text = "🏷 视图标注（各视图名称）", Checked = false };

            // ============================================================
            // 生成按钮
            // ============================================================
            _generateBtn = new Button { Text = "生成专利图" };
            _generateBtn.Click += OnGenerateClick;

            _progressBar = new ProgressBar { MinValue = 0, MaxValue = 100, Value = 0, Visible = false };
            _statusLabel = new Label { Text = "准备就绪...", TextAlignment = TextAlignment.Center, Visible = false, Font = new Font("Arial", 9) };

            // ============================================================
            // 布局
            // ============================================================
            var layout = new DynamicLayout { Spacing = new Size(5, 6), Padding = new Padding(12) };

            layout.AddRow(_infoLabel);
            layout.AddRow(_warningLabel);
            layout.AddRow(null);

            // Creo 导入功能区
            layout.AddRow(new Label { Text = "🔗 Creo 导入", Font = new Font("Arial", 9, FontStyle.Bold) });
            var creoPathRow = new StackLayout
            {
                Orientation = Eto.Forms.Orientation.Horizontal,
                Spacing = 5,
                Items = { new StackLayoutItem(_tbCreoSyncPath, true), _btnCreoBrowse }
            };
            layout.AddRow(creoPathRow);
            layout.AddRow(_btnCreoImport);
            layout.AddRow(_btnCreoExportSelected);
            layout.AddRow(_creoStatusLabel);
            layout.AddRow(null);

            // 分隔线
            layout.AddRow(new Label { Text = "══════════════════════════════════════", TextAlignment = TextAlignment.Center, Font = new Font("Arial", 8, FontStyle.None) });

            // 精度选择
            layout.AddRow(new Label { Text = "📐 过滤与融合公差精度：", Font = new Font("Arial", 9, FontStyle.Bold) });
            layout.AddRow(_rbPrecisionHigh);
            layout.AddRow(_rbPrecisionMed);
            layout.AddRow(_rbPrecisionLow);
            layout.AddRow(null);

            // 视图选择
            layout.AddRow(new Label { Text = "🖼 " + "需要视角选择 (支持多选)：", Font = new Font("Arial", 9, FontStyle.Bold) });
            layout.AddRow(_cbModeSix);
            layout.AddRow(_cbModeIsoFront);
            layout.AddRow(_cbModeIsoBack);
            layout.AddRow(_cbModeCurrent);
            layout.AddRow(null);

            // 渲染输出区域
            layout.AddRow(new Label { Text = "────────────────────────", TextAlignment = TextAlignment.Center, Font = new Font("Arial", 8, FontStyle.None) });
            layout.AddRow(_cbRenderOutput);
            layout.AddRow(new Label { Text = "渲染图保存路径（同时放入模型）:", Font = new Font("Arial", 9) });
            var renderPathRow = new StackLayout
            {
                Orientation = Eto.Forms.Orientation.Horizontal,
                Spacing = 5,
                Items = { new StackLayoutItem(_tbRenderPath, true), _btnRenderBrowse }
            };
            layout.AddRow(renderPathRow);
            layout.AddRow(null);

            // 视图标注
            layout.AddRow(_cbAnnotation);
            layout.AddRow(null);

            // 生成按钮
            layout.AddRow(_generateBtn);

            layout.AddRow(null);
            layout.AddRow(_progressBar);
            layout.AddRow(_statusLabel);

            Content = layout;
        }

        // ============================================================
        // Creo 导入按钮事件
        // ============================================================
        private void OnCreoImportClick(object sender, EventArgs e)
        {
            string filePath = _tbCreoSyncPath.Text ?? "";
            if (string.IsNullOrWhiteSpace(filePath))
            {
                _creoStatusLabel.Text = "⚠️ 请先设置同步文件路径！";
                return;
            }

            _btnCreoImport.Enabled = false;
            _creoStatusLabel.Text = "正在导入...";

            try
            {
                var result = CreoImporter.Import(filePath);
                _creoStatusLabel.Text = result.Message;
            }
            catch (Exception ex)
            {
                _creoStatusLabel.Text = $"❌ 导入异常: {ex.Message}";
                Logger.Error("Creo 导入异常", ex);
            }
            finally
            {
                _btnCreoImport.Enabled = true;
            }
        }


        // ============================================================
        // 导出选中物体到 Creo
        // ============================================================
        private void OnCreoExportSelectedClick(object sender, EventArgs e)
        {
            _btnCreoExportSelected.Enabled = false;
            _creoStatusLabel.Text = "正在导出选中物体...";

            try
            {
                var result = CreoExporter.ExportSelected(CreoExporter.DefaultExportFilePath);
                _creoStatusLabel.Text = result.Success
                    ? $"✅ 已导出到 {result.FilePath}"
                    : $"❌ {result.Message}";
            }
            catch (Exception ex)
            {
                _creoStatusLabel.Text = $"❌ 导出异常: {ex.Message}";
                Logger.Error("Creo 导出异常", ex);
            }
            finally
            {
                _btnCreoExportSelected.Enabled = true;
            }
        }

        private void OnCreoBrowseClick(object sender, EventArgs e)
        {
            var dialog = new OpenFileDialog();
            dialog.Filters.Add(new FileFilter("STEP 文件", ".step", ".stp"));
            dialog.Filters.Add(new FileFilter("所有文件", ".*"));
            if (!string.IsNullOrEmpty(_tbCreoSyncPath.Text))
            {
                try
                {
                    var dir = System.IO.Path.GetDirectoryName(_tbCreoSyncPath.Text);
                    if (!string.IsNullOrEmpty(dir) && System.IO.Directory.Exists(dir))
                        dialog.Directory = new Uri(dir + System.IO.Path.DirectorySeparatorChar);
                }
                catch { }
            }
            if (dialog.ShowDialog(this) == DialogResult.Ok)
                _tbCreoSyncPath.Text = dialog.FileName;
        }

        // ============================================================
        // 生成专利图按钮事件
        // ============================================================
        private async void OnGenerateClick(object sender, EventArgs e)
        {
            bool wantSix = _cbModeSix.Checked ?? false;
            bool wantIsoFront = _cbModeIsoFront.Checked ?? false;
            bool wantIsoBack = _cbModeIsoBack.Checked ?? false;
            bool wantCurrent = _cbModeCurrent.Checked ?? false;

            if (!wantSix && !wantIsoFront && !wantIsoBack && !wantCurrent)
            {
                Rhino.RhinoApp.WriteLine("⚠️ 请至少勾选一种需要输出的视图视角！");
                return;
            }

            bool wantRender = _cbRenderOutput.Checked ?? false;
            string renderPath = _tbRenderPath.Text ?? "";
            if (wantRender && string.IsNullOrWhiteSpace(renderPath))
            {
                Rhino.RhinoApp.WriteLine("⚠️ 已勾选渲染输出但未指定输出路径！");
                return;
            }

            bool wantAnnotation = _cbAnnotation.Checked ?? false;

            _generateBtn.Enabled = false;
            _progressBar.Visible = true;
            _statusLabel.Visible = true;
            _progressBar.Value = 0;
            _statusLabel.Text = "请在 Rhino 视口中框选模型...";

            try
            {
                double chosenTolerance = 0.01;
                if (_rbPrecisionHigh.Checked) chosenTolerance = 0.001;
                else if (_rbPrecisionLow.Checked) chosenTolerance = 0.1;

                var progress = new Progress<int>(v => _progressBar.Value = v);
                var status = new Progress<string>(s => _statusLabel.Text = s);

                await AutoMake2D.PatentCore.PatentCore.ExecuteAsync(wantSix, wantIsoFront, wantIsoBack, wantCurrent, chosenTolerance, wantRender, renderPath, progress, status, wantAnnotation);
            }
            catch (Exception ex)
            {
                Rhino.RhinoApp.WriteLine("运行发生异常: " + ex.Message);
                Logger.Error("生成专利图异常", ex);
            }
            finally
            {
                _generateBtn.Enabled = true;
                _progressBar.Visible = false;
                _statusLabel.Visible = false;
            }
        }

        public void PanelShown(uint documentSerialNumber, ShowPanelReason reason) { }
        public void PanelHidden(uint documentSerialNumber, ShowPanelReason reason) { }
        public void PanelClosing(uint documentSerialNumber, bool onCloseDocument) { }

        private void OnRenderBrowseClick(object sender, EventArgs e)
        {
            var dialog = new SaveFileDialog();
            dialog.Filters.Add(new FileFilter("PNG 图片", ".png"));
            if (!string.IsNullOrEmpty(_tbRenderPath.Text))
                dialog.FileName = System.IO.Path.GetFileName(_tbRenderPath.Text);
            if (dialog.ShowDialog(this) == DialogResult.Ok)
                _tbRenderPath.Text = dialog.FileName;
        }

        private void UpdateRenderPathEnabled()
        {
            bool enabled = _cbRenderOutput.Checked ?? false;
            _tbRenderPath.Enabled = enabled;
            _btnRenderBrowse.Enabled = enabled;
        }
    }
}
