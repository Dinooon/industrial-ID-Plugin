using System;
using System.IO;
using System.Reflection;
using Rhino;
using Rhino.PlugIns;
using Rhino.UI;
using AutoMake2D.Common;

[assembly: System.Runtime.InteropServices.Guid("1F4B3C5D-9E8A-42F1-B7D6-C4A5E8F9B0A1")]

namespace AutoMake2D
{
    public class AutoMake2DPlugin : PlugIn
    {
        public static AutoMake2DPlugin Instance { get; private set; } = null;

        private static Stream _gIconStream = null;
        private static System.Drawing.Icon _gPermanentIcon = null;

        public AutoMake2DPlugin()
        {
            Instance = this;
        }

        protected override LoadReturnCode OnLoad(ref string errorMessage)
        {
            try
            {
                var assembly = Assembly.GetExecutingAssembly();

                _gPermanentIcon = LoadPanelIcon(assembly);

                Panels.RegisterPanel(this, typeof(PatentUiPanel), "AutoMake2D_DJ", _gPermanentIcon);

                RhinoApp.Idle += RhinoApp_OnIdle;

                Logger.Info("AutoMake2D 4.1 插件已加载");
            }
            catch (Exception ex)
            {
                errorMessage = $"自动出图面板加载失败: {ex.Message}";
                return LoadReturnCode.ErrorShowDialog;
            }

            return LoadReturnCode.Success;
        }


        private static System.Drawing.Icon LoadPanelIcon(Assembly assembly)
        {
            // The default embedded-resource namespace differs between the
            // Rhino 7 and Rhino 8 project files. Prefer the fixed logical name,
            // then fall back to any manifest resource ending in icon1.ico.
            string resourceName = "AutoMake2D.icon1.ico";
            Stream stream = assembly.GetManifestResourceStream(resourceName);

            if (stream == null)
            {
                foreach (string name in assembly.GetManifestResourceNames())
                {
                    if (name.EndsWith("icon1.ico", StringComparison.OrdinalIgnoreCase))
                    {
                        resourceName = name;
                        stream = assembly.GetManifestResourceStream(name);
                        break;
                    }
                }
            }

            if (stream == null)
            {
                RhinoApp.WriteLine("[AutoMake2D] Panel icon resource was not found.");
                return null;
            }

            try
            {
                _gIconStream = stream;
                // Clone the icon so it remains valid even if Rhino later releases
                // or reloads the underlying manifest stream.
                using (var temporary = new System.Drawing.Icon(stream))
                {
                    return (System.Drawing.Icon)temporary.Clone();
                }
            }
            catch (Exception ex)
            {
                stream.Dispose();
                RhinoApp.WriteLine($"[AutoMake2D] Panel icon could not be loaded: {ex.Message}");
                return null;
            }
        }

        private void RhinoApp_OnIdle(object sender, EventArgs e)
        {
            RhinoApp.Idle -= RhinoApp_OnIdle;

            try
            {
                var targetPanelId = PatentUiPanel.PanelId;
                if (!Panels.IsPanelVisible(targetPanelId))
                {
                    Panels.OpenPanel(targetPanelId);
                }
            }
            catch (Exception ex)
            {
                RhinoApp.WriteLine($"[AutoMake2D] 延迟弹窗被安全拦截: {ex.Message}");
            }
        }
    }
}
