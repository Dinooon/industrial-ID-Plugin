# AutoMake2D 3.0

> Rhino 3D 专利图纸自动生成插件 — 从 3D 模型一键输出符合专利申请规范的 2D 线框图与渲染效果图

---

## 目录

- [项目概述](#项目概述)
- [功能特性](#功能特性)
- [技术栈](#技术栈)
- [安装与使用说明](#安装与使用说明)
- [本地编译指南](#本地编译指南)
- [最终源码文件清单](#最终源码文件清单)
- [V1–V8 修复历程概述](#v1v8-修复历程概述)
- [最终交付物清单](#最终交付物清单)

---

## 项目概述

**AutoMake2D** 是一款面向 **Rhino 3D** 的插件，专为专利工程师与专利律师设计。它将 Rhino 中的 3D 模型自动投影为符合工程制图规范（"长对正、高平齐"）的 **2D 线框图**与**渲染效果图**，特别针对专利申请图纸的需求优化。

核心能力：

- 从 3D 模型自动提取零部件的二维投影线框
- 按零件名称分组，支持多零件独立分层
- 生成标准工程六视图 + 轴测图 + 当前视角图
- 自动工程排版（防重叠矩阵布局）
- 外轮廓优先融合 + 碎线清洗，产出干净的专利级线稿
- 渲染模式输出 + 白色背景合成，满足专利申请图片规范

---

## 功能特性

### 线框图生成

| 功能 | 说明 |
|---|---|
| **多视图投影** | 支持标准工程六视图（前/后/上/下/左/右）、前 45° 轴测图、后 45° 轴测图、当前视角线框图 |
| **正切边缘线识别与分组** | 基于 `BrepEdge.EdgeConvexity == Tangent` 精确识别正切边缘线，独立分组处理 |
| **交叉处优先组合相切线** | 三阶段融合策略：正常线贪心合并 → 交叉节点相切线合并 → 全局贪心合并 |
| **外轮廓 / 结构线双层分发** | 外轮廓线烘焙到 `Patent_Silhouette` 图层（红色），内部结构线烘焙到 `Patent_Structure` 图层（黑色） |
| **曲线连续性保障** | JoinCurves 容差 ×50 + 角度容差 0.15 rad + 交叉验证 89° + CleanRawCurves 搜索半径 ×10 + 方向验证 |
| **凸包边界几何回退** | 当 `SilhouetteType` 不命中外轮廓标记时，通过凸包边界几何回退判定 IsOuter |
| **多零件独立分组** | 按零件名称自动分组，每个零件的线框独立分层烘焙到 Rhino 文档 |

### 渲染输出

| 功能 | 说明 |
|---|---|
| **视图联动渲染** | 渲染输出与线框视图模式联动，勾选哪些视图就渲染哪些视图 |
| **Rendered 渲染模式** | 使用 Rhino Rendered 显示模式输出真实渲染效果（含光照/阴影），非线框截图 |
| **曲面边缘线叠加** | 渲染图中叠加显示曲面结构线/锐利边缘线 |
| **纯白背景合成** | DrawBackground=false + 白底合成，确保专利申请用图背景为纯白 RGB(255,255,255) |
| **物件居中** | 自动居中 + 边距保护，物件在图片水平与垂直方向均居中显示 |
| **PictureFrame 嵌入** | 渲染图以 PictureFrame 形式嵌入 Rhino 文档（图片嵌入非外部引用），关闭重开文件仍可预览 |

### UI 面板

| 功能 | 说明 |
|---|---|
| **精度选择** | 高精度(0.001) / 中精度(0.01, 默认) / 低精度(0.1) |
| **视图模式勾选** | 六视图 / 轴测前 / 轴测后 / 当前视角，可任意组合 |
| **渲染输出开关** | 独立开关 + 输出路径配置（默认桌面） |
| **进度与状态** | 进度条 + 状态文字实时反馈 |
| **Rhino 命令** | 输入 `AutoMake2D` 命令可打开/关闭面板 |

---

## 技术栈

| 层面 | 技术 |
|---|---|
| **语言** | C# (LangVersion: latest) |
| **框架** | .NET Framework 4.8 (`net48`) |
| **宿主 SDK** | RhinoCommon 7.35 + RhinoWindows 7.35 |
| **UI 框架** | Eto.Forms（Rhino 原生支持的跨平台 UI 框架） |
| **几何引擎** | Rhino.Geometry — `HiddenLineDrawing` 隐线计算引擎 |
| **构建系统** | MSBuild / .NET SDK 风格 `.csproj` |
| **兼容性** | Rhino 7 SR35+ / Rhino 8 |

---

## 安装与使用说明

### 安装

1. 将编译产物 `AutoMake2D.rhp` 复制到本地任意目录
2. 打开 Rhino 7/8，执行菜单 **工具 → 选项 → 插件 → 安装**，选择 `.rhp` 文件
3. 重启 Rhino，插件自动加载并弹出 `AutoMake2D_DJ` 面板

> 也可直接将 `.rhp` 文件拖入 Rhino 窗口完成安装。

### 使用流程

```mermaid
flowchart LR
    A[打开 Rhino 模型] --> B[输入 AutoMake2D 命令<br/>或等待面板自动弹出]
    B --> C[配置参数]
    C --> D[勾选视图模式<br/>六视图/轴测/当前视角]
    D --> E[选择精度]
    E --> F{需要渲染输出?}
    F -- 是 --> G[勾选渲染输出<br/>设置保存路径]
    F -- 否 --> H[点击 生成专利图]
    G --> H
    H --> I[框选模型]
    I --> J[自动投影 + 分组 + 烘焙]
    J --> K[线框图输出到 Rhino 图层<br/>渲染图保存到指定路径]
```

#### 操作步骤

1. **打开面板**：在 Rhino 中输入命令 `AutoMake2D`，面板自动弹出
2. **配置参数**：
   - 选择精度（推荐中精度 0.01）
   - 勾选需要的视图模式（六视图 / 轴测前 / 轴测后 / 当前视角）
   - 如需渲染输出，勾选"渲染输出"并设置保存路径
3. **点击"生成专利图"**
4. **框选模型**：在 Rhino 视口中框选需要生成的 3D 物体
5. **等待生成**：进度条实时显示进度，状态文字反馈当前阶段
6. **查看结果**：
   - 线框图自动烘焙到 Rhino 文档的 `Patent_Silhouette` / `Patent_Structure` 图层
   - 渲染图保存到指定路径，同时以 PictureFrame 形式嵌入 Rhino 文档

> **提示**：尽量不要带内部看不到的零件一起生成，否则计算时间会很长。

---

## 本地编译指南

### 环境要求

| 依赖 | 版本 |
|---|---|
| .NET SDK | 含 .NET Framework 4.8 目标包 |
| MSBuild | 16.x+ (Visual Studio 2019+ 自带) |
| Rhino | 7 SR35+ 或 Rhino 8 |

### 编译步骤

```bash
# 1. 进入源码目录
cd src/

# 2. 还原 NuGet 包
dotnet restore AutoMake2D.csproj

# 3. 编译 (Release 模式)
dotnet build AutoMake2D.csproj -c Release

# 4. 编译产物位于
#    src/bin/Release/net48/AutoMake2D.rhp
```

### 注意事项

- 编译目标框架为 `net48`，需要系统安装 .NET Framework 4.8 Targeting Pack
- `TargetExt` 已设为 `.rhp`，编译产物直接为 Rhino 插件格式
- 图标资源 `icon1.ico` 已作为嵌入式资源包含在程序集中
- 如使用 Visual Studio，可直接打开解决方案文件编译

---

## 最终源码文件清单

| 文件 | 行数 | 说明 |
|---|---|---|
| `src/PatentCore.cs` | 1,355 | 核心引擎：视图投影、隐线计算、正切线识别、三阶段融合、曲线清洗、图层分发、渲染捕获与合成、PictureFrame 嵌入 |
| `src/PatentUiPanel.cs` | 214 | UI 面板：Eto.Forms 参数配置面板，含精度选择、视图模式勾选、渲染输出开关、进度条与状态反馈 |
| `src/AutoMake2DPlugin.cs` | 74 | 插件入口：`PlugIn` 子类，加载图标、注册面板、Idle 延迟弹窗 |
| `src/AutoMake2DCommand.cs` | 28 | 命令定义：`AutoMake2D` 命令，打开/关闭面板 |
| `src/AutoMake2D.csproj` | — | 项目配置：`net48` 目标框架、RhinoCommon 7.35 引用、`.rhp` 输出、图标嵌入 |
| `src/icon1.ico` | — | 插件图标 |

---

## V1–V8 修复历程概述

AutoMake2D 从初始版本到最终 3.0 版本经历了 **8 轮迭代修复**，下表概述每轮的核心问题与修复要点：

| 版本 | 核心问题 | 修复要点 |
|---|---|---|
| **V1 修复** (s6–s7) | 正切线未区分；交叉处垂直线被错误优先组合；渲染输出为场景截图非真正渲染 | 切换正切识别为 `BrepEdge.EdgeConvexity == Tangent`；实现三阶段融合策略（正常线→相切线→全局）；渲染改用 `CaptureToBitmap` + PictureFrame 嵌入 |
| **V2 修复** (s8) | 线框区分度不足（缺隐藏线图层）；PictureFrame 图片无法预览；渲染仍为线框且物件不居中 | 增加隐藏线红色图层；PictureFrame 嵌入图片（embedBitmap）；渲染模式切换 + 居中 |
| **V3 修复** (s13–s15) | 渲染图仍为线框模式；相切线未对标 Rhino 原生 Make2D；图片仍无法预览 | 重写 CaptureViewRender 视口设置顺序；HLD 阶段按 SilhouetteType 分离线段；嵌入图片到 Rhino 文档 |
| **V4 优化** (s22–s23) | 统一线宽；对标 Rhino 8 Make2D 正切线分组；版本升级 3.0 | 去除差异化线宽；对齐 Rhino 8 Make2D 的正切边缘线分组行为；版本号更新 |
| **V5 修复** (s25–s26) | 渲染物件未居中+缺曲面边缘线；轮廓线抓取不完整+线型分类过于复杂 | ZoomBoundingBox 修正 + 显示模式启用边缘线；简化为轮廓线+结构线双层分类 |
| **V6 修复** (s29–s30) | 分类效果退步（V5 误改检测层）；渲染图仍为着色模式非 Rendered | 恢复 s7 分类检测逻辑仅简化输出图层 4→2；渲染模式优先级改为 Rendered → Articulated → Shaded |
| **V7 修复** (s33–s35) | 渲染输出物件不居中；背景非白色（冷灰色） | 坐标空间匹配修正 + ZoomBoundingBox 居中 + 边距保护；DrawBackground=false + 白底合成逻辑 |
| **V8 修复** (s37–s39) | 背景仍非白色（DrawBackground 未生效）；Patent_Silhouette 图层无数据（IsOuter 从未触发+图层分发错误）；曲线多处断开（JoinCurves 容差过严） | DrawBackground=false + 白底合成 + 单视图白底 + DrawAt 预填充；凸包边界几何回退判定 IsOuter + 按 IsOuter 分发图层；JoinCurves 容差 ×50 + 角度容差 0.15rad + 交叉验证 89° + CleanRawCurves 搜索半径 ×10 + 方向验证 |

### 修复历程关键数据

```mermaid
timeline
    title AutoMake2D 迭代修复时间线
    section 初始开发
        V1 基础功能 : 线框分组 + 渲染输出
    section V1 修复
        正切线识别 : 三阶段融合策略
    section V2 修复
        线型区分 : 隐藏线图层 + 图片嵌入
    section V3 修复
        渲染模式 : 视口设置重写 + HLD 分离
    section V4 优化
        对标 Rhino 8 : 统一线宽 + 版本 3.0
    section V5 修复
        简化分类 : 轮廓线 + 结构线双层
    section V6 修复
        回退检测层 : 恢复 s7 分类逻辑
    section V7 修复
        白底居中 : DrawBackground + 坐标空间修正
    section V8 修复
        最终稳定 : 白底合成 + IsOuter 回退 + 容差放宽
```

---

## 最终交付物清单

| 交付物 | 路径 | 说明 |
|---|---|---|
| **编译插件** | `src/bin/Debug/net48/AutoMake2D.rhp` | V8 最终修复版，可直接安装到 Rhino 7/8 |
| **核心源码** | `src/PatentCore.cs` | 核心引擎（1,355 行） |
| **UI 面板源码** | `src/PatentUiPanel.cs` | Eto.Forms 面板（214 行） |
| **插件入口源码** | `src/AutoMake2DPlugin.cs` | PlugIn 子类（74 行） |
| **命令定义源码** | `src/AutoMake2DCommand.cs` | Rhino 命令（28 行） |
| **项目配置** | `src/AutoMake2D.csproj` | .NET SDK 风格项目文件 |
| **插件图标** | `src/icon1.ico` | 嵌入式图标资源 |
| **分析报告** | `AutoMake2D_分析报告.md` | 插件初始分析报告 |
| **V1 任务/执行计划** | `task-plan.md` / `execution-plan.md` | 初始开发计划 |
| **V1 修复计划** | `fix-task-plan.md` / `fix-execution-plan.md` | 第一轮修复 |
| **V2 修复计划** | `fix-task-plan-v2.md` | 第二轮修复 |
| **V3 修复计划** | `fix-task-plan-v3.md` | 第三轮修复 |
| **V4 优化计划** | — (合并在 V5 前置文档中) | 第四轮优化 |
| **V5 修复计划** | `fix-task-plan-v5.md` | 第五轮修复 |
| **V6 修复计划** | `fix-task-plan-v6.md` | 第六轮修复 |
| **V7 任务/执行计划** | `fix-task-plan-v7.md` / `fix-execution-plan-v7.md` | 第七轮修复 |
| **V8 任务/执行计划** | `fix-task-plan-v8.md` / `fix-execution-plan-v8.md` | 第八轮修复 |
| **Rhino 8 对比报告** | `rhino8-make2d-comparison-report.md` | Rhino 8 Make2D 对比调研报告 |

---

## 许可证

本项目源码仅供授权使用，未经许可不得分发。

---

*AutoMake2D 3.0 — 让专利图纸从三维到二维，一键完成。*
