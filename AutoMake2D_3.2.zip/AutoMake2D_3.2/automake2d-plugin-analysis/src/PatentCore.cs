﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using Rhino;
using Rhino.Geometry;
using Rhino.Input;
using Rhino.DocObjects;
using Rhino.Display;

namespace AutoMake2D
{
    public static class PatentCore
    {
        public static async Task ExecuteAsync(bool wantSix, bool wantIsoFront, bool wantIsoBack, bool wantCurrent, double tolerance, bool wantRender, string renderOutputPath, IProgress<int> progress, IProgress<string> status)
        {
            RhinoDoc doc = RhinoDoc.ActiveDoc;
            if (doc == null) return;

            var rc = RhinoGet.GetMultipleObjects("请框选需要生成零部件独立分组线框图的模型", true, ObjectType.Surface | ObjectType.PolysrfFilter | ObjectType.Mesh, out ObjRef[] objRefs);
            if (rc != Rhino.Commands.Result.Success || objRefs == null)
            {
                status?.Report("已取消选择。");
                return;
            }

            status?.Report("正在提取模型几何与零部件特征...");

            List<GeometryBase> pureGeos = new List<GeometryBase>();
            List<string> compNames = new List<string>();
            BoundingBox globalBbox = BoundingBox.Empty;

            for (int i = 0; i < objRefs.Length; i++)
            {
                var geo = objRefs[i].Geometry();
                if (geo != null)
                {
                    pureGeos.Add(geo);
                    globalBbox.Union(geo.GetBoundingBox(true));

                    var rhinoObj = objRefs[i].Object();
                    string name = rhinoObj != null ? rhinoObj.Attributes.Name : null;
                    if (string.IsNullOrEmpty(name)) name = "零件_" + (i + 1);
                    compNames.Add(name);
                }
            }

            if (pureGeos.Count == 0 || !globalBbox.IsValid) return;
            Point3d center = globalBbox.Center;

            var planesToGenerate = new Dictionary<string, Plane>(StringComparer.OrdinalIgnoreCase);

            if (wantSix)
            {
                planesToGenerate["Front"] = GetViewPlane("Front", center);
                planesToGenerate["Back"] = GetViewPlane("Back", center);
                planesToGenerate["Top"] = GetViewPlane("Top", center);
                planesToGenerate["Bottom"] = GetViewPlane("Bottom", center);
                planesToGenerate["Left"] = GetViewPlane("Left", center);
                planesToGenerate["Right"] = GetViewPlane("Right", center);
            }
            if (wantIsoFront) planesToGenerate["IsoFront"] = GetIsoPlane(center, isFront: true, isDown: false);
            if (wantIsoBack) planesToGenerate["IsoBack"] = GetIsoPlane(center, isFront: false, isDown: true);
            if (wantCurrent)
            {
                var activeView = doc.Views.ActiveView;
                if (activeView != null)
                {
                    var vp = activeView.ActiveViewport;
                    planesToGenerate["CurrentView"] = new Plane(center, vp.CameraX, vp.CameraY);
                }
            }

            int totalViews = planesToGenerate.Count;
            if (totalViews == 0) return;

            int completedViews = 0;
            var stopwatch = Stopwatch.StartNew();

            status?.Report("准备进入后台超算引擎...");

            var viewsData = await Task.Run(() =>
            {
                var data = new Dictionary<string, Dictionary<string, List<Curve>>>(StringComparer.OrdinalIgnoreCase);

                foreach (var kvp in planesToGenerate)
                {
                    string etaStr = "计算中...";
                    if (completedViews > 0)
                    {
                        long elapsedMs = stopwatch.ElapsedMilliseconds;
                        long avgMs = elapsedMs / completedViews;
                        long remainingTotalMs = avgMs * (totalViews - completedViews);
                        long remainingSecs = remainingTotalMs / 1000;

                        if (remainingSecs > 60)
                            etaStr = $"总共还需约 {remainingSecs / 60}分{remainingSecs % 60}秒";
                        else
                            etaStr = $"总共还需约 {remainingSecs} 秒";
                    }

                    status?.Report($"🔄 正在死磕计算 [{kvp.Key}] 视图 ({completedViews + 1}/{totalViews}) | {etaStr}");

                    var curvesGroupedByComp = ComputeSingleViewEngine(pureGeos, compNames, kvp.Value, tolerance);
                    data[kvp.Key] = curvesGroupedByComp;

                    completedViews++;
                    progress?.Report((int)((completedViews / (double)totalViews) * 100));
                }

                status?.Report("📐 所有视图计算完毕，正在进行二维矩阵防重叠左侧排版...");
                ArrangeEngineeringViewsGrouped(data);

                return data;
            });

            status?.Report("💾 正在按零件名称进行成组烘焙...");
            BakeToRhinoGrouped(doc, viewsData);
            doc.Views.Redraw();
            RhinoApp.WriteLine("✅ 零部件分层打组——左侧矩阵版专利图输出完毕！");

            // ============================================================
            // 【F2.4】渲染输出（视图联动模式）
            // wantRender=true 时，根据视图选择参数动态渲染对应视图并排版导出 PNG
            // ============================================================
            if (wantRender)
            {
                status?.Report("🎨 正在准备渲染输出...");

                RhinoView? currentView = doc.Views.ActiveView;
                var renderViews = DetermineRenderViews(wantSix, wantIsoFront, wantIsoBack, wantCurrent, globalBbox, currentView);

                if (renderViews.Count == 0)
                {
                    status?.Report("未选定任何视图模式，跳过渲染输出");
                    RhinoApp.WriteLine("⚠️ 渲染输出已勾选但未选定视图模式，跳过渲染。");
                }
                else
                {
                    status?.Report($"🎨 正在捕获 {renderViews.Count} 张渲染图...");

                    // 【FIX-3.2】临时隐藏线框图层，避免渲染图误截线框内容
                    var drawingLayer = doc.Layers.FindName("Patent_Drawings_2D");
                    var tangentLayer = doc.Layers.FindName("TangentEdges");
                    bool drawingLayerWasVisible = drawingLayer != null && drawingLayer.IsVisible;
                    bool tangentLayerWasVisible = tangentLayer != null && tangentLayer.IsVisible;

                    if (drawingLayer != null) drawingLayer.IsVisible = false;
                    if (tangentLayer != null) tangentLayer.IsVisible = false;
                    doc.Views.Redraw();

                    var renderBitmaps = new Dictionary<string, Bitmap>(StringComparer.OrdinalIgnoreCase);

                    try
                    {
                        for (int i = 0; i < renderViews.Count; i++)
                        {
                            var rv = renderViews[i];
                            status?.Report($"🎨 正在渲染 [{rv.Name}] 视图 ({i + 1}/{renderViews.Count})...");
                            progress?.Report((int)((i / (double)renderViews.Count) * 100));

                            Bitmap? bmp = CaptureViewRender(doc, rv.Plane, rv.Name, new Size(1200, 900));
                            if (bmp != null)
                                renderBitmaps[rv.Name] = bmp;
                        }
                    }
                    finally
                    {
                        // 【FIX-3.2】恢复线框图层可见性
                        if (drawingLayer != null) drawingLayer.IsVisible = drawingLayerWasVisible;
                        if (tangentLayer != null) tangentLayer.IsVisible = tangentLayerWasVisible;
                        doc.Views.Redraw();
                    }

                    if (renderBitmaps.Count > 0)
                    {
                        status?.Report($"📐 正在排版 {renderBitmaps.Count} 张渲染图...");
                        Bitmap? composed = ComposeRenderLayout(renderBitmaps);

                        if (composed != null)
                        {
                            status?.Report("💾 正在将渲染图放入模型...");
                            try
                            {
                                // 【FIX-3.3】渲染图以 PictureFrame 放入 Rhino 模型，同时保留 PNG 作为备份
                                // Step 1: 保存到临时文件（AddPictureFrame 需要文件路径）
                                string tempDir = Path.GetTempPath();
                                string tempRenderFile = Path.Combine(tempDir, $"AutoMake2D_Render_{Guid.NewGuid():N}.png");
                                composed.Save(tempRenderFile, ImageFormat.Png);

                                // Step 1.5: 同时保存到用户指定的输出路径（备份）
                                try
                                {
                                    string dir = Path.GetDirectoryName(renderOutputPath);
                                    if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                                        Directory.CreateDirectory(dir);
                                    composed.Save(renderOutputPath, ImageFormat.Png);
                                }
                                catch { /* 外部保存失败不影响模型内放置 */ }

                                // Step 2: 计算 PictureFrame 放置位置（线框排版区域右侧）
                                BoundingBox modelBbox = globalBbox;
                                double offsetX = modelBbox.IsValid ? modelBbox.Max.X + modelBbox.Diagonal.Length * 0.3 : 100;
                                double offsetY = 0;
                                double offsetZ = 0;

                                double aspectRatio = (double)composed.Width / composed.Height;
                                double frameHeight = modelBbox.IsValid ? modelBbox.Diagonal.Length * 0.8 : 100;
                                double frameWidth = frameHeight * aspectRatio;

                                var framePlane = new Plane(
                                    new Point3d(offsetX, offsetY, offsetZ),
                                    Vector3d.XAxis, Vector3d.YAxis);

                                // Step 3: 创建 PictureFrame 并放入专用图层
                                var pictureFrameId = doc.Objects.AddPictureFrame(framePlane, tempRenderFile, false, frameWidth, frameHeight, false, false);

                                if (pictureFrameId != Guid.Empty)
                                {
                                    var renderLayer = doc.Layers.FindName("Patent_Render");
                                    int renderLayerIndex;
                                    if (renderLayer == null)
                                    {
                                        renderLayerIndex = doc.Layers.Add(new Layer
                                        {
                                            Name = "Patent_Render",
                                            Color = System.Drawing.Color.LightGray
                                        });
                                    }
                                    else
                                    {
                                        renderLayerIndex = renderLayer.Index;
                                    }

                                    var pfObj = doc.Objects.FindId(pictureFrameId);
                                    if (pfObj != null)
                                    {
                                        var attrs = pfObj.Attributes.Duplicate();
                                        attrs.LayerIndex = renderLayerIndex;
                                        doc.Objects.ModifyAttributes(pfObj, attrs, false);
                                    }

                                    status?.Report($"✅ 渲染图已放入模型 (Patent_Render 图层)");
                                    RhinoApp.WriteLine($"✅ 渲染图已放入模型 (Patent_Render 图层)，同时保存至: {renderOutputPath}");
                                }
                                else
                                {
                                    status?.Report($"⚠️ PictureFrame 创建失败，渲染图仅保存为外部文件: {renderOutputPath}");
                                    RhinoApp.WriteLine($"⚠️ PictureFrame 创建失败，渲染图已保存至: {renderOutputPath}");
                                }

                                // Step 4: 清理临时文件
                                try { if (File.Exists(tempRenderFile)) File.Delete(tempRenderFile); } catch { }
                            }
                            catch (Exception ex)
                            {
                                status?.Report($"❌ 渲染图输出失败: {ex.Message}");
                                RhinoApp.WriteLine("❌ 渲染图输出失败: " + ex.Message);
                            }
                        }
                    }
                    else
                    {
                        status?.Report("⚠️ 渲染捕获未获得任何位图，跳过输出");
                        RhinoApp.WriteLine("⚠️ 渲染捕获未获得任何位图，跳过输出");
                    }
                }
            }
        }

        private static Plane GetIsoPlane(Point3d origin, bool isFront, bool isDown)
        {
            Vector3d normal;
            if (isFront)
            {
                normal = new Vector3d(1, -1, 1);
            }
            else
            {
                normal = isDown ? new Vector3d(-1, 1, -1) : new Vector3d(-1, 1, 1);
            }

            normal.Unitize();
            Vector3d planeX = Vector3d.CrossProduct(Vector3d.ZAxis, normal);
            planeX.Unitize();

            Vector3d planeY = Vector3d.CrossProduct(normal, planeX);
            planeY.Unitize();

            return new Plane(origin, planeX, planeY);
        }

        private static Dictionary<string, List<Curve>> ComputeSingleViewEngine(List<GeometryBase> geos, List<string> names, Plane viewPlane, double tolerance)
        {
            var rawGrouped = new Dictionary<string, List<Curve>>(StringComparer.OrdinalIgnoreCase);
            foreach (var name in names) rawGrouped[name] = new List<Curve>();

            var paramsHld = new HiddenLineDrawingParameters
            {
                AbsoluteTolerance = tolerance,
                IncludeHiddenCurves = false,
                IncludeTangentEdges = true,
                IncludeTangentSeams = true
            };

            Transform xformP2P = Transform.PlaneToPlane(viewPlane, Plane.WorldXY);
            BoundingBox transformedBbox = BoundingBox.Empty;

            for (int i = 0; i < geos.Count; i++)
            {
                paramsHld.AddGeometry(geos[i], xformP2P, names[i]);
                var dup = geos[i].Duplicate();
                dup.Transform(xformP2P);
                transformedBbox.Union(dup.GetBoundingBox(true));
            }

            var vp = new Rhino.Display.RhinoViewport();
            vp.ChangeToParallelProjection(true);
            double camZ = transformedBbox.IsValid ? transformedBbox.Max.Z + 1000 : 1000;
            vp.SetCameraLocation(new Point3d(0, 0, camZ), false);
            vp.SetCameraDirection(-Vector3d.ZAxis, false);
            vp.CameraUp = Vector3d.YAxis;
            vp.SetCameraTarget(Point3d.Origin, false);
            paramsHld.SetViewport(vp);

            var hld = HiddenLineDrawing.Compute(paramsHld, true);
            if (hld != null)
            {
                Transform xformFlatten = Transform.PlanarProjection(Plane.WorldXY);
                foreach (var seg in hld.Segments)
                {
                    if (seg != null && seg.CurveGeometry != null && seg.SegmentVisibility == HiddenLineDrawingSegment.Visibility.Visible)
                    {
                        string belongingComponent = "未知组件";
                        bool isOuterContour = false;
                        bool isTangentEdge = false;

                        var hldCurve = seg.ParentCurve;
                        if (hldCurve != null)
                        {
                            var hldObj = hldCurve.SourceObject;
                            if (hldObj != null && hldObj.Tag != null)
                            {
                                belongingComponent = hldObj.Tag.ToString();
                            }

                            // 外轮廓判定：投影最外轮廓或裸露边界
                            if (hldCurve.SilhouetteType == SilhouetteType.Projecting ||
                                hldCurve.SilhouetteType == SilhouetteType.Boundary)
                            {
                                isOuterContour = true;
                            }

                            // ============================================================
                            // 【F1.1】正切边缘识别 (Tangent Edge Detection)
                            // ============================================================
                            // 【FIX-1.1】正切边缘识别 — 方案B：SilhouetteType 精确判定 + 双重验证
                            //
                            // 原方案A仅检查 SilhouetteType.None，过于宽泛，导致大量非正切
                            // 内部投影线段被误标记为正切线。
                            //
                            // 方案B改进：SilhouetteType 枚举本身包含 Tangent 和
                            // NonSilhouetteTangent 成员，可直接精确识别正切边缘。
                            // 对 SilhouetteType.None 的段，附加几何特征双重验证
                            // （弧线且曲率连续），避免误标记。
                            //
                            // 注：BrepEdge.EdgeConvexity 在 RhinoCommon 7.35 中不存在，
                            // 故不使用该 API，改用 SilhouetteType 枚举精确值。
                            // ============================================================
                            if (!isOuterContour)
                            {
                                var st = hldCurve.SilhouetteType;

                                // 主判据：SilhouetteType 为 Tangent 或 NonSilhouetteTangent
                                if (st == SilhouetteType.Tangent ||
                                    st == SilhouetteType.NonSilhouetteTangent)
                                {
                                    isTangentEdge = true;
                                }
                                // 回退双重验证：SilhouetteType.None 且曲线为弧线/多跨度
                                // （正切边缘通常是弧线且曲率连续）
                                else if (st == SilhouetteType.None)
                                {
                                    var crvGeom = seg.CurveGeometry;
                                    if (crvGeom != null &&
                                        (crvGeom.IsArc() || crvGeom.SpanCount > 1))
                                    {
                                        isTangentEdge = true;
                                    }
                                }
                            }
                        }

                        if (!rawGrouped.ContainsKey(belongingComponent))
                        {
                            rawGrouped[belongingComponent] = new List<Curve>();
                        }

                        var crv = seg.CurveGeometry.DuplicateCurve();
                        crv.Transform(xformFlatten);

                        // 为提取的线段打上语义标记
                        if (isOuterContour)
                        {
                            crv.SetUserString("IsOuter", "true");
                        }
                        // 【F1.2】正切边缘分组标记 — 数据随曲线对象传播
                        if (isTangentEdge)
                        {
                            crv.SetUserString("IsTangent", "true");
                        }

                        rawGrouped[belongingComponent].Add(crv);
                    }
                }
            }

            var finalCleanedGrouped = new Dictionary<string, List<Curve>>(StringComparer.OrdinalIgnoreCase);
            foreach (var kvp in rawGrouped)
            {
                var list = kvp.Value;
                if (list.Count == 0) continue;

                // Step 1: 物理去重和微小碎线清洗
                list = CleanRawCurves(list, tolerance);

                // ========================================================
                // 【新增 Step 1.5】：外轮廓特权隔离与优先独立组合
                // ========================================================
                List<Curve> outerCurves = new List<Curve>();
                List<Curve> innerCurves = new List<Curve>();
                foreach (var c in list)
                {
                    // 根据基因烙印分流
                    if (c.GetUserString("IsOuter") == "true") outerCurves.Add(c);
                    else innerCurves.Add(c);
                }

                // 仅对外轮廓进行独立闭环组合，杜绝内部相交线抢夺端点
                var joinedOuter = Curve.JoinCurves(outerCurves, tolerance);
                List<Curve> nextPool = new List<Curve>();

                if (joinedOuter != null)
                {
                    foreach (var jo in joinedOuter)
                    {
                        // 继承语义标记
                        PropagateUserStrings(outerCurves.ToArray(), jo);
                        jo.SetUserString("IsOuter", "true");
                        nextPool.Add(jo);
                    }
                }
                else
                {
                    nextPool.AddRange(outerCurves);
                }

                // 将内部线放回池子中，与已经“固若金汤”的外轮廓一起进入后续处理
                nextPool.AddRange(innerCurves);
                list = nextPool;

                // Step 2: 整体线组送入相切优先融合（此时外边界已经是一体的了，内部线只能依附）
                list = JoinTangentCurvesPrioritized(list, tolerance, 0.08);

                // Step 3: 常规直角与死角闭合
                var joinedArray = Curve.JoinCurves(list, tolerance);

                if (joinedArray != null)
                {
                    // 传播语义标记到最终闭合的曲线
                    var finalList = new List<Curve>();
                    foreach (var jc in joinedArray)
                    {
                        PropagateUserStrings(list.ToArray(), jc);
                        finalList.Add(jc);
                    }
                    finalCleanedGrouped[kvp.Key] = finalList;
                }
                else
                {
                    finalCleanedGrouped[kvp.Key] = list;
                }
            }

            return finalCleanedGrouped;
        }

        private static List<Curve> CleanRawCurves(List<Curve> curves, double tolerance)
        {
            if (curves.Count == 0) return curves;
            List<Curve> validCurves = new List<Curve>();
            foreach (var c in curves) { if (c != null && c.GetLength() > 0.0001) validCurves.Add(c); }

            List<Curve> cleaned = new List<Curve>();
            RTree tree = new RTree();

            for (int i = 0; i < validCurves.Count; i++)
            {
                var c1 = validCurves[i];
                double len1 = c1.GetLength();
                Point3d midPt1 = c1.PointAtNormalizedLength(0.5);
                bool isDup = false;
                List<int> neighbors = new List<int>();

                tree.Search(new Sphere(midPt1, tolerance * 0.5), (sender, args) => { neighbors.Add(args.Id); });

                foreach (int j in neighbors)
                {
                    var c2 = cleaned[j];
                    if (Math.Abs(len1 - c2.GetLength()) > tolerance) continue;

                    double dFwd = c1.PointAtStart.DistanceTo(c2.PointAtStart) + c1.PointAtEnd.DistanceTo(c2.PointAtEnd);
                    double dRev = c1.PointAtStart.DistanceTo(c2.PointAtEnd) + c1.PointAtEnd.DistanceTo(c2.PointAtStart);
                    double dMid = midPt1.DistanceTo(c2.PointAtNormalizedLength(0.5));

                    if ((dFwd < tolerance && dMid < tolerance * 0.5) || (dRev < tolerance && dMid < tolerance * 0.5))
                    {
                        isDup = true;
                        break;
                    }
                }

                if (!isDup)
                {
                    tree.Insert(midPt1, cleaned.Count);
                    cleaned.Add(c1);
                }
            }
            return cleaned;
        }

        // ============================================================
        // 【FIX-1.3】交叉感知融合 — 三阶段策略
        // ============================================================
        // 阶段0: 仅正常线互相组合（全局贪心），确保正常线先形成连续链路
        // 阶段1: 交叉节点处相切线局部合并（跳过纯正常线对，已在阶段0处理）
        // 阶段2: 全局贪心融合剩余所有线（复用 JoinTangentCurvesPrioritized_Original）
        // ============================================================
        private static List<Curve> JoinTangentCurvesPrioritized(List<Curve> curves, double tolerance, double angleTolRad)
        {
            if (curves.Count < 2) return curves;

            // 将曲线分为正常线池和相切线池
            var normalCurves = new List<Curve>();
            var tangentCurves = new List<Curve>();
            foreach (var c in curves)
            {
                if (c == null) continue;
                if (c.GetUserString("IsTangent") == "true")
                    tangentCurves.Add(c);
                else
                    normalCurves.Add(c);
            }

            // === 阶段0: 仅正常线互相组合（全局贪心） ===
            var mergedNormals = JoinTangentCurvesPrioritized_Original(normalCurves, tolerance, angleTolRad);

            // === 阶段1: 交叉节点处相切线局部合并 ===
            // 将阶段0结果与相切线合并到候选池
            var pool = new List<Curve>(mergedNormals);
            pool.AddRange(tangentCurves);

            var junctions = DetectJunctionPoints(pool, ComputeJunctionDistTol(tolerance, pool));
            var mergedIndices = new HashSet<int>();
            var stage1Results = new List<Curve>();

            foreach (var junction in junctions)
            {
                // 仅在交叉节点处优先合并涉及相切线的候选对
                var tangentPairs = new List<MergeCandidate>();
                for (int a = 0; a < junction.CurveIndices.Count; a++)
                {
                    for (int b = a + 1; b < junction.CurveIndices.Count; b++)
                    {
                        int ci = junction.CurveIndices[a];
                        int cj = junction.CurveIndices[b];
                        if (mergedIndices.Contains(ci) || mergedIndices.Contains(cj)) continue;

                        // 优先合并：至少一条是相切线
                        bool ciTangent = pool[ci].GetUserString("IsTangent") == "true";
                        bool cjTangent = pool[cj].GetUserString("IsTangent") == "true";
                        if (!ciTangent && !cjTangent) continue;  // 跳过正常线对（已在阶段0处理）

                        if (GetMinTangentAngle(pool[ci], pool[cj], tolerance, out double actualAngle))
                        {
                            if (actualAngle <= angleTolRad)
                            {
                                tangentPairs.Add(new MergeCandidate { Index1 = ci, Index2 = cj, Angle = actualAngle });
                            }
                        }
                    }
                }

                tangentPairs.Sort((a, b) => a.Angle.CompareTo(b.Angle));
                foreach (var pair in tangentPairs)
                {
                    if (mergedIndices.Contains(pair.Index1) || mergedIndices.Contains(pair.Index2)) continue;
                    Curve[] res = Curve.JoinCurves(new Curve[] { pool[pair.Index1], pool[pair.Index2] }, tolerance);
                    if (res != null && res.Length == 1)
                    {
                        PropagateUserStrings(new[] { pool[pair.Index1], pool[pair.Index2] }, res[0]);
                        stage1Results.Add(res[0]);
                        mergedIndices.Add(pair.Index1);
                        mergedIndices.Add(pair.Index2);
                    }
                }
            }

            var remaining = new List<Curve>();
            for (int i = 0; i < pool.Count; i++)
            {
                if (!mergedIndices.Contains(i)) remaining.Add(pool[i]);
            }
            remaining.AddRange(stage1Results);

            // === 阶段2: 全局贪心融合（带交叉感知，见 FIX-2.3） ===
            return JoinTangentCurvesPrioritized_Original(remaining, tolerance, angleTolRad);
        }

        /// <summary>
        /// 【FIX-2.1】基于曲线集合的包围盒对角线自适应计算交叉检测半径。
        /// 避免直接使用用户的几何精度 tolerance 作为空间检测半径。
        /// </summary>
        private static double ComputeJunctionDistTol(double baseTolerance, List<Curve> curves)
        {
            // 计算所有曲线端点的包围盒
            BoundingBox bbox = BoundingBox.Empty;
            foreach (var c in curves)
            {
                if (c == null) continue;
                bbox.Union(c.PointAtStart);
                bbox.Union(c.PointAtEnd);
            }

            if (!bbox.IsValid) return baseTolerance * 100;

            double diagonal = bbox.Diagonal.Length;

            // 自适应阈值：包围盒对角线 × 0.005
            // 不小于 10 × baseTolerance（确保精度容差下也能检测）
            // 不大于包围盒对角线 × 0.02（避免过度检测）
            double adaptiveTol = diagonal * 0.005;
            double minTol = baseTolerance * 10;
            double maxTol = diagonal * 0.02;

            return Math.Max(minTol, Math.Min(adaptiveTol, maxTol));
        }

        // 全局贪心融合逻辑 (阶段0/2)，【FIX-2.3】增加交叉感知
        private static List<Curve> JoinTangentCurvesPrioritized_Original(List<Curve> curves, double tolerance, double angleTolRad)
        {
            if (curves.Count < 2) return curves;

            // 【FIX-2.3】预计算交叉节点集合，用于交叉感知
            // 标记参与交叉节点的曲线（通过 UserString "InJunction"）
            var junctions = DetectJunctionPoints(curves, ComputeJunctionDistTol(tolerance, curves));
            var junctionCurves = new HashSet<int>();
            foreach (var j in junctions)
            {
                foreach (var idx in j.CurveIndices)
                    junctionCurves.Add(idx);
            }
            for (int i = 0; i < curves.Count; i++)
            {
                curves[i].SetUserString("InJunction", junctionCurves.Contains(i) ? "true" : "false");
            }

            List<Curve> pool = new List<Curve>();
            foreach (var c in curves) { if (c != null) pool.Add(c); }

            bool loopAgain = true;
            while (loopAgain)
            {
                loopAgain = false;
                List<MergeCandidate> candidates = new List<MergeCandidate>();

                for (int i = 0; i < pool.Count; i++)
                {
                    for (int j = i + 1; j < pool.Count; j++)
                    {
                        if (GetMinTangentAngle(pool[i], pool[j], tolerance, out double actualAngle))
                        {
                            // 【FIX-2.3】交叉感知：若两条线都参与交叉节点，但夹角偏大，
                            // 说明它们在交叉处不属于同一连续路径，不合并
                            bool iInJunction = pool[i].GetUserString("InJunction") == "true";
                            bool jInJunction = pool[j].GetUserString("InJunction") == "true";
                            if (iInJunction && jInJunction && actualAngle > angleTolRad * 3)
                                continue;

                            if (actualAngle <= angleTolRad)
                            {
                                candidates.Add(new MergeCandidate { Index1 = i, Index2 = j, Angle = actualAngle });
                            }
                        }
                    }
                }

                if (candidates.Count == 0) break;

                candidates.Sort((a, b) => a.Angle.CompareTo(b.Angle));

                List<Curve> nextGenerationPool = new List<Curve>();
                bool[] indexLocked = new bool[pool.Count];

                foreach (var candidate in candidates)
                {
                    if (indexLocked[candidate.Index1] || indexLocked[candidate.Index2]) continue;

                    Curve[] res = Curve.JoinCurves(new Curve[] { pool[candidate.Index1], pool[candidate.Index2] }, tolerance);
                    if (res != null && res.Length == 1)
                    {
                        PropagateUserStrings(new[] { pool[candidate.Index1], pool[candidate.Index2] }, res[0]);
                        nextGenerationPool.Add(res[0]);
                        indexLocked[candidate.Index1] = true;
                        indexLocked[candidate.Index2] = true;
                        loopAgain = true;
                    }
                }

                for (int i = 0; i < pool.Count; i++)
                {
                    if (!indexLocked[i]) nextGenerationPool.Add(pool[i]);
                }

                pool = nextGenerationPool;
            }
            return pool;
        }

        /// <summary>
        /// 【FIX-2.2】计算两条曲线在端点连接处的最小切线夹角。
        /// 增加“趋近垂直交叉验证”：仅当存在≥2种端点连接方式时，
        /// 若最大夹角≥80°则认为两线整体趋近垂直，不合并。
        /// 同时增加绝对上限 60°，超过此角度的线对不论何种连接方式都不合并。
        /// </summary>
        private static bool GetMinTangentAngle(Curve c1, Curve c2, double tolerance, out double minAngle)
        {
            minAngle = double.MaxValue;

            Point3d s1 = c1.PointAtStart; Point3d e1 = c1.PointAtEnd;
            Point3d s2 = c2.PointAtStart; Point3d e2 = c2.PointAtEnd;

            Vector3d tS1 = c1.TangentAtStart; Vector3d tE1 = c1.TangentAtEnd;
            Vector3d tS2 = c2.TangentAtStart; Vector3d tE2 = c2.TangentAtEnd;

            // 收集所有有效连接方式的夹角
            var angles = new List<double>();

            if (e1.DistanceTo(s2) <= tolerance) angles.Add(Vector3d.VectorAngle(tE1, tS2));
            if (e1.DistanceTo(e2) <= tolerance) angles.Add(Vector3d.VectorAngle(tE1, -tE2));
            if (s1.DistanceTo(s2) <= tolerance) angles.Add(Vector3d.VectorAngle(-tS1, tS2));
            if (s1.DistanceTo(e2) <= tolerance) angles.Add(Vector3d.VectorAngle(-tS1, -tE2));

            if (angles.Count == 0) return false;

            minAngle = angles[0];
            double maxAngle = angles[0];
            for (int i = 1; i < angles.Count; i++)
            {
                if (angles[i] < minAngle) minAngle = angles[i];
                if (angles[i] > maxAngle) maxAngle = angles[i];
            }

            // 交叉验证：存在≥2种端点连接方式时，检查最大夹角与最小夹角差距
            if (angles.Count >= 2)
            {
                // 若最大夹角 ≥ 80° (≈1.396 rad)，说明两条线在几何上趋近垂直，
                // 某端点的“小夹角”是巧合，不应合并
                const double nearVerticalRad = 80.0 * Math.PI / 180.0;
                if (maxAngle >= nearVerticalRad)
                    return false;
            }

            // 绝对上限：最小夹角超过 60° (≈1.047 rad) 也不合并
            const double absoluteMaxAngle = 60.0 * Math.PI / 180.0;
            if (minAngle > absoluteMaxAngle) return false;

            return true;
        }

        private static void BakeToRhinoGrouped(RhinoDoc doc, Dictionary<string, Dictionary<string, List<Curve>>> viewsData)
        {
            string layerName = "Patent_Drawings_2D";
            var existingLayer = doc.Layers.FindName(layerName);
            int layerIndex = (existingLayer != null) ? existingLayer.Index : -1;

            if (layerIndex < 0)
            {
                var newLayer = new Layer { Name = layerName, Color = System.Drawing.Color.Black };
                layerIndex = doc.Layers.Add(newLayer);
            }

            // 【F1.3】新增正切边缘子图层（蓝色），用于分组烘焙正切边缘线
            string tangentLayerName = "TangentEdges";
            var existingTangentLayer = doc.Layers.FindName(tangentLayerName);
            int tangentLayerIndex = (existingTangentLayer != null) ? existingTangentLayer.Index : -1;

            if (tangentLayerIndex < 0)
            {
                var tangentLayer = new Layer { Name = tangentLayerName, Color = System.Drawing.Color.Blue };
                tangentLayerIndex = doc.Layers.Add(tangentLayer);
            }

            foreach (var kvpView in viewsData)
            {
                string viewName = kvpView.Key;
                foreach (var kvpComp in kvpView.Value)
                {
                    string componentName = kvpComp.Key;
                    List<Curve> curves = kvpComp.Value;
                    if (curves.Count == 0) continue;

                    string groupName = componentName + "_" + viewName;
                    int groupIndex = doc.Groups.Add(groupName);

                    foreach (var crv in curves)
                    {
                        // 根据 IsTangent 标记分发到不同图层
                        bool isTangent = crv.GetUserString("IsTangent") == "true";
                        int targetLayerIndex = isTangent ? tangentLayerIndex : layerIndex;

                        var attributes = new ObjectAttributes { LayerIndex = targetLayerIndex };
                        attributes.AddToGroup(groupIndex);
                        doc.Objects.AddCurve(crv, attributes);
                    }
                }
            }
        }

        private static void ArrangeEngineeringViewsGrouped(Dictionary<string, Dictionary<string, List<Curve>>> vData)
        {
            var bboxes = new Dictionary<string, BoundingBox>(StringComparer.OrdinalIgnoreCase);
            double globalMaxW = 0, globalMaxH = 0;

            foreach (var kvpView in vData)
            {
                string viewName = kvpView.Key;
                BoundingBox viewBbox = BoundingBox.Empty;

                foreach (var kvpComp in kvpView.Value)
                {
                    foreach (var crv in kvpComp.Value) viewBbox.Union(crv.GetBoundingBox(true));
                }

                bboxes[viewName] = viewBbox;

                if (viewBbox.IsValid)
                {
                    globalMaxW = Math.Max(globalMaxW, viewBbox.Max.X - viewBbox.Min.X);
                    globalMaxH = Math.Max(globalMaxH, viewBbox.Max.Y - viewBbox.Min.Y);

                    Transform toOrigin = Transform.Translation(new Vector3d(-viewBbox.Center.X, -viewBbox.Center.Y, 0));
                    foreach (var kvpComp in kvpView.Value)
                    {
                        foreach (var crv in kvpComp.Value) crv.Transform(toOrigin);
                    }
                }
            }

            double refW = bboxes.ContainsKey("Front") && bboxes["Front"].IsValid ? (bboxes["Front"].Max.X - bboxes["Front"].Min.X) : globalMaxW;
            double refH = bboxes.ContainsKey("Front") && bboxes["Front"].IsValid ? (bboxes["Front"].Max.Y - bboxes["Front"].Min.Y) : globalMaxH;

            double gapX = refW * 0.5 == 0 ? 100 : refW * 0.5;
            double gapY = refH * 0.5 == 0 ? 100 : refH * 0.5;

            double getW(string name) => bboxes.ContainsKey(name) && bboxes[name].IsValid ? (bboxes[name].Max.X - bboxes[name].Min.X) : 0;
            double getH(string name) => bboxes.ContainsKey(name) && bboxes[name].IsValid ? (bboxes[name].Max.Y - bboxes[name].Min.Y) : 0;

            var offsets = new Dictionary<string, Vector3d>(StringComparer.OrdinalIgnoreCase);

            offsets["Front"] = new Vector3d(0, 0, 0);
            offsets["Top"] = new Vector3d(0, -(refH / 2.0 + gapY + getH("Top") / 2.0), 0);
            offsets["Bottom"] = new Vector3d(0, (refH / 2.0 + gapY + getH("Bottom") / 2.0), 0);
            offsets["Right"] = new Vector3d(-(refW / 2.0 + gapX + getW("Right") / 2.0), 0, 0);
            offsets["Left"] = new Vector3d((refW / 2.0 + gapX + getW("Left") / 2.0), 0, 0);
            offsets["Back"] = new Vector3d((refW / 2.0 + gapX + getW("Left") + gapX + getW("Back") / 2.0), 0, 0);

            double rightViewCenterX = -(refW / 2.0 + gapX + getW("Right") / 2.0);
            double extensionX = bboxes.ContainsKey("Right") && bboxes["Right"].IsValid
                ? (rightViewCenterX - getW("Right") / 2.0 - gapX - globalMaxW / 2.0)
                : -(refW / 2.0 + gapX + globalMaxW / 2.0);

            if (refW == 0) extensionX = -(globalMaxW + gapX);

            offsets["IsoFront"] = new Vector3d(extensionX, 0, 0);
            offsets["IsoBack"] = new Vector3d(extensionX, (globalMaxH + gapY), 0);
            offsets["CurrentView"] = new Vector3d(extensionX, -(globalMaxH + gapY), 0);

            foreach (var kvpView in vData)
            {
                if (offsets.TryGetValue(kvpView.Key, out Vector3d moveVec))
                {
                    Transform finalMove = Transform.Translation(moveVec);
                    foreach (var kvpComp in kvpView.Value)
                    {
                        foreach (var crv in kvpComp.Value) crv.Transform(finalMove);
                    }
                }
            }
        }

        private static Plane GetViewPlane(string name, Point3d origin)
        {
            name = name.Trim().ToLower();
            switch (name)
            {
                case "top": return new Plane(origin, Vector3d.XAxis, Vector3d.YAxis);
                case "bottom": return new Plane(origin, -Vector3d.XAxis, Vector3d.YAxis);
                case "front": return new Plane(origin, Vector3d.XAxis, Vector3d.ZAxis);
                case "back": return new Plane(origin, -Vector3d.XAxis, Vector3d.ZAxis);
                case "left": return new Plane(origin, -Vector3d.YAxis, Vector3d.ZAxis);
                case "right": return new Plane(origin, Vector3d.YAxis, Vector3d.ZAxis);
                default: return new Plane(origin, Vector3d.XAxis, Vector3d.YAxis);
            }
        }

        /// <summary>
        /// 【F1.4】检测交叉节点: 端点 distTol 范围内 ≥3 条曲线交汇的位置
        /// 使用 RTree 空间索引快速查找端点邻接关系
        /// </summary>
        private static List<JunctionInfo> DetectJunctionPoints(List<Curve> curves, double distTol)
        {
            var rtree = new RTree();
            // 每条曲线有起点和终点两个端点, 用 id=i*2 (start) / i*2+1 (end) 区分
            var endpoints = new List<(Point3d Point, int CurveIndex)>(curves.Count * 2);

            for (int i = 0; i < curves.Count; i++)
            {
                if (curves[i] == null) continue;
                var start = curves[i].PointAtStart;
                var end = curves[i].PointAtEnd;
                rtree.Insert(start, i * 2);
                rtree.Insert(end, i * 2 + 1);
                endpoints.Add((start, i));
                endpoints.Add((end, i));
            }

            // 对每个端点查找 distTol 范围内的邻接曲线
            var junctions = new List<JunctionInfo>();
            var seenPositions = new HashSet<string>();

            for (int i = 0; i < endpoints.Count; i++)
            {
                var neighbors = new HashSet<int>();
                rtree.Search(new Sphere(endpoints[i].Point, distTol), (sender, args) =>
                {
                    int curveIdx = args.Id / 2;
                    neighbors.Add(curveIdx);
                });

                // 交叉节点定义: distTol 范围内 ≥3 条曲线交汇
                if (neighbors.Count >= 3)
                {
                    // 用位置去重 (同一交叉节点可能被多个端点发现)
                    string posKey = $"{endpoints[i].Point.X:F4}_{endpoints[i].Point.Y:F4}_{endpoints[i].Point.Z:F4}";
                    if (seenPositions.Add(posKey))
                    {
                        junctions.Add(new JunctionInfo
                        {
                            Position = endpoints[i].Point,
                            CurveIndices = new List<int>(neighbors)
                        });
                    }
                }
            }
            return junctions;
        }

        /// <summary>
        /// 将源曲线的语义标记 (IsOuter, IsTangent 等) 传播到合并后的曲线
        /// 【FIX-1.2】IsTangent 改为“正常线优先”策略：
        /// 仅当所有源曲线都是正切线时，结果才继承 IsTangent=true；
        /// 只要有一条正常线（非正切），结果即为正常线（不设 IsTangent）。
        /// IsOuter 和 ComponentName 保持原有的“任意源带标记则继承”逻辑。
        /// </summary>
        private static void PropagateUserStrings(Curve[] sources, Curve target)
        {
            // IsOuter: 任意源带标记则继承（保持原有逻辑）
            foreach (var src in sources)
            {
                if (src == null) continue;
                var val = src.GetUserString("IsOuter");
                if (!string.IsNullOrEmpty(val))
                {
                    target.SetUserString("IsOuter", val);
                    break;
                }
            }

            // IsTangent: 正常线优先 — 仅当所有源都是正切线时，结果才为正切线
            bool allTangent = true;
            bool anyTangent = false;
            foreach (var src in sources)
            {
                if (src == null) continue;
                bool isTangent = src.GetUserString("IsTangent") == "true";
                if (!isTangent) allTangent = false;
                else anyTangent = true;
            }
            if (allTangent && anyTangent)
            {
                target.SetUserString("IsTangent", "true");
            }

            // ComponentName: 任意源带标记则继承（保持原有逻辑）
            foreach (var src in sources)
            {
                if (src == null) continue;
                var val = src.GetUserString("ComponentName");
                if (!string.IsNullOrEmpty(val))
                {
                    target.SetUserString("ComponentName", val);
                    break;
                }
            }
        }

        private class MergeCandidate
        {
            public int Index1 { get; set; }
            public int Index2 { get; set; }
            public double Angle { get; set; }
        }

        // 交叉节点信息
        private class JunctionInfo
        {
            public Point3d Position { get; set; }
            public List<int> CurveIndices { get; set; } = new List<int>();
        }

        // ============================================================
        // 【F2.2】渲染输出 — 视图联动模式
        // ============================================================
        // DetermineRenderViews(): 根据用户选定的视图模式动态构建渲染视图列表
        // CaptureViewsByMode(): 逐个捕获渲染位图（内联于 ExecuteAsync 渲染块）
        // CaptureViewRender():  单视图渲染捕获（临时视口 + 平行投影 + CaptureToBitmap）
        // ComposeRenderLayout(): 动态排版（单视图直出 / 多视图工程排版）
        // ============================================================

        private class RenderViewInfo
        {
            public string Name { get; set; } = "";
            public Plane Plane { get; set; }
        }

        /// <summary>
        /// 根据用户选定的视图模式参数动态确定要渲染的视图列表。
        /// 渲染输出与线框输出的视图选择完全联动一致。
        /// </summary>
        private static List<RenderViewInfo> DetermineRenderViews(
            bool wantSix, bool wantIsoFront, bool wantIsoBack, bool wantCurrent,
            BoundingBox modelBox, RhinoView? currentView)
        {
            var views = new List<RenderViewInfo>();
            Point3d center = modelBox.IsValid ? modelBox.Center : Point3d.Origin;

            if (wantSix)
            {
                views.Add(new RenderViewInfo { Name = "Front", Plane = GetViewPlane("Front", center) });
                views.Add(new RenderViewInfo { Name = "Top", Plane = GetViewPlane("Top", center) });
                views.Add(new RenderViewInfo { Name = "Bottom", Plane = GetViewPlane("Bottom", center) });
                views.Add(new RenderViewInfo { Name = "Left", Plane = GetViewPlane("Left", center) });
                views.Add(new RenderViewInfo { Name = "Right", Plane = GetViewPlane("Right", center) });
                views.Add(new RenderViewInfo { Name = "Back", Plane = GetViewPlane("Back", center) });
            }

            if (wantIsoFront)
                views.Add(new RenderViewInfo { Name = "IsoFront", Plane = GetIsoPlane(center, isFront: true, isDown: false) });

            if (wantIsoBack)
                views.Add(new RenderViewInfo { Name = "IsoBack", Plane = GetIsoPlane(center, isFront: false, isDown: true) });

            if (wantCurrent && currentView != null)
            {
                var vp = currentView.ActiveViewport;
                views.Add(new RenderViewInfo { Name = "CurrentView", Plane = new Plane(center, vp.CameraX, vp.CameraY) });
            }

            return views;
        }

        /// <summary>
        /// 捕获指定视图平面的渲染位图。
        /// 创建临时视口，设置平行投影与相机位置，捕获后移除临时视口。
        /// 【FIX-3.1】从 Shaded + CaptureToBitmap 改为 Rendered 显示模式 + ViewCapture 渲染管道。
        /// </summary>
        private static Bitmap? CaptureViewRender(RhinoDoc doc, Plane viewPlane, string viewName, Size imageSize)
        {
            Bitmap? result = null;
            RhinoView? tempView = null;

            try
            {
                // 1. 创建临时视口（不立即显示）
                tempView = doc.Views.Add(viewName, DefinedViewportProjection.Perspective,
                    new Rectangle(0, 0, imageSize.Width, imageSize.Height), false);

                if (tempView == null)
                {
                    RhinoApp.WriteLine($"⚠️ 无法创建临时视口 [{viewName}]，跳过渲染。");
                    return null;
                }

                var vp = tempView.ActiveViewport;

                // 2. 设置平行投影
                vp.SetProjection(DefinedViewportProjection.Perspective, viewName, false);
                vp.ChangeToParallelProjection(true);

                // 3. 根据视图平面调整相机：相机位于法线方向，朝向目标
                Point3d target = viewPlane.Origin;
                Point3d cameraLocation = viewPlane.Origin + viewPlane.ZAxis * 1000;
                vp.SetCameraLocation(cameraLocation, false);
                vp.SetCameraDirection(-viewPlane.ZAxis, false);
                vp.CameraUp = viewPlane.YAxis;
                vp.SetCameraTarget(target, true);

                // 4. 缩放至模型包围盒，确保完整可见
                BoundingBox modelBox = doc.Views.ActiveView != null
                    ? GetModelBoundingBox(doc)
                    : BoundingBox.Empty;
                if (modelBox.IsValid)
                {
                    Transform xform = Transform.PlaneToPlane(viewPlane, Plane.WorldXY);
                    BoundingBox viewBbox = modelBox;
                    viewBbox.Transform(xform);
                    if (viewBbox.IsValid)
                        vp.ZoomBoundingBox(viewBbox);
                }

                // 【FIX-3.1】设置 Rendered 显示模式（含光照/阴影），备选 Articulated / Shaded
                DisplayModeDescription? renderMode = DisplayModeDescription.FindByName("Rendered");
                if (renderMode == null)
                    renderMode = DisplayModeDescription.FindByName("Articulated");
                if (renderMode == null)
                    renderMode = DisplayModeDescription.FindByName("Shaded");

                if (renderMode != null)
                    vp.DisplayMode = renderMode;

                tempView.Redraw();

                // 【FIX-3.1】使用 ViewCapture 渲染管道捕获位图（非屏幕截图）
                // 主方案：ViewCapture.CaptureToBitmap(ViewCaptureSettings)（静态方法，RasterMode=true 使用渲染管道）
                var captureSettings = new ViewCaptureSettings(tempView, imageSize, 72.0);
                captureSettings.DrawGrid = false;
                captureSettings.DrawAxis = false;
                captureSettings.DrawBackground = true;
                captureSettings.RasterMode = true;

                result = ViewCapture.CaptureToBitmap(captureSettings);

                // 备选方案：若 ViewCapture 返回 null，回退到 CaptureToBitmap(Size, DisplayModeDescription)
                if (result == null && renderMode != null)
                    result = tempView.CaptureToBitmap(imageSize, renderMode);
            }
            catch (Exception ex)
            {
                RhinoApp.WriteLine($"⚠️ 渲染捕获 [{viewName}] 异常: {ex.Message}");
                result = null;
            }
            finally
            {
                if (tempView != null)
                {
                    tempView.Close();
                }
            }

            return result;
        }

        /// <summary>
        /// 获取文档中所有可见物体的包围盒
        /// </summary>
        private static BoundingBox GetModelBoundingBox(RhinoDoc doc)
        {
            BoundingBox bbox = BoundingBox.Empty;
            foreach (var obj in doc.Objects)
            {
                if (obj == null || !obj.Visible) continue;
                var geo = obj.Geometry;
                if (geo != null)
                    bbox.Union(geo.GetBoundingBox(true));
            }
            return bbox;
        }

        // ============================================================
        // 【F2.3】渲染图片动态排版
        // ============================================================

        /// <summary>
        /// 根据实际渲染的视图数量动态排版。
        /// 单视图直接返回原位图；多视图按工程排版规则合成。
        /// </summary>
        private static Bitmap? ComposeRenderLayout(Dictionary<string, Bitmap> viewBitmaps)
        {
            if (viewBitmaps.Count == 0)
                return null;

            // 单视图：无需排版，直接返回单张渲染位图
            if (viewBitmaps.Count == 1)
            {
                using (var enumerator = viewBitmaps.Values.GetEnumerator())
                {
                    if (enumerator.MoveNext())
                        return enumerator.Current;
                }
                return null;
            }

            // 多视图：根据视图数量和类型动态计算布局
            int refW = 0, refH = 0;
            foreach (var bmp in viewBitmaps.Values)
            {
                if (bmp.Width > refW) refW = bmp.Width;
                if (bmp.Height > refH) refH = bmp.Height;
            }
            double gap = refW * 0.3;

            if (viewBitmaps.Count == 6 && IsSixStandardViews(viewBitmaps))
                return ComposeSixViewLayout(viewBitmaps, refW, refH, gap);
            else if (viewBitmaps.Count == 3 && HasThreeOrthoViews(viewBitmaps))
                return ComposeThreeViewLayout(viewBitmaps, refW, refH, gap);
            else
                return ComposeGenericLayout(viewBitmaps, refW, refH, gap);
        }

        /// <summary>判断是否包含全部六个标准视图</summary>
        private static bool IsSixStandardViews(Dictionary<string, Bitmap> viewBitmaps)
        {
            string[] required = { "Front", "Top", "Bottom", "Left", "Right", "Back" };
            foreach (var name in required)
                if (!viewBitmaps.ContainsKey(name)) return false;
            return true;
        }

        /// <summary>判断是否包含三视图标准组合（Front + Top + Right）</summary>
        private static bool HasThreeOrthoViews(Dictionary<string, Bitmap> viewBitmaps)
        {
            return viewBitmaps.ContainsKey("Front") && viewBitmaps.ContainsKey("Top") && viewBitmaps.ContainsKey("Right");
        }

        /// <summary>
        /// 六视图工程排版合成
        /// Layout:
        ///          ┌──────────┐
        ///          │  Bottom  │
        ///  ┌───────┼──────────┼───────┬──────┐
        ///  │ Right │  Front   │ Left  │ Back │
        ///  └───────┼──────────┼───────┴──────┘
        ///          │   Top    │
        ///          └──────────┘
        /// </summary>
        private static Bitmap ComposeSixViewLayout(Dictionary<string, Bitmap> viewBitmaps,
            int refW, int refH, double gap)
        {
            int canvasW = (int)(4 * refW + 3 * gap);
            int canvasH = (int)(3 * refH + 2 * gap);
            var canvas = new Bitmap(canvasW, canvasH);

            using (var g = Graphics.FromImage(canvas))
            {
                g.Clear(Color.White);
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;

                double centerColX = refW + gap;
                double centerRowY = refH + gap;

                if (viewBitmaps.ContainsKey("Front")) DrawAt(g, viewBitmaps["Front"], centerColX, centerRowY, refW, refH);
                if (viewBitmaps.ContainsKey("Top")) DrawAt(g, viewBitmaps["Top"], centerColX, centerRowY + refH + gap, refW, refH);
                if (viewBitmaps.ContainsKey("Bottom")) DrawAt(g, viewBitmaps["Bottom"], centerColX, centerRowY - refH - gap, refW, refH);
                if (viewBitmaps.ContainsKey("Left")) DrawAt(g, viewBitmaps["Left"], centerColX + refW + gap, centerRowY, refW, refH);
                if (viewBitmaps.ContainsKey("Right")) DrawAt(g, viewBitmaps["Right"], centerColX - refW - gap, centerRowY, refW, refH);
                if (viewBitmaps.ContainsKey("Back")) DrawAt(g, viewBitmaps["Back"], centerColX + 2 * (refW + gap), centerRowY, refW, refH);
            }

            return canvas;
        }

        /// <summary>
        /// 三视图工程排版合成
        /// Layout:
        ///  ┌──────────┬──────┐
        ///  │  Front   │ Right│
        ///  ├──────────┤      │
        ///  │   Top    │      │
        ///  └──────────┴──────┘
        /// </summary>
        private static Bitmap ComposeThreeViewLayout(Dictionary<string, Bitmap> viewBitmaps,
            int refW, int refH, double gap)
        {
            int canvasW = (int)(2 * refW + gap);
            int canvasH = (int)(2 * refH + gap);
            var canvas = new Bitmap(canvasW, canvasH);

            using (var g = Graphics.FromImage(canvas))
            {
                g.Clear(Color.White);
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;

                if (viewBitmaps.ContainsKey("Front")) DrawAt(g, viewBitmaps["Front"], 0, 0, refW, refH);
                if (viewBitmaps.ContainsKey("Top")) DrawAt(g, viewBitmaps["Top"], 0, refH + gap, refW, refH);
                if (viewBitmaps.ContainsKey("Right")) DrawAt(g, viewBitmaps["Right"], refW + gap, 0, refW, refH);
            }

            return canvas;
        }

        /// <summary>
        /// 通用网格排版（用于非标准视图组合）
        /// </summary>
        private static Bitmap ComposeGenericLayout(Dictionary<string, Bitmap> viewBitmaps,
            int refW, int refH, double gap)
        {
            int cols = (int)Math.Ceiling(Math.Sqrt(viewBitmaps.Count));
            int rows = (int)Math.Ceiling((double)viewBitmaps.Count / cols);
            int canvasW = (int)(cols * refW + (cols - 1) * gap);
            int canvasH = (int)(rows * refH + (rows - 1) * gap);
            var canvas = new Bitmap(canvasW, canvasH);

            using (var g = Graphics.FromImage(canvas))
            {
                g.Clear(Color.White);
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;

                int idx = 0;
                foreach (var kvp in viewBitmaps)
                {
                    int col = idx % cols;
                    int row = idx / cols;
                    double x = col * (refW + gap);
                    double y = row * (refH + gap);
                    DrawAt(g, kvp.Value, x, y, refW, refH);
                    idx++;
                }
            }

            return canvas;
        }

        /// <summary>
        /// 在画布指定位置绘制缩放后的位图
        /// </summary>
        private static void DrawAt(Graphics g, Bitmap bmp, double x, double y, int refW, int refH)
        {
            if (bmp == null) return;
            g.DrawImage(bmp, (float)x, (float)y, refW, refH);
        }
    }
}