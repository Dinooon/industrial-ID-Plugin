﻿using System;
using System.IO;
using System.Reflection;
using Rhino;
using Rhino.PlugIns;
using Rhino.UI;

[assembly: System.Runtime.InteropServices.Guid("1F4B3C5D-9E8A-42F1-B7D6-C4A5E8F9B0A1")]

namespace AutoMake2D
{
    public class AutoMake2DPlugin : PlugIn
    {
        public static AutoMake2DPlugin Instance { get; private set; } = null;

        private static Stream _gIconStream = null;

        // 【已修复】：这里是声明微软底层的“图标类型”，必须是 System.Drawing.Icon
        private static System.Drawing.Icon _gPermanentIcon = null;

        public AutoMake2DPlugin()
        {
            Instance = this;
        }

        protected override LoadReturnCode OnLoad(ref string errorMessage)
        {
            try
            {
                var assembly = Assembly.GetExecutingAssembly();

                // 【已修复】：这里才是填你真实的“文件名”。
                // 如果你的图片名字叫 icon1.ico，这里就写 "AutoMake2D.icon1.ico"
                // 如果你的图片名字没改，还是叫 icon.ico，请把这里改回 "AutoMake2D.icon.ico"
                string resourceName = "AutoMake2D.icon1.ico";

                _gIconStream = assembly.GetManifestResourceStream(resourceName);
                if (_gIconStream != null)
                {
                    // 【已修复】：实例化类型必须是 System.Drawing.Icon
                    _gPermanentIcon = new System.Drawing.Icon(_gIconStream);
                }

                Panels.RegisterPanel(this, typeof(PatentUiPanel), "AutoMake2D_DJ", _gPermanentIcon);

                RhinoApp.Idle += RhinoApp_OnIdle;
            }
            catch (Exception ex)
            {
                errorMessage = $"自动出图面板加载失败: {ex.Message}";
                return LoadReturnCode.ErrorShowDialog;
            }

            return LoadReturnCode.Success;
        }

        private void RhinoApp_OnIdle(object sender, EventArgs e)
        {
            RhinoApp.Idle -= RhinoApp_OnIdle;

            try
            {
                var targetPanelId = PatentUiPanel.PanelId;
                if (!Panels.IsPanelVisible(targetPanelId))
                {
                    Panels.OpenPanel(targetPanelId);
                }
            }
            catch (Exception ex)
            {
                RhinoApp.WriteLine($"[AutoMake2D] 延迟弹窗被安全拦截: {ex.Message}");
            }
        }
    }
}