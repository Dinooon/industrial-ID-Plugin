﻿using System;
using System.Threading.Tasks;
using Rhino.UI;

// 强力别名锁定，彻底物理屏蔽 System.Windows.Forms 的命名空间污染
using Panel = Eto.Forms.Panel;
using Label = Eto.Forms.Label;
using RadioButton = Eto.Forms.RadioButton;
using CheckBox = Eto.Forms.CheckBox;
using Button = Eto.Forms.Button;
using TextBox = Eto.Forms.TextBox;
using ProgressBar = Eto.Forms.ProgressBar;
using DynamicLayout = Eto.Forms.DynamicLayout;
using TextAlignment = Eto.Forms.TextAlignment;
using Size = Eto.Drawing.Size;
using Padding = Eto.Drawing.Padding;
using Font = Eto.Drawing.Font;
using FontStyle = Eto.Drawing.FontStyle;
using Colors = Eto.Drawing.Colors;
using StackLayout = Eto.Forms.StackLayout;
using StackLayoutItem = Eto.Forms.StackLayoutItem;
using SaveFileDialog = Eto.Forms.SaveFileDialog;
using FileFilter = Eto.Forms.FileFilter;
using DialogResult = Eto.Forms.DialogResult;

namespace AutoMake2D
{
    [System.Runtime.InteropServices.Guid("8C2EFA41-B3D7-4982-A1E4-F6C7D8E9A0B2")]
    public class PatentUiPanel : Panel, IPanel
    {
        private Label _infoLabel;
        private Label _warningLabel;

        private RadioButton _rbPrecisionHigh;
        private RadioButton _rbPrecisionMed;
        private RadioButton _rbPrecisionLow;

        private CheckBox _cbModeSix;
        private CheckBox _cbModeIsoFront;
        private CheckBox _cbModeIsoBack; // 对应后下方轴测
        private CheckBox _cbModeCurrent;

        // 【F2.1】渲染输出控件
        private CheckBox _cbRenderOutput;
        private TextBox _tbRenderPath;
        private Button _btnRenderBrowse;

        private Button _generateBtn;

        private ProgressBar _progressBar;
        private Label _statusLabel;

        public static Guid PanelId
        {
            get { return typeof(PatentUiPanel).GUID; }
        }

        public PatentUiPanel()
        {
            _infoLabel = new Label
            {
                Text = "请配置参数后点击下方按钮生成图纸",
                TextAlignment = TextAlignment.Center
            };

            _warningLabel = new Label
            {
                Text = "温馨提示：尽量不要带内部看不到的零件一起生成，否则计算时间会很长！！",
                TextAlignment = TextAlignment.Center,
                TextColor = Colors.DarkOrange,
                Font = new Font("Arial", 8, FontStyle.None)
            };

            _rbPrecisionHigh = new RadioButton { Text = "高精度 (0.001) - 保留极小细节" };
            _rbPrecisionMed = new RadioButton(_rbPrecisionHigh) { Text = "中精度 (0.01) - 推荐默认", Checked = true };
            _rbPrecisionLow = new RadioButton(_rbPrecisionHigh) { Text = "低精度 (0.1) - 仅大轮廓" };

            _cbModeSix = new CheckBox { Text = "标准工程六视图 (长对正/高平齐)", Checked = true };
            _cbModeIsoFront = new CheckBox { Text = "前45°轴测图 (立体正视角展示)", Checked = true };
            _cbModeIsoBack = new CheckBox { Text = "后45°轴测图 (底面正视角展示)", Checked = true }; // 【文字对齐】
            _cbModeCurrent = new CheckBox { Text = "当前视角线框图 (屏幕所见即所得)" };

            // 【F2.1】渲染输出区域 — 与视图模式联动
            _cbRenderOutput = new CheckBox { Text = "渲染输出（与视图模式联动）", Checked = false };
            _tbRenderPath = new TextBox
            {
                Text = System.IO.Path.Combine(
                    System.Environment.GetFolderPath(System.Environment.SpecialFolder.Desktop),
                    "AutoMake2D_Render.png")
            };
            _btnRenderBrowse = new Button { Text = "浏览..." };
            _btnRenderBrowse.Click += OnRenderBrowseClick;
            UpdateRenderPathEnabled();
            _cbRenderOutput.CheckedChanged += (s, e) => UpdateRenderPathEnabled();

            _generateBtn = new Button { Text = "生成专利图" };
            _generateBtn.Click += OnGenerateClick;

            _progressBar = new ProgressBar { MinValue = 0, MaxValue = 100, Value = 0, Visible = false };
            _statusLabel = new Label { Text = "准备就绪...", TextAlignment = TextAlignment.Center, Visible = false, Font = new Font("Arial", 9) };

            var layout = new DynamicLayout { Spacing = new Size(5, 6), Padding = new Padding(12) };
            layout.AddRow(_infoLabel);
            layout.AddRow(_warningLabel);
            layout.AddRow(null);

            layout.AddRow(new Label { Text = "📐 过滤与融合公差精度：", Font = new Font("Arial", 9, FontStyle.Bold) });
            layout.AddRow(_rbPrecisionHigh);
            layout.AddRow(_rbPrecisionMed);
            layout.AddRow(_rbPrecisionLow);
            layout.AddRow(null);

            layout.AddRow(new Label { Text = "🖼 " + "需要视角选择 (支持多选)：", Font = new Font("Arial", 9, FontStyle.Bold) });
            layout.AddRow(_cbModeSix);
            layout.AddRow(_cbModeIsoFront);
            layout.AddRow(_cbModeIsoBack);
            layout.AddRow(_cbModeCurrent);
            layout.AddRow(null);

            // 【F2.1】渲染输出区域
            layout.AddRow(new Label { Text = "────────────────────────", TextAlignment = TextAlignment.Center, Font = new Font("Arial", 8, FontStyle.None) });
            layout.AddRow(_cbRenderOutput);
            layout.AddRow(new Label { Text = "渲染图保存路径（同时放入模型）:", Font = new Font("Arial", 9) });
            var pathRow = new StackLayout
            {
                Orientation = Eto.Forms.Orientation.Horizontal,
                Spacing = 5,
                Items = { new StackLayoutItem(_tbRenderPath, true), _btnRenderBrowse }
            };
            layout.AddRow(pathRow);
            layout.AddRow(null);

            layout.AddRow(_generateBtn);

            layout.AddRow(null);
            layout.AddRow(_progressBar);
            layout.AddRow(_statusLabel);

            Content = layout;
        }

        private async void OnGenerateClick(object sender, EventArgs e)
        {
            bool wantSix = _cbModeSix.Checked ?? false;
            bool wantIsoFront = _cbModeIsoFront.Checked ?? false;
            bool wantIsoBack = _cbModeIsoBack.Checked ?? false;
            bool wantCurrent = _cbModeCurrent.Checked ?? false;

            if (!wantSix && !wantIsoFront && !wantIsoBack && !wantCurrent)
            {
                Rhino.RhinoApp.WriteLine("⚠️ 请至少勾选一种需要输出的视图视角！");
                return;
            }

            bool wantRender = _cbRenderOutput.Checked ?? false;
            string renderPath = _tbRenderPath.Text ?? "";
            if (wantRender && string.IsNullOrWhiteSpace(renderPath))
            {
                Rhino.RhinoApp.WriteLine("⚠️ 已勾选渲染输出但未指定输出路径！");
                return;
            }

            _generateBtn.Enabled = false;
            _progressBar.Visible = true;
            _statusLabel.Visible = true;
            _progressBar.Value = 0;
            _statusLabel.Text = "请在 Rhino 视口中框选模型...";

            try
            {
                double chosenTolerance = 0.01;
                if (_rbPrecisionHigh.Checked) chosenTolerance = 0.001;
                else if (_rbPrecisionLow.Checked) chosenTolerance = 0.1;

                var progress = new Progress<int>(v => _progressBar.Value = v);
                var status = new Progress<string>(s => _statusLabel.Text = s);

                await PatentCore.ExecuteAsync(wantSix, wantIsoFront, wantIsoBack, wantCurrent, chosenTolerance, wantRender, renderPath, progress, status);
            }
            catch (Exception ex)
            {
                Rhino.RhinoApp.WriteLine("运行发生异常: " + ex.Message);
            }
            finally
            {
                _generateBtn.Enabled = true;
                _progressBar.Visible = false;
                _statusLabel.Visible = false;
            }
        }

        public void PanelShown(uint documentSerialNumber, ShowPanelReason reason) { }
        public void PanelHidden(uint documentSerialNumber, ShowPanelReason reason) { }
        public void PanelClosing(uint documentSerialNumber, bool onCloseDocument) { }

        // 【F2.1】渲染输出路径浏览按钮事件
        private void OnRenderBrowseClick(object? sender, EventArgs e)
        {
            var dialog = new SaveFileDialog();
            dialog.Filters.Add(new FileFilter("PNG 图片", ".png"));
            if (!string.IsNullOrEmpty(_tbRenderPath.Text))
                dialog.FileName = System.IO.Path.GetFileName(_tbRenderPath.Text);
            if (dialog.ShowDialog(this) == DialogResult.Ok)
                _tbRenderPath.Text = dialog.FileName;
        }

        // 根据 CheckBox 勾选状态启用/禁用路径输入区域
        private void UpdateRenderPathEnabled()
        {
            bool enabled = _cbRenderOutput.Checked ?? false;
            _tbRenderPath.Enabled = enabled;
            _btnRenderBrowse.Enabled = enabled;
        }
    }
}