# AutoMake2D 第六轮缺陷修复任务计划书 (V6)

> **版本**: v6.0 | **日期**: 2026-07-10 | **状态**: 待审核  
> **前置文档**: `fix-task-plan-v5.md` (v5.0, 第五轮修复)  
> **当前源码**: PatentCore.cs (s26 提交 80be7ae 的 V5 修复版, 1268 行)  
> **核心原则**: 内部分类保持四类（IsOuter + IsTangent + ComponentName），仅输出图层合并为两类

---

## 1. 背景与目标

### 1.1 问题

V5 修复（s26 提交 80be7ae）实施了 `fix-task-plan-v5.md` 的方案，但用户测试后反馈**两个严重缺陷**——分类效果退步和渲染模式错误。

#### 缺陷V6-1：线框分类效果退步

**现象**：  
V5 将 `ComputeSingleViewEngine()` 的核心分类逻辑从「单字典 + IsOuter/IsTangent 标记」改为「两字典（rawSilhouette + rawStructure）+ IsSilhouette/LineType 标记」，导致分类检测效果退步，不如 s7 第一轮修复后的效果。

**根因分析**：

| 变更点 | s7 之后的逻辑（效果好） | V5 的逻辑（效果退步） | 影响 |
|---|---|---|---|
| 字典结构 | 单字典 `rawGrouped`，所有线段混合后通过标记分流 | 两字典 `rawSilhouette` + `rawStructure`，投影阶段即分流 | 两字典导致同类线段被拆到不同字典，跨字典融合失效 |
| SilhouetteType 分发 | `Projecting/Boundary` → IsOuter；`Tangent/NonSilhouetteTangent` → IsTangent；`None` + 弧线回退 → IsTangent | `Projecting/Boundary/NonSilhouetteCrease` → Silhouette；其余 → Structure | NonSilhouetteCrease 被归入轮廓线导致误判；Tangent/正切线识别逻辑被移除 |
| ClassifyByBrepEdge | 不使用（V5 计划新增但未实现） | 不使用 | 无差异 |
| ProcessGroup 处理 | 单管线：混合 → CleanRaw → 外轮廓隔离(IsOuter) → 三阶段融合 → JoinCurves | 两管线：Silhouette 组(CleanRaw → 外轮廓隔离(IsSilhouette) → 简化融合) + Structure 组(CleanRaw → 简化融合) | 三阶段融合被替换为简化单阶段融合（JoinTangentCurvesPrioritized_Original），交叉感知融合失效 |
| 融合策略 | 三阶段融合（阶段0正常线贪心 → 阶段1交叉节点相切线合并 → 阶段2全局贪心） | 单阶段贪心融合（JoinTangentCurvesPrioritized_Original） | 正常线/相切线优先级和交叉节点感知被移除 |
| 标记体系 | IsOuter + IsTangent + ComponentName（三层语义标记） | IsSilhouette + LineType（两层简化标记） | 丢失正切线语义和组件名称信息 |
| PropagateUserStrings | IsOuter（任意源继承）+ IsTangent（正常线优先）+ ComponentName（任意源继承） | IsSilhouette（所有源才继承）+ LineType（分类标签） | 正切线标记的"正常线优先"策略被移除；IsOuter 语义丢失 |

**核心问题**：用户原意仅是「将输出图层从4类简化为2类」，V5 错误地将简化从**输出层**延伸到了**分类检测层**，导致分类逻辑被破坏。

#### 缺陷V6-2：渲染图仍为着色(Shaded)模式

**现象**：  
V5 将 `CaptureViewRender()` 中的显示模式优先级从 `Rendered → Articulated → Shaded` 改为 `Shaded → Rendered → Articulated`，理由是 Shaded 模式自带曲面边缘线显示。但用户明确需要 **Rendered 渲染模式 + 曲面边缘线显示**，着色模式没有光照/阴影效果。

**根因分析**：

| 变更点 | V5 之前逻辑 | V5 的逻辑 | 影响 |
|---|---|---|---|
| ResolveRenderMode 优先级 | `Rendered → Articulated → Shaded` | `Shaded → Rendered → Articulated` | 渲染图失去光照/材质效果，变为简单着色 |
| 曲面边缘线 | 未实现（仅设 DisplayMode 未启用边缘线） | TryEnableEdgeDisplay() 空实现，依赖 Shaded 自带 | Shaded 模式的边缘线不满足用户需求；Rendered 模式下边缘线需显式启用 |

**核心问题**：用户需要 Rendered 模式的完整渲染效果（光照/阴影/材质）+ 曲面边缘线叠加，而非 Shaded 模式的基本着色+边缘线。

### 1.2 目标用户

专利工程师 / 专利律师 — 使用 AutoMake2D 生成专利申请用线框工程图和渲染图

### 1.3 业务目标与可验证指标

| 缺陷 | 修复目标 | 可验证指标 |
|---|---|---|
| 缺陷V6-1 | 恢复 s7 时代的完整分类检测逻辑，仅在烘焙输出时合并为2个图层 | 分类效果与 s7 版本完全一致（同一模型同一视角输出相同）；输出仅 2 个线型图层 Patent_Silhouette + Patent_Structure |
| 缺陷V6-2 | 渲染图使用 Rendered 模式并显示曲面边缘线 | 渲染图具有光照/阴影效果（非简单着色）；可见曲面棱线和锐利边缘线 |

---

## 2. 范围 (Scope)

### ✅ 本期做

| 编号 | 修复项 | 说明 |
|---|---|---|
| FIX-V6-1.1 | 恢复 ComputeSingleViewEngine() 的单字典分类逻辑 | 将 rawSilhouette + rawStructure 两字典恢复为 rawGrouped 单字典，恢复 IsOuter/IsTangent/ComponentName 三层标记 |
| FIX-V6-1.2 | 恢复 SilhouetteType 精确分发逻辑 | 恢复 Projecting/Boundary → IsOuter；Tangent/NonSilhouetteTangent → IsTangent；None + 弧线回退 → IsTangent |
| FIX-V6-1.3 | 恢复 ProcessGroup 为单管线+三阶段融合 | 移除 V5 的 ProcessGroup() 双管线方法，恢复原始内联单管线：CleanRaw → 外轮廓隔离(IsOuter) → JoinTangentCurvesPrioritized（三阶段） → JoinCurves |
| FIX-V6-1.4 | 恢复 PropagateUserStrings 三层标记传播 | 恢复 IsOuter（任意源继承）+ IsTangent（正常线优先）+ ComponentName（任意源继承），移除 IsSilhouette/LineType |
| FIX-V6-1.5 | 重构 BakeToRhinoGrouped() 为两层输出 | 保持 IsOuter/IsTangent 内部分类标记，烘焙时映射：IsOuter → Patent_Silhouette（红色），其余 → Patent_Structure（黑色） |
| FIX-V6-1.6 | 恢复渲染时线框图层隐藏列表 | 隐藏 Patent_Silhouette + Patent_Structure 替代旧的 Patent_Drawings_2D + TangentEdges |
| FIX-V6-2.1 | ResolveRenderMode() 改回 Rendered 优先 | 显示模式回退链改为：Rendered → Articulated → Shaded |
| FIX-V6-2.2 | 在 Rendered 模式下启用曲面边缘线显示 | 通过 DisplayModeDescription.DisplayAttributes 设置 ShowSurfaceEdges=true，调用 UpdateDisplayMode() 提交 |

### ❌ 本期不做

| 排除项 | 原因 |
|---|---|
| ❌ 四层线型分类（Silhouette + Crease + Tangent + Visible） | V4 方案已被用户否决，维持两层输出 |
| ❌ 新增 ClassifyByBrepEdge() 方法 | s7 版本未使用该方法，恢复 s7 逻辑即可 |
| ❌ NonSilhouetteCrease 作为轮廓线判据 | s7 版本仅用 Projecting/Boundary，恢复后效果已验证 |
| ❌ 渲染材质/光照自定义 | 超出本期范围 |
| ❌ 隐藏线图层 | 用户本期未提及 |
| ❌ Rhino 8 兼容 | 当前绑定 Rhino 7 SR35 |

---

## 3. 核心场景

### 场景 A：专利工程师对照线框图审查轮廓线

> 专利工程师小张使用 AutoMake2D 生成线框图，V5 版本分类效果退步，轮廓线不完整、正切线识别不准确。修复后，分类逻辑恢复到 s7 的成熟效果——轮廓线(红色)与结构线(黑色)清晰分离，正切线被准确识别且不影响正常线组合。输出图层仅有 Patent_Silhouette 和 Patent_Structure 两层，简洁易用。

### 场景 B：专利工程师生成带边缘线的渲染效果图

> 专利工程师小王勾选渲染输出，V5 版本输出的是 Shaded 着色模式图片，缺少光照阴影效果。修复后，渲染图使用 Rendered 模式，有完整的光照/阴影/材质效果，同时曲面边缘线（棱边、折痕）清晰可见，可直接用于专利申请材料中的立体视图。

---

## 4. 功能拆解与优先级

| 功能 | 描述 | 优先级 | 负责专家 |
|---|---|---|---|
| FIX-V6-1.1 | 恢复 ComputeSingleViewEngine 单字典分类 | **Must** | code |
| FIX-V6-1.2 | 恢复 SilhouetteType 精确分发逻辑 | **Must** | code |
| FIX-V6-1.3 | 恢复 ProcessGroup 为单管线+三阶段融合 | **Must** | code |
| FIX-V6-1.4 | 恢复 PropagateUserStrings 三层标记传播 | **Must** | code |
| FIX-V6-1.5 | 重构 BakeToRhinoGrouped 两层输出映射 | **Must** | code |
| FIX-V6-1.6 | 更新渲染时线框图层隐藏列表 | **Must** | code |
| FIX-V6-2.1 | ResolveRenderMode 改回 Rendered 优先 | **Must** | code |
| FIX-V6-2.2 | Rendered 模式下启用曲面边缘线 | **Must** | code |

---

## 5. 用户故事与验收标准

### US-1：线框分类效果恢复到 s7 水平

**故事**: 作为专利工程师，我希望线框图的分类检测效果恢复到之前的好效果，轮廓线和结构线被准确识别和分离，同时输出图层简化为两层，以便我直接使用而无需在多个子图层中查找。

**验收 (Given/When/Then)**:
- Given 任意 3D 模型, When 执行 AutoMake2D, Then 分类检测结果与 s7 版本完全一致（同一模型同一视角输出相同）
- Given 任意模型执行后, When 查看图层面板, Then 仅有 Patent_Silhouette（红色）和 Patent_Structure（黑色）两个线型图层
- Given 含相切过渡面的模型, When 检查输出, Then 正切线被正确识别（IsTangent=true）且不影响正常线的组合
- Given 曲线属性检查, When 读取 UserString, Then 曲线保留 IsOuter/IsTangent/ComponentName 语义标记

### US-2：渲染图使用 Rendered 模式并显示曲面边缘线

**故事**: 作为专利工程师，我希望渲染输出图具有完整的光照/阴影/材质效果（Rendered 模式），同时可见曲面棱线和锐利边缘，以便辨识物体的几何结构。

**验收 (Given/When/Then)**:
- Given 勾选渲染输出并执行, When 检查渲染图, Then 渲染图具有光照/阴影效果（非 Shaded 着色模式）
- Given 含圆角和棱边的 3D 模型, When 执行渲染输出, Then 渲染图中可见曲面边缘线（锐利棱边和曲面交线）
- Given 纯球体模型, When 执行渲染输出, Then 渲染图中无额外边缘线（球体无结构边）

### 验收清单汇总表

| AC-ID | 验收点 (一句话, 可被自动化测试验证) | 优先级 | 关联 US |
|---|---|---|---|
| AC-1 | ComputeSingleViewEngine 使用单字典 rawGrouped，无 rawSilhouette/rawStructure | P0 | US-1 |
| AC-2 | SilhouetteType 分发逻辑为 Projecting/Boundary → IsOuter，Tangent/NonSilhouetteTangent → IsTangent | P0 | US-1 |
| AC-3 | 管线流程为 CleanRaw → 外轮廓隔离(IsOuter) → JoinTangentCurvesPrioritized(三阶段) → JoinCurves | P0 | US-1 |
| AC-4 | PropagateUserStrings 传播 IsOuter(任意源) + IsTangent(正常线优先) + ComponentName(任意源) | P0 | US-1 |
| AC-5 | BakeToRhinoGrouped 仅输出 Patent_Silhouette 和 Patent_Structure 两个图层 | P0 | US-1 |
| AC-6 | IsOuter=true 的曲线烘焙到 Patent_Silhouette 图层 | P0 | US-1 |
| AC-7 | IsOuter!=true 的曲线烘焙到 Patent_Structure 图层 | P0 | US-1 |
| AC-8 | 曲线 UserString 中无 IsSilhouette/LineType 标记 | P1 | US-1 |
| AC-9 | CaptureViewRender 中显示模式回退链为 Rendered → Articulated → Shaded | P0 | US-2 |
| AC-10 | 渲染图中具有光照/阴影效果（Rendered 模式特征） | P0 | US-2 |
| AC-11 | 含棱边的模型渲染图中可见曲面边缘线 | P0 | US-2 |
| AC-12 | DisplayModeDescription.DisplayAttributes.ShowSurfaceEdges 已被设为 true | P0 | US-2 |
| AC-13 | DisplayModeDescription.UpdateDisplayMode() 在修改属性后已被调用 | P0 | US-2 |
| AC-14 | 编译通过，0 errors | P0 | 全部 |

---

## 6. 流程 / 信息架构

### 6.1 V6 线框分类流程（恢复 s7 逻辑 + 两层输出映射）

```mermaid
flowchart TD
    A[HiddenLineDrawing.Compute<br/>IncludeTangentEdges=true] --> B[遍历 hld.Segments]
    B --> C{SilhouetteType?}
    C -- "Projecting / Boundary" --> D[标记 IsOuter=true]
    C -- "Tangent / NonSilhouetteTangent" --> E[标记 IsTangent=true]
    C -- "None + 弧线/多跨度回退" --> E
    C -- "其他" --> F[无特殊标记]
    
    D --> G[加入 rawGrouped 单字典]
    E --> G
    F --> G
    
    G --> H[单管线处理]
    H --> H1[CleanRawCurves 去重清洗]
    H1 --> H2[外轮廓隔离 IsOuter 分流]
    H2 --> H3[JoinCurves 外轮廓独立闭合]
    H3 --> H4[JoinTangentCurvesPrioritized<br/>三阶段融合]
    H4 --> H5[JoinCurves 最终闭合]
    H5 --> I[finalCleanedGrouped<br/>保留 IsOuter/IsTangent/ComponentName]
    
    I --> J[BakeToRhinoGrouped 两层映射]
    J --> J1["IsOuter=true → Patent_Silhouette（红色）"]
    J --> J2["其余 → Patent_Structure（黑色）"]
```

### 6.2 V6 渲染模式流程

```mermaid
flowchart TD
    A[CaptureViewRender] --> B[创建临时视口]
    B --> C[设置平行投影 + 相机]
    C --> D[获取模型包围盒<br/>排除 Patent_ 图层]
    D --> E[ZoomBoundingBox + 居中 + Inflate]
    E --> F["设置 Rendered 显示模式<br/>回退链: Rendered→Articulated→Shaded"]
    F --> G["启用曲面边缘线<br/>DisplayAttributes.ShowSurfaceEdges=true<br/>UpdateDisplayMode()"]
    G --> H[Redraw]
    H --> I[ViewCapture.CaptureToBitmap<br/>RasterMode=true]
    I --> J[关闭临时视口]
```

---

## 7. 风险与未决问题

| ID | 风险 | 影响 | 缓解措施 |
|---|---|---|---|
| RK-1 | DisplayModeDescription 的内置 Rendered 模式可能是 PipelineLocked=true，不允许修改 DisplayAttributes | 无法在 Rendered 模式下启用边缘线 | 方案A：克隆 Rendered 模式为自定义模式（AddDisplayMode），修改自定义模式属性；方案B：修改 Rhino 安装目录下的 Rendered.ini 配置文件；方案C：在渲染捕获时叠加绘制边缘线（DisplayConduit 方案） |
| RK-2 | ShowSurfaceEdges 属性在 Rhino 7 SR35 中可能不存在或命名不同 | 边缘线启用失败 | 查阅 RhinoCommon 7 API 确认属性名；备选属性：ShowMeshEdges、MeshSpecificAttributes 相关属性 |
| RK-3 | UpdateDisplayMode() 会全局修改显示模式，影响用户当前 Rhino 会话 | 用户其他视口的 Rendered 模式也被修改 | 修改前克隆显示模式为自定义模式，仅修改自定义模式；或捕获后恢复原始属性 |
| RK-4 | 恢复 s7 逻辑后 IsTangent 标记的曲线在 BakeToRhinoGrouped 中映射为 Patent_Structure（黑色），正切线不再有独立颜色区分 | 用户可能看不到正切线的颜色区分 | 本期可接受：用户明确要求两层（轮廓+结构），正切线属于结构线范畴；如需区分可在后续版本中增加线型样式 |

### 未决问题

1. **DisplayModeDescription.Rendered 是否 PipelineLocked？** 需在 Rhino 环境中验证。如果锁定，需采用克隆显示模式方案。
2. **ShowSurfaceEdges 属性名是否正确？** 需确认 Rhino 7 SR35 中 DisplayPipelineAttributes 的确切属性名。
3. **UpdateDisplayMode 全局影响范围？** 需确认修改是否影响用户其他视口，若影响需实现修改后恢复。

---

## 8. 与 V5 计划的差异对比

| 维度 | V5 计划（导致退步） | V6 计划（修复退步） | 变更原因 |
|---|---|---|---|
| **字典结构** | 两字典 rawSilhouette + rawStructure | **单字典 rawGrouped**（恢复 s7） | 两字典拆分导致跨字典融合失效 |
| **SilhouetteType 分发** | Projecting/Boundary/NonSilhouetteCrease → Silhouette | **Projecting/Boundary → IsOuter**（恢复 s7） | NonSilhouetteCrease 归入轮廓线导致误判；恢复原精确分发 |
| **正切线识别** | 移除（归入 Structure） | **恢复 Tangent/NonSilhouetteTangent + None 回退 → IsTangent** | 正切线识别是 s7 分类效果好的关键因素 |
| **融合策略** | JoinTangentCurvesPrioritized_Original（单阶段） | **JoinTangentCurvesPrioritized（三阶段）**（恢复 s7） | 单阶段贪心丢失正常线/正切线优先级和交叉感知 |
| **标记体系** | IsSilhouette + LineType | **IsOuter + IsTangent + ComponentName**（恢复 s7） | 三层标记支撑完整分类语义 |
| **PropagateUserStrings** | IsSilhouette(全源继承) + LineType | **IsOuter(任意源) + IsTangent(正常线优先) + ComponentName(任意源)** | 恢复正常线优先策略 |
| **BakeToRhinoGrouped** | Patent_Silhouette + Patent_Structure（按 LineType 分发） | **Patent_Silhouette + Patent_Structure（按 IsOuter 分发）** | 图层名不变，但内部分发逻辑不同：IsOuter→轮廓线，其余→结构线 |
| **渲染模式** | Shaded 优先 | **Rendered 优先** | 用户需要完整渲染效果 |
| **曲面边缘线** | TryEnableEdgeDisplay 空实现 | **DisplayAttributes.ShowSurfaceEdges + UpdateDisplayMode** | 需要实际启用边缘线显示 |

---

*第六轮修复任务计划书结束 — 待审核确认后进入执行阶段*
