# AutoMake2D 2.0 第二轮缺陷修复任务计划书

> 版本: v2.0  
> 日期: 2026-07-09  
> 状态: 待审核  
> 前置文档: `fix-task-plan.md` (v1.0, 第一轮修复), `task-plan.md` (v1.1)

---

## 1. 背景与目标

### 问题

AutoMake2D 2.0 Rhino 插件已完成第一轮缺陷修复（s7），修复了正切线识别、交叉组合逻辑和渲染输出方式三个缺陷。用户实际测试后又发现三个新缺陷：

1. **线框区分度不足** — Rhino 原生 Make2D 能系统性用黑色线（可见轮廓线）和红色线（隐藏线/被遮挡结构线）区分不同线型；当前插件只分"主图层黑色"和"正切线蓝色"两层，缺乏隐藏线图层，整体区分效果远不如原生 Make2D
2. **图片预览异常** — PictureFrame 显示为灰色矩形占位符，完全无法看到图片内容（图片引用丢失）
3. **渲染图仍为线框显示 + 物体不居中** — 渲染输出 AutoMake2D_Render.png 仍是线框显示模式截图而非真正渲染效果，且每个视图中物体不在图片中间、有大有小不居中

### 目标用户

专利工程师 / 专利律师 — 使用 AutoMake2D 生成专利申请用线框工程图和渲染图的用户

### 业务目标与可验证指标

| 缺陷 | 修复目标 | 可验证指标 |
|---|---|---|
| 缺陷V2-1 | 线框图参照 Rhino 原生 Make2D 的图层/颜色体系，系统区分可见线、隐藏线、正切线 | 生成结果包含 ≥3 个图层：可见线（黑色）、隐藏线（红色）、正切线（蓝色/灰色）；与 Rhino 原生 Make2D 同模型输出视觉对比一致度 ≥ 80% |
| 缺陷V2-2 | PictureFrame 正确显示渲染图内容 | 渲染图放入模型后，PictureFrame 显示实际图片内容而非灰色占位符；关闭并重新打开 Rhino 文件后图片仍然可见 |
| 缺陷V2-3 | 渲染输出为真正渲染效果，物体居中且大小一致 | 渲染图具有光照/材质效果（非线框截图）；所有视图中物体在画面中央且比例统一 |

---

## 2. 范围 (Scope)

### ✅ 本期做

| 编号 | 修复项 | 说明 |
|---|---|---|
| FIX-V2-1.1 | 启用 HiddenLineDrawing 隐藏线计算 | 将 `IncludeHiddenCurves = false` 改为 `true`，使 HiddenLineDrawing 计算隐藏线段 |
| FIX-V2-1.2 | 提取并处理隐藏线段 | 在 `ComputeSingleViewEngine()` 的 HLD 遍历中，同时处理 `SegmentVisibility == Hidden` 的段，标记 `IsHidden=true` |
| FIX-V2-1.3 | 新增 HiddenLines 图层（红色） | 在 `BakeToRhinoGrouped()` 中新增 `HiddenLines` 子图层，颜色为红色，隐藏线分发到此图层 |
| FIX-V2-1.4 | 隐藏线使用虚线线型 | 隐藏线图层使用虚线（Dash）线型，与可见实线视觉区分 |
| FIX-V2-1.5 | 外轮廓线粗化或独立图层 | `IsOuter` 标记的曲线烘焙到专用 `Outline` 子图层或设置更粗线宽，增强外轮廓辨识度 |
| FIX-V2-2.1 | 将 embedBitmap 改为 true | `AddPictureFrame` 的最后一个参数从 `false` 改为 `true`，图片嵌入 Rhino 文件 |
| FIX-V2-2.2 | 修复临时文件过早删除 | 图片嵌入后安全删除临时文件；或改用 `renderOutputPath`（已保存的 PNG）作为 PictureFrame 图片源，避免临时文件依赖 |
| FIX-V2-3.1 | 修复渲染显示模式 | 验证并修复 `DisplayModeDescription.FindByName("Rendered")` 的可用性，确保视口切换到渲染模式 |
| FIX-V2-3.2 | 调整视口设置顺序 | 先设置 DisplayMode → Redraw → ZoomBoundingBox → Redraw → CaptureToBitmap |
| FIX-V2-3.3 | 修复物体不居中/大小不一致 | ZoomBoundingBox 后增加边距调整，确保物体在视口中央且各视图比例统一 |
| FIX-V2-3.4 | 确保 Redraw 在关键步骤后执行 | DisplayMode 设置后、ZoomBoundingBox 后均调用 Redraw |

### ❌ 本期不做

| 排除项 | 原因 |
|---|---|
| ❌ 隐藏线自定义样式（线宽/虚线模式可调） | 仍属增强功能，本期使用固定默认样式 |
| ❌ 渲染材质/光照自定义 | 仍属原始计划的 Scope Out |
| ❌ Rhino 8 兼容 | 当前绑定 Rhino 7 SR35 |
| ❌ 渲染引擎从 ViewCapture 切换到 RenderPipeline | 改动过大，本期在现有架构内修复 |
| ❌ 多视图渲染布局自定义 | 排版逻辑已实现，本期仅修复渲染模式本身 |
| ❌ 图片文件格式选择（JPG/BMP等） | 保持 PNG 格式 |

---

## 3. 核心场景

### 场景 A：专利工程师对照隐藏线审查结构

> 专利工程师小王需要判断专利图纸是否完整展示了产品的内部结构。Rhino 原生 Make2D 输出的红色隐藏线让他一眼看到被遮挡的内部结构。修复后，AutoMake2D 同样输出红色虚线表示隐藏线，与原生 Make2D 的视觉体系一致，小王不再需要在两个工具间反复切换对比。

### 场景 B：专利律师在 Rhino 中直接预览渲染图

> 专利律师小李在 Rhino 中查看已生成的渲染图 PictureFrame，之前只看到灰色占位符。修复后，PictureFrame 直接显示渲染图片内容，小李可以在 Rhino 中确认渲染效果、调整位置，无需到外部文件管理器找 PNG。

### 场景 C：专利工程师生成标准渲染效果图

> 专利工程师小张勾选渲染输出后，得到的图片之前是线框模式截图且物体不居中。修复后，渲染输出是具有光照效果的真正渲染图，各视图中物体居中且大小一致，可直接用于专利申请材料。

---

## 4. 功能拆解与优先级

| 功能 | 描述 | 优先级 | 负责专家 |
|---|---|---|---|
| FIX-V2-1.1 | 启用 HiddenLineDrawing 隐藏线计算 | Must | code |
| FIX-V2-1.2 | 提取并标记隐藏线段 | Must | code |
| FIX-V2-1.3 | 新增 HiddenLines 图层（红色） | Must | code |
| FIX-V2-1.4 | 隐藏线使用虚线线型 | Should | code |
| FIX-V2-1.5 | 外轮廓线独立图层或粗线宽 | Could | code |
| FIX-V2-2.1 | embedBitmap 改为 true | Must | code |
| FIX-V2-2.2 | 修复临时文件删除策略 | Must | code |
| FIX-V2-3.1 | 修复渲染显示模式 | Must | code |
| FIX-V2-3.2 | 调整视口设置顺序 | Must | code |
| FIX-V2-3.3 | 修复物体不居中 | Must | code |
| FIX-V2-3.4 | 确保关键步骤后 Redraw | Should | code |

---

## 5. 用户故事与验收标准

### US-V2-1：线框图系统区分可见线/隐藏线/正切线

- **故事**: 作为专利工程师，我希望线框图参照 Rhino 原生 Make2D 的颜色/图层体系，系统区分可见轮廓线（黑色）、隐藏线（红色虚线）和正切边缘线（蓝色），以便一眼识别线型含义，不再需要与原生 Make2D 对比
- **验收 (Given/When/Then)**:
  - Given 任意 3D 模型, When 执行生成, Then 隐藏线（被遮挡的背面/内部结构线）被计算并输出到 `HiddenLines` 图层
  - Given 含内部结构的模型, When 检查图层, Then `HiddenLines` 图层包含红色曲线，`Patent_Drawings_2D` 图层仅包含可见线（黑色），`TangentEdges` 图层包含正切线（蓝色）
  - Given 隐藏线图层, When 检查线型, Then 隐藏线使用虚线（Dash）线型
  - Given 与 Rhino 原生 Make2D 同模型输出对比, When 视觉对比, Then 隐藏线位置与原生 Make2D 的红色线位置基本一致

### US-V2-2：PictureFrame 正确显示渲染图内容

- **故事**: 作为专利律师，我希望放入 Rhino 模型中的渲染图 PictureFrame 能正确显示图片内容而非灰色占位符，以便在 Rhino 中直接预览和确认渲染效果
- **验收 (Given/When/Then)**:
  - Given 勾选渲染输出并执行生成, When 在 Rhino 中查看 PictureFrame, Then PictureFrame 显示实际渲染图片内容而非灰色矩形
  - Given 渲染图已放入模型, When 保存 Rhino 文件并重新打开, Then PictureFrame 仍然显示图片内容（图片已嵌入文件）
  - Given 渲染图已嵌入, When 检查文件大小, Then Rhino 文件大小增加（包含嵌入的图片数据）

### US-V2-3：渲染输出为真正渲染效果且物体居中

- **故事**: 作为专利工程师，我希望渲染输出具有光照/材质效果的真正渲染图（非线框截图），且各视图中物体居中、大小一致，以便直接用于专利申请材料
- **验收 (Given/When/Then)**:
  - Given 勾选渲染输出并执行生成, When 检查渲染图, Then 渲染图具有光照效果（高光/阴影），非线框模式截图
  - Given 多视图渲染输出, When 检查各视图, Then 所有视图中物体位于画面中央
  - Given 多视图渲染输出, When 检查各视图, Then 同一模型在各视图中的显示大小比例一致
  - Given 渲染图生成, When 与线框截图对比, Then 渲染图不包含线框曲线

### 验收清单汇总表

| AC-ID | 验收点（一句话，可被自动化测试验证） | 优先级 | 关联 US |
|---|---|---|---|
| AC-V2-1.1 | `IncludeHiddenCurves = true` 后 HiddenLineDrawing.Compute 返回的 Segments 中包含 `SegmentVisibility == Hidden` 的段 | P0 | US-V2-1 |
| AC-V2-1.2 | 隐藏线段被标记 `IsHidden=true` 并加入曲线集合 | P0 | US-V2-1 |
| AC-V2-1.3 | BakeToRhinoGrouped 输出包含 `HiddenLines` 子图层且颜色为红色 | P0 | US-V2-1 |
| AC-V2-1.4 | HiddenLines 图层的曲线使用虚线线型 | P1 | US-V2-1 |
| AC-V2-1.5 | 外轮廓线（IsOuter=true）位于 `Outline` 子图层或线宽 ≥ 可见线 | P2 | US-V2-1 |
| AC-V2-1.6 | 可见线图层（Patent_Drawings_2D）不包含隐藏线段 | P0 | US-V2-1 |
| AC-V2-1.7 | 与 Rhino 原生 Make2D 同模型输出对比，隐藏线位置匹配度 ≥ 80% | P1 | US-V2-1 |
| AC-V2-2.1 | AddPictureFrame 的 embedBitmap 参数为 true | P0 | US-V2-2 |
| AC-V2-2.2 | 渲染输出后 PictureFrame 在 Rhino 中显示图片内容而非灰色占位符 | P0 | US-V2-2 |
| AC-V2-2.3 | 保存并重新打开 Rhino 文件后 PictureFrame 仍显示图片内容 | P0 | US-V2-2 |
| AC-V2-2.4 | 临时文件删除后 PictureFrame 不受影响（图片已嵌入） | P0 | US-V2-2 |
| AC-V2-3.1 | CaptureViewRender 使用 Rendered 显示模式（非 Shaded/Wireframe） | P0 | US-V2-3 |
| AC-V2-3.2 | 渲染输出图片具有光照/阴影效果，非线框截图 | P0 | US-V2-3 |
| AC-V2-3.3 | 各视图中物体位于画面中央（距四边距离差异 ≤ 10%） | P0 | US-V2-3 |
| AC-V2-3.4 | 同一模型在各视图中的显示大小比例一致（包围盒占比差异 ≤ 15%） | P1 | US-V2-3 |
| AC-V2-3.5 | DisplayMode 设置和 ZoomBoundingBox 后均调用了 Redraw | P1 | US-V2-3 |
| AC-V2-3.6 | 渲染捕获期间线框图层被临时隐藏，捕获后恢复 | P0 | US-V2-3 |

---

## 6. 流程 / 信息架构

### 6.1 缺陷V2-1修复 — 隐藏线提取与多图层烘焙流程

```mermaid
flowchart TD
    A[HiddenLineDrawing 投影<br/>IncludeHiddenCurves=true] --> B[遍历 hld.Segments]
    B --> C{seg.SegmentVisibility?}
    C -->|Visible| D[提取可见线段<br/>标记 IsOuter/IsTangent]
    C -->|Hidden| E[提取隐藏线段<br/>标记 IsHidden=true]
    D --> F[CleanRawCurves 去重清洗]
    E --> F
    F --> G[外轮廓特权隔离]
    G --> H[三阶段融合管线]
    H --> I[BakeToRhinoGrouped 多图层烘焙]
    I --> J[可见线 → Patent_Drawings_2D<br/>颜色: 黑色, 线型: 实线]
    I --> K[隐藏线 → HiddenLines<br/>颜色: 红色, 线型: 虚线]
    I --> L[正切线 → TangentEdges<br/>颜色: 蓝色, 线型: 实线]
    I --> M[外轮廓 → Outline<br/>颜色: 黑色, 线宽: 粗]
```

### 6.2 缺陷V2-2修复 — PictureFrame 嵌入流程

```mermaid
flowchart TD
    A[渲染位图合成完成] --> B[保存到用户指定 renderOutputPath]
    B --> C[AddPictureFrame<br/>embedBitmap=true]
    C --> D[图片数据嵌入 Rhino 文件]
    D --> E[安全删除临时文件]
    E --> F[PictureFrame 在 Rhino 中正确显示]
    F --> G[保存/重开文件后图片仍可见]
```

### 6.3 缺陷V2-3修复 — 渲染捕获流程

```mermaid
flowchart TD
    A[创建临时视口] --> B[设置平行投影 + 相机]
    B --> C[设置 Rendered 显示模式]
    C --> D[Redraw]
    D --> E[ZoomBoundingBox + 边距]
    E --> F[Redraw]
    F --> G[ViewCapture.CaptureToBitmap<br/>RasterMode=true]
    G --> H[关闭临时视口]
```

---

## 7. 风险与注意事项

| 风险 | 影响 | 缓解措施 |
|---|---|---|
| `IncludeHiddenCurves=true` 可能显著增加计算时间 | 复杂模型生成时间变长 | 隐藏线计算是 HLD 内置功能，开销可控；可在 UI 提示中说明 |
| 隐藏线与可见线可能存在微小重叠/间隙 | 视觉上有细小瑕疵 | 使用与可见线相同的 `AbsoluteTolerance`；隐藏线段也参与 CleanRawCurves 去重 |
| Rhino 7 中 `DisplayModeDescription.FindByName("Rendered")` 可能返回 null | 渲染模式无法启用 | 已有 Articulated/Shaded 回退链；若全不可用则需使用 `DisplayModeDescription.Rendered` 静态属性或其他获取方式 |
| `embedBitmap=true` 会增大 Rhino 文件体积 | 文件从 KB 级增长到 MB 级 | 可接受：渲染图通常 1-5 MB，专利文件需要自包含 |
| ZoomBoundingBox 边距调整需要经验值 | 边距过大/过小 | 默认增加 10% 边距，通过 `vp.ZoomBoundingBox(bbox, 0.1)` 或手动调整缩放比例 |
| 隐藏线可能包含大量内部投影线，导致图纸过于复杂 | 专利图纸视觉噪点多 | HiddenLines 图层默认可见但可关闭；后续可增加 UI 选项控制是否输出隐藏线 |
| PropagateUserStrings 需新增 `IsHidden` 标记传播 | 合并时隐藏线标记丢失 | IsHidden 传播策略：与 IsTangent 类似，正常线优先——仅当所有源都是隐藏线时结果才为隐藏线 |

---

## 8. 与第一轮修复（s7 / fix-task-plan.md v1.0）的差异对比

| 差异维度 | 第一轮修复 (s7) | 第二轮修复 (s8) | 关系 |
|---|---|---|---|
| **正切线处理** | 修复正切识别方案（方案A→方案B/SilhouetteType 精确判定）；修复 PropagateUserStrings 传播逻辑；三阶段融合 | 不涉及正切线识别本身，但 `IsHidden` 标记需要纳入 PropagateUserStrings 传播 | **依赖**：V2-1.2 的 IsHidden 传播建立在 s7 已修复的 PropagateUserStrings 基础上 |
| **图层体系** | 仅 2 个图层：主图层 + TangentEdges | 扩展为 ≥3 个图层：+ HiddenLines（红色）+ 可选 Outline | **扩展**：第一轮建立了图层分发机制（IsTangent 分流），本轮在此基础上增加 IsHidden 和 IsOuter 分流 |
| **隐藏线** | `IncludeHiddenCurves = false`，完全忽略隐藏线 | `IncludeHiddenCurves = true`，提取隐藏线并独立输出 | **新增**：第一轮未涉及隐藏线，本轮核心改动 |
| **PictureFrame** | 实现了 PictureFrame 输出（FIX-3.3），但 `embedBitmap=false` | 修复 `embedBitmap=true`，解决图片引用丢失 | **修补**：第一轮实现了 PictureFrame 输出机制，但遗漏了嵌入参数，本轮修正 |
| **渲染模式** | 从 Shaded 截图改为 Rendered + ViewCapture 渲染管道（FIX-3.1） | 修复渲染模式实际生效问题（设置顺序/Redraw/DisplayMode 获取） | **修补**：第一轮切换了渲染捕获 API 但实际效果仍是线框，本轮解决渲染模式真正生效 |
| **物体居中** | 使用 ZoomBoundingBox 但未考虑边距 | 增加 ZoomBoundingBox 后的边距调整 | **增强**：第一轮未涉及居中问题，本轮新增 |
| **交叉组合逻辑** | 修复交叉检测阈值、角度判断、交叉感知 | 不涉及 | **无关**：本轮三个缺陷与交叉组合无关 |

---

*第二轮修复任务计划书结束 — 待审核确认后进入执行阶段*
