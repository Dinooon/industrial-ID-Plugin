# AutoMake2D 第八轮缺陷修复任务计划书 (V8)

> **版本**: v8.0 | **日期**: 2026-07-10 | **状态**: 待审核  
> **前置文档**: `fix-task-plan-v7.md` (v7.0, 第七轮修复)  
> **当前源码**: PatentCore.cs (1355 行), PatentUiPanel.cs (214 行)  
> **核心原则**: 三个缺陷并行修复 — 白色背景 + Silhouette 图层 + 曲线连续性

---

## 1. 背景与目标

### 1.1 问题

V7 修复因 worktree 合并问题部分未生效，且 V7 仅覆盖渲染居中与白底两个缺陷。用户测试后暴露**三个严重缺陷**——背景仍非白色、Patent Silhouette 图层无数据、对角曲线多处断开。

#### 缺陷V8-1：渲染输出图片背景仍非白色

**现象**（引用图片分析结论）：
- image.png 分析：背景灰色 RGB(157,163,170)，纯白像素仅占 4.2%，与 V6/V7 目标纯白 RGB(255,255,255) 差距显著
- 用户期望：专利申请用渲染图要求纯白色背景

**根因分析**：

| # | 根因 | 方法名 | 行号 | 详细说明 |
|---|---|---|---|---|
| RC1.1 | DrawBackground 仍为 true | `CaptureViewRender()` | **第1152行** | V7 声称已改为 false，但 worktree 合并失败导致代码仍是 `captureSettings.DrawBackground = true`，Rhino 使用默认灰色背景渲染 |
| RC1.2 | 单视图直出无白底合成 | `ComposeRenderLayout()` | **第1207-1213行** | 单视图分支直接 `return enumerator.Current`，原始位图保留灰色背景，无白底合成逻辑 |
| RC1.3 | DrawAt 无白底预填充 | `DrawAt()` | **第1350-1353行** | 多视图分支虽有 `g.Clear(White)`，但 `DrawAt()` 把带深色背景的子图位图直接 `DrawImage` 贴上去，覆盖了白底 |

#### 缺陷V8-2：Patent Silhouette 图层无数据

**现象**（引用图片分析结论）：
- image_1.png 分析：所有线条均为同一种深灰色，无颜色/线型区分，说明外轮廓与内部线未分层烘焙
- 预期：外轮廓线烘焙到 `Patent_Silhouette` 图层，内部结构线烘焙到 `Patent_Structure` 图层

**根因分析**：

| # | 根因 | 方法名 | 行号 | 详细说明 |
|---|---|---|---|---|
| RC2.1 | 图层分发逻辑仍是旧版 | `BakeToRhinoGrouped()` | **第784-830行** | 当前仅按 `IsTangent` 分发到 `Patent_Drawings_2D` / `TangentEdges` 两层，不存在 `Patent_Silhouette` / `Patent_Structure` 的分发逻辑 |
| RC2.2 | IsOuter 标记从未触发 | `ComputeSingleViewEngine()` | **第351-353行** | IsOuter 仅在 `SilhouetteType.Projecting` 或 `SilhouetteType.Boundary` 时设为 true，但平行投影+封闭Brep中这两个值不出现 |
| RC2.3 | 缺少几何特征回退判定 | `ComputeSingleViewEngine()` | **第340-395行** | 无回退机制：当 SilhouetteType 不命中时，需要通过投影最大包围轮廓等几何特征判定外轮廓 |

#### 缺陷V8-3：对角曲线多处断开

**现象**（引用图片分析结论）：
- image_2.png 分析：对角曲线被分为 24 段，上半段偏移最严重（5-15 倍理论值），红色箭头标记了完全无线条的区域
- 预期：连续的轮廓线应合并为少量长曲线（理想为 1 条闭环）

**根因分析**：

| # | 根因 | 方法名 | 行号 | 详细说明 |
|---|---|---|---|---|
| RC3.1 | JoinCurves 容差过严 | `ComputeSingleViewEngine()` | **第443/469/601/712行** | 所有 `Curve.JoinCurves()` 调用均使用用户 tolerance（≈0.001），HLD 产生的线段端点浮点偏差 0.001-0.01 导致无法合并 — **最核心原因** |
| RC3.2 | 角度容差过小 | `ComputeSingleViewEngine()` | **第466行** | `JoinTangentCurvesPrioritized(list, tolerance, 0.08)` 传入 0.08 rad(4.6°)，许多本应连续的线段切线夹角略大于 4.6° 被拒绝 |
| RC3.3 | 交叉验证过度拦截 | `GetMinTangentAngle()` | **第772-776行** | 两线只要存在一种连接方式夹角 ≥80° 就整体拒绝合并，误杀了大量合法连续线段 |
| RC3.4 | CleanRawCurves 误删合法曲线 | `CleanRawCurves()` | **第508/519行** | `tolerance*0.5` 搜索半径过小 + `dMid < tolerance*0.5` 中点距离阈值过严，导致方向一致的近似重复线被误删 |
| RC3.5 | 外轮廓隔离合并容差过严 | `ComputeSingleViewEngine()` | **第443行** | 外轮廓独立 `JoinCurves(outerCurves, tolerance)` 使用原始 tolerance，端点微小偏差即无法合并 |

### 1.2 目标用户

专利工程师 / 专利律师 — 使用 AutoMake2D 生成专利申请用 2D 线框图与渲染效果图

### 1.3 业务目标与可验证指标

| 缺陷 | 修复目标 | 可验证指标 |
|---|---|---|
| 缺陷V8-1 | 渲染输出图片背景为纯白色 | 背景像素 RGB 值均为 (255,255,255)，偏差 ≤ 5；纯白像素占比 ≥ 95%；单视图和多视图输出均满足 |
| 缺陷V8-2 | 外轮廓与内部结构线分层烘焙到独立图层 | `Patent_Silhouette` 图层包含外轮廓线（IsOuter=true）；`Patent_Structure` 图层包含内部结构线（IsOuter≠true）；两层均有数据 |
| 缺陷V8-3 | 对角曲线连续合并，无明显断开 | 对角曲线段数从 24 段降至 ≤ 3 段；HLD 线段端点偏移 ≤ 合并容差；无"完全无线条"的空缺区域 |

---

## 2. 范围 (Scope)

### ✅ 本期做

| 编号 | 修复项 | 说明 |
|---|---|---|
| FIX-V8-1.1 | DrawBackground 改为 false | `CaptureViewRender()` 第1152行，确保 `DrawBackground = false` 生效 |
| FIX-V8-1.2 | 捕获后白底合成 | `CaptureViewRender()` 捕获位图后创建白底 + DrawImage 合成 |
| FIX-V8-1.3 | 单视图分支白底处理 | `ComposeRenderLayout()` 第1207-1213行，单视图分支不再直接返回原始位图，先白底合成 |
| FIX-V8-1.4 | DrawAt 白底预填充 | `DrawAt()` 第1350-1353行，DrawImage 前先 FillRectangle(White) |
| FIX-V8-2.1 | BakeToRhinoGrouped 按 IsOuter 分发 | `BakeToRhinoGrouped()` 第784-830行，曲线按 IsOuter 标记分发到 `Patent_Silhouette` / `Patent_Structure` 图层 |
| FIX-V8-2.2 | IsOuter 判定增加几何特征回退 | `ComputeSingleViewEngine()` 第340-395行，当 SilhouetteType 不命中时，通过投影最大包围轮廓判定外轮廓 |
| FIX-V8-2.3 | 清理旧图层逻辑 | 移除 TangentEdges 图层分发，统一为 Silhouette/Structure 二分法 |
| FIX-V8-3.1 | JoinCurves 容差放宽 | 第443/469/601/712行所有 JoinCurves 调用容差从 tolerance 放宽至 tolerance*50 |
| FIX-V8-3.2 | 角度容差放宽 | 第466行 angleTolRad 从 0.08 放宽至 0.15 rad(≈8.6°) |
| FIX-V8-3.3 | 交叉验证调整 | 第772行 nearVerticalRad 从 80°(1.396 rad) 提高至 89°(1.553 rad) |
| FIX-V8-3.4 | CleanRawCurves 去重放宽+方向验证 | 第508行搜索半径从 tolerance*0.5 放大至 tolerance*5；第519行中点距离从 tolerance*0.5 放大至 tolerance*2；增加方向一致性验证 |
| FIX-V8-3.5 | 外轮廓隔离合并容差放大 | 第443行外轮廓独立 JoinCurves 时使用 tolerance*50 |

### ❌ 本期不做

| 排除项 | 原因 |
|---|---|
| ❌ 修改渲染材质/光照/阴影效果 | 本期聚焦背景色与图层分发 |
| ❌ 修改 HLD 参数（IncludeTangentEdges/Seams） | 根因不在 HLD 参数，而在后处理容差 |
| ❌ 修改视口居中逻辑 | V7 的居中修复本期保留不变 |
| ❌ 修改输出图片分辨率 | 1200×900 满足需求 |
| ❌ 新增 UI 控件 | 所有修复均为内部逻辑调整 |
| ❌ 修改 Curve.JoinCurves 的 RhinoCommon 实现 | 使用放宽容差调用，不修改底层 |

---

## 3. 核心场景

### 场景 A：专利工程师输出渲染图（白底要求）

> 专利工程师小张勾选"渲染输出"并选择 Front 视图。当前输出背景灰色 RGB(157,163,170)。修复后，DrawBackground=false 避免灰色渲染，白底合成确保输出纯白背景 RGB(255,255,255)，可直接用于专利申请材料。

### 场景 B：专利工程师查看分层线框图（Silhouette/Structure 分离）

> 专利工程师小李执行 AutoMake2D 后查看图层。当前 Patent_Silhouette 图层无数据，所有线条都在同一灰色图层。修复后，外轮廓线烘焙到 Patent_Silhouette（黑色粗线），内部结构线烘焙到 Patent_Structure（灰色细线），工程师可独立控制显示和打印样式。

### 场景 C：专利工程师审核对角曲线连续性

> 专利工程师小王审核 IsoFront 视图的线框图。当前对角曲线被分为 24 段且有多处空白区。修复后，容差放宽使 HLD 线段能正确合并，对角曲线段数降至 ≤3 段，无空白区，可直接用于专利图纸。

---

## 4. 功能拆解与优先级

| 功能 | 描述 | 优先级 | 负责专家 |
|---|---|---|---|
| FIX-V8-1.1 | DrawBackground=false | **Must** | code |
| FIX-V8-1.2 | 捕获后白底合成 | **Must** | code |
| FIX-V8-1.3 | 单视图分支白底处理 | **Must** | code |
| FIX-V8-1.4 | DrawAt 白底预填充 | **Must** | code |
| FIX-V8-2.1 | BakeToRhinoGrouped IsOuter 分发 | **Must** | code |
| FIX-V8-2.2 | IsOuter 几何特征回退判定 | **Must** | code |
| FIX-V8-2.3 | 清理旧 TangentEdges 图层逻辑 | **Should** | code |
| FIX-V8-3.1 | JoinCurves 容差放宽至 tolerance*50 | **Must** | code |
| FIX-V8-3.2 | 角度容差放宽至 0.15 rad | **Must** | code |
| FIX-V8-3.3 | 交叉验证 nearVerticalRad 调至 89° | **Must** | code |
| FIX-V8-3.4 | CleanRawCurves 去重放宽+方向验证 | **Must** | code |
| FIX-V8-3.5 | 外轮廓隔离合并容差放大 | **Should** | code |

---

## 5. 用户故事与验收标准

### US-1：渲染输出图片背景纯白

**故事**: 作为专利工程师，我希望渲染输出图片的背景为纯白色 RGB(255,255,255)，无论单视图还是多视图模式，以便图片符合专利申请材料的标准格式要求。

**验收 (Given/When/Then)**:
- Given 勾选渲染输出并执行, When 检查单视图输出图片, Then 背景像素 RGB 值均为 (255,255,255)，偏差 ≤ 5
- Given 勾选六视图渲染输出并执行, When 检查排版图片, Then 整体背景为白色（含子图间隙区域和子图内部非物件区域）
- Given DrawBackground=false 生效, When 检查捕获位图, Then 位图物件区域外为透明/非灰色，白底合成后整体白色

### US-2：外轮廓与内部结构线分层烘焙

**故事**: 作为专利工程师，我希望外轮廓线自动烘焙到 Patent_Silhouette 图层、内部结构线烘焙到 Patent_Structure 图层，以便在专利图纸中独立控制线型和打印样式。

**验收 (Given/When/Then)**:
- Given 任意 3D 模型, When 执行 AutoMake2D, Then Patent_Silhouette 图层存在且包含外轮廓曲线（IsOuter=true 的曲线）
- Given 任意 3D 模型, When 执行 AutoMake2D, Then Patent_Structure 图层存在且包含内部结构曲线
- Given 封闭 Brep 且 SilhouetteType 不命中, When 执行 AutoMake2D, Then IsOuter 通过几何特征回退判定正确标记外轮廓

### US-3：对角曲线连续合并无断开

**故事**: 作为专利工程师，我希望对角方向的轮廓线连续无断开，合并后的段数 ≤3，以便专利图纸中线条完整可读。

**验收 (Given/When/Then)**:
- Given 任意含对角轮廓的 3D 模型, When 执行 AutoMake2D, Then 对角曲线段数 ≤ 3（vs 当前 24 段）
- Given HLD 线段端点浮点偏差 0.001-0.01, When JoinCurves 使用 tolerance*50 容差, Then 端点偏差在容差内的线段正确合并
- Given 两条线段切线夹角 5°-8°, When 角度容差 0.15 rad, Then 正确合并而非拒绝

### 验收清单汇总表

| AC-ID | 验收点 (一句话, 可被自动化测试验证) | 优先级 | 关联 US |
|---|---|---|---|
| AC-1 | CaptureViewRender 第1152行 captureSettings.DrawBackground = false | P0 | US-1 |
| AC-2 | CaptureViewRender 返回的位图经过白底合成（g.Clear(White) + DrawImage） | P0 | US-1 |
| AC-3 | ComposeRenderLayout 第1207-1213行单视图分支返回的位图有白色背景 | P0 | US-1 |
| AC-4 | DrawAt 第1350行在 DrawImage 前执行 g.FillRectangle(White) | P0 | US-1 |
| AC-5 | 单视图输出图片背景像素 RGB 平均值与 (255,255,255) 偏差 ≤ 5 | P0 | US-1 |
| AC-6 | 多视图排版图片子图间隙区域和子图非物件区域背景为白色 | P0 | US-1 |
| AC-7 | BakeToRhinoGrouped 第784行 IsOuter=true 的曲线烘焙到 Patent_Silhouette 图层 | P0 | US-2 |
| AC-8 | BakeToRhinoGrouped IsOuter≠true 的曲线烘焙到 Patent_Structure 图层 | P0 | US-2 |
| AC-9 | Patent_Silhouette 图层和 Patent_Structure 图层均存在且有数据 | P0 | US-2 |
| AC-10 | ComputeSingleViewEngine 第340行 IsOuter 判定包含几何特征回退（投影凸包边界判定） | P0 | US-2 |
| AC-11 | 第443/469/601/712行所有 Curve.JoinCurves 调用容差为 tolerance*50 而非 tolerance | P0 | US-3 |
| AC-12 | 第466行 JoinTangentCurvesPrioritized 角度容差为 0.15 rad 而非 0.08 | P0 | US-3 |
| AC-13 | 第772行 GetMinTangentAngle 中 nearVerticalRad 为 89°(1.553 rad) 而非 80°(1.396 rad) | P0 | US-3 |
| AC-14 | 第508行 CleanRawCurves 搜索半径为 tolerance*5 且第519行中点距离阈值为 tolerance*2 | P0 | US-3 |
| AC-15 | CleanRawCurves 去重判断增加方向一致性验证（端点顺序匹配） | P1 | US-3 |
| AC-16 | 第443行外轮廓独立 JoinCurves 容差为 tolerance*50 | P1 | US-3 |
| AC-17 | 编译通过，0 errors | P0 | 全部 |

---

## 6. 流程 / 信息架构

### 6.1 V8 渲染白底流程（三层防护）

```mermaid
flowchart TD
    A[CaptureViewRender] --> B[创建临时视口]
    B --> C[设置相机 + Rendered 模式]
    C --> D[ZoomBoundingBox 居中]
    D --> E["ViewCapture.CaptureToBitmap<br/>【V8修复】DrawBackground = false"]
    E --> F["【V8修复】白底合成<br/>new Bitmap → g.Clear(White) → g.DrawImage → Dispose 原始"]
    F --> G{视图数量?}
    G -- "1" --> H["【V8修复】ComposeRenderLayout 单视图<br/>再次白底合成（双重保险）"]
    G -- ">1" --> I["多视图排版<br/>g.Clear(White) 画布"]
    I --> J["【V8修复】DrawAt 白底预填充<br/>g.FillRectangle(White) → g.DrawImage"]
    H --> K[返回白底位图]
    J --> K
```

### 6.2 V8 图层烘焙分发流程

```mermaid
flowchart TD
    A[BakeToRhinoGrouped] --> B["创建 Patent_Silhouette 图层<br/>黑色"]
    A --> C["创建 Patent_Structure 图层<br/>灰色"]
    D["遍历 viewsData 中每条曲线"] --> E{"IsOuter == true?"}
    E -- "Yes" --> F["烘焙到 Patent_Silhouette 图层"]
    E -- "No" --> G["烘焙到 Patent_Structure 图层"]
    F --> H["按 componentName_viewName 分组"]
    G --> H
```

### 6.3 V8 IsOuter 判定流程（含几何回退）

```mermaid
flowchart TD
    A["HLD 段处理"] --> B{"SilhouetteType ==<br/>Projecting 或 Boundary?"}
    B -- "Yes" --> C["isOuterContour = true"]
    B -- "No" --> D{"几何特征回退判定"}
    D --> E["收集同组件所有可见线段"]
    E --> F["计算投影后的凸包/包围轮廓"]
    F --> G{"当前线段在凸包边界上?"}
    G -- "Yes" --> C
    G -- "No" --> H["isOuterContour = false"]
```

### 6.4 V8 曲线合并容差策略

```mermaid
flowchart LR
    subgraph "V7（过严）"
        A1["JoinCurves(tolerance≈0.001)"] --> B1["角度 0.08 rad(4.6°)"]
        B1 --> C1["nearVertical 80°"]
        C1 --> D1["❌ 24段断开"]
    end
    subgraph "V8（放宽）"
        A2["JoinCurves(tolerance×50≈0.05)"] --> B2["角度 0.15 rad(8.6°)"]
        B2 --> C2["nearVertical 89°"]
        C2 --> D2["✅ ≤3段连续"]
    end
```

---

## 7. 风险与注意事项

| ID | 风险 | 影响 | 缓解措施 |
|---|---|---|---|
| RK-1 | tolerance*50 合并容差可能将本不应合并的线段误合并 | 内部结构线被错误合并到外轮廓 | 合并后通过 PropagateUserStrings 保留 IsOuter 标记；IsOuter 线段优先独立合并（Step 1.5 隔离） |
| RK-2 | 角度容差 0.15 rad(8.6°) 可能将微弯转角误判为连续 | 转角处应断开的线被连续合并 | 8.6° 仍远小于常见直角(90°)和锐角(30°)，风险可控；可后续微调 |
| RK-3 | 几何特征回退判定的凸包计算性能 | 大模型多视图时凸包计算耗时 | 使用 2D 投影后的 Andrew's monotone chain 算法，O(n log n) 复杂度可接受 |
| RK-4 | DrawBackground=false 后 Alpha 通道可能导致白底合成边缘伪影 | 渲染图物件边缘有白边或锯齿 | 设置 CompositingMode = SourceOver + HighQualityBicubic 插值 |
| RK-5 | DrawAt 白底预填充对已有白底子图为空操作，但增加 FillRectangle 调用 | 极微小的性能开销 | 可忽略不计，安全性优先 |
| RK-6 | 旧 TangentEdges 图层残留 | 用户打开旧文件时出现已不使用的图层 | 仅在新建时不再创建 TangentEdges；不清除已有图层 |

### 未决问题

1. **几何特征回退判定的精确算法**：使用凸包边界还是包围盒边界？凸包更精确但计算量更大，建议先用凸包，如性能不足降级为包围盒。
2. **tolerance*50 是否为最优倍率**：用户 tolerance≈0.001 时 tolerance*50=0.05，覆盖 HLD 浮点偏差 0.001-0.01。如合并后仍有断开，可进一步调至 tolerance*100。
3. **nearVerticalRad 89° 是否过于宽松**：89° 几乎允许任何方向的线段合并，仅排除真正垂直交叉的线。如出现误合并，可回调至 85°。

---

## 8. 与 V7 计划的差异对比

| 维度 | V7 计划 | V8 计划 | 变更原因 |
|---|---|---|---|
| **缺陷覆盖** | 2 个缺陷（居中+白底） | **3 个缺陷（白底+图层+曲线连续性）** | V7 未覆盖图层分发和曲线合并问题 |
| **白底修复** | DrawBackground=false + 捕获后白底合成（未生效） | **DrawBackground=false + 捕获后白底合成 + 单视图白底 + DrawAt 白底预填充** | V7 修复因 worktree 合并失败未生效；V8 增加三层防护 |
| **DrawAt** | V7 不修改 DrawAt | **V8 在 DrawAt 中增加 FillRectangle(White)** | 多视图子图灰背景覆盖画布白底的问题需在绘制层面解决 |
| **图层分发** | V7 仅按 IsTangent 分发到 TangentEdges | **V8 按 IsOuter 分发到 Patent_Silhouette / Patent_Structure** | 用户需求是外轮廓/内部结构分层，而非正切/非正切分层 |
| **IsOuter 判定** | V7 仅依赖 SilhouetteType | **V8 增加几何特征回退（投影凸包边界判定）** | 平行投影+封闭Brep 中 SilhouetteType.Projecting/Boundary 不命中 |
| **JoinCurves 容差** | V7 使用用户 tolerance(≈0.001) | **V8 使用 tolerance*50(≈0.05)** | HLD 浮点偏差 0.001-0.01 无法在 tolerance=0.001 下合并 |
| **角度容差** | V7 使用 0.08 rad(4.6°) | **V8 使用 0.15 rad(8.6°)** | 4.6° 过严，5°-8° 夹角的合法连续线段被拒绝 |
| **交叉验证** | V7 nearVerticalRad=80° | **V8 nearVerticalRad=89°** | 80° 过严，两线只要有一种连接方式 ≥80° 就整体拒绝 |
| **CleanRawCurves** | V7 搜索半径 tolerance*0.5，中点阈值 tolerance*0.5 | **V8 搜索半径 tolerance*5，中点阈值 tolerance*2，增加方向验证** | 去重阈值过严导致近似重复线被误删 |
| **居中修复** | V7 核心修复 | **V8 保留不变** | 居中逻辑已在 V7 正确设计，仅需确保 V8 代码中不回退 |

---

*第八轮修复任务计划书结束 — 待审核确认后进入执行阶段*
