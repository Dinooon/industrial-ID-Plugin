# AutoMake2D 2.0 缺陷修复执行计划书

> 版本: v1.0  
> 日期: 2026-07-09  
> 状态: 待审核  
> 前置文档: `fix-task-plan.md`, `execution-plan.md` (v1.1)

---

## 1. 技术方案总览

三个缺陷的修复集中在 `PatentCore.cs`（核心引擎），其中缺陷3涉及 `PatentUiPanel.cs`（UI 面板）的少量调整。整体策略为**最小侵入修复**——在已实现的功能基础上修正逻辑错误和切换实现方案，不重构管线架构。

| 缺陷 | 涉及文件 | 改动性质 |
|---|---|---|
| 缺陷1：正切线区分与组合优先级 | `PatentCore.cs` | 修改正切识别逻辑（方案A→方案B）；修复传播逻辑；重构融合为三阶段 |
| 缺陷2：多线交叉组合逻辑错误 | `PatentCore.cs` | 修改交叉检测阈值；修复角度判断漏洞；增强阶段2交叉感知 |
| 缺陷3：渲染输出方式错误 | `PatentCore.cs` | 修改渲染捕获方式；增加图层隐藏/恢复；替换输出方式为 PictureFrame |

---

## 2. 缺陷1 — 技术修复方案：正切线区分与组合优先级

### 2.1 FIX-1.1：正切识别方案切换（方案A → 方案B）

**改动文件**: `PatentCore.cs` — `ComputeSingleViewEngine()` 方法，第 280~310 行区域

**当前代码**（第 296~299 行）:
```csharp
if (hldCurve.SilhouetteType == SilhouetteType.None)
{
    isTangentEdge = true;
}
```

**问题**: `SilhouetteType.None` 过于宽泛，许多非正切边缘的内部投影线段也具有此类型，导致误标记。

**修复方案**: 切换为方案B，通过 `BrepEdge.EdgeConvexity` 精确识别正切边缘。

**伪代码**:
```csharp
// 替换方案A，启用方案B
if (!isOuterContour && hldObj != null && hldObj.Geometry is Brep brep)
{
    // 获取 HLD 曲线对应的源 Brep 边
    // 策略：通过曲线与 Brep 边的空间关系匹配
    // 1. 获取 hldCurve 在 3D 空间中的对应几何
    // 2. 遍历 Brep.Edges，检查 EdgeConvexity
    // 3. 若任一边的 EdgeConvexity == EdgeConvexity.Tangent 且空间位置与 hldCurve 接近，则标记
    
    foreach (var edge in brep.Edges)
    {
        if (edge.EdgeConvexity == EdgeConvexity.Tangent)
        {
            // 验证：hldCurve 的投影是否对应此边
            // 简化策略：若 Brep 中存在任何 Tangent 边，且当前 hldCurve 
            //           的 SilhouetteType 不是 Projecting/Boundary/Crease，
            //           则标记为正切边缘
            if (hldCurve.SilhouetteType != SilhouetteType.Projecting &&
                hldCurve.SilhouetteType != SilhouetteType.Boundary &&
                hldCurve.SilhouetteType != SilhouetteType.Crease)
            {
                isTangentEdge = true;
                break;
            }
        }
    }
}
```

**关键验证点**:
- `hldCurve.SourceObject` → `Geometry` 转 `Brep` 是否可靠
- `Brep.Edges` 遍历开销是否可接受（通常 < 1000 边，可接受）
- 若 SourceObject 链路不可达，回退策略：通过曲线端点处相邻面法线夹角推断（法线夹角接近 0° 则为相切连接）

**回退方案**: 若方案B验证失败（SourceObject 不可获取 BrepEdge），使用"双重验证"策略：
```csharp
// 回退方案：SilhouetteType.None + 曲线几何特征（弧线、且曲率连续）
if (hldCurve.SilhouetteType == SilhouetteType.None && !isOuterContour)
{
    // 附加验证：正切边缘通常是弧线且曲率半径 > 0
    if (curve.IsArc() || curve.SpanCount > 1)
    {
        isTangentEdge = true;
    }
}
```

### 2.2 FIX-1.2：修复 PropagateUserStrings 传播逻辑

**改动文件**: `PatentCore.cs` — `PropagateUserStrings()` 方法，第 790~805 行

**当前代码**（第 793~805 行）:
```csharp
private static void PropagateUserStrings(Curve[] sources, Curve target)
{
    string[] knownKeys = { "IsOuter", "IsTangent", "ComponentName" };
    foreach (var key in knownKeys)
    {
        foreach (var src in sources)
        {
            if (src == null) continue;
            var val = src.GetUserString(key);
            if (!string.IsNullOrEmpty(val))
            {
                target.SetUserString(key, val);
                break;  // 找到第一个就停止
            }
        }
    }
}
```

**问题**: 对 `IsTangent` 标记采用"任意源带标记则继承"策略。当正常线（IsTangent 未设或为 false）与正切线（IsTangent=true）合并时，结果继承 IsTangent=true，导致正常线"退化"为正切线。

**修复方案**: 对 `IsTangent` 标记采用"正常线优先"策略——仅当所有源曲线都是正切线时，结果才为正切线。

**伪代码**:
```csharp
private static void PropagateUserStrings(Curve[] sources, Curve target)
{
    // IsOuter: 任意源带标记则继承（保持原有逻辑）
    foreach (var src in sources)
    {
        if (src == null) continue;
        var val = src.GetUserString("IsOuter");
        if (!string.IsNullOrEmpty(val))
        {
            target.SetUserString("IsOuter", val);
            break;
        }
    }
    
    // IsTangent: 正常线优先 — 仅当所有源都是正切线时，结果才为正切线
    bool allTangent = true;
    bool anyTangent = false;
    foreach (var src in sources)
    {
        if (src == null) continue;
        bool isTangent = src.GetUserString("IsTangent") == "true";
        if (!isTangent) allTangent = false;
        else anyTangent = true;
    }
    if (allTangent && anyTangent)
    {
        target.SetUserString("IsTangent", "true");
    }
    // 否则不设置 IsTangent（默认即为非正切）
    
    // ComponentName: 任意源带标记则继承（保持原有逻辑）
    foreach (var src in sources)
    {
        if (src == null) continue;
        var val = src.GetUserString("ComponentName");
        if (!string.IsNullOrEmpty(val))
        {
            target.SetUserString("ComponentName", val);
            break;
        }
    }
}
```

**影响范围**: 所有调用 `PropagateUserStrings` 的地方均受益，无需逐处修改：
- 第 365 行：外轮廓合并传播
- 第 391 行：常规 JoinCurves 传播
- 第 498 行：阶段1交叉感知合并传播
- 第 561 行：阶段2全局贪心合并传播

### 2.3 FIX-1.3：实现分层组合优先级（三阶段融合）

**改动文件**: `PatentCore.cs` — `JoinTangentCurvesPrioritized()` 方法，第 456~515 行

**当前逻辑**（两阶段）:
```
阶段1: 交叉节点处相切线局部合并
阶段2: 全局贪心融合（不区分正常线/相切线）
```

**问题**: 两个阶段都不区分正常线与相切线，未实现"先组合正常线、再组合相切线"的优先级。

**修复方案**: 重构为三阶段融合管线。

**伪代码**:
```csharp
private static List<Curve> JoinTangentCurvesPrioritized(List<Curve> curves, double tolerance, double angleTolRad)
{
    if (curves.Count < 2) return curves;

    // === 阶段0: 仅正常线互相组合 ===
    // 将曲线分为正常线池和相切线池
    var normalCurves = new List<Curve>();
    var tangentCurves = new List<Curve>();
    foreach (var c in curves)
    {
        if (c.GetUserString("IsTangent") == "true")
            tangentCurves.Add(c);
        else
            normalCurves.Add(c);
    }

    // 正常线之间进行全局贪心融合
    var mergedNormals = JoinTangentCurvesPrioritized_Original(normalCurves, tolerance, angleTolRad);

    // === 阶段1: 交叉节点处相切线局部合并 ===
    // 将阶段0结果与相切线合并到候选池
    var pool = new List<Curve>(mergedNormals);
    pool.AddRange(tangentCurves);

    var junctions = DetectJunctionPoints(pool, ComputeJunctionDistTol(tolerance, pool));
    var mergedIndices = new HashSet<int>();
    var stage1Results = new List<Curve>();

    foreach (var junction in junctions)
    {
        // 仅在交叉节点处优先合并相切线对
        var tangentPairs = new List<MergeCandidate>();
        for (int a = 0; a < junction.CurveIndices.Count; a++)
        {
            for (int b = a + 1; b < junction.CurveIndices.Count; b++)
            {
                int ci = junction.CurveIndices[a];
                int cj = junction.CurveIndices[b];
                if (mergedIndices.Contains(ci) || mergedIndices.Contains(cj)) continue;

                // 优先合并：至少一条是相切线
                bool ciTangent = pool[ci].GetUserString("IsTangent") == "true";
                bool cjTangent = pool[cj].GetUserString("IsTangent") == "true";
                if (!ciTangent && !cjTangent) continue;  // 跳过正常线对（已在阶段0处理）

                if (GetMinTangentAngle(pool[ci], pool[cj], tolerance, out double actualAngle))
                {
                    if (actualAngle <= angleTolRad)
                    {
                        tangentPairs.Add(new MergeCandidate { Index1 = ci, Index2 = cj, Angle = actualAngle });
                    }
                }
            }
        }

        tangentPairs.Sort((a, b) => a.Angle.CompareTo(b.Angle));
        foreach (var pair in tangentPairs)
        {
            if (mergedIndices.Contains(pair.Index1) || mergedIndices.Contains(pair.Index2)) continue;
            Curve[] res = Curve.JoinCurves(new Curve[] { pool[pair.Index1], pool[pair.Index2] }, tolerance);
            if (res != null && res.Length == 1)
            {
                PropagateUserStrings(new[] { pool[pair.Index1], pool[pair.Index2] }, res[0]);
                stage1Results.Add(res[0]);
                mergedIndices.Add(pair.Index1);
                mergedIndices.Add(pair.Index2);
            }
        }
    }

    var remaining = new List<Curve>();
    for (int i = 0; i < pool.Count; i++)
    {
        if (!mergedIndices.Contains(i)) remaining.Add(pool[i]);
    }
    remaining.AddRange(stage1Results);

    // === 阶段2: 全局贪心融合（带交叉感知，见 FIX-2.3） ===
    return JoinTangentCurvesPrioritized_Original(remaining, tolerance, angleTolRad);
}
```

**关键设计决策**:
- 阶段0 仅处理正常线之间的组合，确保正常线先形成连续链路
- 阶段1 仅在交叉节点处合并涉及相切线的候选对，跳过纯正常线对
- 阶段2 对剩余所有线执行全局贪心融合（正常线已组合完毕，此阶段主要处理相切线与正常线的最终合并）

---

## 3. 缺陷2 — 技术修复方案：多线交叉组合逻辑错误

### 3.1 FIX-2.1：修复 DetectJunctionPoints 的 distTol 参数

**改动文件**: `PatentCore.cs` — `DetectJunctionPoints()` 方法（第 738~780 行），以及调用处（第 461 行）

**当前代码**（第 461 行调用处）:
```csharp
var junctions = DetectJunctionPoints(curves, tolerance);
```

**问题**: 用用户的 `tolerance`（0.001/0.01/0.1）作为交叉检测半径。tolerance 是几何精度容差，对交叉检测而言可能太小（高精度0.001导致漏检）或太大（低精度0.1导致误检）。

**修复方案**: 新增自适应阈值计算方法 `ComputeJunctionDistTol()`。

**伪代码**:
```csharp
/// <summary>
/// 基于曲线集合的包围盒对角线长度自适应计算交叉检测半径
/// </summary>
private static double ComputeJunctionDistTol(double baseTolerance, List<Curve> curves)
{
    // 计算所有曲线端点的包围盒
    BoundingBox bbox = BoundingBox.Empty;
    foreach (var c in curves)
    {
        if (c == null) continue;
        bbox.Union(c.PointAtStart);
        bbox.Union(c.PointAtEnd);
    }
    
    if (!bbox.IsValid) return baseTolerance * 100;  // 安全回退
    
    double diagonal = bbox.Diagonal.Length;
    
    // 自适应阈值：包围盒对角线 × 0.005
    // 但不小于 10 × baseTolerance（确保精度容差下也能检测）
    // 且不大于包围盒对角线 × 0.02（避免过度检测）
    double adaptiveTol = diagonal * 0.005;
    double minTol = baseTolerance * 10;
    double maxTol = diagonal * 0.02;
    
    return Math.Max(minTol, Math.Min(adaptiveTol, maxTol));
}
```

**改动点**: 将 `JoinTangentCurvesPrioritized()` 中第 461 行的 `DetectJunctionPoints(curves, tolerance)` 改为 `DetectJunctionPoints(curves, ComputeJunctionDistTol(tolerance, curves))`。

### 3.2 FIX-2.2：修复 GetMinTangentAngle 角度判断漏洞

**改动文件**: `PatentCore.cs` — `GetMinTangentAngle()` 方法，第 579~596 行

**当前代码**:
```csharp
private static bool GetMinTangentAngle(Curve c1, Curve c2, double tolerance, out double minAngle)
{
    minAngle = double.MaxValue;
    bool isConnected = false;

    Point3d s1 = c1.PointAtStart; Point3d e1 = c1.PointAtEnd;
    Point3d s2 = c2.PointAtStart; Point3d e2 = c2.PointAtEnd;

    Vector3d tS1 = c1.TangentAtStart; Vector3d tE1 = c1.TangentAtEnd;
    Vector3d tS2 = c2.TangentAtStart; Vector3d tE2 = c2.TangentAtEnd;

    if (e1.DistanceTo(s2) <= tolerance) { double a = Vector3d.VectorAngle(tE1, tS2); if (a < minAngle) { minAngle = a; isConnected = true; } }
    if (e1.DistanceTo(e2) <= tolerance) { double a = Vector3d.VectorAngle(tE1, -tE2); if (a < minAngle) { minAngle = a; isConnected = true; } }
    if (s1.DistanceTo(s2) <= tolerance) { double a = Vector3d.VectorAngle(-tS1, tS2); if (a < minAngle) { minAngle = a; isConnected = true; } }
    if (s1.DistanceTo(e2) <= tolerance) { double a = Vector3d.VectorAngle(-tS1, -tE2); if (a < minAngle) { minAngle = a; isConnected = true; } }

    return isConnected;
}
```

**问题**: 取4种端点连接方式中的**最小**夹角。如果两条几乎垂直的线在某种连接方式下恰好夹角较小（例如 e1→s2 夹角 5° 但实际几何上几乎垂直），会被误判为"可合并"。

**修复方案**: 增加"最大夹角交叉验证"——仅当最小夹角与次小夹角差距不太大时，才认定为有效连接；同时增加绝对上限检查。

**伪代码**:
```csharp
private static bool GetMinTangentAngle(Curve c1, Curve c2, double tolerance, out double minAngle)
{
    minAngle = double.MaxValue;
    bool isConnected = false;

    Point3d s1 = c1.PointAtStart; Point3d e1 = c1.PointAtEnd;
    Point3d s2 = c2.PointAtStart; Point3d e2 = c2.PointAtEnd;

    Vector3d tS1 = c1.TangentAtStart; Vector3d tE1 = c1.TangentAtEnd;
    Vector3d tS2 = c2.TangentAtStart; Vector3d tE2 = c2.TangentAtEnd;

    // 收集所有有效连接方式的夹角
    var angles = new List<double>();

    if (e1.DistanceTo(s2) <= tolerance) angles.Add(Vector3d.VectorAngle(tE1, tS2));
    if (e1.DistanceTo(e2) <= tolerance) angles.Add(Vector3d.VectorAngle(tE1, -tE2));
    if (s1.DistanceTo(s2) <= tolerance) angles.Add(Vector3d.VectorAngle(-tS1, tS2));
    if (s1.DistanceTo(e2) <= tolerance) angles.Add(Vector3d.VectorAngle(-tS1, -tE2));

    if (angles.Count == 0) return false;

    // 取最小夹角作为主判据
    minAngle = angles.Min();

    // 【新增】交叉验证：仅当存在多个端点连接方式时，
    // 检查最大夹角与最小夹角的差距，排除"单端巧合"的垂直误判
    if (angles.Count >= 2)
    {
        double maxAngle = angles.Max();
        // 若最大夹角 ≥ 80° (≈1.4 rad) 且最小夹角 < 阈值，
        // 说明两条线在几何上趋近垂直，某端点的"小夹角"是巧合
        const double nearVerticalRad = 80.0 * Math.PI / 180.0;  // ≈1.396 rad
        if (maxAngle >= nearVerticalRad)
        {
            // 两条线趋近垂直，不应合并
            return false;
        }
    }

    // 【新增】绝对上限：最小夹角超过 60° 也不合并
    const double absoluteMaxAngle = 60.0 * Math.PI / 180.0;  // ≈1.047 rad
    if (minAngle > absoluteMaxAngle) return false;

    return true;
}
```

**关键设计决策**:
- 增加 `nearVerticalRad` 检查（80°）：两条线若在某端点看似夹角小但整体趋近垂直，不合并
- 增加绝对上限 60°：超过此角度的线对不论何种连接方式都不合并（原阈值 0.08 rad ≈ 4.6° 已很严格，但此上限防止极端情况）
- 仅当存在 ≥2 种端点连接方式时才做交叉验证（避免误杀仅单端连接的合法情况）

### 3.3 FIX-2.3：为阶段2全局贪心增加交叉感知

**改动文件**: `PatentCore.cs` — `JoinTangentCurvesPrioritized_Original()` 方法，第 519~575 行

**当前逻辑**: 阶段2全局贪心完全不考虑交叉拓扑，仅按角度排序逐对合并。

**修复方案**: 在阶段2合并前，预计算交叉节点集合；合并候选对时，若两条线都属于同一交叉节点且合并夹角 > 交叉感知阈值，跳过合并。

**伪代码**（在 `JoinTangentCurvesPrioritized_Original` 方法开头增加）:
```csharp
private static List<Curve> JoinTangentCurvesPrioritized_Original(List<Curve> curves, double tolerance, double angleTolRad)
{
    if (curves.Count < 2) return curves;
    
    // 【新增】预计算交叉节点集合，用于阶段2的交叉感知
    var junctionCurves = new HashSet<int>();  // 参与交叉的曲线索引
    var junctions = DetectJunctionPoints(curves, ComputeJunctionDistTol(tolerance, curves));
    foreach (var j in junctions)
    {
        foreach (var idx in j.CurveIndices)
            junctionCurves.Add(idx);
    }

    // ... 原有全局贪心逻辑 ...
    // 在候选对筛选循环中增加交叉感知条件:
    
    for (int i = 0; i < pool.Count; i++)
    {
        for (int j = i + 1; j < pool.Count; j++)
        {
            if (GetMinTangentAngle(pool[i], pool[j], tolerance, out double actualAngle))
            {
                // 【新增】交叉感知：若两条线都参与交叉节点，但夹角偏大，
                // 说明它们在交叉处不属于同一连续路径，不合并
                bool iInJunction = junctionCurves.Contains(/* 原 curves 中对应索引 */);
                bool jInJunction = junctionCurves.Contains(/* 原 curves 中对应索引 */);
                
                if (iInJunction && jInJunction && actualAngle > angleTolRad * 3)
                {
                    continue;  // 跳过交叉处的大角度合并
                }
                
                if (actualAngle <= angleTolRad)
                {
                    candidates.Add(new MergeCandidate { Index1 = i, Index2 = j, Angle = actualAngle });
                }
            }
        }
    }
    // ... 后续逻辑不变 ...
}
```

**注意**: 由于阶段2的 pool 是经过阶段0/1处理后的曲线集合，需要维护从 pool 索引到原始 curves 索引的映射。简化方案：为每条曲线增加一个 `UserString("InJunction", "true")` 标记，在预计算交叉节点时标记，阶段2中通过 `GetUserString` 检查。

---

## 4. 缺陷3 — 技术修复方案：渲染图输出方式修正

### 4.1 FIX-3.1：将 CaptureViewRender 从视口截图改为真正渲染

**改动文件**: `PatentCore.cs` — `CaptureViewRender()` 方法，第 879~940 行

**当前代码**（第 928~934 行）:
```csharp
var shadedMode = DisplayModeDescription.FindByName("Shaded");
if (shadedMode != null)
    vp.DisplayMode = shadedMode;

result = tempView.CaptureToBitmap(imageSize);
```

**问题**: 
1. `Shaded` 显示模式是视口渲染（wireframe + 着色），不是真正的渲染
2. `CaptureToBitmap` 是视口截图，不是渲染输出

**修复方案**: 使用 `Rendered` 显示模式或 `Rhino.Render.RenderWindow.RenderToBitmap()` API。

**伪代码**:
```csharp
private static Bitmap? CaptureViewRender(RhinoDoc doc, Plane viewPlane, string viewName, Size imageSize)
{
    Bitmap? result = null;
    RhinoView? tempView = null;

    try
    {
        // 1. 创建临时视口
        tempView = doc.Views.Add(viewName, DefinedViewportProjection.Perspective,
            new Rectangle(0, 0, imageSize.Width, imageSize.Height), false);
        if (tempView == null) return null;

        var vp = tempView.ActiveViewport;

        // 2. 设置平行投影 + 相机位置（保持不变）
        vp.ChangeToParallelProjection(true);
        Point3d target = viewPlane.Origin;
        Point3d cameraLocation = viewPlane.Origin + viewPlane.ZAxis * 1000;
        vp.SetCameraLocation(cameraLocation, false);
        vp.SetCameraDirection(-viewPlane.ZAxis, false);
        vp.CameraUp = viewPlane.YAxis;
        vp.SetCameraTarget(target, true);

        // 3. 缩放至模型包围盒（保持不变）
        BoundingBox modelBox = GetModelBoundingBox(doc);
        if (modelBox.IsValid)
        {
            Transform xform = Transform.PlaneToPlane(viewPlane, Plane.WorldXY);
            BoundingBox viewBbox = modelBox;
            viewBbox.Transform(xform);
            if (viewBbox.IsValid)
                vp.ZoomBoundingBox(viewBbox);
        }

        tempView.Redraw();

        // 【修复4.1】使用 Rendered 显示模式替代 Shaded
        // 主方案: Rendered 模式提供真正的渲染效果（含光照/阴影）
        var renderedMode = DisplayModeDescription.FindByName("Rendered");
        if (renderedMode != null)
        {
            vp.DisplayMode = renderedMode;
        }
        else
        {
            // 备选方案1: 使用 Articulated 模式（Rhino 7 自带的艺术渲染模式）
            var articulatedMode = DisplayModeDescription.FindByName("Articulated");
            if (articulatedMode != null)
                vp.DisplayMode = articulatedMode;
            else
            {
                // 备选方案2: 回退到 Shaded，但至少隐藏线框
                var shadedMode = DisplayModeDescription.FindByName("Shaded");
                if (shadedMode != null)
                    vp.DisplayMode = shadedMode;
            }
        }

        tempView.Redraw();

        // 【修复4.1】使用 ViewCapture 进行渲染捕获（支持渲染模式截图）
        // 方案A: ViewCapture + ViewCaptureSettings（推荐）
        var captureSettings = new ViewCaptureSettings(tempView, imageSize.Width, imageSize.Height);
        captureSettings.DrawViewportFill = true;
        captureSettings.DrawGrid = false;
        captureSettings.DrawAxis = false;
        captureSettings.DrawWorldAxes = false;
        captureSettings.ScreenCapture = false;  // 非屏幕截图，使用渲染管道
        
        var viewCapture = new ViewCapture();
        result = viewCapture.CaptureToBitmap(captureSettings);

        // 方案B（备选，若方案A返回null）: 回退到 CaptureToBitmap
        if (result == null)
        {
            result = tempView.CaptureToBitmap(imageSize);
        }
    }
    catch (Exception ex)
    {
        RhinoApp.WriteLine($"⚠️ 渲染捕获 [{viewName}] 异常: {ex.Message}");
        result = null;
    }
    finally
    {
        if (tempView != null) tempView.Close();
    }

    return result;
}
```

**关键技术验证点**:
- `DisplayModeDescription.FindByName("Rendered")` 在 Rhino 7 中是否返回有效对象
- `ViewCaptureSettings.ScreenCapture = false` 是否触发渲染管道而非屏幕截图
- 若 Rendered 模式不可用，Articulated 模式的效果是否满足要求

### 4.2 FIX-3.2：截图前隐藏线框图层

**改动文件**: `PatentCore.cs` — 渲染捕获循环区域，第 140~175 行

**当前代码**（第 151 行区域）:
```csharp
Bitmap? bmp = CaptureViewRender(doc, rv.Plane, rv.Name, new Size(1200, 900));
```

**问题**: 截图时遍历所有可见物体（包括已烘焙到 `Patent_Drawings_2D` 的线框），导致渲染图包含线框内容。

**修复方案**: 在渲染捕获循环开始前临时隐藏线框图层，循环结束后恢复。

**伪代码**:
```csharp
// 在渲染捕获循环开始前
// 【修复4.2】临时隐藏线框图层
var drawingLayer = doc.Layers.FindName("Patent_Drawings_2D");
var tangentLayer = doc.Layers.FindName("TangentEdges");
bool drawingLayerWasVisible = drawingLayer != null && drawingLayer.IsVisible;
bool tangentLayerWasVisible = tangentLayer != null && tangentLayer.IsVisible;

if (drawingLayer != null) drawingLayer.IsVisible = false;
if (tangentLayer != null) tangentLayer.IsVisible = false;
doc.Views.Redraw();

try
{
    // 原有渲染捕获循环
    for (int i = 0; i < renderViews.Count; i++)
    {
        var rv = renderViews[i];
        status?.Report($"🎨 正在渲染 [{rv.Name}] 视图 ({i + 1}/{renderViews.Count})...");
        progress?.Report((int)((i / (double)renderViews.Count) * 100));

        Bitmap? bmp = CaptureViewRender(doc, rv.Plane, rv.Name, new Size(1200, 900));
        if (bmp != null)
            renderBitmaps[rv.Name] = bmp;
    }
}
finally
{
    // 【修复4.2】恢复线框图层可见性
    if (drawingLayer != null) drawingLayer.IsVisible = drawingLayerWasVisible;
    if (tangentLayer != null) tangentLayer.IsVisible = tangentLayerWasVisible;
    doc.Views.Redraw();
}
```

### 4.3 FIX-3.3：渲染图以 PictureFrame 放入 Rhino 模型

**改动文件**: `PatentCore.cs` — 渲染输出区域，第 160~175 行

**当前代码**（第 170 行）:
```csharp
composed.Save(renderOutputPath, ImageFormat.Png);
```

**问题**: 将合成位图保存到外部 PNG 文件，用户要求渲染图作为模型内对象放入。

**修复方案**: 保存临时 PNG 文件 → 使用 `AddPictureFrame()` 插入到 Rhino 文档 → 可选清理临时文件。

**伪代码**:
```csharp
if (composed != null)
{
    status?.Report("💾 正在将渲染图放入模型...");
    try
    {
        // 【修复4.3】渲染图以 PictureFrame 放入 Rhino 模型
        // Step 1: 保存到临时文件（AddPictureFrame 需要文件路径）
        string tempDir = Path.GetTempPath();
        string tempRenderFile = Path.Combine(tempDir, $"AutoMake2D_Render_{Guid.NewGuid():N}.png");
        composed.Save(tempRenderFile, ImageFormat.Png);
        
        // Step 2: 计算 PictureFrame 放置位置
        // 策略：放在线框排版区域的右侧偏移位置
        // 使用世界坐标系的 XY 平面，在线框包围盒右侧偏移
        BoundingBox modelBbox = GetModelBoundingBox(doc);
        double offsetX = modelBbox.IsValid ? modelBbox.Max.X + modelBbox.Diagonal.Length * 0.3 : 100;
        double offsetY = 0;
        double offsetZ = 0;
        
        // PictureFrame 的宽高比（保持渲染图原始比例）
        double aspectRatio = (double)composed.Width / composed.Height;
        double frameHeight = modelBbox.IsValid ? modelBbox.Diagonal.Length * 0.8 : 100;
        double frameWidth = frameHeight * aspectRatio;
        
        // Step 3: 创建 PictureFrame
        var framePlane = new Plane(
            new Point3d(offsetX, offsetY, offsetZ),
            Vector3d.XAxis, Vector3d.YAxis);
        
        // 先将临时文件路径写入 renderOutputPath（满足用户对路径控件的预期）
        try
        {
            string dir = Path.GetDirectoryName(renderOutputPath);
            if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                Directory.CreateDirectory(dir);
            composed.Save(renderOutputPath, ImageFormat.Png);
        }
        catch { /* 外部保存失败不影响模型内放置 */ }
        
        // 使用 AddPictureFrame 将图片插入模型
        var pictureFrameId = doc.Objects.AddPictureFrame(framePlane, tempRenderFile, false, frameWidth, frameHeight, false);
        
        if (pictureFrameId != Guid.Empty)
        {
            // 将 PictureFrame 放到专用图层
            var renderLayer = doc.Layers.FindName("Patent_Render");
            int renderLayerIndex;
            if (renderLayer == null)
            {
                renderLayerIndex = doc.Layers.Add(new Layer 
                { 
                    Name = "Patent_Render", 
                    Color = System.Drawing.Color.LightGray 
                });
            }
            else
            {
                renderLayerIndex = renderLayer.Index;
            }
            
            var pfObj = doc.Objects.FindId(pictureFrameId);
            if (pfObj != null)
            {
                var attrs = pfObj.Attributes.Duplicate();
                attrs.LayerIndex = renderLayerIndex;
                doc.Objects.ModifyAttributes(pfObj, attrs, false);
            }
            
            status?.Report($"✅ 渲染图已放入模型 (Patent_Render 图层)");
            RhinoApp.WriteLine($"✅ 渲染图已放入模型 (Patent_Render 图层)，同时保存至: {renderOutputPath}");
        }
        else
        {
            status?.Report($"⚠️ PictureFrame 创建失败，渲染图仅保存为外部文件: {renderOutputPath}");
            RhinoApp.WriteLine($"⚠️ PictureFrame 创建失败，渲染图已保存至: {renderOutputPath}");
        }
        
        // Step 4: 清理临时文件
        try { if (File.Exists(tempRenderFile)) File.Delete(tempRenderFile); } catch { }
    }
    catch (Exception ex)
    {
        status?.Report($"❌ 渲染图输出失败: {ex.Message}");
        RhinoApp.WriteLine("❌ 渲染图输出失败: " + ex.Message);
    }
}
```

**UI 调整** (`PatentUiPanel.cs`):
- `_tbRenderPath` 的标签文本从"输出路径"改为"渲染图保存路径（同时放入模型）"
- 保留路径控件，因为外部 PNG 仍会保存（作为备份和 PictureFrame 的临时文件源）

---

## 5. 分步执行计划

### 里程碑 FM1：缺陷1修复 — 正切线识别与组合优先级

| 步骤 | 任务 | 涉及文件 | 改动描述 | 预计耗时 |
|---|---|---|---|---|
| FM1-1 | 验证方案B链路 | — | 在 Rhino 中验证 `hldCurve.SourceObject` → `Brep` → `BrepEdge.EdgeConvexity` 是否可达 | 1h |
| FM1-2 | 切换正切识别方案 | `PatentCore.cs` 第 280~310 行 | 注释方案A，启用方案B（BrepEdge.EdgeConvexity）；若验证失败启用双重验证回退 | 1.5h |
| FM1-3 | 修复 PropagateUserStrings | `PatentCore.cs` 第 790~805 行 | IsTangent 标记改为"正常线优先"策略 | 0.5h |
| FM1-4 | 重构为三阶段融合 | `PatentCore.cs` 第 456~515 行 | 阶段0正常线组合 → 阶段1交叉处相切线合并 → 阶段2全局贪心 | 2h |
| FM1-5 | 单元测试 | — | 含圆角模型验证正切识别正确性；纯棱柱模型验证无误标记 | 1h |

**FM1 交付物**: 正切边缘线正确识别且与正常线分属不同图层；组合遵循"先正常线、后相切线"优先级

### 里程碑 FM2：缺陷2修复 — 多线交叉组合逻辑

| 步骤 | 任务 | 涉及文件 | 改动描述 | 预计耗时 |
|---|---|---|---|---|
| FM2-1 | 实现 ComputeJunctionDistTol | `PatentCore.cs` — 新增方法 | 基于包围盒对角线自适应计算交叉检测半径 | 0.5h |
| FM2-2 | 替换交叉检测调用 | `PatentCore.cs` 第 461 行 | `DetectJunctionPoints(curves, tolerance)` → `DetectJunctionPoints(curves, ComputeJunctionDistTol(...))` | 0.5h |
| FM2-3 | 修复 GetMinTangentAngle | `PatentCore.cs` 第 579~596 行 | 增加趋近垂直交叉验证 + 绝对角度上限 | 1h |
| FM2-4 | 阶段2增加交叉感知 | `PatentCore.cs` 第 519~575 行 | 预计算交叉节点集合；合并时跳过大角度交叉候选对 | 1.5h |
| FM2-5 | 集成测试 | — | 三管交叉模型验证；垂直线不被合并；简单模型回归 | 1h |

**FM2 交付物**: 多线交叉处趋近相切的线优先合并，垂直线不被误合并

### 里程碑 FM3：缺陷3修复 — 渲染输出方式

| 步骤 | 任务 | 涉及文件 | 改动描述 | 预计耗时 |
|---|---|---|---|---|
| FM3-1 | 验证 Rendered 模式 API | — | 验证 `DisplayModeDescription.FindByName("Rendered")` + `ViewCapture` 渲染效果 | 1h |
| FM3-2 | 修改 CaptureViewRender | `PatentCore.cs` 第 879~940 行 | Shaded → Rendered 模式；CaptureToBitmap → ViewCapture 渲染管道 | 1.5h |
| FM3-3 | 增加图层隐藏/恢复 | `PatentCore.cs` 第 140~175 行 | 渲染前隐藏线框图层，渲染后恢复 | 0.5h |
| FM3-4 | 实现 PictureFrame 输出 | `PatentCore.cs` 第 160~175 行 | 临时 PNG → AddPictureFrame → 专利渲染图层 | 1.5h |
| FM3-5 | UI 标签调整 | `PatentUiPanel.cs` | 路径标签改为"渲染图保存路径（同时放入模型）" | 0.5h |
| FM3-6 | 端到端测试 | — | 勾选渲染 → 生成 → 检查 PictureFrame 在模型中 + 渲染图无线框内容 | 1h |

**FM3 交付物**: 渲染输出为真正渲染效果；不截入线框；以 PictureFrame 形式存在于 Rhino 模型中

### 里程碑 FM4：集成回归测试

| 步骤 | 任务 | 涉及文件 | 改动描述 | 预计耗时 |
|---|---|---|---|---|
| FM4-1 | 三个缺陷联合测试 | — | 含圆角+交叉模型 + 渲染输出的完整流程测试 | 1.5h |
| FM4-2 | 回归测试 | — | 原有六视图线框生成、外轮廓隔离、分组命名等不受影响 | 1h |
| FM4-3 | 边界测试 | — | 无圆角模型、无交叉模型、大模型性能 | 1h |
| FM4-4 | 代码整理 | 全部 | 注释更新、冗余代码清理 | 0.5h |

---

## 6. 里程碑时间线

```
Day 1:  FM1 — 正切线识别与组合优先级修复
Day 2:  FM2 — 多线交叉组合逻辑修复
Day 3:  FM3 — 渲染输出方式修复
Day 4:  FM4 — 集成回归测试
```

> 总预计耗时：4 个工作日（单人），关键路径在 FM1-1 和 FM3-1 的 API 验证步骤。

---

## 7. 技术依赖

| 依赖 | API / 类 | 用途 | 版本要求 |
|---|---|---|---|
| RhinoCommon | `BrepEdge.EdgeConvexity` | 正切边缘精确识别（方案B） | 7.35+ |
| RhinoCommon | `DisplayModeDescription.FindByName("Rendered")` | 获取 Rendered 显示模式 | 7.35+ |
| RhinoCommon | `ViewCapture` / `ViewCaptureSettings` | 渲染管道位图捕获 | 7.35+ |
| RhinoCommon | `RhinoDoc.Objects.AddPictureFrame()` | 将图片作为 PictureFrame 插入模型 | 7.35+ |
| RhinoCommon | `Layer.IsVisible` | 临时隐藏/恢复图层 | 7.35+ |
| .NET Framework 4.8 | `System.Drawing.Bitmap` / `Graphics` | 位图合成与 PNG 导出 | 内置 |

### API 风险与备选

| API | 风险 | 备选方案 |
|---|---|---|
| `BrepEdge.EdgeConvexity` | HLD SourceObject 链路可能断开 | 双重验证回退：SilhouetteType.None + 几何特征（弧线/曲率连续） |
| `FindByName("Rendered")` | Rhino 7 某些配置可能无此模式 | 回退到 Articulated 模式或 Shaded 模式 |
| `ViewCaptureSettings.ScreenCapture` | 属性可能不存在或行为不符预期 | 回退到 `RhinoView.CaptureToBitmap()` |
| `AddPictureFrame()` | 需要文件路径输入，不支持内存流 | 先保存临时 PNG 再读入；清理临时文件 |

---

## 8. 测试验证建议

### 8.1 缺陷1 测试

| 用例 | 模型特征 | 预期结果 |
|---|---|---|
| T1.1 | 含圆角的长方体 | 圆角弧线标记为 `IsTangent=true`，棱边线不标记 |
| T1.2 | 无圆角纯棱柱 | 无曲线带 `IsTangent` 标记（原误标记的内部线段不再标记） |
| T1.3 | 正常线+正切线合并 | 合并结果 IsTangent=false（正常线优先） |
| T1.4 | 含交叉+圆角模型 | 正常线先组合为连续链路，再组合相切线 |

### 8.2 缺陷2 测试

| 用例 | 模型特征 | 预期结果 |
|---|---|---|
| T2.1 | 三管交叉模型 | 交叉处趋近相切线优先合并，垂直线不合并 |
| T2.2 | 高精度(0.001)交叉模型 | 交叉检测不被精度容差限制而漏检 |
| T2.3 | 低精度(0.1)交叉模型 | 交叉检测不被精度容差放大而误检 |
| T2.4 | 两条几乎垂直的线共端点 | 不被误判为"可合并" |

### 8.3 缺陷3 测试

| 用例 | 操作 | 预期结果 |
|---|---|---|
| T3.1 | 勾选渲染 + 六视图 → 生成 | 渲染图不包含线框内容 |
| T3.2 | 勾选渲染 → 生成 → 检查 Rhino | PictureFrame 存在于 Patent_Render 图层 |
| T3.3 | 勾选渲染 → 生成 → 检查光影 | 渲染图具有光照/阴影效果（非简单截图） |
| T3.4 | 不勾选渲染 → 生成 | 行为与原版完全一致 |
| T3.5 | 渲染完成后重新打开 Rhino 文档 | PictureFrame 仍然存在 |

### 8.4 回归测试

| 用例 | 验证点 |
|---|---|
| 原有六视图线框生成 | 所有原功能不受影响 |
| 外轮廓特权隔离 | 外轮廓仍然独立闭环 |
| 零件分组 | 分组命名规则不变 |
| 工程排版 | 线框排版布局不变 |

---

## 9. 文件改动汇总

| 文件 | 改动类型 | 具体改动 |
|---|---|---|
| `PatentCore.cs` 第 280~310 行 | 修改 | 正切识别方案A → 方案B（BrepEdge.EdgeConvexity） |
| `PatentCore.cs` 第 456~515 行 | 修改 | `JoinTangentCurvesPrioritized` 重构为三阶段（阶段0+阶段1+阶段2） |
| `PatentCore.cs` 第 461 行 | 修改 | 交叉检测调用替换为自适应阈值 |
| `PatentCore.cs` 第 579~596 行 | 修改 | `GetMinTangentAngle` 增加趋近垂直交叉验证和绝对角度上限 |
| `PatentCore.cs` 第 519~575 行 | 修改 | `JoinTangentCurvesPrioritized_Original` 增加交叉感知逻辑 |
| `PatentCore.cs` 第 790~805 行 | 修改 | `PropagateUserStrings` IsTangent 改为正常线优先策略 |
| `PatentCore.cs` — 新增 | 新增 | `ComputeJunctionDistTol()` 自适应交叉检测阈值 |
| `PatentCore.cs` 第 879~940 行 | 修改 | `CaptureViewRender` 改用 Rendered 模式 + ViewCapture 渲染管道 |
| `PatentCore.cs` 第 140~175 行 | 修改 | 渲染循环增加图层隐藏/恢复逻辑 |
| `PatentCore.cs` 第 160~175 行 | 修改 | 渲染输出改为 PictureFrame + 临时 PNG |
| `PatentUiPanel.cs` | 修改 | 路径标签文本调整 |

---

## 10. 与原始执行计划（execution-plan.md v1.1）的差异点说明

| 差异点 | 原始执行计划 | 修复执行计划 | 原因 |
|---|---|---|---|
| 正切识别方案 | 方案A为主，方案B为备选注释代码 | 直接启用方案B，方案A作为回退 | 用户测试证明方案A误标记严重 |
| 融合阶段数 | 两阶段（交叉感知 + 全局贪心） | 三阶段（正常线组合 + 交叉相切线合并 + 全局贪心） | 缺乏"先正常线、后相切线"分层是核心缺陷 |
| PropagateUserStrings | 任意源带标记则继承 | 正常线优先（仅全相切才继承 IsTangent） | 当前逻辑导致正常线被"污染" |
| 交叉检测阈值 | 直接使用用户 tolerance 参数 | 新增 ComputeJunctionDistTol 自适应计算 | tolerance 不适合作为空间检测半径 |
| 角度判断 | 4种端点取最小夹角 | 最小夹角 + 趋近垂直交叉验证 + 绝对上限 | 垂直线被误合并的根因 |
| 渲染捕获方式 | Shaded + CaptureToBitmap | Rendered + ViewCapture 渲染管道 | Shaded 仍是截图，不是真正渲染 |
| 图层处理 | 无 | 渲染前隐藏线框图层，渲染后恢复 | 截图误截线框 |
| 渲染输出方式 | PNG 文件导出 | PictureFrame 放入模型 + PNG 备份 | 用户要求放入模型而非导出 |
| 里程碑划分 | M1~M5（5天） | FM1~FM4（4天） | 修复任务聚焦于现有功能修正，无需从零实现 |
| UI 改动 | 新增渲染输出控件 | 仅调整标签文本 | 控件已存在，仅需文案修改 |

---

*修复执行计划书结束 — 待审核确认后进入开发阶段*
