# AutoMake2D 第七轮缺陷修复执行计划书 (V7)

> **版本**: v7.0 | **日期**: 2026-07-10 | **状态**: 待审核  
> **前置文档**: `fix-task-plan-v7.md` (任务计划书)  
> **当前源码**: PatentCore.cs (V6 版本, 1478 行), PatentUiPanel.cs (214 行)  
> **核心原则**: 修复渲染输出物件居中 + 白色背景，最小改动原则

---

## 1. 总览

| 缺陷 | 修复范围 | 涉及方法 | 里程碑 | 预计耗时 |
|---|---|---|---|---|
| V7-1 物件不居中 | CaptureViewRender | 1 个方法 | FM1 | 1.5h |
| V7-2 背景非白色 | CaptureViewRender / ComposeRenderLayout / DrawAt | 3 个方法 | FM2 | 1h |

---

## 2. 技术方案

### 2.1 缺陷 V7-1：物件不居中修复

#### 2.1.1 问题描述

当前 `CaptureViewRender()` 中 ZoomBoundingBox 的坐标空间不匹配：

```
当前 V6 代码（约第1163-1170行）：
BoundingBox modelBox = GetModelBoundingBoxExcludingPatentLayers(doc);  // 世界坐标
Transform xform = Transform.PlaneToPlane(viewPlane, Plane.WorldXY);    // ❌ 变换到 WorldXY
BoundingBox viewBbox = modelBox;
viewBbox.Transform(xform);                                               // ❌ 包围盒在 WorldXY 空间
if (viewBbox.IsValid)
{
    Point3d bboxCenter = viewBbox.Center;                                // ❌ WorldXY 空间的中心
    Transform centering = Transform.Translation(-bboxCenter.X, ...);     // ❌ V5 居中变换
    viewBbox.Transform(centering);
    vp.SetCameraTarget(Point3d.Origin, true);                            // ❌ 目标设为原点
    double margin = viewBbox.Diagonal.Length * 0.05;                     // ❌ 边距太小
    viewBbox.Inflate(margin);
    vp.ZoomBoundingBox(viewBbox);                                        // ❌ 相机在 viewPlane 空间，包围盒在 WorldXY 空间
}
```

问题本质：视口相机处于 `viewPlane` 坐标系（相机位于 `viewPlane.Origin + viewPlane.ZAxis * 1000`，朝向 `viewPlane.Origin`），但包围盒经过 PlaneToPlane 变换到了 WorldXY 坐标系。ZoomBoundingBox 期望包围盒与相机在同一坐标系中。

#### 2.1.2 修复方案：直接使用世界坐标包围盒 + ZoomBoundingBox

**核心思路**：移除 PlaneToPlane 变换和 V5 居中变换，让 ZoomBoundingBox 直接在世界坐标系中操作。ZoomBoundingBox 会自动计算包围盒在当前视口相机视角下的可见范围并调整缩放。

**修复代码**（替换第1163-1173行）：

```csharp
// 5. 缩放至模型包围盒（排除 Patent_ 前缀图层），居中 + 充足边距
BoundingBox modelBox = GetModelBoundingBoxExcludingPatentLayers(doc);
if (modelBox.IsValid)
{
    // 【V7修复】移除 PlaneToPlane 变换 — 直接使用世界坐标包围盒
    // ZoomBoundingBox 会根据当前视口相机的视角自动计算可见范围
    // 不再做 Transform.PlaneToPlane(viewPlane, WorldXY)，避免坐标空间不匹配
    
    // 【V7修复】移除 V5 的居中变换(Translation + SetCameraTarget(Origin))
    // 相机已在步骤3中正确设置(朝向 viewPlane.Origin)，ZoomBoundingBox 会自动居中
    
    // 【V7修复】增加边距至 10%（总边距 20%），确保物件不贴边且四周留白均匀
    double margin = modelBox.Diagonal.Length * 0.10;
    BoundingBox inflatedBox = modelBox;
    inflatedBox.Inflate(margin);
    vp.ZoomBoundingBox(inflatedBox);
}
```

**为什么直接 ZoomBoundingBox(modelBox) 能正确居中？**

1. Rhino 的 `ZoomBoundingBox(BoundingBox)` 方法内部会：计算包围盒在当前视口投影下的屏幕范围 → 调整相机位置/目标使得包围盒居中显示 → 调整缩放使得包围盒充满视口
2. 相机已正确设置（位于 `viewPlane.Origin + viewPlane.ZAxis * 1000`，朝向 `viewPlane.Origin`），世界坐标包围盒与此相机在同一坐标系中
3. ZoomBoundingBox 会自动将 `viewPlane.Origin`（相机目标点）和包围盒中心对齐，实现居中

**备选方案**（如果 ZoomBoundingBox 对世界坐标包围盒效果不佳）：

```csharp
// 备选方案：将包围盒变换到相机坐标系，再 ZoomBoundingBox
// 1. 计算包围盒在相机坐标系中的范围
Transform toCamera = Transform.PlaneToPlane(Plane.WorldXY, viewPlane);
BoundingBox cameraSpaceBox = modelBox;
cameraSpaceBox.Transform(toCamera);
if (cameraSpaceBox.IsValid)
{
    double margin = cameraSpaceBox.Diagonal.Length * 0.10;
    cameraSpaceBox.Inflate(margin);
    vp.ZoomBoundingBox(cameraSpaceBox);
}
```

> **注意**：备选方案的变换方向是 `WorldXY → viewPlane`（与 V6 的 `viewPlane → WorldXY` 相反），这样包围盒变换到了与相机相同的坐标系。

#### 2.1.3 完整修复后的 CaptureViewRender 核心片段

```csharp
// 步骤 3: 根据视图平面调整相机
Point3d target = viewPlane.Origin;
Point3d cameraLocation = viewPlane.Origin + viewPlane.ZAxis * 1000;
vp.SetCameraLocation(cameraLocation, false);
vp.SetCameraDirection(-viewPlane.ZAxis, false);
vp.CameraUp = viewPlane.YAxis;
vp.SetCameraTarget(target, true);  // 相机目标 = viewPlane.Origin

// ... DisplayMode 设置 + Redraw ...

// 步骤 5: 缩放至模型包围盒（V7修复后）
BoundingBox modelBox = GetModelBoundingBoxExcludingPatentLayers(doc);
if (modelBox.IsValid)
{
    // 【V7】直接使用世界坐标包围盒，不做 PlaneToPlane 变换
    double margin = modelBox.Diagonal.Length * 0.10;
    BoundingBox inflatedBox = modelBox;
    inflatedBox.Inflate(margin);
    vp.ZoomBoundingBox(inflatedBox);
}

// 步骤 5b: Zoom 后再次 Redraw
tempView.Redraw();
doc.Views.Redraw();
System.Threading.Thread.Sleep(150);
tempView.Redraw();
System.Threading.Thread.Sleep(50);
```

---

### 2.2 缺陷 V7-2：背景非白色修复

#### 2.2.1 方案选型

| 方案 | 描述 | 优点 | 缺点 | 选择 |
|---|---|---|---|---|
| A. 设置视口白色背景 | 修改 DisplayMode 的背景属性为纯色白色 | 渲染时直接白色背景 | 内置 Rendered 模式可能 PipelineLocked 无法修改；全局影响 | ❌ 备选 |
| B. DrawBackground=false + 白底合成 | 捕获后创建白底位图，合成物件 | 可靠、不影响全局；对 Rendered 模式无侵入 | 需要额外 Bitmap 创建和绘制 | ✅ **采用** |
| C. DrawBackground=true + 视口环境设白 | 保持 DrawBackground=true，设置视口环境为白色 | 一步到位 | 需要修改 Rendered 模式的 DisplayAttributes；可能影响用户其他视口 | ❌ 备选 |

**选择方案 B**：DrawBackground=false + 白底合成。原因：
1. V6 已设 `DrawBackground=false`，只需在此基础上增加白底合成
2. 不需要修改 DisplayMode 属性，避免 PipelineLocked 风险
3. 对所有视图模式（正交/等轴测/自定义）通用

#### 2.2.2 修复 CaptureViewRender()：捕获后白底合成（约第1195-1205行）

**当前 V6 代码**：
```csharp
var captureSettings = new ViewCaptureSettings(tempView, imageSize, 72.0);
captureSettings.DrawGrid = false;
captureSettings.DrawAxis = false;
captureSettings.DrawBackground = false;
captureSettings.RasterMode = true;

result = ViewCapture.CaptureToBitmap(captureSettings);

if (result == null && renderMode != null)
    result = tempView.CaptureToBitmap(imageSize, renderMode);
```

**V7 修复后**：
```csharp
var captureSettings = new ViewCaptureSettings(tempView, imageSize, 72.0);
captureSettings.DrawGrid = false;
captureSettings.DrawAxis = false;
captureSettings.DrawBackground = false;  // 不绘制视口背景（避免灰色）
captureSettings.RasterMode = true;

Bitmap? captured = ViewCapture.CaptureToBitmap(captureSettings);

if (captured == null && renderMode != null)
    captured = tempView.CaptureToBitmap(imageSize, renderMode);

// 【V7修复】白底合成：创建白色底图 + 绘制捕获内容
if (captured != null)
{
    result = new Bitmap(captured.Width, captured.Height);
    using (var g = Graphics.FromImage(result))
    {
        g.Clear(Color.White);  // 纯白背景
        g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
        g.CompositingMode = System.Drawing.Drawing2D.CompositingMode.SourceOver;
        g.DrawImage(captured, 0, 0, captured.Width, captured.Height);
    }
    captured.Dispose();  // 释放原始位图
}
```

#### 2.2.3 修复 ComposeRenderLayout()：单视图白底处理（约第1330-1337行）

**当前 V6 代码**：
```csharp
// 单视图：无需排版，直接返回单张渲染位图
if (viewBitmaps.Count == 1)
{
    using (var enumerator = viewBitmaps.Values.GetEnumerator())
    {
        if (enumerator.MoveNext())
            return enumerator.Current;  // ❌ 直接返回，可能无白底
    }
    return null;
}
```

**V7 修复后**：
```csharp
// 单视图：【V7修复】确保白底后返回
if (viewBitmaps.Count == 1)
{
    using (var enumerator = viewBitmaps.Values.GetEnumerator())
    {
        if (enumerator.MoveNext())
        {
            var src = enumerator.Current;
            if (src == null) return null;
            
            // 白底合成（双重保险：CaptureViewRender 已做白底，此处确保万无一失）
            var whiteBg = new Bitmap(src.Width, src.Height);
            using (var g = Graphics.FromImage(whiteBg))
            {
                g.Clear(Color.White);
                g.DrawImage(src, 0, 0, src.Width, src.Height);
            }
            return whiteBg;
        }
    }
    return null;
}
```

> **说明**：如果 2.2.2 中 CaptureViewRender 已正确做白底合成，单视图分支理论上不需要再次白底合成。但作为防御性编程，保留此处理可防止遗漏场景。如果性能敏感，可在验证后移除。

#### 2.2.4 修复 DrawAt()：子图白底预处理（约第1473-1477行）

**当前 V6 代码**：
```csharp
private static void DrawAt(Graphics g, Bitmap bmp, double x, double y, int refW, int refH)
{
    if (bmp == null) return;
    g.DrawImage(bmp, (float)x, (float)y, refW, refH);
}
```

**V7 修复后**：不需要修改 DrawAt()。原因：如果 CaptureViewRender 已在返回前做白底合成，所有子图本身就有白色背景，多视图合成中 `g.Clear(Color.White)` 的白色填充会被子图正确覆盖（子图白色区域与画布白色一致，物件区域正确显示）。

**但如果 CaptureViewRender 的白底合成未生效**（如备选捕获方法返回未白底的位图），需在 DrawAt 中添加白底预处理：

```csharp
// 仅在确认 CaptureViewRender 白底合成不稳定时启用
private static void DrawAt(Graphics g, Bitmap bmp, double x, double y, int refW, int refH)
{
    if (bmp == null) return;
    
    // 【V7防御性】白底预处理：确保子图有白色背景
    // 如果 bmp 已有白底（来自 CaptureViewRender 的白底合成），此操作为空操作
    // 如果 bmp 无白底，先绘制白色矩形再绘制子图
    g.FillRectangle(Brushes.White, (float)x, (float)y, refW, refH);
    g.DrawImage(bmp, (float)x, (float)y, refW, refH);
}
```

> **建议**：先实施 2.2.2 的 CaptureViewRender 白底合成，编译测试。如果多视图输出仍有灰色背景，再启用 DrawAt 的白底预处理。

---

## 3. 分步执行计划

### 里程碑 FM1：物件居中修复（1.5h）

| 步骤 | 描述 | 涉及文件 | 改动点 | 预计 |
|---|---|---|---|---|
| FM1-1 | 移除 PlaneToPlane 变换 + V5 居中变换 | src/PatentCore.cs 第1163-1173行 | 删除 `Transform xform = Transform.PlaneToPlane(viewPlane, Plane.WorldXY)` 及后续 viewBbox.Transform(xform)、Translation 居中变换、SetCameraTarget(Origin)；改为直接 `ZoomBoundingBox(inflatedBox)` | 0.5h |
| FM1-2 | 增加 Inflate 边距 | src/PatentCore.cs 第1169行 | `0.05` → `0.10`（从 5% 增加到 10%，总边距从 10% 增加到 20%） | 0.1h |
| FM1-3 | 清理构建产物并编译验证 | `rm -rf src/bin src/obj && dotnet build` | — | 0.5h |
| FM1-4 | 代码审查：确认无 PlaneToPlane 残留 | grep 验证 | — | 0.2h |
| FM1-5 | 备选方案准备（如主方案不生效） | src/PatentCore.cs | 编写备选代码：Transform.PlaneToPlane(WorldXY, viewPlane) 反向变换 | 0.2h |

### 里程碑 FM2：白色背景修复（1h）

| 步骤 | 描述 | 涉及文件 | 改动点 | 预计 |
|---|---|---|---|---|
| FM2-1 | CaptureViewRender 捕获后白底合成 | src/PatentCore.cs 第1195-1205行 | 捕获后创建白底位图 + Graphics.Clear(White) + DrawImage + Dispose 原始位图 | 0.3h |
| FM2-2 | ComposeRenderLayout 单视图白底处理 | src/PatentCore.cs 第1330-1337行 | 单视图分支不再直接返回，先白底合成再返回 | 0.2h |
| FM2-3 | 清理构建产物并编译验证 | `rm -rf src/bin src/obj && dotnet build` | — | 0.3h |
| FM2-4 | 代码审查：确认所有输出路径均有白底处理 | grep 验证 | — | 0.2h |

---

## 4. 文件改动汇总

| 文件 | 改动数 | 改动方法 | 说明 |
|---|---|---|---|
| src/PatentCore.cs | 2 处修改 | CaptureViewRender, ComposeRenderLayout | 核心改动 |
| src/PatentUiPanel.cs | 0 处 | 无 | UI 无需修改 |

### 改动详情

| # | 方法 | 行号(约) | 改动类型 | 描述 |
|---|---|---|---|---|
| 1 | CaptureViewRender | 1163-1173 | **替换** | 移除 PlaneToPlane 变换 + V5 居中变换，改为直接 ZoomBoundingBox(modelBox) + Inflate(10%) |
| 2 | CaptureViewRender | 1195-1205 | **修改** | 捕获后白底合成：result = new Bitmap → g.Clear(White) → g.DrawImage(captured) → captured.Dispose() |
| 3 | ComposeRenderLayout | 1330-1337 | **修改** | 单视图分支白底合成后再返回 |

---

## 5. 技术依赖

| API | 用途 | 版本 | 风险 |
|---|---|---|---|
| `RhinoViewport.ZoomBoundingBox(BoundingBox)` | 缩放视口至包围盒 | RhinoCommon 7.35 | 中 — 需确认世界坐标包围盒在非 WorldXY 相机下的行为 |
| `ViewCapture.CaptureToBitmap(ViewCaptureSettings)` | 渲染管道捕获位图 | RhinoCommon 7.35 | 无（已有） |
| `ViewCaptureSettings.DrawBackground` | 控制是否绘制背景 | RhinoCommon 7.35 | 无（已用） |
| `Graphics.Clear(Color)` | 填充白色背景 | System.Drawing | 无 |
| `Graphics.DrawImage()` | 绘制物件到白底 | System.Drawing | 无 |
| `Bitmap.Dispose()` | 释放原始位图 | System.Drawing | 无 |

### API 风险与备选方案

| 风险 | 备选方案 |
|---|---|
| ZoomBoundingBox 对世界坐标包围盒在非标准 viewPlane 相机下计算错误 | 方案A：反向变换 `PlaneToPlane(WorldXY, viewPlane)` 将包围盒变换到相机坐标系；方案B：使用 `vp.ZoomExtents()` 后手动调整缩放比 |
| DrawBackground=false 时捕获位图有 Alpha 通道导致白底合成有边缘伪影 | 设置 `g.CompositingMode = SourceOver`（默认值，正确混合 Alpha）；如仍有伪影，改用 DrawBackground=true + 设置视口白色背景方案 |
| 白底合成后内存占用过高 | 使用 using 及时释放原始位图；单视图分支白底合成后 Dispose 原始位图 |

---

## 6. 测试验证建议

### 6.1 编译验证

```bash
rm -rf src/bin src/obj
dotnet build
# 预期: 0 errors
```

### 6.2 代码审查验证

| 验证点 | 验证方法 | 预期结果 |
|---|---|---|
| PlaneToPlane 已移除 | `grep -c "PlaneToPlane" src/PatentCore.cs` | 0（在 CaptureViewRender 中） |
| V5 居中变换已移除 | `grep -c "Translation.*bboxCenter" src/PatentCore.cs` | 0 |
| Inflate 边距增加 | `grep -A2 "Inflate" src/PatentCore.cs` | 0.10 而非 0.05 |
| 白底合成已添加 | `grep -c "g.Clear(Color.White)" src/PatentCore.cs` | ≥2（CaptureViewRender + ComposeRenderLayout 单视图分支） |
| 原始位图已释放 | `grep -c "captured.Dispose" src/PatentCore.cs` | ≥1 |
| 单视图白底处理 | `grep -A10 "viewBitmaps.Count == 1" src/PatentCore.cs` | 包含 Clear(White) + DrawImage |
| ZoomBoundingBox 使用 modelBox | `grep -B2 "ZoomBoundingBox" src/PatentCore.cs` | 使用 inflatedBox（基于 modelBox），无 viewBbox |

### 6.3 功能测试用例

| 用例 | 模型 | 操作 | 预期结果 |
|---|---|---|---|
| TC-1 | 任意 3D 模型 | 单视图 Front 渲染 | 物件居中（偏移 ≤5%）、无截断、白色背景 |
| TC-2 | 任意 3D 模型 | 六视图渲染 | 每个子图物件居中、白色背景、排版整体白底 |
| TC-3 | 任意 3D 模型 | IsoFront 等轴测渲染 | 物件居中、白色背景 |
| TC-4 | 非对称模型（重心偏离原点） | Front 渲染 | 物件仍然居中 |
| TC-5 | 极小模型 | Front 渲染 | 物件居中且不贴边 |
| TC-6 | 极大模型 | Front 渲染 | 物件居中且完整可见 |
| TC-7 | 单视图渲染 | 像素检测 | 图片四角像素 RGB = (255,255,255) |
| TC-8 | 六视图渲染 | 像素检测 | 子图间隙区域像素 RGB = (255,255,255) |

### 6.4 居中效果量化验证

对渲染输出图片进行像素级分析：
1. 读取图片，检测非白色像素的边界范围
2. 计算物件边界矩形的中心坐标
3. 与图片中心坐标对比，偏移应 ≤ 图片尺寸的 5%
4. 检查物件四边是否均有留白（非白色像素不接触图片边缘）

---

## 7. 里程碑划分

```
FM1 物件居中修复 (1.5h)
├── FM1-1: 移除 PlaneToPlane 变换 + V5 居中变换 (0.5h)
├── FM1-2: 增加 Inflate 边距 (0.1h)
├── FM1-3: 编译验证 (0.5h)
├── FM1-4: 代码审查 (0.2h)
└── FM1-5: 备选方案准备 (0.2h)

FM2 白色背景修复 (1h)
├── FM2-1: CaptureViewRender 捕获后白底合成 (0.3h)
├── FM2-2: ComposeRenderLayout 单视图白底处理 (0.2h)
├── FM2-3: 编译验证 (0.3h)
└── FM2-4: 代码审查 (0.2h)
```

**总预计耗时**: 2.5h  
**关键路径**: FM1-1（坐标空间修复）— 如果 ZoomBoundingBox 对世界坐标包围盒行为不正确，需切换到备选方案

---

## 8. 与 V6 执行计划差异对比

| 维度 | V6 执行计划 | V7 执行计划 | 差异原因 |
|---|---|---|---|
| **渲染居中** | PlaneToPlane(viewPlane, WorldXY) + Translation(-bboxCenter) + SetCameraTarget(Origin) + Inflate(5%) | **直接 ZoomBoundingBox(modelBox) + Inflate(10%)** | 坐标空间不匹配导致物件偏上 |
| **渲染背景** | DrawBackground=true（V6改前）/ DrawBackground=false（V6改后）| **DrawBackground=false + 白底合成** | DrawBackground=false 无白底补偿 |
| **单视图输出** | 直接返回 enumerator.Current | **白底合成后返回** | 单视图跳过白底处理 |
| **多视图合成** | 依赖 g.Clear(White) | **子图已白底 + g.Clear(White) 双保险** | 子图灰背景覆盖白色画布 |

---

## 9. 开发注意事项

1. **最小改动原则**: V7 仅修改渲染捕获和排版输出的两个缺陷点，不触碰线框分类、显示模式、曲面边缘线等已修复功能
2. **ZoomBoundingBox 行为验证**: Rhino 的 ZoomBoundingBox 文档不明确说明坐标空间要求，需在编译后通过测试验证。如果直接传世界坐标包围盒不生效，立即切换到备选方案（反向 PlaneToPlane 变换）
3. **白底合成内存管理**: 原始捕获位图（captured）在白底合成后必须 Dispose，避免内存泄漏；单视图分支的原始位图也需 Dispose
4. **Graphics 绘制参数**: 白底合成时使用 `InterpolationMode.HighQualityBicubic` 和 `CompositingMode.SourceOver`，确保 Alpha 通道正确混合
5. **清理构建产物**: 编译前必须 `rm -rf src/bin src/obj`，避免历史构建产物导致问题
6. **DrawAt() 不改**: 多视图合成的 DrawAt() 方法暂不修改，因为子图已在 CaptureViewRender 中做了白底合成。如果实测发现多视图仍有灰色背景，再添加 FillRectangle(White) 预处理
7. **边距可调**: Inflate(0.10) 是推荐值，如果实测物件贴边或留白过多，可调整为 0.08-0.15 之间

---

*第七轮修复执行计划书结束 — 待审核确认后进入开发阶段*
