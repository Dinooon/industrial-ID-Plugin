# AutoMake2D 2.0 缺陷修复任务计划书

> 版本: v1.0  
> 日期: 2026-07-09  
> 状态: 待审核  
> 前置文档: `task-plan.md` (v1.1)

---

## 1. 背景与目标

### 问题

AutoMake2D 2.0 Rhino 插件已完成需求1（线框分组+融合优化）和需求2（渲染输出+排版）的开发，但用户实际测试后发现三个缺陷：

1. **正切线区分与组合优先级失效** — 正切边缘线与正常棱边线混在一起无法区分，且未实现"先组合正常线、再组合相切线"的分层优先级逻辑
2. **多线交叉组合逻辑错误** — 多线交叉处应优先组合趋近相切的线，但实际几乎互相垂直的线被优先组合
3. **渲染图实为场景截取非真正渲染且误截线框** — 渲染输出实际是视口截图（SceneCapture），不是真正渲染；会误截已输出的线框图；输出方式是导出文件而非放入模型

### 目标用户

专利工程师 / 专利律师 — 使用 AutoMake2D 生成专利申请用线框工程图和渲染图的用户

### 业务目标与可验证指标

| 缺陷 | 修复目标 | 可验证指标 |
|---|---|---|
| 缺陷1 | 正切线正确识别且与正常线可区分；组合遵循"先正常线、后相切线"优先级 | 含圆角模型生成后，正切边缘线与正常线分属不同图层；正常线先组合为连续链路后再组合相切线 |
| 缺陷2 | 多线交叉处趋近相切的线优先组合，几乎垂直的线不被错误合并 | 含交叉节点的测试模型中，交叉处夹角 ≤ 阈值的线优先合并；≥ 80° 的线对不被合并 |
| 缺陷3 | 渲染输出为真正渲染而非截图；不截入线框图层；渲染图作为 Rhino 模型内对象放入 | 渲染图不包含线框内容；渲染图以 PictureFrame 形式存在于 Rhino 文档中而非外部文件 |

---

## 2. 范围 (Scope)

### ✅ 本期做

| 编号 | 修复项 | 说明 |
|---|---|---|
| FIX-1.1 | 切换正切识别方案为方案B | 将 `SilhouetteType.None` 判定替换为 `BrepEdge.EdgeConvexity == Tangent`，消除误标记 |
| FIX-1.2 | 修复 PropagateUserStrings 传播逻辑 | 正常线 + 正切线合并时，结果应保持为正常线（而非继承 IsTangent） |
| FIX-1.3 | 实现分层组合优先级 | 改造融合管线为"先组合正常线 → 再组合相切线"的三阶段策略 |
| FIX-2.1 | 修复 DetectJunctionPoints 的 distTol 参数 | 交叉检测半径不使用 geometry tolerance，改用基于模型包围盒的自适应阈值 |
| FIX-2.2 | 修复 GetMinTangentAngle 角度判断漏洞 | 增加端点连接方式与夹角的交叉验证，排除垂直线被误判 |
| FIX-2.3 | 为阶段2全局贪心增加交叉感知 | 阶段2合并时，若候选对涉及交叉节点且夹角过大，跳过合并 |
| FIX-3.1 | 将 CaptureViewRender 从视口截图改为真正渲染 | 使用 `Rhino.Render.RenderToBitmap()` 或 `ViewCapture` + Rendered 显示模式 |
| FIX-3.2 | 截图前隐藏线框图层，截图后恢复 | 临时隐藏 `Patent_Drawings_2D` 和 `TangentEdges` 图层 |
| FIX-3.3 | 渲染图以 PictureFrame 放入 Rhino 模型 | 使用 `doc.Objects.AddPictureFrame()` 将合成位图作为模型内对象插入 |

### ❌ 本期不做

| 排除项 | 原因 |
|---|---|
| ❌ 渲染风格/材质自定义 | 仍属原始计划的 Scope Out |
| ❌ 线宽/线型差异化 | 仍属原始计划的 Scope Out |
| ❌ 自动标注/尺寸线 | 不在修复范围内 |
| ❌ Rhino 8 兼容 | 当前绑定 Rhino 7 SR35 |
| ❌ 渲染输出路径 UI 控件移除 | 保留路径控件作为临时文件路径，PictureFrame 仍需先写临时文件再读入 |

---

## 3. 核心场景

### 场景 A：专利工程师区分正切线与正常线

> 专利工程师小王处理含圆角的机械零件，发现圆角过渡线（正切边缘）与棱边线混在一起，无法分别选中设置线型。修复后，圆角弧线正确标记为 `IsTangent` 并位于 `TangentEdges` 子图层，棱边线位于主图层；组合时正常棱边线先合并为连续链路，再合并相切线，不出现"正常线被正切线抢占"的问题。

### 场景 B：多管交叉模型的线框质量

> 工程师小张处理三管交叉模型，发现交叉处几乎垂直的线被错误合并，导致线框在交叉点出现畸形。修复后，交叉检测使用合理的空间阈值，角度判断排除垂直误判，全局贪心阶段感知交叉拓扑，趋近相切的线优先合并。

### 场景 C：渲染图作为模型内对象

> 专利律师小李勾选"渲染输出"后，期望渲染图作为 Rhino 模型内的对象直接可见，而非导出外部文件。修复后，渲染图以 PictureFrame 形式放入模型，且不包含已输出的线框图层内容，是真正的渲染效果而非截图。

---

## 4. 功能拆解与优先级

| 功能 | 描述 | 优先级 | 负责专家 |
|---|---|---|---|
| FIX-1.1 | 正切识别方案切换为 BrepEdge.EdgeConvexity | Must | code |
| FIX-1.2 | PropagateUserStrings 传播逻辑修复 | Must | code |
| FIX-1.3 | 分层组合优先级（先正常线、后相切线） | Must | code |
| FIX-2.1 | DetectJunctionPoints distTol 自适应阈值 | Must | code |
| FIX-2.2 | GetMinTangentAngle 角度交叉验证 | Must | code |
| FIX-2.3 | 阶段2全局贪心增加交叉感知 | Should | code |
| FIX-3.1 | CaptureViewRender 改为真正渲染 | Must | code |
| FIX-3.2 | 截图前隐藏线框图层 | Must | code |
| FIX-3.3 | 渲染图以 PictureFrame 放入模型 | Must | code |

---

## 5. 用户故事与验收标准

### US-FIX1：正切线正确识别与分层组合

- **故事**: 作为专利工程师，我希望正切边缘线被正确识别（不被误标记），且组合时正常线先合并、再合并相切线，以便线框图在交叉处干净、分组准确
- **验收 (Given/When/Then)**:
  - Given 模型包含圆角/倒角, When 执行生成, Then 仅真正相切的边缘线标记为 `IsTangent=true`，内部投影线段不被误标记
  - Given 含圆角模型生成后, When 检查图层, Then 正切边缘线位于 TangentEdges 子图层，正常线位于主图层
  - Given 含交叉节点的模型, When 检查融合结果, Then 正常线先形成连续链路，相切线随后合并，不存在正常线被正切线"抢占"的情况
  - Given 正常线与正切线被合并后, When 检查结果的 IsTangent 标记, Then 结果保持为正常线（IsTangent 不为 true），即多数表决或正常线优先

### US-FIX2：多线交叉处趋近相切的线优先组合

- **故事**: 作为专利工程师，我希望多线交叉处趋近相切的线优先合并，几乎垂直的线不被错误合并，以便线框在复杂交叉点保持正确拓扑
- **验收 (Given/When/Then)**:
  - Given 含三管交叉的模型, When 执行生成, Then 交叉处夹角 ≤ 阈值的线优先合并，夹角 ≥ 80° 的线对不被合并
  - Given 交叉节点处, When 检测交叉点, Then 交叉检测半径基于模型包围盒自适应计算，不受用户 geometry tolerance 误影响
  - Given 两条几乎垂直的线在某端点恰好接近, When 角度判断, Then 不会被误判为"可合并"

### US-FIX3：渲染图正确输出为模型内对象

- **故事**: 作为专利工程师，我希望渲染输出是真正的渲染效果（非截图），不包含已输出的线框图，且渲染图作为 Rhino 模型内的对象放入，以便直接在 Rhino 中查看和使用
- **验收 (Given/When/Then)**:
  - Given 勾选渲染输出并执行生成, When 查看渲染图内容, Then 渲染图不包含线框图层上的曲线
  - Given 勾选渲染输出并执行生成, When 检查渲染效果, Then 渲染图具有光影效果（非简单视口截图）
  - Given 渲染图生成完成, When 在 Rhino 中检查, Then 渲染图以 PictureFrame 对象存在于模型中，而非仅保存为外部文件
  - Given 渲染图已放入模型, When 用户关闭 Rhino 后重新打开, Then 渲染图仍然存在于模型中

### 验收清单汇总表

| AC-ID | 验收点（一句话，可被自动化测试验证） | 优先级 | 关联 US |
|---|---|---|---|
| AC-F1-1 | 含圆角模型生成后，仅 BrepEdge.EdgeConvexity==Tangent 对应的线段带 IsTangent=true 标记 | P0 | US-FIX1 |
| AC-F1-2 | 不含圆角/倒角的纯棱柱模型，无曲线带 IsTangent 标记 | P1 | US-FIX1 |
| AC-F1-3 | 正常线与正切线合并后，结果的 IsTangent 标记为 false（正常线优先） | P0 | US-FIX1 |
| AC-F1-4 | 融合管线按"先正常线→后相切线"顺序执行组合 | P0 | US-FIX1 |
| AC-F1-5 | 正切边缘线位于 TangentEdges 子图层，正常线位于 Patent_Drawings_2D 主图层 | P0 | US-FIX1 |
| AC-F2-1 | 交叉检测半径基于模型包围盒对角线长度自适应计算，不直接使用用户 tolerance | P0 | US-FIX2 |
| AC-F2-2 | 夹角 ≥ 80° 的线对不被合并（即使某端点连接方式下夹角较小） | P0 | US-FIX2 |
| AC-F2-3 | 三管交叉模型生成后，交叉处趋近相切的线合并为连续曲线 | P0 | US-FIX2 |
| AC-F2-4 | 阶段2全局贪心合并时，涉及交叉节点且夹角过大的候选对被跳过 | P1 | US-FIX2 |
| AC-F3-1 | 渲染捕获使用 Rendered 显示模式或 RenderToBitmap API，非 Shaded 截图 | P0 | US-FIX3 |
| AC-F3-2 | 渲染捕获期间，Patent_Drawings_2D 和 TangentEdges 图层被临时隐藏 | P0 | US-FIX3 |
| AC-F3-3 | 渲染捕获完成后，线框图层恢复为原始可见状态 | P0 | US-FIX3 |
| AC-F3-4 | 渲染图以 PictureFrame 对象存在于 Rhino 文档中 | P0 | US-FIX3 |
| AC-F3-5 | 渲染图 PictureFrame 的位置与线框排版位置不重叠 | P1 | US-FIX3 |
| AC-F3-6 | 勾选渲染输出不导出外部 PNG 文件（或 PNG 仅作为临时文件，最终以 PictureFrame 放入模型） | P0 | US-FIX3 |

---

## 6. 流程 / 信息架构

### 6.1 缺陷1修复 — 分层组合优先级流程

```mermaid
flowchart TD
    A[HiddenLineDrawing 投影] --> B[提取可见线段]
    B --> C{正切边缘识别}
    C -->|方案B: BrepEdge.EdgeConvexity==Tangent| D[标记 IsTangent=true]
    C -->|非正切边缘| E[保持默认]
    D --> F[CleanRawCurves 去重清洗]
    E --> F
    F --> G{外轮廓特权隔离}
    G --> H[外轮廓独立闭环]
    G --> I[内部线进入融合池]
    H --> J[分层融合]
    I --> J
    J --> K[阶段0: 仅正常线互相组合]
    K --> L[阶段1: 交叉节点处相切线局部合并]
    L --> M[阶段2: 全局贪心融合 带交叉感知]
    M --> N[分组烘焙输出]
    N --> O[正常线 → 主图层]
    N --> P[正切边缘线 → TangentEdges 子图层]
```

### 6.2 缺陷3修复 — 渲染输出流程

```mermaid
flowchart TD
    A[用户勾选渲染输出] --> B[线框管线执行]
    B --> C[线框烘焙到 Rhino 图层]
    C --> D[临时隐藏线框图层]
    D --> E[按视图模式创建渲染列表]
    E --> F[逐视图: 设置 Rendered 显示模式 + 捕获位图]
    F --> G[恢复线框图层可见性]
    G --> H[排版合成渲染位图]
    H --> I[保存临时 PNG 文件]
    I --> J["doc.Objects.AddPictureFrame() 插入模型"]
    J --> K[清理临时文件]
    K --> L[完成通知]
```

---

## 7. 风险与注意事项

| 风险 | 影响 | 缓解措施 |
|---|---|---|
| 方案B（BrepEdge.EdgeConvexity）在 HLD 上下文中 SourceObject 可能无法直接获取 BrepEdge | 无法通过方案B识别正切线 | 需在开发阶段先验证 HLD → SourceObject → BrepEdge 链路是否可达；若不可达，通过曲线端点处相邻面法线夹角推断 |
| PropagateUserStrings 改为"正常线优先"可能导致某些边缘情况正切标记丢失 | 正切线合并后标记为正常线 | 仅在"正常线+正切线"合并时正常线优先；"正切线+正切线"合并仍保持 IsTangent=true |
| RenderToBitmap / Rendered 显示模式在无材质场景下可能效果不佳 | 渲染图质量不理想 | 确保设置默认光照；可回退到 Shaded 模式但必须隐藏线框图层 |
| AddPictureFrame 需要先保存临时 PNG 文件再读入 | 需要文件 I/O，可能因权限问题失败 | 使用 Path.GetTempPath() 生成临时文件路径；异常时回退到仅导出 PNG |
| 渲染时临时隐藏图层可能被用户注意到"闪烁" | 用户体验轻微下降 | 隐藏/恢复操作在短时间内完成（毫秒级），用户感知极小 |
| 交叉检测自适应阈值的选择需要经验调优 | 阈值过大检测出伪交叉，过小漏检 | 默认值取包围盒对角线 × 0.005，同时设置上下限（不小于 10× tolerance，不大于包围盒对角线 × 0.02） |

---

## 8. 与原始计划（task-plan.md v1.1）的差异点说明

| 差异点 | 原始计划 | 修复计划 | 原因 |
|---|---|---|---|
| 正切识别方案 | 方案A（SilhouetteType.None）为主，方案B为备选 | 直接切换为方案B（BrepEdge.EdgeConvexity） | 用户测试证明方案A误标记严重，SilhouetteType.None 过于宽泛 |
| 融合管线阶段 | 两阶段（交叉感知 + 全局贪心） | 三阶段（正常线组合 → 交叉感知相切线合并 → 全局贪心带交叉感知） | 缺乏"先正常线、后相切线"的分层逻辑是核心缺陷 |
| PropagateUserStrings 行为 | 任意源带标记则继承 | 正常线优先（多数表决或非 IsTangent 优先） | 当前逻辑导致正常线与正切线合并后全部变正切线 |
| 交叉检测阈值 | 直接使用用户 tolerance | 基于模型包围盒自适应计算 | tolerance 是几何精度（0.001~0.1），不适合作为交叉检测半径 |
| 渲染捕获方式 | Shaded 显示模式 + CaptureToBitmap | Rendered 显示模式 或 RenderToBitmap | Shaded 仍是视口截图，不是真正渲染 |
| 线框图层处理 | 未考虑渲染时线框图层可见 | 渲染前临时隐藏线框图层 | 截图会误截已烘焙的线框 |
| 渲染输出方式 | PNG 文件导出 | PictureFrame 放入 Rhino 模型 | 用户要求"将排版好的图片放置在模型内不是导出" |

---

*修复任务计划书结束 — 待审核确认后进入执行阶段*
