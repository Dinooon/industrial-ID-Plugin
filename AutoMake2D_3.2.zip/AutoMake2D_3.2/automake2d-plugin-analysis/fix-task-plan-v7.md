# AutoMake2D 第七轮缺陷修复任务计划书 (V7)

> **版本**: v7.0 | **日期**: 2026-07-10 | **状态**: 待审核  
> **前置文档**: `fix-task-plan-v6.md` (v6.0, 第六轮修复)  
> **当前源码**: PatentCore.cs (V6 版本, 1478 行), PatentUiPanel.cs (214 行)  
> **核心原则**: 渲染输出图片物件居中 + 白色背景，两个缺陷并行修复

---

## 1. 背景与目标

### 1.1 问题

V6 修复（线框分类恢复 + Rendered 渲染模式 + 曲面边缘线）已部署，用户测试渲染输出后反馈**两个严重缺陷**——物件不居中（偏上+顶部截断）和背景非白色（冷灰色）。

#### 缺陷V7-1：渲染输出图片物件不居中

**现象**：  
渲染输出图片中，物件水平方向居中正常，但垂直方向严重偏上约 25% 图片高度。物件从图片第 0 行开始，顶部被裁切；图片下半部分约 50% 完全空白。

**根因分析**：

| # | 根因 | 方法名 | 行号(约) | 详细说明 |
|---|---|---|---|---|
| RC1.1 | 坐标空间不匹配 | `CaptureViewRender()` | 1164-1170 | `ZoomBoundingBox` 接收的是经过 `Transform.PlaneToPlane(viewPlane, WorldXY)` 变换后的包围盒 `viewBbox`，但视口相机仍处于 `viewPlane` 坐标系，导致 ZoomBoundingBox 的居中计算在错误的坐标空间中执行 |
| RC1.2 | 居中变换多余 | `CaptureViewRender()` | 1166-1167 | V5 引入的居中变换（`Transform.Translation(-bboxCenter)` + `vp.SetCameraTarget(Origin)`）在 PlaneToPlane 变换后的坐标空间中操作，进一步放大了坐标空间不匹配的影响 |
| RC1.3 | 无边距保护 | `CaptureViewRender()` | 1169 | `viewBbox.Inflate(margin)` 仅扩展了 5%（总边距 10%），对于坐标空间不匹配导致的偏移量级不足，且贴边渲染在正常情况下也不美观 |

**偏移量级估算**：假设模型包围盒中心偏离 viewPlane.Origin 的 Z 分量为 500mm，PlaneToPlane 变换将其映射到 Y 轴方向，导致 ZoomBoundingBox 的视图中心偏移约 500 单位，在 900px 高的图片中约占 25% — 与用户反馈吻合。

#### 缺陷V7-2：渲染输出图片背景非白色

**现象**：  
渲染输出图片背景为均匀的冷灰色 RGB(156,162,169)，而非期望的纯白色 RGB(255,255,255)。

**根因分析**：

| # | 根因 | 方法名 | 行号(约) | 详细说明 |
|---|---|---|---|---|
| RC2.1 | DrawBackground=false 无白底补偿 | `CaptureViewRender()` | 1196 | V6 已将 `DrawBackground` 设为 `false`（避免 Rhino 默认灰背景），但**未在捕获后填充白色背景**，导致位图中物件外部区域为透明/黑色像素 |
| RC2.2 | 单视图直出无白底处理 | `ComposeRenderLayout()` | 1330-1337 | 单视图分支直接 `return enumerator.Current`，完全跳过合成阶段，无任何白底填充机会 |
| RC2.3 | 多视图合成的 g.Clear(White) 被子图覆盖 | `ComposeSixViewLayout` 等 | 1392/1427/1452 | 多视图合成虽在画布上 `g.Clear(Color.White)`，但子图本身非白底（透明区域或灰背景），DrawImage 覆盖了白色填充 |

**背景色来源解释**：V6 设置 `DrawBackground=false`，理论上位图背景应为透明（PNG alpha 通道）或黑色。但用户看到 RGB(156,162,169) 冷灰色，可能是因为：(1) `CaptureToBitmap` 在 `RasterMode=true` + `DrawBackground=false` 时仍渲染了视口环境色；(2) PNG 透明像素在查看器中显示为灰色。无论哪种情况，修复方案均为**强制白底合成**。

### 1.2 目标用户

专利工程师 / 专利律师 — 使用 AutoMake2D 生成专利申请用的渲染效果图，要求物件居中且白色背景

### 1.3 业务目标与可验证指标

| 缺陷 | 修复目标 | 可验证指标 |
|---|---|---|
| 缺陷V7-1 | 渲染输出图片中物件在水平+垂直方向均居中显示 | 物件中心与图片中心偏移 ≤ 图片尺寸的 5%；物件完整可见无截断；四边留白均匀且 ≥ 物件尺寸的 5% |
| 缺陷V7-2 | 渲染输出图片背景为纯白色 | 背景像素 RGB 值均为 (255,255,255)，偏差 ≤ 5；无论单视图还是多视图输出均满足 |

---

## 2. 范围 (Scope)

### ✅ 本期做

| 编号 | 修复项 | 说明 |
|---|---|---|
| FIX-V7-1.1 | 修复 CaptureViewRender() 的 ZoomBoundingBox 坐标空间 | 移除 PlaneToPlane 变换，直接在世界坐标系中使用模型包围盒进行 ZoomBoundingBox；或同时将相机变换到 WorldXY 使坐标空间一致 |
| FIX-V7-1.2 | 修复居中逻辑 | 移除 V5 的居中变换（Translation + SetCameraTarget(Origin)），改为在视口相机坐标系中正确居中 |
| FIX-V7-1.3 | 增加边距 | 将 Inflate 边距从 5% 增加到 10-15%，确保物件不贴边且四周留白均匀 |
| FIX-V7-2.1 | CaptureViewRender 捕获后白底合成 | DrawBackground=false 保持不变，捕获位图后用 `Graphics.Clear(White)` + `DrawImage` 合成白底位图 |
| FIX-V7-2.2 | 单视图直出分支添加白底处理 | ComposeRenderLayout() 单视图分支不再直接返回原始位图，先做白底合成再返回 |
| FIX-V7-2.3 | 多视图合成子图白底预处理 | 多视图排版前对每个子图先做白底预处理，确保子图本身有白底 |

### ❌ 本期不做

| 排除项 | 原因 |
|---|---|
| ❌ 修改渲染材质/光照/阴影效果 | V6 已修复 Rendered 模式，本期不涉及 |
| ❌ 曲面边缘线相关修改 | V6 已修复，本期不涉及 |
| ❌ 线框分类逻辑修改 | V6 已恢复，本期不涉及 |
| ❌ 修改 PictureFrame 放置逻辑 | PictureFrame 在模型空间的位置不影响渲染输出图片的居中 |
| ❌ 修改输出图片分辨率 | 当前 1200×900 满足需求 |
| ❌ 修改 GetModelBoundingBoxExcludingPatentLayers() 排除规则 | V6 已排除 Patent_ 前缀图层和 PictureFrame 和 InstanceReference，本期不调整 |

---

## 3. 核心场景

### 场景 A：专利工程师输出单视图渲染图

> 专利工程师小张勾选"渲染输出"并选择单个视图（如 Front），执行 AutoMake2D。V6 版本输出的图片物件偏上且顶部截断、背景为冷灰色。修复后，物件在图片中央完整显示，四周留白均匀，背景为纯白色，可直接用于专利申请材料。

### 场景 B：专利工程师输出多视图渲染图

> 专利工程师小李勾选"渲染输出"并选择六视图模式。V6 版本输出的排版图中每个子视图都有冷灰色背景。修复后，每个子视图物件居中、白底，合成的排版图整体背景也为白色。

### 场景 C：专利工程师输出等轴测视图

> 专利工程师小王勾选 IsoFront 视图渲染。等轴测视图的 viewPlane 非标准正交平面，PlaneToPlane 变换对非标准平面的影响更大。修复后，等轴测视图的物件同样居中显示，与正交视图行为一致。

---

## 4. 功能拆解与优先级

| 功能 | 描述 | 优先级 | 负责专家 |
|---|---|---|---|
| FIX-V7-1.1 | 修复 ZoomBoundingBox 坐标空间不匹配 | **Must** | code |
| FIX-V7-1.2 | 移除 V5 居中变换，改用正确居中逻辑 | **Must** | code |
| FIX-V7-1.3 | 增加边距至 10-15% | **Should** | code |
| FIX-V7-2.1 | CaptureViewRender 捕获后白底合成 | **Must** | code |
| FIX-V7-2.2 | 单视图直出分支白底处理 | **Must** | code |
| FIX-V7-2.3 | 多视图子图白底预处理 | **Must** | code |

---

## 5. 用户故事与验收标准

### US-1：渲染输出图片物件居中

**故事**: 作为专利工程师，我希望渲染输出图片中的物件在水平和垂直方向均居中显示，且完整可见无截断，以便图片可直接用于专利申请材料而无需手动调整。

**验收 (Given/When/Then)**:
- Given 任意 3D 模型, When 执行单视图渲染输出(Front), Then 物件在图片中水平+垂直方向均居中（偏移 ≤ 5% 图片尺寸）
- Given 任意 3D 模型, When 执行单视图渲染输出, Then 物件完整可见，顶部/底部/左侧/右侧均无截断
- Given 任意 3D 模型, When 执行渲染输出, Then 物件四周留白均匀且 ≥ 物件尺寸的 5%
- Given 等轴测视图(IsoFront/IsoBack), When 执行渲染输出, Then 等轴测视图物件同样居中显示
- Given 非对称模型(包围盒中心偏离原点), When 执行渲染输出, Then 物件仍然居中显示

### US-2：渲染输出图片背景纯白

**故事**: 作为专利工程师，我希望渲染输出图片的背景为纯白色，无论单视图还是多视图模式，以便图片符合专利申请材料的标准格式要求。

**验收 (Given/When/Then)**:
- Given 勾选渲染输出并执行, When 检查单视图输出图片, Then 背景像素 RGB 值均为 (255,255,255)，偏差 ≤ 5
- Given 勾选六视图渲染输出并执行, When 检查排版图片, Then 整体背景为白色（含子图间隙区域和子图内部非物件区域）
- Given 勾选三视图渲染输出并执行, When 检查排版图片, Then 整体背景为白色
- Given 非标准视图组合渲染, When 检查排版图片, Then 背景为白色

### 验收清单汇总表

| AC-ID | 验收点 (一句话, 可被自动化测试验证) | 优先级 | 关联 US |
|---|---|---|---|
| AC-1 | CaptureViewRender 中 ZoomBoundingBox 接收世界坐标包围盒（未经 PlaneToPlane 变换） | P0 | US-1 |
| AC-2 | CaptureViewRender 中无 PlaneToPlane(viewPlane, WorldXY) 变换 | P0 | US-1 |
| AC-3 | CaptureViewRender 中无 V5 居中变换（Transform.Translation(-bboxCenter)） | P0 | US-1 |
| AC-4 | 单视图渲染输出图片中物件中心与图片中心偏移 ≤ 图片尺寸的 5% | P0 | US-1 |
| AC-5 | 单视图渲染输出图片中物件完整可见（四边无截断） | P0 | US-1 |
| AC-6 | Inflate 边距 ≥ 包围盒对角线长度的 10% | P1 | US-1 |
| AC-7 | CaptureViewRender 返回的位图已做白底合成（DrawBackground=false + Graphics.Clear(White) + DrawImage） | P0 | US-2 |
| AC-8 | 单视图直出分支返回的位图有白色背景 | P0 | US-2 |
| AC-9 | 多视图合成中每个子图在 DrawImage 前已做白底预处理 | P0 | US-2 |
| AC-10 | 单视图输出图片背景像素 RGB 平均值与 (255,255,255) 偏差 ≤ 5 | P0 | US-2 |
| AC-11 | 多视图排版图片间隙区域和子图非物件区域背景为白色 | P0 | US-2 |
| AC-12 | 编译通过，0 errors | P0 | 全部 |

---

## 6. 流程 / 信息架构

### 6.1 V7 渲染捕获流程（修复居中+白底）

```mermaid
flowchart TD
    A[CaptureViewRender] --> B[创建临时视口]
    B --> C[设置平行投影 + 相机位置<br/>cameraLocation = viewPlane.Origin + viewPlane.ZAxis × 1000<br/>cameraDirection = -viewPlane.ZAxis<br/>cameraUp = viewPlane.YAxis]
    C --> D[设置 Rendered 显示模式<br/>+ TryEnableSurfaceEdges]
    D --> E[获取模型包围盒<br/>GetModelBoundingBoxExcludingPatentLayers<br/>返回世界坐标 BoundingBox]
    E --> F["【V7修复】直接在世界坐标系中 ZoomBoundingBox<br/>1. 计算模型包围盒在视口相机方向的投影范围<br/>2. ZoomBoundingBox(modelBox) — 不做 PlaneToPlane 变换<br/>3. Inflate(10-15%) 留边距"]
    F --> G[Redraw × 2]
    G --> H["ViewCapture.CaptureToBitmap<br/>DrawBackground = false<br/>RasterMode = true"]
    H --> I["【V7修复】白底合成<br/>1. 创建同尺寸白色位图<br/>2. g.Clear(Color.White)<br/>3. g.DrawImage(capturedBmp, 0, 0)<br/>4. 返回白底位图"]
    I --> J[关闭临时视口]
    J --> K[返回白底位图]
```

### 6.2 V7 排版合成流程（修复单视图白底）

```mermaid
flowchart TD
    A[ComposeRenderLayout] --> B{视图数量?}
    B -- "1" --> C["【V7修复】单视图白底处理<br/>1. 创建同尺寸白色位图<br/>2. g.Clear(Color.White)<br/>3. g.DrawImage(原始位图, 0, 0)<br/>4. 返回白底位图"]
    B -- ">1" --> D["多视图排版<br/>（子图已有白底，g.Clear(White) 有效）"]
    D --> D1[ComposeSixViewLayout / ThreeViewLayout / GenericLayout]
    D1 --> E[返回排版位图]
```

### 6.3 坐标空间对比

```mermaid
flowchart LR
    subgraph "V6（错误）"
        A1[模型包围盒 modelBox<br/>世界坐标] --> B1["PlaneToPlane(viewPlane, WorldXY)<br/>变换为 viewBbox"]
        B1 --> C1["Translation(-bboxCenter)<br/>居中到原点"]
        C1 --> D1[ZoomBoundingBox viewBbox<br/>❌ 相机在 viewPlane 空间<br/>包围盒在 WorldXY 空间<br/>空间不匹配！]
    end
    
    subgraph "V7（修复）"
        A2[模型包围盒 modelBox<br/>世界坐标] --> B2["直接传给 ZoomBoundingBox<br/>或变换相机到 WorldXY"]
        B2 --> C2["ZoomBoundingBox modelBox<br/>✅ 相机和包围盒在同一空间"]
        C2 --> D2["Inflate(10-15%)<br/>留边距"]
    end
```

---

## 7. 风险与未决问题

| ID | 风险 | 影响 | 缓解措施 |
|---|---|---|---|
| RK-1 | ZoomBoundingBox 对非标准 viewPlane（如 IsoFront）的世界坐标包围盒可能无法正确计算视口缩放 | 等轴测视图物件仍然偏移 | 方案A：在 ZoomBoundingBox 前将包围盒投影到视口相机坐标系（计算 viewPlane 法线方向的深度范围）；方案B：改用 vp.ZoomExtents() 然后手动调整缩放比 |
| RK-2 | DrawBackground=false 后 CaptureToBitmap 返回的位图可能有透明通道（ARGB），DrawImage 到白底时透明区域正确显示为白色，但物件边缘可能有抗锯齿伪影 | 渲染图物件边缘有白边或锯齿 | 方案A：设置 g.CompositingMode = SourceOver（默认）+ g.SmoothingMode 确保正确混合；方案B：若伪影严重，改回 DrawBackground=true + 设置视口白色背景方案 |
| RK-3 | Inflate(10-15%) 对极小或极大模型可能不足或过大 | 物件贴边或留白过多 | 使用对角线长度百分比 + 最小边距像素值双重保护 |
| RK-4 | 多次创建 Bitmap 对象（白底合成）可能导致内存压力 | 大模型多视图渲染时内存占用高 | 使用 using 语句及时释放原始位图；单视图分支白底合成后 dispose 原始位图 |

### 未决问题

1. **ZoomBoundingBox 是否支持非标准坐标系包围盒？** Rhino SDK 文档中 ZoomBoundingBox 的行为未明确说明对非 WorldXY 坐标系包围盒的处理。需测试或查阅 API 文档。
2. **DrawBackground=false 时位图是否有 Alpha 通道？** 如果位图有 Alpha 通道，白底合成时需设置正确的 CompositingMode；如果是纯 RGB 无 Alpha，则直接 DrawImage 即可。
3. **是否需要设置视口白色背景作为双重保险？** 在 DrawBackground=false + 白底合成的基础上，是否还需要在临时视口设置 DisplayMode 的背景为白色？答案：不需要，白底合成已解决此问题，设置视口白背景是冗余操作。

---

## 8. 与 V6 计划的差异对比

| 维度 | V6 计划 | V7 计划 | 变更原因 |
|---|---|---|---|
| **渲染居中** | PlaneToPlane 变换 + Translation 居中 + 5% Inflate | **直接世界坐标 ZoomBoundingBox + 10-15% Inflate** | 坐标空间不匹配导致物件偏上 |
| **渲染背景** | DrawBackground=true（使用 Rhino 默认灰背景）→ V6 已改为 false | **DrawBackground=false + 白底合成** | DrawBackground=false 无白底补偿导致冷灰色背景 |
| **单视图输出** | 直接返回原始位图 | **白底合成后返回** | 单视图直出跳过白底处理 |
| **多视图合成** | g.Clear(White) 但子图非白底 | **子图先白底预处理 + g.Clear(White)** | 子图灰背景覆盖了画布白色填充 |

---

*第七轮修复任务计划书结束 — 待审核确认后进入执行阶段*
