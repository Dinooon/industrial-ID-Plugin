# AutoMake2D 2.0 优化执行计划书

> 版本: v1.1 (渲染输出视图联动修订)  
> 日期: 2026-07-09  
> 状态: 待用户审核  
> 前置文档: `task-plan.md`

---

## 1. 技术方案总览

两项需求的技术改动集中在 `PatentCore.cs`（核心引擎）和 `PatentUiPanel.cs`（UI 面板），不涉及插件入口和命令文件。整体策略为**最小侵入**——在现有管线中插入新的识别/分组/捕获环节，而非重构管线。

| 需求 | 涉及文件 | 改动性质 |
|---|---|---|
| 需求1：线框分组+融合优化 | `PatentCore.cs` | 修改 `ComputeSingleViewEngine()`、`JoinTangentCurvesPrioritized()`；新增正切识别与交叉检测逻辑 |
| 需求2：渲染输出（视图联动模式） | `PatentCore.cs` + `PatentUiPanel.cs` | 新增渲染捕获与排版方法（按视图模式动态生成）；UI 新增 CheckBox + 路径选择 |

---

## 2. 需求1 — 技术方案：线框分组与融合策略优化

### 2.1 正切边缘线识别（F1.1）

**改动文件**: `PatentCore.cs` — `ComputeSingleViewEngine()` 方法

**当前代码**（第 ~行，隐线计算后提取可见段）:
```csharp
// 当前：仅提取 Visible 段，不做正切区分
foreach (var seg in hld.Segments)
{
    if (seg.SegmentVisibility == SegmentVisibility.Visible)
    {
        // 提取曲线 + 零件归属 + 外轮廓标记
    }
}
```

**改造方案**:

```csharp
// 改造后：在提取可见段时，同步识别正切边缘
foreach (var seg in hld.Segments)
{
    if (seg.SegmentVisibility != SegmentVisibility.Visible) continue;

    var curve = seg.Curve.DuplicateCurve();
    
    // [新增] 正切边缘识别逻辑
    bool isTangentEdge = false;
    
    // 方案A：通过 SegmentType 判定（需验证 Rhino SDK 是否提供区分）
    // HiddenLineDrawingSegment 可能包含 SilhouetteType 或 SegmentType 属性
    // 若 seg 对应的 ParentCurve.SourceObject 为圆角/倒角面的边，则判定为正切边缘
    
    // 方案B（备选）：通过 ParentCurve 的几何特征推断
    // 检查 seg.ParentCurve.SourceObject 的 BrepEdge 是否属于光滑连接（EdgeConvexity = Tangent）
    
    if (isTangentEdge)
    {
        curve.SetUserString("IsTangent", "true");
    }
    
    // 原有的零件归属 + 外轮廓标记逻辑不变
    var componentName = seg.ParentCurve.SourceObject.Tag as string;
    curve.SetUserString("ComponentName", componentName);
    
    bool isOuter = seg.SilhouetteType == SilhouetteType.Projecting 
                || seg.SilhouetteType == SilhouetteType.Boundary;
    if (isOuter) curve.SetUserString("IsOuter", "true");
    
    rawCurves.Add(curve);
}
```

**关键技术验证点**:
- `HiddenLineDrawingSegment` 是否暴露正切边缘的属性（开发第一步需在 Rhino 中用测试模型验证）
- 备选方案：遍历 `hld.Curves` → 每个 `HiddenLineDrawingCurve` 有 `SourceObject` → 获取 `BrepEdge.EdgeConvexity`，若为 `Tangent` 则对应的所有 Segments 标记为正切边缘
- 终极备选：若 SDK 不提供直接区分，则根据 `HiddenLineDrawingCurve.TrimType` 或曲线与邻接面的夹角推断

### 2.2 分组标记（F1.2）

**改动文件**: `PatentCore.cs`

已在 2.1 中通过 `SetUserString("IsTangent", "true")` 实现。无需额外方法，数据随曲线对象传播。

### 2.3 分组烘焙（F1.3）

**改动文件**: `PatentCore.cs` — `BakeToRhinoGrouped()` 方法

**当前代码**:
```csharp
// 当前：所有曲线烘焙到同一图层 Patent_Drawings_2D
var layer = doc.Layers.FindName("Patent_Drawings_2D");
```

**改造方案**:

```csharp
// 改造后：正切边缘线输出到子图层
var mainLayer = doc.Layers.FindName("Patent_Drawings_2D");
if (mainLayer == null)
{
    mainLayer = new Layer { Name = "Patent_Drawings_2D", Color = System.Drawing.Color.Black };
    mainLayer = doc.Layers.Add(mainLayer);
}

// 新增子图层
var tangentLayer = doc.Layers.FindName("Patent_Drawings_2D::TangentEdges");
if (tangentLayer == null)
{
    tangentLayer = new Layer { Name = "TangentEdges", ParentLayerId = mainLayer.Id, Color = System.Drawing.Color.Blue };
    tangentLayer = doc.Layers.Add(tangentLayer);
}

// 烘焙时根据 IsTangent 标记分发
foreach (var curve in curves)
{
    bool isTangent = curve.GetUserString("IsTangent") == "true";
    var targetLayer = isTangent ? tangentLayer : mainLayer;
    var obj = doc.Objects.AddCurve(curve, new ObjectAttributes { LayerIndex = targetLayer.Index });
    // ... Group 逻辑不变
}
```

### 2.4 交叉感知融合（F1.4）

**改动文件**: `PatentCore.cs` — `JoinTangentCurvesPrioritized()` 方法

**当前逻辑**:
1. 计算所有曲线对的最小切线夹角
2. 筛选夹角 ≤ 0.08 弧度的候选对
3. 按夹角升序排序，逐对贪心合并
4. 问题：全局贪心不考虑交叉拓扑，交叉节点处相切线可能被非相切线抢占

**改造方案 — 两阶段融合**:

```
阶段1：交叉节点检测 + 相切线局部链路合并
阶段2：剩余线全局贪心融合（复用现有逻辑）
```

**伪代码**:

```csharp
List<Curve> JoinTangentCurvesPrioritized_V2(List<Curve> curves, double angleTolRad, double distTol)
{
    // === 阶段1：交叉感知的相切线链路合并 ===
    
    // 1.1 构建端点邻接图：找出所有"多线交叉节点"
    // 对每条曲线的起点和终点，用 RTree 查找 distTol 范围内的其他曲线端点
    // 若某端点邻接 ≥3 条曲线，则该端点为"交叉节点"
    var junctionPoints = DetectJunctionPoints(curves, distTol);
    // junctionPoints: List<(Point3d position, List<int> curveIndices)>
    
    // 1.2 在每个交叉节点处，优先合并相切线对
    var mergedIndices = new HashSet<int>();
    var resultCurves = new List<Curve>();
    
    foreach (var junction in junctionPoints)
    {
        // 获取交叉节点处的所有相切候选对
        var tangentPairsAtJunction = new List<(int i, int j, double angle)>();
        for (int a = 0; a < junction.curveIndices.Count; a++)
        {
            for (int b = a + 1; b < junction.curveIndices.Count; b++)
            {
                int ci = junction.curveIndices[a];
                int cj = junction.curveIndices[b];
                if (mergedIndices.Contains(ci) || mergedIndices.Contains(cj)) continue;
                
                double minAngle = GetMinTangentAngle(curves[ci], curves[cj], distTol);
                if (minAngle <= angleTolRad)
                {
                    tangentPairsAtJunction.Add((ci, cj, minAngle));
                }
            }
        }
        
        // 按夹角升序排序，逐对合并
        tangentPairsAtJunction.Sort((a, b) => a.angle.CompareTo(b.angle));
        foreach (var pair in tangentPairsAtJunction)
        {
            if (mergedIndices.Contains(pair.i) || mergedIndices.Contains(pair.j)) continue;
            var joined = Curve.JoinCurves(new[] { curves[pair.i], curves[pair.j] });
            if (joined.Length == 1)
            {
                resultCurves.Add(joined[0]);
                mergedIndices.Add(pair.i);
                mergedIndices.Add(pair.j);
            }
        }
    }
    
    // 1.3 未被合并的曲线加入剩余池
    var remainingCurves = new List<Curve>();
    for (int i = 0; i < curves.Count; i++)
    {
        if (!mergedIndices.Contains(i))
            remainingCurves.Add(curves[i]);
    }
    // 阶段1合并的结果也加入剩余池（作为新曲线参与阶段2）
    remainingCurves.AddRange(resultCurves);
    
    // === 阶段2：全局相切贪心融合（复用原有逻辑） ===
    return JoinTangentCurvesPrioritized_Original(remainingCurves, angleTolRad, distTol);
}

List<(Point3d pos, List<int> indices)> DetectJunctionPoints(List<Curve> curves, double distTol)
{
    // 用 RTree 索引所有曲线端点
    var rtree = new RTree();
    var endpoints = new List<(Point3d point, int curveIndex, bool isStart)>();
    for (int i = 0; i < curves.Count; i++)
    {
        var start = curves[i].PointAtStart;
        var end = curves[i].PointAtEnd;
        rtree.Insert(start, i * 2);
        rtree.Insert(end, i * 2 + 1);
        endpoints.Add((start, i, true));
        endpoints.Add((end, i, false));
    }
    
    // 查找每个端点的邻接曲线数
    var junctions = new List<(Point3d pos, List<int> indices)>();
    for (int i = 0; i < endpoints.Count; i++)
    {
        var neighbors = new HashSet<int>();
        rtree.Search(new Sphere(endpoints[i].point, distTol), (sender, args) =>
        {
            int curveIdx = args.Id / 2;
            if (curveIdx != endpoints[i].curveIndex)
                neighbors.Add(curveIdx);
        });
        // 交叉节点定义：端点邻接 ≥2 条其他曲线（即该点共 ≥3 条曲线交汇）
        if (neighbors.Count >= 2)
        {
            var allCurvesAtPoint = new List<int>(neighbors);
            allCurvesAtPoint.Add(endpoints[i].curveIndex);
            junctions.Add((endpoints[i].point, allCurvesAtPoint));
        }
    }
    return junctions;
}
```

**关键设计决策**:
- 交叉节点阈值：端点 distTol 范围内 ≥3 条曲线交汇 → 标记为交叉节点
- 两阶段策略保证：交叉处相切线优先合并，但不破坏非交叉处的全局贪心效果
- `DetectJunctionPoints()` 为新增私有方法，复用已有的 RTree 空间索引模式

---

## 3. 需求2 — 技术方案：渲染输出（视图联动模式）与排版

### 3.1 渲染模式选项（F2.1）

**改动文件**: `PatentUiPanel.cs`

**当前 UI 结构**:
```
DynamicLayout
├── 信息提示 Label
├── 警告 Label
├── 精度选择 (3× RadioButton)
├── 视角选择 (4× CheckBox)
├── 生成按钮
└── 进度反馈 (ProgressBar + Label)
```

**改造方案** — 在视角选择与生成按钮之间插入渲染输出区域:

```csharp
// PatentUiPanel.cs — 构造函数中新增

// 分隔线
layout.Add(new Eto.Forms.Separator());

// 渲染输出区域
var renderCheckBox = new Eto.Forms.CheckBox { Text = "渲染输出（与视图模式联动）" };
layout.Add(renderCheckBox);

// 输出路径（默认展开，渲染勾选时启用）
var pathLabel = new Eto.Forms.Label { Text = "输出路径:" };
var pathTextBox = new Eto.Forms.TextBox 
{ 
    Text = System.IO.Path.Combine(
        System.Environment.GetFolderPath(Environment.SpecialFolder.Desktop),
        "AutoMake2D_Render.png"
    )
};
var pathBrowseButton = new Eto.Forms.Button { Text = "浏览..." };

var pathRow = new Eto.Forms.StackLayout
{
    Orientation = Eto.Forms.Orientation.Horizontal,
    Items = { pathTextBox, pathBrowseButton }
};
layout.Add(pathLabel);
layout.Add(pathRow);

// 浏览按钮事件
pathBrowseButton.Click += (s, e) =>
{
    var dialog = new Eto.Forms.SaveFileDialog
    {
        Filters = { new Eto.Forms.FileFilter("PNG 图片", ".png") }
    };
    if (dialog.ShowDialog(this) == Eto.Forms.DialogResult.Ok)
        pathTextBox.Text = dialog.FileName;
};
```

**ExecuteAsync 签名扩展**:

```csharp
// 原签名
async Task ExecuteAsync(bool wantSix, bool wantIsoFront, bool wantIsoBack,
                        bool wantCurrent, double tolerance,
                        IProgress<int> progress, IProgress<string> status)

// 新签名（追加渲染参数）
async Task ExecuteAsync(bool wantSix, bool wantIsoFront, bool wantIsoBack,
                        bool wantCurrent, double tolerance,
                        bool wantRender, string renderOutputPath,   // 新增
                        IProgress<int> progress, IProgress<string> status)

// ⚠ 渲染参数与视图选择参数的联动关系说明:
// wantRender=true 时，渲染输出不固定遍历六视图，而是根据 wantSix/wantIsoFront/wantIsoBack/wantCurrent
// 等视图选择参数动态确定要渲染的视图列表，与线框输出完全一致:
//   - wantSix=true         → 渲染六标准视图 (Front/Top/Bottom/Left/Right/Back)
//   - wantIsoFront=true    → 渲染轴测前视图
//   - wantIsoBack=true     → 渲染轴测后视图
//   - wantCurrent=true     → 渲染当前视口视角
//   - 多个参数组合         → 渲染对应多个视图并排版
//   - 均为 false           → 无渲染输出（即使 wantRender=true）
```

### 3.2 渲染捕获（F2.2 — 视图联动模式）

**改动文件**: `PatentCore.cs` — 新增方法

**方案**: 使用 `ViewCapture` API 捕获指定视角的渲染位图。不再固定遍历六个标准视图，而是根据当前选定的视图模式参数动态确定要渲染的视图列表。

```csharp
/// <summary>
/// 捕获指定视图平面的渲染位图
/// </summary>
Bitmap CaptureViewRender(RhinoDoc doc, Plane viewPlane, string viewName, Size imageSize)
{
    // 1. 创建临时视口（不影响用户当前视图）
    var view = doc.Views.Add(viewName, DefinedViewportProjection.Perspective, 
                              new Rectangle(0, 0, imageSize.Width, imageSize.Height), false);
    
    // 2. 设置平行投影 + 相机位置
    var vp = view.ActiveViewport;
    vp.SetProjection(DefinedViewportProjection.Parallel, viewName, false);
    
    // 3. 根据视图平面调整相机
    // 将相机放置在 viewPlane 法线方向，朝向原点
    var cameraTarget = viewPlane.Origin;
    var cameraLocation = viewPlane.Origin + viewPlane.ZAxis * 1000;
    vp.SetCameraLocation(cameraLocation, false);
    vp.SetCameraTarget(cameraTarget, true);
    
    // 4. 设置默认光照（确保渲染可见）
    // 使用 Rhino 的默认光照设置或 DisplayMode
    
    // 5. 捕获位图
    var capture = new ViewCapture(view, imageSize.Width, imageSize.Height, true);
    // 或使用: ViewCapture.CaptureToBitmap(view, captureSettings)
    var bitmap = capture.CaptureToBitmap();
    
    // 6. 移除临时视口
    doc.Views.Remove(view, false);
    
    return bitmap;
}
```

**备选方案**（若 ViewCapture 不可用或效果不佳）:
- 使用 `DisplayPipeline.DrawOverlay()` + `Rhino.Render.RenderToBitmap()` 
- 使用 `RhinoView.CaptureToBitmap()` 直接截取视口渲染

**按视图模式动态确定渲染列表**（核心变更）:

```csharp
/// <summary>
/// 根据用户选定的视图模式参数，动态确定要渲染的视图列表
/// 渲染输出与线框输出的视图选择联动一致
/// </summary>
List<(string name, Plane plane)> DetermineRenderViews(
    bool wantSix, bool wantIsoFront, bool wantIsoBack, bool wantCurrent,
    BoundingBox modelBox, RhinoView currentView)
{
    var views = new List<(string name, Plane plane)>();
    var center = modelBox.Center;
    
    // 六视图模式：添加六个标准视图
    if (wantSix)
    {
        views.Add(("Front", GetViewPlane("Front", center)));
        views.Add(("Top", GetViewPlane("Top", center)));
        views.Add(("Bottom", GetViewPlane("Bottom", center)));
        views.Add(("Left", GetViewPlane("Left", center)));
        views.Add(("Right", GetViewPlane("Right", center)));
        views.Add(("Back", GetViewPlane("Back", center)));
    }
    
    // 轴测前视图
    if (wantIsoFront)
    {
        views.Add(("IsoFront", GetIsoViewPlane("Front", center)));
    }
    
    // 轴测后视图
    if (wantIsoBack)
    {
        views.Add(("IsoBack", GetIsoViewPlane("Back", center)));
    }
    
    // 当前视口视角
    if (wantCurrent && currentView != null)
    {
        var currentPlane = currentView.ActiveViewport.CameraPlane;
        views.Add(("Current", currentPlane));
    }
    
    return views;
}

/// <summary>
/// 按动态视图列表逐个捕获渲染位图
/// </summary>
Dictionary<string, Bitmap> CaptureViewsByMode(
    RhinoDoc doc, bool wantSix, bool wantIsoFront, bool wantIsoBack, bool wantCurrent,
    BoundingBox modelBox, RhinoView currentView, Size imageSize)
{
    // 1. 根据视图模式参数动态确定渲染列表
    var viewList = DetermineRenderViews(wantSix, wantIsoFront, wantIsoBack, wantCurrent, modelBox, currentView);
    
    if (viewList.Count == 0)
        return new Dictionary<string, Bitmap>();
    
    // 2. 逐视图捕获渲染位图
    var result = new Dictionary<string, Bitmap>();
    foreach (var (name, plane) in viewList)
    {
        var bitmap = CaptureViewRender(doc, plane, name, imageSize);
        if (bitmap != null)
            result[name] = bitmap;
    }
    
    return result;
}
```

### 3.3 图片排版（F2.3 — 动态排版）

**改动文件**: `PatentCore.cs` — 新增方法

**排版规则**（根据实际渲染视图数量动态排版，复用 `ArrangeEngineeringViewsGrouped()` 的布局逻辑）:

- **单视图**（1 张渲染位图）：无需排版，直接输出单张渲染 PNG
- **多视图**（2+ 张渲染位图）：按工程排版规则排列到一张合成图中
  - 三视图（如 Front/Top/Right）：按"长对正/高平齐"规则三格排版
  - 六视图：按标准六视图工程排版规则排列
  - 其他组合：按视图数量和类型动态计算布局

```csharp
/// <summary>
/// 根据实际渲染的视图数量动态排版
/// 单视图直接返回原位图，多视图按工程排版规则合成
/// </summary>
Bitmap ComposeRenderLayout(Dictionary<string, Bitmap> viewBitmaps, int dpi = 300)
{
    if (viewBitmaps.Count == 0)
        return null;
    
    // 单视图：无需排版，直接返回单张渲染位图
    if (viewBitmaps.Count == 1)
    {
        return viewBitmaps.Values.First();
    }
    
    // 多视图：根据视图数量和类型动态计算布局
    double refW = viewBitmaps.Values.Max(b => b.Width);
    double refH = viewBitmaps.Values.Max(b => b.Height);
    double gap = refW * 0.3;  // 间距
    
    // 根据视图集合确定排版策略
    if (viewBitmaps.Count == 6 && IsSixStandardViews(viewBitmaps))
    {
        // 标准六视图排版（与线框排版一致）
        // Layout:
        //          ┌──────────┐
        //          │  Bottom  │
        //  ┌───────┼──────────┼───────┬──────┐
        //  │ Right │  Front   │ Left  │ Back │
        //  └───────┼──────────┼───────┴──────┘
        //          │   Top    │
        //          └──────────┘
        return ComposeSixViewLayout(viewBitmaps, refW, refH, gap, dpi);
    }
    else if (viewBitmaps.Count == 3 && HasThreeOrthoViews(viewBitmaps))
    {
        // 三视图排版：Front 居左, Top 在 Front 正下方, Right 在 Front 右侧
        // Layout:
        //  ┌──────────┬──────┐
        //  │  Front   │ Right│
        //  ├──────────┤      │
        //  │   Top    │      │
        //  └──────────┴──────┘
        return ComposeThreeViewLayout(viewBitmaps, refW, refH, gap, dpi);
    }
    else
    {
        // 其他组合：横向/网格等间距排列
        return ComposeGenericLayout(viewBitmaps, refW, refH, gap, dpi);
    }
}

/// <summary>
/// 六视图工程排版合成
/// </summary>
Bitmap ComposeSixViewLayout(Dictionary<string, Bitmap> viewBitmaps,
    double refW, double refH, double gap, int dpi)
{
    int canvasW = (int)(3 * refW + 2 * gap + refW + gap);  // 3列 + Back列 + 间距
    int canvasH = (int)(3 * refH + 2 * gap);               // 3行 + 间距
    var canvas = new Bitmap(canvasW, canvasH);
    
    using (var g = Graphics.FromImage(canvas))
    {
        g.Clear(System.Drawing.Color.White);
        
        double centerX = refW + gap;
        double centerRowY = refH + gap;
        
        // Front 居中
        DrawAt(g, viewBitmaps["Front"], centerX, centerRowY);
        // Top 在 Front 正下方
        DrawAt(g, viewBitmaps["Top"], centerX, centerRowY + refH + gap);
        // Bottom 在 Front 正上方
        DrawAt(g, viewBitmaps["Bottom"], centerX, centerRowY - refH - gap);
        // Left 在 Front 右侧
        DrawAt(g, viewBitmaps["Left"], centerX + refW + gap, centerRowY);
        // Right 在 Front 左侧
        DrawAt(g, viewBitmaps["Right"], centerX - refW - gap, centerRowY);
        // Back 在 Left 右侧
        DrawAt(g, viewBitmaps["Back"], centerX + 2 * (refW + gap), centerRowY);
    }
    
    return canvas;
}

/// <summary>
/// 三视图工程排版合成
/// </summary>
Bitmap ComposeThreeViewLayout(Dictionary<string, Bitmap> viewBitmaps,
    double refW, double refH, double gap, int dpi)
{
    // Front + Top + Right 三视图排版
    int canvasW = (int)(2 * refW + gap);
    int canvasH = (int)(2 * refH + gap);
    var canvas = new Bitmap(canvasW, canvasH);
    
    using (var g = Graphics.FromImage(canvas))
    {
        g.Clear(System.Drawing.Color.White);
        
        if (viewBitmaps.ContainsKey("Front"))
            DrawAt(g, viewBitmaps["Front"], 0, 0);
        if (viewBitmaps.ContainsKey("Top"))
            DrawAt(g, viewBitmaps["Top"], 0, refH + gap);
        if (viewBitmaps.ContainsKey("Right"))
            DrawAt(g, viewBitmaps["Right"], refW + gap, 0);
    }
    
    return canvas;
}

/// <summary>
/// 通用网格排版（用于非标准视图组合）
/// </summary>
Bitmap ComposeGenericLayout(Dictionary<string, Bitmap> viewBitmaps,
    double refW, double refH, double gap, int dpi)
{
    int cols = (int)Math.Ceiling(Math.Sqrt(viewBitmaps.Count));
    int rows = (int)Math.Ceiling((double)viewBitmaps.Count / cols);
    int canvasW = (int)(cols * refW + (cols - 1) * gap);
    int canvasH = (int)(rows * refH + (rows - 1) * gap);
    var canvas = new Bitmap(canvasW, canvasH);
    
    using (var g = Graphics.FromImage(canvas))
    {
        g.Clear(System.Drawing.Color.White);
        int idx = 0;
        foreach (var kvp in viewBitmaps)
        {
            int col = idx % cols;
            int row = idx / cols;
            double x = col * (refW + gap);
            double y = row * (refH + gap);
            DrawAt(g, kvp.Value, x, y);
            idx++;
        }
    }
    
    return canvas;
}
```

> **注意**: 上述使用 `System.Drawing.Bitmap` 和 `System.Drawing.Graphics`。在 .NET Framework 4.8 中这些类型可用。若需跨平台兼容，可替换为 Eto.Drawing 的 Bitmap 类。

### 3.4 图片输出（F2.4）

**改动文件**: `PatentCore.cs` — 在 `ExecuteAsync()` 末尾新增渲染输出环节

```csharp
// ExecuteAsync() 末尾，BakeToRhinoGrouped() 之后

if (wantRender)
{
    // 根据视图模式参数动态确定渲染视图列表并捕获
    var viewBitmaps = CaptureViewsByMode(doc, wantSix, wantIsoFront, wantIsoBack, wantCurrent,
                                         modelBox, currentView, imageSize);
    
    if (viewBitmaps.Count > 0)
    {
        status.Report($"正在排版 {viewBitmaps.Count} 张渲染图...");
        var composedBitmap = ComposeRenderLayout(viewBitmaps);
        
        if (composedBitmap != null)
        {
            status.Report("正在导出 PNG...");
            composedBitmap.Save(renderOutputPath, System.Drawing.Imaging.ImageFormat.Png);
            status.Report($"渲染图已保存至: {renderOutputPath}");
        }
    }
    else
    {
        status.Report("未选定任何视图模式，跳过渲染输出");
    }
}
```

---

## 4. 分步执行计划

### 里程碑 M1：正切边缘识别与分组（需求1 前半）

| 步骤 | 任务 | 涉及文件 | 改动描述 | 预计耗时 |
|---|---|---|---|---|
| M1-1 | SDK 验证 | — | 在 Rhino 中用测试模型验证 `HiddenLineDrawingSegment` 和 `HiddenLineDrawingCurve` 是否暴露正切边缘属性，确认识别方案 | 2h |
| M1-2 | 实现正切识别 | `PatentCore.cs` → `ComputeSingleViewEngine()` | 在可见段提取循环中增加正切边缘判定逻辑，标记 `IsTangent` | 2h |
| M1-3 | 实现分组烘焙 | `PatentCore.cs` → `BakeToRhinoGrouped()` | 新增子图层 `TangentEdges`，烘焙时按标记分发 | 1h |
| M1-4 | 单元测试 | — | 用含圆角的测试模型验证正切边缘被正确识别和分组 | 1h |

**M1 交付物**: 含圆角/倒角的模型生成后，正切边缘线与正常线分别位于不同图层

### 里程碑 M2：交叉感知融合（需求1 后半）

| 步骤 | 任务 | 涉及文件 | 改动描述 | 预计耗时 |
|---|---|---|---|---|
| M2-1 | 实现交叉节点检测 | `PatentCore.cs` → 新增 `DetectJunctionPoints()` | RTree 端点索引 + 邻接数 ≥3 判定 | 2h |
| M2-2 | 重构融合为两阶段 | `PatentCore.cs` → `JoinTangentCurvesPrioritized()` | 原方法重命名为 `_Original`，新方法增加阶段1交叉感知逻辑 | 3h |
| M2-3 | 集成到管线 | `PatentCore.cs` → `ComputeSingleViewEngine()` | 替换融合方法调用 | 0.5h |
| M2-4 | 回归测试 | — | 用简单模型验证原功能不受影响；用交叉模型验证新功能 | 1.5h |

**M2 交付物**: 含交叉节点的模型生成后，交叉处相切线优先合并为连续链路

### 里程碑 M3：渲染输出 UI 与捕获（需求2 前半）

| 步骤 | 任务 | 涉及文件 | 改动描述 | 预计耗时 |
|---|---|---|---|---|
| M3-1 | API 验证 | — | 验证 `ViewCapture` / `CaptureToBitmap` 在 Rhino 7 中的可用性和渲染效果 | 2h |
| M3-2 | UI 新增渲染选项 | `PatentUiPanel.cs` | 新增 CheckBox + 路径输入 + 浏览按钮；渲染输出说明改为"与视图模式联动" | 1.5h |
| M3-3 | 扩展 ExecuteAsync 签名 | `PatentCore.cs` + `PatentUiPanel.cs` | 新增 `wantRender` / `renderOutputPath` 参数，说明渲染参数与视图选择参数的联动关系 | 0.5h |
| M3-4 | 实现单视图渲染捕获 | `PatentCore.cs` → 新增 `CaptureViewRender()` | 临时视口 + 平行投影 + 位图捕获 | 3h |
| M3-5 | 实现视图模式动态确定与多视图捕获 | `PatentCore.cs` → 新增 `DetermineRenderViews()` + `CaptureViewsByMode()` | 根据视图模式参数动态确定渲染列表，逐视图调用 `CaptureViewRender` | 2h |

**M3 交付物**: 勾选渲染选项后可按视图模式动态获取对应数量的渲染位图

### 里程碑 M4：渲染排版与输出（需求2 后半）

| 步骤 | 任务 | 涉及文件 | 改动描述 | 预计耗时 |
|---|---|---|---|---|
| M4-1 | 实现动态排版合成 | `PatentCore.cs` → 新增 `ComposeRenderLayout()` + 子方法 | 单视图直接输出；多视图按工程排版规则布局；六视图/三视图/通用网格排版 | 3h |
| M4-2 | 实现 PNG 导出 | `PatentCore.cs` → `ExecuteAsync()` 末尾 | 合成位图保存到指定路径 | 0.5h |
| M4-3 | 进度反馈适配 | `PatentCore.cs` + `PatentUiPanel.cs` | 渲染阶段增加进度报告（按实际视图数量显示进度，如 3/3 视图进度） | 0.5h |
| M4-4 | 端到端测试 | — | 完整流程测试：勾选渲染→选定视图模式→框选模型→生成→检查 PNG 输出；覆盖单视图/三视图/六视图模式 | 1.5h |

**M4 交付物**: 一键按视图模式输出渲染 PNG，单视图直接导出，多视图自动排版

### 里程碑 M5：集成测试与发布准备

| 步骤 | 任务 | 涉及文件 | 改动描述 | 预计耗时 |
|---|---|---|---|---|
| M5-1 | 综合测试 | — | 两个需求功能联合测试；边界情况测试（无圆角模型、无交叉模型等） | 2h |
| M5-2 | 性能测试 | — | 大模型（>100 零件）性能对比，确保不出现显著退化 | 1h |
| M5-3 | 代码整理 | 全部 | 注释补充、命名规范、冗余代码清理 | 1h |
| M5-4 | 文档更新 | — | 更新 README（如有）、变更日志 | 0.5h |

---

## 5. 里程碑时间线

```
Day 1-2:  M1 — 正切边缘识别与分组
Day 2-3:  M2 — 交叉感知融合
Day 3-4:  M3 — 渲染输出 UI 与捕获
Day 4-5:  M4 — 渲染排版与输出
Day 5:    M5 — 集成测试与发布准备
```

> 总预计耗时：5 个工作日（单人），关键路径在 M1-1 和 M3-1 的 SDK 验证步骤。

---

## 6. 技术依赖详解

| 依赖 | API / 类 | 用途 | 版本要求 |
|---|---|---|---|
| RhinoCommon | `HiddenLineDrawingCurve` | 正切边缘属性查询 | 7.35+ |
| RhinoCommon | `BrepEdge.EdgeConvexity` | 备选：边凸性判定（Tangent/Convex/Concave） | 7.35+ |
| RhinoCommon | `ViewCapture` / `ViewCapture.CaptureToBitmap()` | 视口渲染位图捕获 | 7.35+ |
| RhinoCommon | `RhinoView` / `RhinoViewport` | 临时视口创建与相机控制 | 7.35+ |
| .NET Framework 4.8 | `System.Drawing.Bitmap` / `Graphics` | 位图合成与 PNG 导出 | 内置 |
| Eto.Forms | `CheckBox` / `TextBox` / `SaveFileDialog` | UI 扩展 | 随 RhinoWindows 提供 |

### API 风险与备选

| API | 风险 | 备选方案 |
|---|---|---|
| `HiddenLineDrawingCurve` 正切属性 | SDK 可能不直接暴露正切边缘类型 | 通过 `BrepEdge.EdgeConvexity == Tangent` 推断；或通过相邻面的法线夹角计算 |
| `ViewCapture.CaptureToBitmap()` | 在某些 Rhino 配置下可能返回 null | 使用 `RhinoView.CaptureToBitmap()` 或 `RenderToBitmap()` |
| `System.Drawing.Bitmap` | .NET Core/5+ 中需引用 `System.Drawing.Common` NuGet | 本项目锁定 net48，无此问题 |

---

## 7. 测试验证建议

### 7.1 需求1 测试模型

| 测试用例 | 模型特征 | 预期结果 |
|---|---|---|
| T1.1 | 含圆角的长方体 | 圆角弧线标记为 `IsTangent=true`，棱边线标记为 `IsTangent=false` |
| T1.2 | 含倒角的圆柱 | 倒角线标记为正切边缘 |
| T1.3 | 三管交叉模型 | 交叉处相切线优先合并，无明显断点 |
| T1.4 | 无圆角/倒角的纯棱柱 | 无曲线标记为 `IsTangent`，行为与原版一致 |
| T1.5 | 复杂装配体（>10 零件） | 性能无明显退化（≤20% 耗时增加） |

### 7.2 需求2 测试模型

| 测试用例 | 操作 | 预期结果 |
|---|---|---|
| T2.1 | 勾选渲染输出 + 选定六视图模式 + 框选模型 → 生成 | 输出六视图排版 PNG 文件到指定路径 |
| T2.2 | 不勾选渲染输出 → 生成 | 行为与原版完全一致，无额外计算 |
| T2.3 | 渲染输出路径为只读目录 | 提示路径不可写，不崩溃 |
| T2.4 | 勾选渲染输出 + 选定六视图模式 → 检查 PNG 布局 | 六视图按"长对正/高平齐"排列 |
| T2.5 | 线框+渲染同时生成 | 线框烘焙到图层，渲染图保存为 PNG，互不干扰 |
| T2.6 | 勾选渲染输出 + 选定单视图模式 → 生成 | 输出单张渲染图 PNG（无排版合成） |
| T2.7 | 勾选渲染输出 + 选定三视图模式 → 生成 | 输出三视图排版 PNG |
| T2.8 | 勾选渲染输出 + 不选定任何视图模式 → 生成 | 提示未选定视图模式，无渲染输出 |

### 7.3 回归测试

| 用例 | 验证点 |
|---|---|
| 原有六视图线框生成 | 不勾选渲染输出时，所有原功能不受影响 |
| 外轮廓特权隔离 | 外轮廓仍然独立闭环 |
| 零件分组 | 分组命名规则不变 |
| 工程排版 | 线框排版布局不变 |

---

## 8. 文件改动汇总

| 文件 | 改动类型 | 具体改动 |
|---|---|---|
| `PatentCore.cs` | 修改 | `ComputeSingleViewEngine()` — 增加正切边缘识别逻辑 |
| `PatentCore.cs` | 修改 | `BakeToRhinoGrouped()` — 增加子图层分发逻辑 |
| `PatentCore.cs` | 修改 | `JoinTangentCurvesPrioritized()` — 重构为两阶段融合 |
| `PatentCore.cs` | 新增 | `DetectJunctionPoints()` — 交叉节点检测 |
| `PatentCore.cs` | 新增 | `CaptureViewRender()` — 单视图渲染捕获 |
| `PatentCore.cs` | 新增 | `DetermineRenderViews()` — 根据视图模式参数动态确定渲染列表 |
| `PatentCore.cs` | 新增 | `CaptureViewsByMode()` — 按模式动态捕获多视图渲染位图 |
| `PatentCore.cs` | 新增 | `ComposeRenderLayout()` — 动态排版合成（单视图直出/多视图排版） |
| `PatentCore.cs` | 新增 | `ComposeSixViewLayout()` / `ComposeThreeViewLayout()` / `ComposeGenericLayout()` — 各模式排版子方法 |
| `PatentCore.cs` | 修改 | `ExecuteAsync()` — 签名扩展 + 末尾渲染输出环节 |
| `PatentUiPanel.cs` | 修改 | 构造函数 — 新增渲染输出 CheckBox + 路径输入 + 浏览按钮 |
| `PatentUiPanel.cs` | 修改 | `OnGenerateClick` — 传递新参数到 `ExecuteAsync` |

---

## 9. 注意事项

1. **SDK 验证优先**: M1-1 和 M3-1 是关键验证步骤，结果直接影响后续实现方案的选择。若 API 不可用，需切换到备选方案，可能影响工期 1-2 天
2. **临时视口生命周期**: `CaptureViewRender()` 中创建的临时视口必须确保在方法退出前被移除，否则会泄漏 Rhino 视口资源
3. **线程安全**: 渲染捕获涉及 Rhino UI 线程，可能需要使用 `RhinoApp.Invoke()` 确保在主线程执行视口操作
4. **位图内存**: 渲染位图内存占用与视图模式相关，六视图高分辨率渲染位图可能占用大量内存，建议单张不超过 2000×2000 像素，合成图不超过 6000×6000；单视图/三视图模式内存压力较小
5. **相切识别精度**: `EdgeConvexity` 的判定依赖 Rhino 的容差设置，不同模型精度可能导致判定不一致，建议使用用户选择的精度参数作为判定阈值
6. **向后兼容**: 所有新增参数均有默认值（`wantRender = false`），确保不传参时行为与原版一致
7. **视图模式联动**: 渲染输出的视图列表由 `DetermineRenderViews()` 根据 `wantSix`/`wantIsoFront`/`wantIsoBack`/`wantCurrent` 参数动态生成，与线框输出的视图选择完全一致。若用户未选定任何视图模式，即使勾选渲染输出也不执行渲染计算

---

*执行计划书结束 — 待用户审核确认后进入开发阶段*
