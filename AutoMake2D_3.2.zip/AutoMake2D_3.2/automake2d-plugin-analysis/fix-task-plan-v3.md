# AutoMake2D 2.0 第三轮缺陷修复任务计划书

> 版本: v3.0  
> 日期: 2026-07-09  
> 状态: 待审核  
> 前置文档: `fix-task-plan-v2.md` (v2.0, 第二轮修复), `fix-task-plan.md` (v1.0, 第一轮修复)  
> 重要声明: 当前代码仍是**旧版未应用 V2 修复**，V3 修复方案必须同时覆盖 V2 的未落地修复项

---

## 1. 背景与目标

### 问题

AutoMake2D 2.0 插件经两轮修复（s7 V1 + s8 V2 计划书）后，用户实际测试发现 **V2 修复计划未落地到代码**，三个缺陷仍然存在且有了更精确的定位：

1. **缺陷V3-1：渲染图仍输出线框模式而非渲染模式，且物件未居中**  
   用户上传截图确认所有视图均为线框模式（无材质/光照/阴影），物件偏向一侧未居中，各视图大小不一致。根因是 `CaptureViewRender()` 方法（第 1090~1160 行）存在多个问题：视口设置顺序错误、Rendered 显示模式可能未真正生效、隐藏视口的 DisplayMode 切换可能不生效、ZoomBoundingBox 无边距。

2. **缺陷V3-2：相切边缘线仍未对标 Rhino 原生 Make2D 的分离与分组行为**  
   用户明确要求「找原生组件的实现逻辑，优化现在的代码」。当前虽有红黑区分但效果远不如原生 Make2D。根因：仍使用 `SilhouetteType.None` + 弧线/多跨度回退判据（过于宽泛，误标记大量非正切线）；所有线段统一加入 `rawGrouped` 字典混合处理，正切线与正常线未在投影阶段分离；三阶段融合策略在混合池中操作效果不稳定。Rhino 原生 Make2D 的机制是：在 HLD 计算时设置 `IncludeTangentEdges=true`，投影后根据 `SilhouetteType` 将线段分类到不同图层，**各类线段独立分组不混合处理**。

3. **缺陷V3-3：放入 Rhino 的图片无法预览，只显示灰色矩形曲面**  
   用户截图确认 PictureFrame 显示为纯灰色填充矩形。根因：`embedBitmap=false`（第 218 行）导致图片仅引用外部文件路径不嵌入；使用临时文件路径且随后删除（第 253 行），路径失效后 PictureFrame 无图可显示。

### 目标用户

专利工程师 / 专利律师 — 使用 AutoMake2D 生成专利申请用线框工程图和渲染图的用户

### 业务目标与可验证指标

| 缺陷 | 修复目标 | 可验证指标 |
|---|---|---|
| 缺陷V3-1 | 渲染输出为真正渲染效果（含光照/材质/阴影），物件居中且大小一致 | 渲染图具有光照效果（高光/阴影）非线框截图；各视图物件位于画面中央（距四边差异 ≤ 10%）；同模型各视图显示大小比例一致（包围盒占比差异 ≤ 15%） |
| 缺陷V3-2 | 正切边缘线对标 Rhino 原生 Make2D 的分离与独立分组行为 | 移除 `SilhouetteType.None` 回退判据，仅使用 Tangent/NonSilhouetteTangent 精确枚举；正切线与正常线在投影阶段分离到两个独立字典；各组独立执行去重→融合→闭合管线；与 Rhino 原生 Make2D 同模型输出视觉对比一致度 ≥ 80% |
| 缺陷V3-3 | PictureFrame 正确显示渲染图内容 | 渲染图放入模型后 PictureFrame 显示实际图片内容而非灰色占位符；保存并重新打开 Rhino 文件后图片仍然可见 |

---

## 2. 范围 (Scope)

### ✅ 本期做

| 编号 | 修复项 | 说明 |
|---|---|---|
| FIX-V3-1.1 | 修复视口设置顺序 | 调整 CaptureViewRender() 中操作顺序为：创建视口 → 设置投影 → 设置相机 → 设置 DisplayMode → **Redraw** → ZoomBoundingBox（含边距）→ **Redraw** → CaptureToBitmap |
| FIX-V3-1.2 | 确保隐藏视口 DisplayMode 生效 | 验证 `doc.Views.Add()` 的最后一个参数 `false`（隐藏视口）下 DisplayMode 设置是否生效；若不生效，改为 `true` 显示视口或改用活动视口方案 |
| FIX-V3-1.3 | 修复 Rendered 模式获取 | 验证 `DisplayModeDescription.FindByName("Rendered")` 在 Rhino 7 SR35 中的可用性；若返回 null，尝试 `DisplayModeDescription.Rendered` 静态属性或其他获取方式 |
| FIX-V3-1.4 | ZoomBoundingBox 增加边距 | ZoomBoundingBox 后增加 10%~15% 边距，确保物件不贴边且居中显示 |
| FIX-V3-1.5 | 多视图渲染大小一致性 | 确保各视图使用相同的 ZoomBoundingBox 策略，物件在各视图中显示大小比例一致 |
| FIX-V3-2.1 | 移除 SilhouetteType.None 回退判据 | 删除 `SilhouetteType.None` 时的弧线/多跨度回退验证，仅使用 `Tangent` / `NonSilhouetteTangent` 精确枚举判定正切线 |
| FIX-V3-2.2 | 投影阶段分离正切线与正常线 | 在 `ComputeSingleViewEngine()` 中，使用两个独立字典 `rawGroupedNormal` 和 `rawGroupedTangent` 分别收集正常线与正切线，不再混合到同一个 `rawGrouped` |
| FIX-V3-2.3 | 各组独立执行去重→融合→闭合管线 | 正常线组和正切线组分别独立执行 `CleanRawCurves → 外轮廓隔离 → JoinTangentCurvesPrioritized → Curve.JoinCurves` 全流程，最后合并到 `finalCleanedGrouped` |
| FIX-V3-2.4 | 合并时重新标记语义 | 正常线组合并结果标记 `IsTangent` 为空，正切线组合并结果标记 `IsTangent=true`，烘焙时根据标记分发到对应图层 |
| FIX-V3-3.1 | embedBitmap 改为 true | `AddPictureFrame` 的 embedBitmap 参数从 `false` 改为 `true`，图片嵌入 Rhino 文件 |
| FIX-V3-3.2 | 改用 renderOutputPath 持久化路径 | 用已保存到用户指定路径的 PNG 文件作为 PictureFrame 的图片来源，替代临时文件；在确认嵌入成功后再安全清理临时文件 |
| FIX-V3-3.3 | 验证嵌入后 PictureFrame 可预览 | 确保嵌入后 PictureFrame 在 Rhino 中显示实际图片内容，保存/重开文件后仍可见 |

### ❌ 本期不做

| 排除项 | 原因 |
|---|---|
| ❌ 隐藏线图层（V2 计划的 FIX-V2-1 系列） | 当前用户反馈的核心问题聚焦于上述三个缺陷，隐藏线图层作为增强功能留待下期 |
| ❌ 渲染材质/光照自定义 | 原始计划的 Scope Out |
| ❌ Rhino 8 兼容 | 当前绑定 Rhino 7 SR35 |
| ❌ 渲染引擎从 ViewCapture 切换到 RenderPipeline | 改动过大，本期在现有架构内修复 |
| ❌ 隐藏线提取与处理 | 属于 V2 计划的独立特性，本期聚焦 V3 三个核心缺陷 |
| ❌ 外轮廓线粗化或独立图层 | 增强功能，非核心缺陷修复 |
| ❌ 隐藏线虚线线型 | 同上 |

---

## 3. 核心场景

### 场景 A：专利工程师生成标准渲染效果图

> 专利工程师小张勾选渲染输出后，之前得到的图片是线框模式截图且物体不居中、各视图大小不一致。修复后，渲染输出具有光照/材质/阴影效果的真正渲染图，各视图中物体居中且大小一致，可直接用于专利申请材料，无需手动截图和后期处理。

### 场景 B：专利工程师对照正切线审查结构

> 专利工程师小王需要判断哪些边缘是相切过渡、哪些是锐角棱边。Rhino 原生 Make2D 勾选「建立正切边缘」后，正切线被独立分离到单独图层。修复后，AutoMake2D 同样精确识别正切边缘（仅使用 SilhouetteType.Tangent/NonSilhouetteTangent 枚举），正切线与正常线完全分离处理，不存在交叉干扰，输出效果与原生 Make2D 一致。

### 场景 C：专利律师在 Rhino 中直接预览渲染图

> 专利律师小李在 Rhino 中查看已生成的渲染图 PictureFrame，之前只看到灰色占位符。修复后，PictureFrame 直接显示渲染图片内容，关闭并重新打开 Rhino 文件后图片仍然可见，无需到外部文件管理器找 PNG。

---

## 4. 功能拆解与优先级

| 功能 | 描述 | 优先级 | 负责专家 |
|---|---|---|---|
| FIX-V3-1.1 | 修复视口设置顺序（DisplayMode→Redraw→Zoom→Redraw→Capture） | Must | code |
| FIX-V3-1.2 | 确保隐藏视口 DisplayMode 生效 | Must | code |
| FIX-V3-1.3 | 修复 Rendered 模式获取 | Must | code |
| FIX-V3-1.4 | ZoomBoundingBox 增加边距 | Must | code |
| FIX-V3-1.5 | 多视图渲染大小一致性 | Must | code |
| FIX-V3-2.1 | 移除 SilhouetteType.None 回退判据 | Must | code |
| FIX-V3-2.2 | 投影阶段分离正切线与正常线到独立字典 | Must | code |
| FIX-V3-2.3 | 各组独立执行去重→融合→闭合管线 | Must | code |
| FIX-V3-2.4 | 合并时重新标记语义 | Should | code |
| FIX-V3-3.1 | embedBitmap 改为 true | Must | code |
| FIX-V3-3.2 | 改用 renderOutputPath 持久化路径 | Must | code |
| FIX-V3-3.3 | 验证嵌入后 PictureFrame 可预览 | Must | code |

---

## 5. 用户故事与验收标准

### US-V3-1：渲染输出为真正渲染效果且物体居中

- **故事**: 作为专利工程师，我希望渲染输出具有光照/材质效果的真正渲染图（非线框截图），且各视图中物体居中、大小一致，以便直接用于专利申请材料
- **验收 (Given/When/Then)**:
  - Given 勾选渲染输出并执行生成, When 检查渲染图, Then 渲染图具有光照效果（高光/阴影），非线框模式截图
  - Given 多视图渲染输出, When 检查各视图, Then 所有视图中物体位于画面中央（距四边距离差异 ≤ 10%）
  - Given 多视图渲染输出, When 检查各视图, Then 同一模型在各视图中的显示大小比例一致（包围盒占比差异 ≤ 15%）
  - Given 渲染图生成, When 与线框截图对比, Then 渲染图不包含线框曲线
  - Given CaptureViewRender 执行, When 检查操作顺序, Then 顺序为：DisplayMode → Redraw → ZoomBoundingBox → Redraw → CaptureToBitmap

### US-V3-2：正切边缘线对标原生 Make2D 的分离与独立分组行为

- **故事**: 作为专利工程师，我希望正切边缘线的识别和分组完全对标 Rhino 原生 Make2D 的行为——仅使用精确枚举识别正切线，正切线与正常线在投影阶段即分离、独立处理，以便输出效果与原生 Make2D 一致
- **验收 (Given/When/Then)**:
  - Given 任意 3D 模型, When 执行生成, Then 正切线仅通过 `SilhouetteType.Tangent` 或 `SilhouetteType.NonSilhouetteTangent` 判定，不再使用 `SilhouetteType.None` 回退判据
  - Given 含相切过渡面的模型, When 检查 ComputeSingleViewEngine 内部, Then 正常线与正切线分别存储在 `rawGroupedNormal` 和 `rawGroupedTangent` 两个独立字典中
  - Given 两个独立字典, When 检查管线, Then 各组独立执行 CleanRawCurves → 外轮廓隔离 → JoinTangentCurvesPrioritized → Curve.JoinCurves 全流程
  - Given 最终合并结果, When 检查曲线标记, Then 来自正常线组的曲线不含 `IsTangent` 标记，来自正切线组的曲线包含 `IsTangent=true`
  - Given 与 Rhino 原生 Make2D 同模型输出对比, When 视觉对比, Then 正切线位置与原生 Make2D 正切边缘线位置基本一致（匹配度 ≥ 80%）

### US-V3-3：PictureFrame 正确显示渲染图内容

- **故事**: 作为专利律师，我希望放入 Rhino 模型中的渲染图 PictureFrame 能正确显示图片内容而非灰色占位符，以便在 Rhino 中直接预览和确认渲染效果
- **验收 (Given/When/Then)**:
  - Given 勾选渲染输出并执行生成, When 在 Rhino 中查看 PictureFrame, Then PictureFrame 显示实际渲染图片内容而非灰色矩形
  - Given 渲染图已放入模型, When 保存 Rhino 文件并重新打开, Then PictureFrame 仍然显示图片内容（图片已嵌入文件）
  - Given 渲染图已嵌入, When 检查 AddPictureFrame 调用, Then embedBitmap 参数为 true
  - Given AddPictureFrame 创建成功, When 检查图片来源, Then 使用 renderOutputPath（已保存的 PNG）而非临时文件路径

### 验收清单汇总表

| AC-ID | 验收点（一句话，可被自动化测试验证） | 优先级 | 关联 US |
|---|---|---|---|
| AC-V3-1.1 | CaptureViewRender 中操作顺序为 DisplayMode→Redraw→ZoomBoundingBox→Redraw→CaptureToBitmap | P0 | US-V3-1 |
| AC-V3-1.2 | CaptureViewRender 中 DisplayMode 设置后、ZoomBoundingBox 后均调用了 Redraw | P0 | US-V3-1 |
| AC-V3-1.3 | `DisplayModeDescription.FindByName("Rendered")` 不返回 null，或回退链能获取到非 Wireframe 的显示模式 | P0 | US-V3-1 |
| AC-V3-1.4 | 隐藏视口（`doc.Views.Add` 最后参数 false）的 DisplayMode 设置后视口确实处于 Rendered 模式 | P0 | US-V3-1 |
| AC-V3-1.5 | ZoomBoundingBox 后物件距视口四边距离差异 ≤ 10% | P0 | US-V3-1 |
| AC-V3-1.6 | 同一模型在各视图渲染图中的显示大小比例一致（包围盒占比差异 ≤ 15%） | P1 | US-V3-1 |
| AC-V3-1.7 | 渲染捕获期间线框图层被临时隐藏，捕获后恢复 | P0 | US-V3-1 |
| AC-V3-1.8 | 渲染输出图片具有光照/阴影效果，非线框截图 | P0 | US-V3-1 |
| AC-V3-2.1 | 正切线判定不再使用 `SilhouetteType.None` 回退判据（弧线/多跨度验证已移除） | P0 | US-V3-2 |
| AC-V3-2.2 | 正切线仅通过 `SilhouetteType.Tangent` 或 `SilhouetteType.NonSilhouetteTangent` 判定 | P0 | US-V3-2 |
| AC-V3-2.3 | ComputeSingleViewEngine 中使用两个独立字典 `rawGroupedNormal` 和 `rawGroupedTangent` 分别收集正常线与正切线 | P0 | US-V3-2 |
| AC-V3-2.4 | 正常线组独立执行 CleanRawCurves → 外轮廓隔离 → JoinTangentCurvesPrioritized → Curve.JoinCurves | P0 | US-V3-2 |
| AC-V3-2.5 | 正切线组独立执行 CleanRawCurves → JoinTangentCurvesPrioritized → Curve.JoinCurves（正切线无外轮廓概念，跳过外轮廓隔离） | P0 | US-V3-2 |
| AC-V3-2.6 | 最终合并时，来自正常线组的曲线不含 `IsTangent` 标记，来自正切线组的曲线包含 `IsTangent=true` | P1 | US-V3-2 |
| AC-V3-2.7 | 与 Rhino 原生 Make2D 同模型输出对比，正切线位置匹配度 ≥ 80% | P1 | US-V3-2 |
| AC-V3-3.1 | AddPictureFrame 的 embedBitmap 参数为 true | P0 | US-V3-3 |
| AC-V3-3.2 | AddPictureFrame 的图片来源为 renderOutputPath（用户指定路径的 PNG），非临时文件路径 | P0 | US-V3-3 |
| AC-V3-3.3 | 渲染输出后 PictureFrame 在 Rhino 中显示图片内容而非灰色占位符 | P0 | US-V3-3 |
| AC-V3-3.4 | 保存并重新打开 Rhino 文件后 PictureFrame 仍显示图片内容 | P0 | US-V3-3 |
| AC-V3-3.5 | 临时文件清理在嵌入成功后执行，不影响已嵌入的图片 | P1 | US-V3-3 |

---

## 6. 流程 / 信息架构

### 6.1 缺陷V3-1修复 — 渲染捕获正确流程

```mermaid
flowchart TD
    A[创建临时视口<br/>doc.Views.Add] --> B[设置平行投影<br/>ChangeToParallelProjection]
    B --> C[设置相机位置/方向/Up]
    C --> D[设置 Rendered 显示模式<br/>DisplayModeDescription.FindByName]
    D --> E[Redraw — 让渲染管线初始化]
    E --> F[ZoomBoundingBox<br/>含 10% 边距]
    F --> G[Redraw — 确保缩放后渲染更新]
    G --> H[ViewCapture.CaptureToBitmap<br/>RasterMode=true]
    H --> I[关闭临时视口]
    
    style D fill:#f9f,stroke:#333
    style E fill:#ff9,stroke:#333
    style G fill:#ff9,stroke:#333
```

### 6.2 缺陷V3-2修复 — 正切线与正常线分离处理流程

```mermaid
flowchart TD
    A[HiddenLineDrawing 投影<br/>IncludeTangentEdges=true] --> B[遍历 hld.Segments]
    B --> C{SilhouetteType?}
    C -->|Tangent / NonSilhouetteTangent| D[正切线字典 rawGroupedTangent<br/>标记 IsTangent=true]
    C -->|其他| E[正常线字典 rawGroupedNormal<br/>标记 IsOuter/IsHidden]
    
    D --> F[正切线独立管线<br/>CleanRawCurves → JoinTangentCurvesPrioritized → JoinCurves]
    E --> G[正常线独立管线<br/>CleanRawCurves → 外轮廓隔离 → JoinTangentCurvesPrioritized → JoinCurves]
    
    F --> H[合并到 finalCleanedGrouped]
    G --> H
    H --> I[BakeToRhinoGrouped 多图层烘焙]
    I --> J[正常线 → Patent_Drawings_2D<br/>颜色: 黑色]
    I --> K[正切线 → TangentEdges<br/>颜色: 蓝色]
```

### 6.3 缺陷V3-3修复 — PictureFrame 嵌入流程

```mermaid
flowchart TD
    A[渲染位图合成完成] --> B[保存到 renderOutputPath<br/>用户指定路径]
    B --> C[AddPictureFrame<br/>bitmapPath=renderOutputPath<br/>embedBitmap=true]
    C --> D[图片数据嵌入 Rhino 文件]
    D --> E[安全清理临时文件]
    E --> F[PictureFrame 在 Rhino 中正确显示]
    F --> G[保存/重开文件后图片仍可见]
```

---

## 7. 风险与未决问题

| 风险 | 影响 | 缓解措施 |
|---|---|---|
| 隐藏视口（`doc.Views.Add` 参数 `false`）的 DisplayMode 设置可能不生效 | 渲染输出仍为线框 | 方案A：将 `false` 改为 `true`，让视口可见后设置 DisplayMode 再 Redraw；方案B：使用当前活动视口（先备份/恢复状态） |
| `DisplayModeDescription.FindByName("Rendered")` 在 Rhino 7 SR35 中可能返回 null | 无法获取 Rendered 模式 | 回退链：Rendered → Articulated → Shaded；或尝试 `DisplayModeDescription` 的静态属性遍历 |
| 分离字典后，正切线组不再经过 `JoinTangentCurvesPrioritized` 三阶段融合中的交叉感知逻辑 | 正切线可能在交叉节点处未合并 | 正切线组独立调用简化版融合（仅做贪心合并，不需要交叉感知，因为正切线之间不存在交叉冲突） |
| `embedBitmap=true` 可能导致 Rhino 文件体积显著增大 | 文件从 KB 级增长到 MB 级 | 可接受：渲染图通常 1-5 MB，专利文件需要自包含 |
| 分离管线后，正切线和正常线可能共享同一包围盒空间 | 排版时线条重叠 | 正常线和正切线使用相同的 component key 存入 `finalCleanedGrouped`，排版时作为一个组件整体处理 |
| `renderOutputPath` 对应的文件在 AddPictureFrame 调用时可能尚未写入完成 | PictureFrame 创建失败 | 确保 `composed.Save(renderOutputPath)` 完成后再调用 AddPictureFrame；当前代码已是先保存再创建，但需确认 Save 是同步调用 |

### 未决问题

1. **隐藏视口的 DisplayMode 是否真正生效？** 需要在 Rhino 环境中实际验证。如果隐藏视口无法切换 DisplayMode，需要改用可见视口或活动视口方案。
2. **正切线组是否需要外轮廓隔离？** 正切线无"外轮廓"概念，但可能有 `IsOuter=true` 的正切线（极少见）。当前方案：正切线组跳过外轮廓隔离步骤，直接进入融合管线。
3. **分离字典后的 `JoinTangentCurvesPrioritized` 三阶段策略是否需要简化？** 正常线组保留三阶段策略；正切线组使用简化版（仅全局贪心融合），因为正切线之间不存在正常线与正切线的交叉冲突。

---

## 8. 与前两轮修复的差异对比

| 差异维度 | 第一轮修复 (s7) | 第二轮修复 (s8 计划) | 第三轮修复 (s13, 本文档) | 关系 |
|---|---|---|---|---|
| **正切线识别** | 修复方案A→B（SilhouetteType 精确判定 + None 回退） | 不涉及 | **移除 None 回退**，仅使用 Tangent/NonSilhouetteTangent | **强化**：V1 引入精确枚举但保留了回退，V3 彻底移除回退 |
| **正切线分组** | 所有线段混合到 rawGrouped | 不涉及 | **分离为两个独立字典**，各自独立管线 | **重构**：V1/V2 均未解决混合处理问题，V3 从架构层面分离 |
| **渲染模式** | 切换到 Rendered + ViewCapture 渲染管道 | 修复设置顺序/Redraw | **同 V2 方向** + 确保隐藏视口 DisplayMode 生效 | **延续**：V3 在 V2 计划基础上增加隐藏视口验证 |
| **物体居中** | 未涉及 | 增加 ZoomBoundingBox 边距 | **同 V2 方向** | **延续** |
| **PictureFrame** | 实现了 PictureFrame（embedBitmap=false） | 修复 embedBitmap=true | **同 V2 方向** + 改用 renderOutputPath | **延续+增强**：V3 增加持久化路径替代临时文件 |
| **隐藏线** | 未涉及 | 新增 HiddenLines 图层 | **本期不做** | **推迟**：用户反馈聚焦于其他三个缺陷 |

---

*第三轮修复任务计划书结束 — 待审核确认后进入执行阶段*
