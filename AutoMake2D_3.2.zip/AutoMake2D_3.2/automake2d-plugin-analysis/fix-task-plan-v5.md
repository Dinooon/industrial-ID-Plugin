# AutoMake2D 第五轮缺陷修复任务计划书 (V5)

> **版本**: v5.0 | **日期**: 2026-07-10 | **状态**: 待审核  
> **前置文档**: `optimization-task-plan-v4.md` (v4.0, 第四轮优化), `fix-task-plan-v3.md` (v3.0, 第三轮修复)  
> **当前源码**: PatentCore.cs (1355行), PatentUiPanel.cs (214行)  
> **用户反馈图片**: `/home/ubuntu/upload/image.png` (渲染图缺陷), `/home/ubuntu/upload/image_1.png` (线框分类缺陷)

---

## 1. 背景与目标

### 1.1 问题

V4 优化计划提出了四层线型分类体系（Silhouette + Crease + Tangent + Visible）和渲染管道切换方案，但用户测试 V4 版本（已实装 V3 修复 + 部分 V4 修改）后反馈**两个新缺陷**：

#### 缺陷V5-1：渲染图中物件未居中且缺少曲面边缘线显示

**参考图片**: `/home/ubuntu/upload/image.png`

**现象**：
1. **物件未居中**：输出渲染图中物体多数位于视窗边缘，上排物体偏上、中排物体偏向左右两侧、下排物体偏下，未居中于图片中央
2. **缺少曲面边缘线**：渲染图有基本的着色和光影效果（Rendered 模式已生效），但**没有曲面结构线/锐利边缘线显示**，视图中仅散布微小点状标记，曲面棱线不可辨识

**根因分析**：

| 子问题 | 根因 | 涉及方法与行号 |
|---|---|---|
| 物件未居中 | `CaptureViewRender()` 中 `ZoomBoundingBox(viewBbox)` 传入的包围盒是模型全量包围盒经 `PlaneToPlane` 变换后的结果，变换后包围盒中心可能不在视口原点；且 `GetModelBoundingBox()` 包含了已烘焙线框物体的包围盒（线框图层未排除）；未添加边距 Inflate | `CaptureViewRender()` 第 1118-1131 行 |
| 缺少曲面边缘线 | Rhino Rendered 显示模式默认**不显示曲面边缘线**，当前代码仅设置了 `vp.DisplayMode = renderMode`，未配置显示模式属性来启用边缘线 | `CaptureViewRender()` 第 1133-1140 行 |

#### 缺陷V5-2：轮廓线未抓取分类且需简化线型分类

**参考图片**: `/home/ubuntu/upload/image_1.png`

**现象**：
1. **轮廓线抓取不完整**：当前输出中蓝色线条代表轮廓线，但轮廓线抓取不完整，部分应为轮廓线的线段未正确识别
2. **用户要求去除结构线线型分类**：不再需要 Crease/Tangent/Visible 四层分类，简化线型

**多模态分析确认**：当前输出中蓝色线条代表轮廓线，黑色线条代表内部结构线，灰色点阵为隐藏线/参考点。轮廓线抓取不完整，且用户要求去除结构线的子分类。

**根因分析**：

| 子问题 | 根因 | 涉及方法与行号 |
|---|---|---|
| 轮廓线抓取不完整 | 当前 `ComputeSingleViewEngine()` 仅以 `SilhouetteType.Projecting` 和 `SilhouetteType.Boundary` 判定外轮廓线（第 353-357 行），遗漏了 `SilhouetteType.NonSilhouetteCrease` 等可能构成外轮廓的线段；且 `HiddenLineDrawingParameters` 设置 `IncludeTangentEdges=true` 但 `IncludeHiddenCurves=false`，部分轮廓线可能在 HLD 计算阶段即被过滤 | `ComputeSingleViewEngine()` 第 302-360 行 |
| 结构线分类过于复杂 | V4 计划提出的四层分类（Silhouette + Crease + Tangent + Visible）增加了用户理解负担，用户明确要求简化为：**轮廓线 (Silhouette)** + **结构线 (Structure)** 两层即可 | `ComputeSingleViewEngine()` 整体, `BakeToRhinoGrouped()` 第 838-890 行 |

### 1.2 目标用户

专利工程师 / 专利律师 — 使用 AutoMake2D 生成专利申请用线框工程图和渲染图

### 1.3 业务目标与可验证指标

| 缺陷 | 修复目标 | 可验证指标 |
|---|---|---|
| 缺陷V5-1a | 渲染图中物件居中于图片中央 | 物件包围盒中心与图片中心偏差 ≤ 5%（像素距离/图片尺寸）；各视图中物件位置对称 |
| 缺陷V5-1b | 渲染图显示曲面边缘线 | 渲染图中可见曲面棱线和锐利边缘线（非仅着色），目视可辨识曲面结构 |
| 缺陷V5-2a | 完整抓取和分类轮廓线 (Silhouette) | 与 Rhino 原生 Make2D 同视角输出对比，轮廓线覆盖率 ≥ 90% |
| 缺陷V5-2b | 简化线型为两层：轮廓线 + 结构线 | 输出仅 2 个线型图层：Patent_Silhouette（轮廓线）+ Patent_Structure（结构线），无 Crease/Tangent/Visible 子分类 |

---

## 2. 范围 (Scope)

### ✅ 本期做

| 编号 | 修复项 | 说明 |
|---|---|---|
| FIX-V5-1.1 | 修复 ZoomBoundingBox 居中逻辑 | 重构 `CaptureViewRender()` 中包围盒计算：排除隐藏图层和线框图层 → 变换后居中到视口原点 → Inflate 边距 → ZoomBoundingBox |
| FIX-V5-1.2 | 新增 GetModelBoundingBoxExcludingHidden() 方法 | 仅计算可见且非线框图层的物体包围盒，替代当前的 `GetModelBoundingBox()` |
| FIX-V5-1.3 | 渲染图显示曲面边缘线 | 在 Rendered 显示模式下启用曲面边缘线显示：通过 `DisplayModeDescription` 属性设置或叠加 Wireframe 边缘 |
| FIX-V5-1.4 | 渲染时确保线框图层隐藏 | 扩展 `ExecuteAsync` 渲染块中的线框图层隐藏逻辑，覆盖所有 Patent_ 前缀图层 |
| FIX-V5-2.1 | 扩展轮廓线识别范围 | 在 `ComputeSingleViewEngine()` 中扩展轮廓线判定：除 `Projecting/Boundary` 外，补充 `NonSilhouetteCrease`（裸露边折痕）等可能构成外轮廓的 SilhouetteType 值 |
| FIX-V5-2.2 | 简化线型分类为两层 | 将当前 IsOuter + IsTangent + 默认三分类简化为 Silhouette（轮廓线）+ Structure（所有非轮廓线）两层；去除 LineType=Crease/Tangent/Visible 分类 |
| FIX-V5-2.3 | 重构 BakeToRhinoGrouped() 为两层图层 | 输出图层从当前 Patent_Drawings_2D + TangentEdges 改为 Patent_Silhouette（轮廓线，红色）+ Patent_Structure（结构线，黑色） |
| FIX-V5-2.4 | 简化 PropagateUserStrings() 标记传播 | 简化语义标记为 IsSilhouette（替代 IsOuter），去除 IsTangent/LineType 标记 |

### ❌ 本期不做

| 排除项 | 原因 |
|---|---|
| ❌ 四层线型分类（V4 方案的 Silhouette + Crease + Tangent + Visible） | 用户明确要求简化，不需要细分结构线类型 |
| ❌ BrepEdge 邻接面法角二次分类 | 简化后结构线不再细分 Crease/Tangent，无需法角检测 |
| ❌ 渲染管道切换（Rhino.Render.RenderPipeline） | 当前 Rendered 模式已有基本着色效果，本期聚焦居中和边缘线显示 |
| ❌ 隐藏线图层 | 用户本期未提及，留待后续 |
| ❌ 线宽差异化 | 用户要求线宽统一 |
| ❌ 渲染材质/光照自定义 | 超出本期范围 |
| ❌ Rhino 8 兼容 | 当前绑定 Rhino 7 SR35 |

---

## 3. 核心场景

### 场景 A：专利工程师生成居中渲染效果图

> 专利工程师小张勾选渲染输出后，之前得到的渲染图中物体偏向画面边缘，且无法辨识曲面棱线。修复后，物体居中于画面中央，曲面边缘线清晰可见，渲染图可直接用于专利申请材料中的立体视图，无需手动调整位置或补充边缘线。

### 场景 B：专利工程师生成简化的线框图

> 专利工程师小王使用 AutoMake2D 生成线框图，之前输出分为多层（Crease/Tangent/Visible），结构复杂且轮廓线不完整。修复后，输出仅两层：轮廓线（红色，清晰标识物体外轮廓）和结构线（黑色，包含所有内部结构线），轮廓线抓取更完整，图层简洁易用，符合专利图规范。

---

## 4. 功能拆解与优先级

| 功能 | 描述 | 优先级 | 负责专家 |
|---|---|---|---|
| FIX-V5-1.1 | 修复 ZoomBoundingBox 居中逻辑（排除线框图层 + 变换后居中 + Inflate 边距） | **Must** | code |
| FIX-V5-1.2 | 新增 GetModelBoundingBoxExcludingHidden() | **Must** | code |
| FIX-V5-1.3 | 渲染图显示曲面边缘线 | **Must** | code |
| FIX-V5-1.4 | 渲染时确保线框图层隐藏 | **Should** | code |
| FIX-V5-2.1 | 扩展轮廓线识别范围 | **Must** | code |
| FIX-V5-2.2 | 简化线型分类为 Silhouette + Structure 两层 | **Must** | code |
| FIX-V5-2.3 | 重构 BakeToRhinoGrouped() 为两层图层 | **Must** | code |
| FIX-V5-2.4 | 简化 PropagateUserStrings() 标记传播 | **Should** | code |

---

## 5. 用户故事与验收标准

### US-1：渲染图物件居中

**故事**: 作为专利工程师，我希望渲染输出图中物体位于画面正中央，这样我能直接使用渲染图作为专利申请材料，无需手动裁剪和调整。

**验收 (Given/When/Then)**:
- Given 一个包含多个零部件的 3D 模型，When 执行 AutoMake2D 勾选渲染输出，Then 渲染图中物体包围盒中心与图片中心像素偏差 ≤ 5%
- Given 任意标准视图（Front/Top/Left 等），When 渲染该视图，Then 物体在图片中水平与垂直方向均居中

### US-2：渲染图显示曲面边缘线

**故事**: 作为专利工程师，我希望渲染图中能清晰看到曲面的棱线和锐利边缘，这样我能辨识物体的几何结构，而不仅是模糊的着色块。

**验收 (Given/When/Then)**:
- Given 一个含圆角和棱边的 3D 模型，When 执行渲染输出，Then 渲染图中可见曲面边缘线（锐利棱边和曲面交线）
- Given 一个纯球体模型，When 执行渲染输出，Then 渲染图中无额外边缘线（球体无结构边）

### US-3：完整抓取轮廓线

**故事**: 作为专利工程师，我希望线框图中的轮廓线 (Silhouette) 被完整抓取，这样我能准确看到物体的最大可视外轮廓，与 Rhino 原生 Make2D 输出一致。

**验收 (Given/When/Then)**:
- Given 一个含曲面特征的模型，When 执行 AutoMake2D，Then 轮廓线图层包含完整的视点相关外轮廓线
- Given 同一模型同一视角，When 对比 AutoMake2D 输出与 Rhino 原生 Make2D，Then 轮廓线覆盖率 ≥ 90%

### US-4：简化线型分类

**故事**: 作为专利工程师，我希望线框图输出仅有轮廓线和结构线两种类型，这样图层简洁、颜色清晰，不需要在多个子分类图层中查找线条。

**验收 (Given/When/Then)**:
- Given 任意模型执行 AutoMake2D，When 查看图层面板，Then 仅有 Patent_Silhouette（红色）和 Patent_Structure（黑色）两个线型图层
- Given 执行后检查曲线属性，When 读取 UserString，Then 曲线仅有 IsSilhouette 标记，无 IsTangent/LineType 标记

### 验收清单汇总表

| AC-ID | 验收点 (一句话, 可被自动化测试验证) | 优先级 | 关联 US |
|---|---|---|---|
| AC-1 | 渲染图中物体包围盒中心与图片中心像素偏差 ≤ 5% | P0 | US-1 |
| AC-2 | 各视图渲染图中物体水平与垂直方向均居中（对称） | P0 | US-1 |
| AC-3 | 含棱边的模型渲染图中可见曲面边缘线/锐利边缘线 | P0 | US-2 |
| AC-4 | 纯球体模型渲染图中无额外结构边缘线（球体无 Crease） | P1 | US-2 |
| AC-5 | 渲染图中不包含已输出的线框几何线条 | P1 | US-2 |
| AC-6 | 轮廓线图层 (Patent_Silhouette) 包含视点相关外轮廓线 | P0 | US-3 |
| AC-7 | 与 Rhino 原生 Make2D 同视角对比，轮廓线覆盖率 ≥ 90% | P1 | US-3 |
| AC-8 | 输出仅有 Patent_Silhouette 和 Patent_Structure 两个线型图层 | P0 | US-4 |
| AC-9 | 曲线 UserString 中无 IsTangent/LineType 标记 | P1 | US-4 |
| AC-10 | 编译通过，0 errors | P0 | 全部 |
| AC-11 | 渲染完成后用户原始 ActiveView 恢复正常 | P0 | US-1 |

---

## 6. 流程 / 信息架构

### 6.1 渲染输出流程 (V5 修复后)

```mermaid
flowchart TD
    A[用户点击执行] --> B{wantRender?}
    B -- No --> Z[仅输出线框]
    B -- Yes --> C[保存当前 ActiveView]
    C --> D[隐藏所有 Patent_ 前缀线框图层]
    D --> E[创建可见临时视口]
    E --> F[设置平行投影 + 相机位置]
    F --> G[设置 Rendered 显示模式]
    G --> G1[启用曲面边缘线显示属性]
    G1 --> H[切换为 ActiveView]
    H --> I[GetModelBoundingBoxExcludingHidden]
    I --> J[PlaneToPlane 变换 → 居中到原点 → Inflate 5%]
    J --> K[ZoomBoundingBox]
    K --> L[多次 Redraw + Sleep]
    L --> M[ViewCapture.CaptureToBitmap]
    M --> N[恢复线框图层可见性]
    N --> O[恢复原始 ActiveView]
    O --> P[关闭临时视口]
    P --> Q[排版合成 → PictureFrame + PNG]
```

### 6.2 线框分类流程 (V5 简化后)

```mermaid
flowchart TD
    A[HiddenLineDrawing.Compute] --> B[遍历 Segments]
    B --> C{SilhouetteType 判定}
    C -- "Projecting / Boundary / NonSilhouetteCrease" --> D[轮廓线组 rawSilhouette]
    C -- "Tangent / NonSilhouetteTangent / TangentProjects / NonSilhouetteSeam" --> E[结构线组 rawStructure]
    C -- "Crease / SectionCut / 其他" --> E
    C -- "None" --> F{补充判定}
    F -- "裸露边界边 BrepEdge" --> D
    F -- "其他" --> E
    D --> G[轮廓线独立管线: CleanRaw → 外轮廓隔离 → JoinCurves]
    E --> H[结构线独立管线: CleanRaw → JoinCurves]
    G --> I[标记 IsSilhouette=true]
    H --> J[标记 IsSilhouette=false/空]
    I --> K[合并到 finalCleanedGrouped]
    J --> K
    K --> L[两层烘焙输出]
    L --> L1[Patent_Silhouette 红色]
    L --> L2[Patent_Structure 黑色]
```

---

## 7. 风险与注意事项

| ID | 风险 | 影响 | 缓解措施 |
|---|---|---|---|
| RK-1 | Rhino Rendered 显示模式启用边缘线的 API 可能不存在或不稳定 | 渲染图中仍无法显示边缘线 | 多级备选：DisplayModeDescription 属性设置 → 自定义显示模式 → Wireframe 叠加渲染 → 最终回退为 Shaded 模式（有基本线框） |
| RK-2 | ZoomBoundingBox 居中修复后，不同形状模型的包围盒变换可能导致缩放不一致 | 部分模型渲染图中物体偏大或偏小 | 统一使用 Inflate 百分比边距，确保各视图缩放比例一致 |
| RK-3 | 扩展轮廓线识别范围可能引入误判（如将内部结构线误判为轮廓线） | 轮廓线图层包含非轮廓线线段 | 以 SilhouetteType 枚举精确值为主判据，仅对 None 类型做 BrepEdge 边界检测作为补充 |
| RK-4 | 简化分类后，原有 TangentEdges 图层和 Patent_Drawings_2D 图层需清理 | 旧图层残留导致用户困惑 | BakeToRhinoGrouped() 中检测并清理旧图层，或在文档中标注旧图层可手动删除 |
| RK-5 | GetModelBoundingBoxExcludingHidden() 排除线框图层后，如果模型本身在隐藏图层，渲染图将为空 | 渲染输出 null | 仅排除以 "Patent_" 开头的图层，不排除用户模型的隐藏图层 |
| RK-6 | 曲面边缘线在渲染图中的粗细/颜色可能不可控 | 边缘线过细或颜色不合适影响可读性 | 通过 DisplayModeDescription 属性设置边缘线颜色和粗细，或接受默认渲染边缘线样式 |

---

## 8. 与 V4 计划的差异对比

| 维度 | V4 计划 | V5 计划 | 变更原因 |
|---|---|---|---|
| **线型分类** | 四层：Silhouette + Crease + Tangent + Visible | **两层：Silhouette + Structure** | 用户明确要求简化，去除结构线子分类 |
| **轮廓线识别** | Projecting/Boundary 枚举 | **Projecting/Boundary/NonSilhouetteCrease + BrepEdge 边界补充** | 用户反馈轮廓线抓取不完整 |
| **结构线识别** | BrepEdge 邻接面法角二次分类 (ClassifyByBrepEdge) | **取消二次分类**，所有非轮廓线统一归入 Structure | 用户不需要细分 Crease/Tangent/Visible |
| **渲染居中** | 未深入分析根因，仅建议"ZoomBoundingBox 增加边距" | **根因修复**：排除线框图层包围盒 + 变换后居中到视口原点 + Inflate 边距 | 用户反馈物件未居中，需根因修复 |
| **曲面边缘线** | 未涉及 | **新增**：Rendered 模式下启用边缘线显示 | 用户反馈渲染图缺少曲面边缘线 |
| **烘焙输出** | 四层图层 (红/黑/蓝/灰) | **两层图层** (Patent_Silhouette 红 + Patent_Structure 黑) | 配合线型简化 |
| **标记体系** | LineType=Silhouette/Crease/Tangent/Visible | **IsSilhouette=true/false** 仅一个标记 | 配合线型简化 |
| **BrepEdge 法角检测** | 新增 ClassifyByBrepEdge() 方法 (~200行) | **不实现** | 简化分类后无需法角检测 |
