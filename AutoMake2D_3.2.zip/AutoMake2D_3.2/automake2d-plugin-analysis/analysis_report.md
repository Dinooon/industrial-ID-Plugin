# PatentCore.cs 三大问题根因分析报告

**文件**: `src/PatentCore.cs` (1355 行)  
**分析日期**: 2026-07-10  
**分析范围**: V7 版本当前代码

---

## 问题 A：输出图片背景仍非白色

### 根因：`DrawBackground = true` 导致 Rhino 渲染管道绘制原始背景色

**问题代码位置**: 第 1151 行

```csharp
captureSettings.DrawBackground = true;   // ← 第1151行：应设为 false
```

### 详细分析

Context 提到 "V7 修复中已设置 `DrawBackground=false` + `Graphics.Clear(White)`"，但**当前代码中 `DrawBackground` 的值是 `true`，不是 `false`**。说明 V7 修复要么从未落地，要么被后续改动覆盖。

完整的渲染捕获流程如下：

1. **`CaptureViewRender()` (第 1090-1180 行)** — 单视图渲染捕获：
   - 第 1148-1152 行设置 `ViewCaptureSettings`：
     ```csharp
     captureSettings.DrawGrid = false;
     captureSettings.DrawAxis = false;
     captureSettings.DrawBackground = true;   // ← 根因：绘制了 Rhino 视口背景色（通常为深灰/黑）
     captureSettings.RasterMode = true;
     ```
   - 第 1154 行：`result = ViewCapture.CaptureToBitmap(captureSettings);`
   - `DrawBackground = true` 意味着 `ViewCapture` 渲染管道会在位图上**先填充 Rhino 视口的背景色**（默认深灰色），然后才渲染模型。这导致每张单视图位图自带深色背景。

2. **`ComposeRenderLayout()` (第 1200-1240 行)** — 排版合成：
   - **单视图分支** (第 1207-1213 行)：**直接返回原始位图，不做任何白底处理**：
     ```csharp
     if (viewBitmaps.Count == 1)
     {
         using (var enumerator = viewBitmaps.Values.GetEnumerator())
         {
             if (enumerator.MoveNext())
                 return enumerator.Current;   // ← 直接返回带深色背景的位图
         }
         return null;
     }
     ```
   - **多视图分支**：六视图/三视图/通用排版中虽然调用了 `g.Clear(Color.White)` (第 1268/1303/1328 行)，但这只是画布底色。`DrawAt()` (第 1349 行) 直接 `g.DrawImage(bmp, ...)` 将带深色背景的单视图位图贴上去，**深色背景会覆盖白色画布**，最终结果仍然非白。

### 根因总结

| 环节 | 期望 | 实际 |
|------|------|------|
| `CaptureViewRender` 第1151行 | `DrawBackground = false` | `DrawBackground = true` |
| 单视图输出 (`ComposeRenderLayout` 第1207-1213行) | 白底合成 | 直接返回原图（带深色背景） |
| 多视图输出 | 白底画布 + 透明背景位图 | 白底画布 + 不透明深色背景位图覆盖 |

### 修复方案

1. **第 1151 行**：`captureSettings.DrawBackground = false;` — 让 ViewCapture 不绘制视口背景，输出透明背景位图
2. **单视图分支（第 1207-1213 行）**：增加白底合成逻辑：
   ```csharp
   if (viewBitmaps.Count == 1)
   {
       // 创建白底画布，将原始位图贴上去
       using (var enumerator = viewBitmaps.Values.GetEnumerator())
       {
           if (enumerator.MoveNext())
           {
               var original = enumerator.Current;
               var canvas = new Bitmap(original.Width, original.Height);
               using (var g = Graphics.FromImage(canvas))
               {
                   g.Clear(Color.White);
                   g.DrawImage(original, 0, 0, original.Width, original.Height);
               }
               return canvas;
           }
       }
       return null;
   }
   ```
3. 若 `DrawBackground = false` 后位图仍不透明，需在 `CaptureViewRender` 中手动 `Graphics.Clear(Color.White)` 再叠加渲染结果。

---

## 问题 B：Patent Silhouette 图层无数据（IsOuter 从未被设为 true）

### 根因：`BakeToRhinoGrouped()` 中根本不存在 Silhouette/Structure 图层分发逻辑

**问题代码位置**: `BakeToRhinoGrouped()` 第 783-832 行

### 详细分析

#### B1. IsOuter 标记设置（ComputeSingleViewEngine，第 350-388 行）

IsOuter 的标记逻辑**确实存在且看起来正确**：

```csharp
// 第 350-353 行
if (hldCurve.SilhouetteType == SilhouetteType.Projecting ||
    hldCurve.SilhouetteType == SilhouetteType.Boundary)
{
    isOuterContour = true;
}

// 第 387-389 行
if (isOuterContour)
{
    crv.SetUserString("IsOuter", "true");
}
```

理论上，当 `HiddenLineDrawing` 计算出的曲线段其 `SilhouetteType` 为 `Projecting` 或 `Boundary` 时，`IsOuter` 会被设为 `"true"`。但这里存在一个**关键风险**：

> **RhinoCommon 的 `SilhouetteType` 枚举在平行投影 + `HiddenLineDrawing` 管道中，`Projecting` 和 `Boundary` 可能永远不会被赋值。** 
> 
> `SilhouetteType.Projecting` 通常出现在透视投影的轮廓线场景；`SilhouetteType.Boundary` 表示裸露边界（如开放曲面的边缘）。对于封闭的 Brep/Mesh 零件，平行投影下大多数可见线段的 `SilhouetteType` 为 `None`，因为它们是面的边缘（mesh edges / brep edges），而非投影轮廓线。

这意味着**对于典型的封闭零件模型，所有曲线的 `IsOuter` 都可能保持默认值（未设置 / null / "false"），`isOuterContour` 始终为 false**。

#### B2. BakeToRhinoGrouped 中完全没有 Silhouette/Structure 图层（第 783-832 行）

这是**最严重的根因**。完整的 BakeToRhinoGrouped 方法体如下：

```csharp
private static void BakeToRhinoGrouped(RhinoDoc doc, Dictionary<string, Dictionary<string, List<Curve>>> viewsData)
{
    string layerName = "Patent_Drawings_2D";          // 第 785 行
    // ... 创建 Patent_Drawings_2D 图层 ...

    string tangentLayerName = "TangentEdges";          // 第 798 行
    // ... 创建 TangentEdges 图层 ...

    foreach (var kvpView in viewsData)
    {
        foreach (var kvpComp in kvpView.Value)
        {
            foreach (var crv in curves)
            {
                // 第 822 行：仅按 IsTangent 分发，没有按 IsOuter 分发
                bool isTangent = crv.GetUserString("IsTangent") == "true";
                int targetLayerIndex = isTangent ? tangentLayerIndex : layerIndex;
                
                var attributes = new ObjectAttributes { LayerIndex = targetLayerIndex };
                attributes.AddToGroup(groupIndex);
                doc.Objects.AddCurve(crv, attributes);
            }
        }
    }
}
```

**代码中完全不存在以下内容**：
- 没有 "Patent Silhouette" 图层的创建
- 没有 "Patent Structure" 图层的创建
- 没有按 `IsOuter` 标记分发曲线到不同图层的逻辑

Context 提到 "V6 恢复了 s7 时代的 IsOuter 标记和 BakeToRhinoGrouped 按 IsOuter 分发"，但**当前 V7 代码中这一分发逻辑已经丢失**。当前代码只做了两层分发：
- `IsTangent == "true"` → `TangentEdges` 图层
- 其他 → `Patent_Drawings_2D` 图层

没有 `IsOuter` 的参与。

### 根因总结

| 问题点 | 行号 | 状态 |
|--------|------|------|
| IsOuter 标记设置逻辑 | 350-353, 387-389 | ✅ 存在，但可能因 SilhouetteType 枚举在平行投影下不产生 Projecting/Boundary 而实际不触发 |
| BakeToRhinoGrouped 中 IsOuter 分发 | 783-832 | ❌ **完全缺失** — 没有 Silhouette/Structure 图层，没有按 IsOuter 分发 |
| Silhouette 图层创建 | — | ❌ **不存在** |
| Structure 图层创建 | — | ❌ **不存在** |

### 修复方案

1. **BakeToRhinoGrouped 中新增 Silhouette/Structure 图层分发**：
   ```csharp
   // 创建图层
   string silhouetteLayerName = "Patent Silhouette";
   string structureLayerName = "Patent Structure";
   // ... 创建图层逻辑 ...

   // 分发逻辑（替换第 822-827 行）
   bool isTangent = crv.GetUserString("IsTangent") == "true";
   bool isOuter = crv.GetUserString("IsOuter") == "true";
   
   int targetLayerIndex;
   if (isOuter)
       targetLayerIndex = silhouetteLayerIndex;    // 外轮廓 → Silhouette
   else if (isTangent)
       targetLayerIndex = tangentLayerIndex;        // 正切线 → TangentEdges
   else
       targetLayerIndex = structureLayerIndex;      // 内部结构线 → Structure
   ```

2. **修正 IsOuter 判定逻辑**（第 350-353 行）：当前仅依赖 `SilhouetteType.Projecting` 和 `SilhouetteType.Boundary`，对于封闭零件在平行投影下可能永不触发。建议增加几何特征回退判定：
   ```csharp
   // 回退判定：若 SilhouetteType 未标记但曲线是组件最外包围的封闭环
   if (!isOuterContour)
   {
       // 可通过计算曲线是否构成组件投影的最大包围轮廓来判定
       // 或检查 hldCurve.SilhouetteType 是否为其他可表示外轮廓的值
   }
   ```

---

## 问题 C：曲线多处断开

### 根因：多重因素叠加 — 去重误删 + 相切角容差过严 + 交叉感知过度拦截 + 外轮廓隔离破坏端点对齐

### 详细分析

#### C1. CleanRawCurves 去重逻辑可能误删合法曲线（第 489-538 行）

```csharp
// 第 510 行：使用中点 + tolerance*0.5 的球体搜索近邻
tree.Search(new Sphere(midPt1, tolerance * 0.5), (sender, args) => { neighbors.Add(args.Id); });

// 第 515-523 行：去重判定
double dFwd = c1.PointAtStart.DistanceTo(c2.PointAtStart) + c1.PointAtEnd.DistanceTo(c2.PointAtEnd);
double dRev = c1.PointAtStart.DistanceTo(c2.PointAtEnd) + c1.PointAtEnd.DistanceTo(c2.PointAtStart);
double dMid = midPt1.DistanceTo(c2.PointAtNormalizedLength(0.5));

if ((dFwd < tolerance && dMid < tolerance * 0.5) || (dRev < tolerance && dMid < tolerance * 0.5))
{
    isDup = true;   // 误删风险
    break;
}
```

**问题**：
- `dMid < tolerance * 0.5` 的阈值非常严格，当两条不同曲线恰好在中间区域几何接近时会被误判为重复
- 去重仅基于中点位置和端点距离，不考虑曲线方向和曲率，弧线和直线可能在端点和中点都接近但实际是不同几何特征
- 去重后的曲线**不保留被删曲线的 UserString 标记**，可能导致后续 IsOuter/IsTangent 标记丢失

#### C2. GetMinTangentAngle 角度判定过严（第 743-781 行）

```csharp
// 第 772-776 行：交叉验证 — 两线整体趋近垂直时不合并
if (angles.Count >= 2)
{
    const double nearVerticalRad = 80.0 * Math.PI / 180.0;
    if (maxAngle >= nearVerticalRad)
        return false;   // ← 即使最小夹角很小，只要存在一种连接方式夹角≥80°就拒绝合并
}

// 第 779-781 行：绝对上限 60°
const double absoluteMaxAngle = 60.0 * Math.PI / 180.0;
if (minAngle > absoluteMaxAngle) return false;
```

**问题**：
- `angleTolRad` 传入值为 `0.08` 弧度（约 4.6°），这是一个**极小的角度容差**。正常工程图中，许多本应连续的线段在端点处的切线夹角可能略大于 4.6°（特别是 NURBS 曲线离散化后的段），导致这些线对无法被合并
- 交叉验证的 `nearVerticalRad = 80°` 过于激进：当两条线在某端点有 5° 夹角（应合并）但在另一端点恰好有 82° 夹角时，整个线对被拒绝合并
- 绝对上限 60° 进一步收紧了合并范围

#### C3. 外轮廓隔离逻辑破坏后续合并（第 425-460 行）

```csharp
// 第 427-433 行：按 IsOuter 分流
foreach (var c in list)
{
    if (c.GetUserString("IsOuter") == "true") outerCurves.Add(c);
    else innerCurves.Add(c);
}

// 第 437 行：外轮廓独立 JoinCurves
var joinedOuter = Curve.JoinCurves(outerCurves, tolerance);

// 第 442-451 行：外轮廓结果放回 nextPool
// 第 457 行：内部线放回 nextPool
nextPool.AddRange(innerCurves);
list = nextPool;

// 第 460 行：整体送入 JoinTangentCurvesPrioritized
list = JoinTangentCurvesPrioritized(list, tolerance, 0.08);
```

**问题**：
- 外轮廓线被独立 `JoinCurves` 后，生成的合并曲线端点位置可能与原始内部线端点**产生微小偏移**（因为 JoinCurves 内部会做几何拟合），导致外轮廓与内部线在交叉点处不再精确对齐
- 后续 `JoinTangentCurvesPrioritized` 中 `GetMinTangentAngle` 检查端点距离时用的是 `tolerance`（用户几何精度，通常很小如 0.001），如果偏移超过 tolerance，这些线对就因为端点不在 tolerance 内而无法合并

#### C4. JoinTangentCurvesPrioritized 三阶段策略中的端点锁定问题（第 539-650 行）

**阶段0（第 558 行）**：仅正常线互相合并
```csharp
var mergedNormals = JoinTangentCurvesPrioritized_Original(normalCurves, tolerance, angleTolRad);
```

**阶段1（第 562-600 行）**：交叉节点处相切线局部合并
```csharp
// 第 582-583 行：跳过纯正常线对
if (!ciTangent && !cjTangent) continue;
```

**问题**：
- 阶段0 先将正常线合并，合并后的新曲线端点可能与原始相切线端点不再对齐
- 阶段1 中 `mergedIndices` 锁定机制（第 591-592 行）一旦某条曲线被合并，它在同一交叉节点的其他配对就会被跳过，即使那些配对也应当合并
- 阶段1 的合并结果加入 `remaining` 池后再送入阶段2，但此时池中曲线的端点关系已经被阶段0和阶段1改变，阶段2 的全局贪心可能无法发现新的可合并对

#### C5. JoinCurves 容差参数分析

整个代码中 `Curve.JoinCurves` 的调用使用了以下容差：

| 位置 | 代码 | 容差 |
|------|------|------|
| 第 437 行（外轮廓） | `Curve.JoinCurves(outerCurves, tolerance)` | 用户 tolerance |
| 第 603 行（阶段1局部） | `Curve.JoinCurves(new Curve[] { pool[pair.Index1], pool[pair.Index2] }, tolerance)` | 用户 tolerance |
| 第 714 行（阶段0/2全局） | `Curve.JoinCurves(new Curve[] { pool[candidate.Index1], pool[candidate.Index2] }, tolerance)` | 用户 tolerance |
| 第 465 行（Step 3 闭合） | `Curve.JoinCurves(list, tolerance)` | 用户 tolerance |

**问题**：所有 `JoinCurves` 调用都使用用户的几何精度 `tolerance`（Rhino 默认 `doc.ModelAbsoluteTolerance` 通常为 0.001 单位）。这个容差对于"合并已经计算好的投影线段"来说**过于严格**：
- `HiddenLineDrawing` 计算产生的线段端点在浮点精度上可能存在微小偏差（如 0.001-0.01 单位级别）
- `JoinCurves` 的容差参数控制的是"两端点距离小于此值才合并"，0.001 的容差可能导致大量本应连接的线段因浮点偏差而无法合并
- 特别是经过 `Transform.PlaneToPlane` 变换后的曲线，端点坐标经过了矩阵运算，浮点误差会累积

### 根因总结

| 因素 | 严重度 | 行号 | 问题描述 |
|------|--------|------|----------|
| CleanRawCurves 误删 | ⚠️ 中 | 515-523 | `dMid < tolerance * 0.5` 过严，可能误删合法曲线 |
| GetMinTangentAngle 角度容差 | 🔴 高 | 558(传入0.08) / 772-781 | 0.08 rad(4.6°)过小 + 交叉验证80°过度拦截 + 绝对上限60° |
| 外轮廓隔离偏移 | ⚠️ 中 | 437-457 | JoinCurves 后端点偏移导致后续无法对齐 |
| 三阶段端点锁定 | ⚠️ 中 | 591-592 | mergedIndices 锁定导致同节点其他配对被跳过 |
| JoinCurves 容差过严 | 🔴 高 | 437/603/714/465 | 全部使用 tolerance(0.001)，浮点偏差导致无法合并 |

### 修复方案

1. **放宽 JoinCurves 容差**：对所有 `JoinCurves` 调用使用 `tolerance * 10` 或 `tolerance * 100` 作为合并容差（不影响几何精度，仅影响端点连接判定）：
   ```csharp
   double joinTol = tolerance * 50;  // 放宽端点连接容差
   var joinedOuter = Curve.JoinCurves(outerCurves, joinTol);
   ```

2. **放宽角度容差**：将 `angleTolRad` 从 0.08 (4.6°) 调整为 0.15-0.20 (8.6°-11.5°)：
   ```csharp
   list = JoinTangentCurvesPrioritized(list, tolerance, 0.15);
   ```

3. **修正交叉验证**：`nearVerticalRad` 从 80° 调整为 120° 或删除此检查，仅保留绝对上限 60°

4. **CleanRawCurves 去重保护**：增加方向验证，避免方向不同但中点接近的曲线被误删

5. **外轮廓隔离后对齐**：外轮廓 JoinCurves 后，将结果端点 snap 回最近的内部线端点

---

## 附录：三个问题之间的关联性

问题 B 和问题 C 存在关联：
- 如果 IsOuter 从未被设为 true（问题 B），则外轮廓隔离逻辑（第 427-460 行）中 `outerCurves` 始终为空，所有曲线都进入 `innerCurves`，外轮廓特权隔离形同虚设
- 这意味着所有曲线都走常规的 `JoinTangentCurvesPrioritized` + `JoinCurves` 流程，但上述流程的容差问题（问题 C）依然存在
- 反过来，如果 IsOuter 被正确标记，外轮廓隔离逻辑会独立处理外轮廓，但隔离后的端点偏移会加剧曲线断开（问题 C 的 C3 因素）
