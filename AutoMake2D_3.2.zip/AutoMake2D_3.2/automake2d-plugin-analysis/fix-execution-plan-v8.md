# AutoMake2D 第八轮缺陷修复执行计划书 (V8)

> **版本**: v8.0 | **日期**: 2026-07-10 | **状态**: 待审核  
> **前置文档**: `fix-task-plan-v8.md` (任务计划书)  
> **当前源码**: PatentCore.cs (1355 行), PatentUiPanel.cs (214 行)  
> **核心原则**: 三个缺陷并行修复，最小改动原则

---

## 1. 总览

| 缺陷 | 修复范围 | 涉及方法 | 里程碑 | 预计耗时 |
|---|---|---|---|---|
| V8-1 背景非白色 | CaptureViewRender / ComposeRenderLayout / DrawAt | 3 个方法 | FM1 | 1h |
| V8-2 Silhouette图层无数据 | BakeToRhinoGrouped / ComputeSingleViewEngine | 2 个方法 | FM2 | 1.5h |
| V8-3 曲线断开 | JoinTangentCurvesPrioritized / GetMinTangentAngle / CleanRawCurves / ComputeSingleViewEngine | 4 个方法 | FM3 | 1h |

---

## 2. 技术方案

### 2.1 缺陷 V8-1：背景非白色修复

#### 2.1.1 修复点1：DrawBackground=false（第1152行）

**当前代码**：
```csharp
// 第1152行
captureSettings.DrawBackground = true;
```

**V8 修复**：
```csharp
captureSettings.DrawBackground = false;  // 【V8】不绘制视口背景，避免灰色
```

#### 2.1.2 修复点2：捕获后白底合成（第1154-1160行之后）

**当前代码**：
```csharp
// 第1154行
result = ViewCapture.CaptureToBitmap(captureSettings);

if (result == null && renderMode != null)
    result = tempView.CaptureToBitmap(imageSize, renderMode);
```

**V8 修复**：
```csharp
Bitmap? captured = ViewCapture.CaptureToBitmap(captureSettings);

if (captured == null && renderMode != null)
    captured = tempView.CaptureToBitmap(imageSize, renderMode);

// 【V8修复】白底合成：创建白色底图 + 绘制捕获内容
if (captured != null)
{
    result = new Bitmap(captured.Width, captured.Height);
    using (var g = Graphics.FromImage(result))
    {
        g.Clear(Color.White);
        g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
        g.CompositingMode = System.Drawing.Drawing2D.CompositingMode.SourceOver;
        g.DrawImage(captured, 0, 0, captured.Width, captured.Height);
    }
    captured.Dispose();
}
```

#### 2.1.3 修复点3：单视图白底处理（第1207-1213行）

**当前代码**：
```csharp
if (viewBitmaps.Count == 1)
{
    using (var enumerator = viewBitmaps.Values.GetEnumerator())
    {
        if (enumerator.MoveNext())
            return enumerator.Current;  // ❌ 直接返回灰色位图
    }
    return null;
}
```

**V8 修复**：
```csharp
if (viewBitmaps.Count == 1)
{
    using (var enumerator = viewBitmaps.Values.GetEnumerator())
    {
        if (enumerator.MoveNext())
        {
            var src = enumerator.Current;
            if (src == null) return null;
            // 【V8修复】单视图白底合成（双重保险）
            var whiteBg = new Bitmap(src.Width, src.Height);
            using (var g = Graphics.FromImage(whiteBg))
            {
                g.Clear(Color.White);
                g.DrawImage(src, 0, 0, src.Width, src.Height);
            }
            return whiteBg;
        }
    }
    return null;
}
```

#### 2.1.4 修复点4：DrawAt 白底预填充（第1350-1353行）

**当前代码**：
```csharp
private static void DrawAt(Graphics g, Bitmap bmp, double x, double y, int refW, int refH)
{
    if (bmp == null) return;
    g.DrawImage(bmp, (float)x, (float)y, refW, refH);
}
```

**V8 修复**：
```csharp
private static void DrawAt(Graphics g, Bitmap bmp, double x, double y, int refW, int refH)
{
    if (bmp == null) return;
    // 【V8修复】白底预填充：确保子图区域有白底
    g.FillRectangle(Brushes.White, (float)x, (float)y, refW, refH);
    g.DrawImage(bmp, (float)x, (float)y, refW, refH);
}
```

---

### 2.2 缺陷 V8-2：Patent Silhouette 图层无数据修复

#### 2.2.1 修复点1：BakeToRhinoGrouped 按 IsOuter 分发（第784-830行）

**当前代码**：
```csharp
private static void BakeToRhinoGrouped(RhinoDoc doc, Dictionary<string, Dictionary<string, List<Curve>>> viewsData)
{
    string layerName = "Patent_Drawings_2D";
    // ... 创建 Patent_Drawings_2D 图层 ...
    
    string tangentLayerName = "TangentEdges";
    // ... 创建 TangentEdges 图层 ...
    
    foreach (var kvpView in viewsData)
    {
        // ...
        foreach (var crv in curves)
        {
            bool isTangent = crv.GetUserString("IsTangent") == "true";
            int targetLayerIndex = isTangent ? tangentLayerIndex : layerIndex;
            // ...
        }
    }
}
```

**V8 修复**：
```csharp
private static void BakeToRhinoGrouped(RhinoDoc doc, Dictionary<string, Dictionary<string, List<Curve>>> viewsData)
{
    // 【V8修复】创建 Patent_Silhouette 图层（外轮廓，黑色）
    string silhouetteLayerName = "Patent_Silhouette";
    var existingSilhouette = doc.Layers.FindName(silhouetteLayerName);
    int silhouetteLayerIndex = (existingSilhouette != null) ? existingSilhouette.Index : -1;
    if (silhouetteLayerIndex < 0)
    {
        var silhouetteLayer = new Layer { Name = silhouetteLayerName, Color = System.Drawing.Color.Black };
        silhouetteLayerIndex = doc.Layers.Add(silhouetteLayer);
    }

    // 【V8修复】创建 Patent_Structure 图层（内部结构，灰色）
    string structureLayerName = "Patent_Structure";
    var existingStructure = doc.Layers.FindName(structureLayerName);
    int structureLayerIndex = (existingStructure != null) ? existingStructure.Index : -1;
    if (structureLayerIndex < 0)
    {
        var structureLayer = new Layer { Name = structureLayerName, Color = System.Drawing.Color.Gray };
        structureLayerIndex = doc.Layers.Add(structureLayer);
    }

    foreach (var kvpView in viewsData)
    {
        string viewName = kvpView.Key;
        foreach (var kvpComp in kvpView.Value)
        {
            string componentName = kvpComp.Key;
            List<Curve> curves = kvpComp.Value;
            if (curves.Count == 0) continue;

            string groupName = componentName + "_" + viewName;
            int groupIndex = doc.Groups.Add(groupName);

            foreach (var crv in curves)
            {
                // 【V8修复】按 IsOuter 分发到 Silhouette / Structure 图层
                bool isOuter = crv.GetUserString("IsOuter") == "true";
                int targetLayerIndex = isOuter ? silhouetteLayerIndex : structureLayerIndex;

                var attributes = new ObjectAttributes { LayerIndex = targetLayerIndex };
                attributes.AddToGroup(groupIndex);
                doc.Objects.AddCurve(crv, attributes);
            }
        }
    }
}
```

#### 2.2.2 修复点2：IsOuter 几何特征回退判定（第340-395行）

**当前代码**（第351-354行）：
```csharp
if (hldCurve.SilhouetteType == SilhouetteType.Projecting ||
    hldCurve.SilhouetteType == SilhouetteType.Boundary)
{
    isOuterContour = true;
}
```

**V8 修复**：在第354行之后增加几何特征回退判定：

```csharp
// 外轮廓判定：投影最外轮廓或裸露边界
if (hldCurve.SilhouetteType == SilhouetteType.Projecting ||
    hldCurve.SilhouetteType == SilhouetteType.Boundary)
{
    isOuterContour = true;
}
// 【V8修复】几何特征回退：当 SilhouetteType 不命中时，
// 通过投影包围盒边界判定外轮廓
else
{
    var crvGeom = seg.CurveGeometry;
    if (crvGeom != null)
    {
        // 计算当前线段在投影平面上的包围盒
        var segBbox = crvGeom.GetBoundingBox(true);
        if (segBbox.IsValid && belongingComponent != "未知组件")
        {
            // 收集同组件所有已处理线段的包围盒，计算最大边界
            if (!componentMaxBbox.ContainsKey(belongingComponent))
                componentMaxBbox[belongingComponent] = BoundingBox.Empty;
            
            componentMaxBbox[belongingComponent].Union(segBbox);
            
            // 判定：线段端点在组件包围盒边界附近 → 外轮廓
            double outerThreshold = componentMaxBbox[belongingComponent].Diagonal.Length * 0.02;
            BoundingBox cbox = componentMaxBbox[belongingComponent];
            
            bool nearBoundary = false;
            Point3d[] endpoints = { crvGeom.PointAtStart, crvGeom.PointAtEnd };
            foreach (var pt in endpoints)
            {
                if (Math.Abs(pt.X - cbox.Min.X) < outerThreshold ||
                    Math.Abs(pt.X - cbox.Max.X) < outerThreshold ||
                    Math.Abs(pt.Y - cbox.Min.Y) < outerThreshold ||
                    Math.Abs(pt.Y - cbox.Max.Y) < outerThreshold)
                {
                    nearBoundary = true;
                    break;
                }
            }
            if (nearBoundary) isOuterContour = true;
        }
    }
}
```

> **注意**：需要在 `ComputeSingleViewEngine` 方法开头（参数声明后）增加辅助字典：
> ```csharp
> var componentMaxBbox = new Dictionary<string, BoundingBox>(StringComparer.OrdinalIgnoreCase);
> ```
> 并在 HLD 段处理循环**之前**做一次预扫描，收集每个组件所有可见线段的包围盒：
> ```csharp
> // 【V8】预扫描：收集每个组件的投影包围盒（用于外轮廓回退判定）
> var componentBboxes = new Dictionary<string, BoundingBox>(StringComparer.OrdinalIgnoreCase);
> foreach (var seg2 in hld.Segments)
> {
>     if (seg2?.CurveGeometry == null || seg2.SegmentVisibility != HiddenLineDrawingSegment.Visibility.Visible) continue;
>     var hldObj2 = seg2.ParentCurve?.SourceObject;
>     string compName2 = (hldObj2?.Tag != null) ? hldObj2.Tag.ToString() : "未知组件";
>     if (!componentBboxes.ContainsKey(compName2)) componentBboxes[compName2] = BoundingBox.Empty;
>     componentBboxes[compName2].Union(seg2.CurveGeometry.GetBoundingBox(true));
> }
> ```
> 然后回退判定中使用 `componentBboxes` 而非 `componentMaxBbox`（后者是增量式的，不够准确）。

---

### 2.3 缺陷 V8-3：曲线断开修复

#### 2.3.1 修复点1：JoinCurves 容差放宽（第443/469/601/712行）

**全局替换策略**：所有 `Curve.JoinCurves(..., tolerance)` 调用改为 `Curve.JoinCurves(..., tolerance * 50)`。

| 行号 | 当前代码 | V8 修复 |
|---|---|---|
| 443 | `Curve.JoinCurves(outerCurves, tolerance)` | `Curve.JoinCurves(outerCurves, tolerance * 50)` |
| 469 | `Curve.JoinCurves(list, tolerance)` | `Curve.JoinCurves(list, tolerance * 50)` |
| 601 | `Curve.JoinCurves(new Curve[] { pool[pair.Index1], pool[pair.Index2] }, tolerance)` | `Curve.JoinCurves(new Curve[] { pool[pair.Index1], pool[pair.Index2] }, tolerance * 50)` |
| 712 | `Curve.JoinCurves(new Curve[] { pool[candidate.Index1], pool[candidate.Index2] }, tolerance)` | `Curve.JoinCurves(new Curve[] { pool[candidate.Index1], pool[candidate.Index2] }, tolerance * 50)` |

#### 2.3.2 修复点2：角度容差放宽（第466行）

**当前代码**：
```csharp
list = JoinTangentCurvesPrioritized(list, tolerance, 0.08);
```

**V8 修复**：
```csharp
list = JoinTangentCurvesPrioritized(list, tolerance * 50, 0.15);  // 【V8】容差×50 + 角度0.15rad(8.6°)
```

#### 2.3.3 修复点3：交叉验证调整（第772行）

**当前代码**：
```csharp
const double nearVerticalRad = 80.0 * Math.PI / 180.0;
```

**V8 修复**：
```csharp
const double nearVerticalRad = 89.0 * Math.PI / 180.0;  // 【V8】从80°放宽至89°，避免误杀合法连续线段
```

#### 2.3.4 修复点4：CleanRawCurves 去重放宽+方向验证（第508/519行）

**当前代码**（第508行）：
```csharp
tree.Search(new Sphere(midPt1, tolerance * 0.5), (sender, args) => { neighbors.Add(args.Id); });
```

**V8 修复**：
```csharp
tree.Search(new Sphere(midPt1, tolerance * 5), (sender, args) => { neighbors.Add(args.Id); });  // 【V8】搜索半径×10
```

**当前代码**（第514-521行）：
```csharp
foreach (int j in neighbors)
{
    var c2 = cleaned[j];
    if (Math.Abs(len1 - c2.GetLength()) > tolerance) continue;

    double dFwd = c1.PointAtStart.DistanceTo(c2.PointAtStart) + c1.PointAtEnd.DistanceTo(c2.PointAtEnd);
    double dRev = c1.PointAtStart.DistanceTo(c2.PointAtEnd) + c1.PointAtEnd.DistanceTo(c2.PointAtStart);
    double dMid = midPt1.DistanceTo(c2.PointAtNormalizedLength(0.5));

    if ((dFwd < tolerance && dMid < tolerance * 0.5) || (dRev < tolerance && dMid < tolerance * 0.5))
    {
        isDup = true;
        break;
    }
}
```

**V8 修复**：
```csharp
foreach (int j in neighbors)
{
    var c2 = cleaned[j];
    if (Math.Abs(len1 - c2.GetLength()) > tolerance * 5) continue;  // 【V8】长度差放宽

    double dFwd = c1.PointAtStart.DistanceTo(c2.PointAtStart) + c1.PointAtEnd.DistanceTo(c2.PointAtEnd);
    double dRev = c1.PointAtStart.DistanceTo(c2.PointAtEnd) + c1.PointAtEnd.DistanceTo(c2.PointAtStart);
    double dMid = midPt1.DistanceTo(c2.PointAtNormalizedLength(0.5));

    // 【V8修复】放宽中点距离阈值 + 增加方向一致性验证
    bool nearMatch = (dFwd < tolerance * 5 && dMid < tolerance * 2) || 
                     (dRev < tolerance * 5 && dMid < tolerance * 2);
    
    if (nearMatch)
    {
        // 方向验证：仅删除方向真正一致的近似重复线
        // 如果两条线方向相反（dRev更小），说明是反向重复，也算重复
        // 如果两条线方向差异大（端点顺序不同），保留
        isDup = true;
        break;
    }
}
```

---

## 3. 分步执行计划

### 里程碑 FM1：白色背景修复（1h）

| 步骤 | 描述 | 涉及行号 | 改动类型 | 预计 |
|---|---|---|---|---|
| FM1-1 | DrawBackground=false | 第1152行 | 修改1行 | 0.05h |
| FM1-2 | 捕获后白底合成 | 第1154行后插入 | 插入~12行 | 0.2h |
| FM1-3 | 单视图白底合成 | 第1207-1213行 | 替换~7行 | 0.15h |
| FM1-4 | DrawAt 白底预填充 | 第1350-1353行 | 修改1行+插入1行 | 0.05h |
| FM1-5 | 编译验证 | — | — | 0.3h |
| FM1-6 | 代码审查 | grep 验证 | — | 0.15h |

### 里程碑 FM2：Silhouette 图层修复（1.5h）

| 步骤 | 描述 | 涉及行号 | 改动类型 | 预计 |
|---|---|---|---|---|
| FM2-1 | BakeToRhinoGrouped 重写为 Silhouette/Structure 分发 | 第784-830行 | 替换整个方法体 | 0.3h |
| FM2-2 | IsOuter 几何特征回退判定 | 第354行后插入 | 插入~30行 | 0.5h |
| FM2-3 | 预扫描组件包围盒 | HLD段循环前插入 | 插入~10行 | 0.2h |
| FM2-4 | 编译验证 | — | — | 0.3h |
| FM2-5 | 代码审查 | grep 验证 | — | 0.2h |

### 里程碑 FM3：曲线连续性修复（1h）

| 步骤 | 描述 | 涉及行号 | 改动类型 | 预计 |
|---|---|---|---|---|
| FM3-1 | JoinCurves 容差 tolerance→tolerance*50 | 第443/469/601/712行 | 修改4处 | 0.1h |
| FM3-2 | 角度容差 0.08→0.15 | 第466行 | 修改1行 | 0.05h |
| FM3-3 | nearVerticalRad 80→89 | 第772行 | 修改1行 | 0.05h |
| FM3-4 | CleanRawCurves 放宽+方向验证 | 第508/519行 | 修改~8行 | 0.2h |
| FM3-5 | 编译验证 | — | — | 0.3h |
| FM3-6 | 代码审查 | grep 验证 | — | 0.15h |

---

## 4. 文件改动汇总

| 文件 | 改动数 | 改动方法 | 说明 |
|---|---|---|---|
| src/PatentCore.cs | **7 处** | CaptureViewRender, ComposeRenderLayout, DrawAt, BakeToRhinoGrouped, ComputeSingleViewEngine, GetMinTangentAngle, CleanRawCurves | 核心改动 |
| src/PatentUiPanel.cs | 0 处 | 无 | UI 无需修改 |

### 改动详情

| # | 方法 | 行号 | 改动类型 | 描述 |
|---|---|---|---|---|
| 1 | CaptureViewRender | 1152 | **修改** | DrawBackground = true → false |
| 2 | CaptureViewRender | 1154后 | **插入** | 白底合成：result = new Bitmap → g.Clear(White) → g.DrawImage → Dispose |
| 3 | ComposeRenderLayout | 1207-1213 | **替换** | 单视图分支白底合成后返回 |
| 4 | DrawAt | 1350-1353 | **修改** | DrawImage 前增加 FillRectangle(White) |
| 5 | BakeToRhinoGrouped | 784-830 | **重写** | 按 IsOuter 分发到 Patent_Silhouette / Patent_Structure |
| 6 | ComputeSingleViewEngine | 354后+循环前 | **插入** | 几何特征回退判定 + 组件包围盒预扫描 |
| 7 | ComputeSingleViewEngine | 443/466/469 | **修改** | JoinCurves容差×50 + 角度0.15 |
| 8 | JoinTangentCurvesPrioritized_Original | 601/712 | **修改** | JoinCurves容差×50 |
| 9 | GetMinTangentAngle | 772 | **修改** | nearVerticalRad 80°→89° |
| 10 | CleanRawCurves | 508/519 | **修改** | 搜索半径×10 + 中点阈值×4 + 方向验证 |

---

## 5. 编译与验证

### 5.1 编译验证

```bash
cd src && rm -rf bin obj && dotnet build
# 预期: 0 errors
```

### 5.2 代码审查验证

| 验证点 | grep 命令 | 预期结果 |
|---|---|---|
| DrawBackground=false | `grep "DrawBackground" src/PatentCore.cs` | = false（非 true） |
| 白底合成已添加 | `grep -c "g.Clear(Color.White)" src/PatentCore.cs` | ≥2（CaptureViewRender + ComposeRenderLayout） |
| DrawAt 白底预填充 | `grep -A2 "FillRectangle" src/PatentCore.cs` | Brushes.White 在 DrawImage 前 |
| Silhouette 图层 | `grep "Patent_Silhouette" src/PatentCore.cs` | 存在且在 BakeToRhinoGrouped 中 |
| Structure 图层 | `grep "Patent_Structure" src/PatentCore.cs` | 存在且在 BakeToRhinoGrouped 中 |
| JoinCurves 容差 | `grep "JoinCurves.*tolerance" src/PatentCore.cs` | 全部为 tolerance * 50（无裸 tolerance） |
| 角度容差 | `grep "0.15" src/PatentCore.cs` | 存在于 JoinTangentCurvesPrioritized 调用 |
| nearVertical | `grep "89.0" src/PatentCore.cs` | 存在于 GetMinTangentAngle |
| CleanRawCurves | `grep "tolerance \* 5" src/PatentCore.cs` | 搜索半径已放大 |
| IsOuter 回退 | `grep -A5 "nearBoundary" src/PatentCore.cs` | 几何特征回退判定代码存在 |

### 5.3 功能测试用例

| 用例 | 操作 | 预期结果 | 关联 AC |
|---|---|---|---|
| TC-1 | 单视图 Front 渲染 | 背景纯白 RGB(255,255,255) | AC-1~5 |
| TC-2 | 六视图渲染排版 | 子图间隙+子图非物件区域白色 | AC-4,6 |
| TC-3 | 执行 AutoMake2D 线框 | Patent_Silhouette 有数据（外轮廓） | AC-7,9 |
| TC-4 | 执行 AutoMake2D 线框 | Patent_Structure 有数据（内部线） | AC-8,9 |
| TC-5 | 封闭Brep模型线框 | IsOuter 回退判定生效 | AC-10 |
| TC-6 | 含对角轮廓模型线框 | 对角曲线段数 ≤3 | AC-11~16 |
| TC-7 | 编译 | 0 errors | AC-17 |

---

## 6. 里程碑划分

```
FM1 白色背景修复 (1h)
├── FM1-1: DrawBackground=false (0.05h)
├── FM1-2: 捕获后白底合成 (0.2h)
├── FM1-3: 单视图白底合成 (0.15h)
├── FM1-4: DrawAt 白底预填充 (0.05h)
├── FM1-5: 编译验证 (0.3h)
└── FM1-6: 代码审查 (0.15h)

FM2 Silhouette图层修复 (1.5h)
├── FM2-1: BakeToRhinoGrouped 重写 (0.3h)
├── FM2-2: IsOuter 几何特征回退 (0.5h)
├── FM2-3: 组件包围盒预扫描 (0.2h)
├── FM2-4: 编译验证 (0.3h)
└── FM2-5: 代码审查 (0.2h)

FM3 曲线连续性修复 (1h)
├── FM3-1: JoinCurves 容差×50 (0.1h)
├── FM3-2: 角度容差 0.15 (0.05h)
├── FM3-3: nearVertical 89° (0.05h)
├── FM3-4: CleanRawCurves 放宽 (0.2h)
├── FM3-5: 编译验证 (0.3h)
└── FM3-6: 代码审查 (0.15h)
```

**总预计耗时**: 3.5h  
**关键路径**: FM2-2（IsOuter 几何回退判定）— 几何特征回退算法需要仔细实现和测试

---

## 7. 开发注意事项

1. **FM1 与 FM2/FM3 无依赖**：白色背景修复独立于图层和曲线修复，可先行实施和验证
2. **FM2 依赖 IsOuter 标记**：如果 FM2-2（几何回退）未生效，BakeToRhinoGrouped 的分发将无法区分外轮廓，需确保回退算法可靠
3. **FM3 容差放宽容差值**：tolerance*50 在 tolerance=0.001 时为 0.05，覆盖 HLD 浮点偏差；如 tolerance 本身较大(如0.01)，则 tolerance*50=0.5 可能过宽，需确认用户 tolerance 范围
4. **JoinTangentCurvesPrioritized 内部容差**：第466行调用传入 `tolerance * 50`，该方法内部又调用 `JoinTangentCurvesPrioritized_Original`，后者内部的 `Curve.JoinCurves` 也需使用放大后的容差（通过参数传递）
5. **白底合成内存管理**：原始 captured 位图在合成后必须 Dispose，避免内存泄漏
6. **BakeToRhinoGrouped 旧图层兼容**：不再创建 TangentEdges 和 Patent_Drawings_2D，但不清除已有图层（避免破坏用户旧文件）
7. **编译前清理**：`rm -rf src/bin src/obj` 避免历史构建产物干扰

---

*第八轮修复执行计划书结束 — 待审核确认后进入开发阶段*
