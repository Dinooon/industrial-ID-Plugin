# AutoMake2D 4.0 + CreoToRhino 2.0 联合升级目标计划书

> **文档版本**: v1.0  
> **编制日期**: 2026-07-17  
> **编制人**: Beta AI Agent  
> **审阅人**: Jie.Dong  

---

## 一、升级背景与动机

### 1.1 当前产品现状

| 产品 | 版本 | 定位 | 技术栈 |
|------|------|------|--------|
| **AutoMake2D** | 3.0 (V8 最终修复版) | Rhino 专利图纸自动生成插件 | C# / .NET Framework 4.8 / RhinoCommon 7.35 / Eto.Forms |
| **CreoToRhino LiveLink** | 1.0 | Creo 5.0 → Rhino 实时模型直传插件 | C++ (Creo端) / C# (Rhino端) / Named Pipe IPC / openNURBS |

### 1.2 核心痛点

1. **两套插件割裂运行**：用户需先在 Creo 中手动发送模型到 Rhino，再在 Rhino 中手动启动 AutoMake2D 生成专利图，工作流存在明显断裂
2. **AutoMake2D 仅支持手动框选**：无法接收来自 CreoToRhino 的自动导入事件，缺少端到端的自动化链路
3. **RhinoCommon 版本不统一**：AutoMake2D 使用 RhinoCommon 7.35，CreoToRhino Rhino端使用 RhinoCommon 8.0，混装时存在兼容性风险
4. **缺少一键专利图工作流**：Creo 工程师期望"Creo 中一键点击 → 自动出专利图"，当前无法实现
5. **AutoMake2D UI 功能有限**：缺少批量处理、图纸导出格式选择（DWG/PDF）、图纸模板等功能
6. **CreoToRhino 几何转换精度有待提升**：复杂曲面（如 Swept、自交曲面）转换偶尔出现拓扑丢失

### 1.3 升级愿景

**构建"Creo → Rhino → 专利图纸"端到端自动化工作流**，实现从 Creo 一键出发，自动完成模型传输、视图投影、线框生成、渲染输出、图纸排版的完整链路，将专利工程师的出图效率提升 80% 以上。

---

## 二、升级总体目标

| 维度 | 目标 |
|------|------|
| **功能整合** | AutoMake2D 与 CreoToRhino 深度集成，支持 Creo 端一键触发专利图生成 |
| **版本统一** | 统一升级至 RhinoCommon 8.x，同时兼容 Rhino 7 SR35+ |
| **架构升级** | 重构为模块化插件架构，支持独立使用与联合使用两种模式 |
| **功能增强** | 新增 DWG/PDF 导出、批量处理、图纸模板、视图标注等功能 |
| **性能优化** | 大型装配体处理速度提升 50%，渲染输出并行化 |
| **质量保障** | 建立自动化测试框架，覆盖核心几何转换与投影逻辑 |

---

## 三、当前架构分析

### 3.1 AutoMake2D 3.0 架构

```
┌── AutoMake2D.rhp ──────────────────────────────────────────┐
│                                                            │
│  AutoMake2DPlugin.cs (74行)                                │
│    └─ OnLoad → 注册面板 → Idle 延迟弹窗                     │
│                                                            │
│  AutoMake2DCommand.cs (28行)                               │
│    └─ "AutoMake2D" 命令 → 打开/关闭面板                     │
│                                                            │
│  PatentUiPanel.cs (214行)                                  │
│    └─ Eto.Forms 面板                                       │
│       ├─ 精度选择 (高/中/低)                                │
│       ├─ 视图模式勾选 (六视图/轴测前/轴测后/当前视角)         │
│       ├─ 渲染输出开关 + 路径                                │
│       └─ 生成按钮 → 调用 PatentCore.ExecuteAsync()          │
│                                                            │
│  PatentCore.cs (1355行)                                    │
│    ├─ ExecuteAsync() — 主流程入口                           │
│    ├─ GetViewPlane() / GetIsoPlane() — 视图平面计算          │
│    ├─ HiddenLineDrawing 投影 — 隐线计算引擎                  │
│    ├─ 三阶段融合策略 (正常线→相切线→全局贪心)                │
│    ├─ CleanRawCurves() — 碎线清洗                           │
│    ├─ 凸包边界几何回退 — IsOuter 判定                       │
│    ├─ 图层分发 (Patent_Silhouette / Patent_Structure)       │
│    ├─ CaptureViewRender() — 渲染捕获                        │
│    ├─ ComposeRenderLayout() — 渲染排版合成                  │
│    └─ PictureFrame 嵌入                                    │
│                                                            │
│  依赖: RhinoCommon 7.35 / RhinoWindows 7.35 / net48        │
└────────────────────────────────────────────────────────────┘
```

**关键特征**：
- 单一插件，所有逻辑集中在 PatentCore.cs (1355行)
- 用户必须手动框选模型才能工作
- 无外部事件接收能力（不监听 Pipe / 不接收消息）
- 渲染输出仅支持 PNG 格式
- 无图纸导出功能（DWG / PDF）
- 无批量处理能力

### 3.2 CreoToRhino LiveLink 1.0 架构

```
┌── Creo 端 (CreoToRhino.dll) ──────────────────────────────┐
│                                                            │
│  CreoToRhinoPlugin.cpp — Ribbon 注册 + 按钮回调             │
│  ConfigManager.h/cpp — config.json 读写                    │
│  ConfigDialog.h/cpp — Win32 动态对话框 (5分区配置)          │
│  GeometryConverter.h/cpp — Creo→openNURBS 几何转换          │
│  IPCManager.h/cpp — Named Pipe Client + Rhino 进程管理     │
│  Logger.h/cpp — 日志系统                                   │
│                                                            │
│  依赖: Creo Toolkit 5.0 / openNURBS SDK / nlohmann/json    │
└────────────────────────┬───────────────────────────────────┘
                         │ Named Pipe: \\.\pipe\CreoToRhino
                         │ (JSON 消息模式)
┌────────────────────────┴───────────────────────────────────┐
│  Rhino 端 (CreoReceiver.rhp)                               │
│                                                            │
│  CreoReceiverPlugin.cs — OnLoad 启动 PipeServer             │
│  PipeServer.cs — 后台线程监听 Named Pipe                    │
│  ImportHandler.cs — UI线程调度 doc.Import() + 图层/视图     │
│  Models.cs — JSON 消息序列化/反序列化                       │
│  Logger.cs — 日志系统                                      │
│                                                            │
│  依赖: RhinoCommon 8.0 / net48                             │
└────────────────────────────────────────────────────────────┘
```

**关键特征**：
- 双端插件，Creo端 C++ + Rhino端 C#
- Named Pipe 双向通信，JSON 消息格式
- 支持三种导出模式：精确(3DM) / 快速(STEP) / 网格
- Rhino 端仅做导入，不做任何后续处理（无投影/线框/渲染）
- 无法触发 AutoMake2D 的专利图生成流程

### 3.3 两套插件的断裂点

```
Creo ──[CreoToRhino]──→ Rhino(导入模型) ──✕──→ AutoMake2D(手动框选+生成)
                                         ↑
                                    断裂点：无自动衔接
```

| 断裂点 | 描述 |
|--------|------|
| **事件断裂** | CreoToRhino 导入模型后，AutoMake2D 无感知，需用户手动启动 |
| **数据断裂** | CreoToRhino 导入的对象属性（零件名、层级）未传递给 AutoMake2D |
| **版本断裂** | RhinoCommon 7.35 vs 8.0，同时安装可能冲突 |
| **UI断裂** | 两个插件各自独立面板，用户体验割裂 |

---

## 四、升级目标详细分解

### 4.1 核心目标 1：端到端自动化链路

**目标描述**：在 Creo 中点击"发送并生成专利图"按钮后，自动完成模型传输 → Rhino 导入 → AutoMake2D 投影 → 线框生成 → 渲染输出 → 图纸排版的全流程。

**实现方案**：

1. **扩展 Named Pipe 消息协议**，新增 `action: "importAndMake2D"` 消息类型
2. **CreoToRhino Rhino端** 接收该消息后，先执行 `doc.Import()`，再调用 `PatentCore.ExecuteAsync()`
3. **AutoMake2D PatentCore** 新增 `ExecuteFromImport()` 入口，接收已导入的对象引用，跳过手动框选步骤
4. **Creo 端配置面板** 新增"自动生成专利图"选项及参数配置区

**消息协议扩展**：

```json
{
    "action": "importAndMake2D",
    "filePath": "C:\\Users\\xxx\\AppData\\Local\\Temp\\creo_xxx.3dm",
    "config": {
        "createLayer": true,
        "layerName": "Creo_MyPart_143052",
        "autoZoom": true,
        "clearScene": true,
        "hideExisting": false,
        "unitMode": "original",
        "importMode": "3dm",
        "make2D": {
            "enabled": true,
            "tolerance": 0.01,
            "views": ["six", "isoFront", "isoBack"],
            "render": true,
            "renderPath": "%DESKTOP%\\AutoMake2D_Render.png",
            "exportDwg": true,
            "dwgPath": "%DESKTOP%\\AutoMake2D_Output.dwg"
        }
    }
}
```

**验收标准**：
- Creo 中一键操作，10秒内（中小型模型）完成全部流程
- 无需在 Rhino 中进行任何手动操作
- 生成结果与手动操作完全一致

---

### 4.2 核心目标 2：RhinoCommon 版本统一与兼容性

**目标描述**：统一升级至 RhinoCommon 8.x，同时保持对 Rhino 7 SR35+ 的向后兼容。

**实现方案**：

1. AutoMake2D 的 `.csproj` 升级 RhinoCommon 从 `7.35` → `8.x`
2. 使用条件编译处理 Rhino 7/8 API 差异（如 `HiddenLineDrawing` 在 Rhino 8 中的行为变化）
3. CreoToRhino Rhino端保持 RhinoCommon 8.x
4. 统一 .NET 目标框架为 `net48`（两套插件一致）
5. 编译时使用 `RhinoCommon 8.x` 包，运行时通过反射检测 Rhino 版本，动态适配

**兼容性矩阵**：

| Rhino 版本 | AutoMake2D 4.0 | CreoToRhino 2.0 | 联合模式 |
|------------|----------------|------------------|----------|
| Rhino 7 SR35+ | ✅ 兼容 | ✅ 兼容 | ✅ 兼容 |
| Rhino 8 (最新) | ✅ 原生 | ✅ 原生 | ✅ 原生 |
| Rhino 7 SR34- | ❌ 不支持 | ❌ 不支持 | ❌ 不支持 |

**验收标准**：
- 在 Rhino 7 和 Rhino 8 上均可正常安装和运行
- 无 API 兼容性警告或运行时异常
- 两套插件同时安装无冲突

---

### 4.3 核心目标 3：AutoMake2D 功能增强

**目标描述**：在现有线框+渲染基础上，新增图纸导出、批量处理、视图标注等功能。

#### 4.3.1 图纸导出功能

| 导出格式 | 说明 | 优先级 |
|----------|------|--------|
| **DWG/DXF** | 导出为 AutoCAD 兼容格式，含图层信息 | P0 (必须) |
| **PDF** | 矢量 PDF，含线框图 + 渲染图排版 | P0 (必须) |
| **PNG (增强)** | 支持 DPI 设置、尺寸自定义 | P1 (重要) |
| **SVG** | 矢量图形，便于网页展示 | P2 (可选) |

**实现要点**：
- DWG 导出使用 RhinoCommon 的 `Rhino.FileIO.WriteDwg()` 或 `doc.Export()` 
- PDF 导出使用 `Rhino.FileIO.WritePdf()` 或 iTextSharp 库
- 导出时保留 `Patent_Silhouette` / `Patent_Structure` 图层分类

#### 4.3.2 批量处理功能

**场景**：一次性框选多个零件，自动为每个零件独立生成全套专利图。

**实现要点**：
- PatentCore 新增 `ExecuteBatchAsync()` 方法
- 按零件名称分组，每组独立执行投影→融合→烘焙流程
- 每个零件生成独立的图层组：`Patent_Silhouette_{零件名}` / `Patent_Structure_{零件名}`
- 支持每个零件独立导出 DWG/PDF 文件
- 进度反馈按零件维度报告

#### 4.3.3 视图标注功能

| 标注项 | 说明 | 优先级 |
|--------|------|--------|
| **视图名称标注** | 前视图/后视图/俯视图等 | P0 |
| **比例标注** | 如 1:2, 1:5 | P1 |
| **尺寸标注** | 关键尺寸自动标注（长宽高） | P2 |
| **图框** | 标准专利图纸图框 (A4/A3) | P1 |

#### 4.3.4 UI 面板升级

**新增 UI 元素**：

```
┌─ AutoMake2D 4.0 面板 ──────────────────────────┐
│                                                  │
│  📐 精度选择:  ○高 ○中 ○低                      │
│                                                  │
│  🖼 视图选择:  ☑六视图 ☑轴测前 ☑轴测后 ☐当前    │
│                                                  │
│  📤 图纸导出:  ☑DWG  ☑PDF  ☐SVG                │
│  导出路径: [____________________________] [浏览] │
│                                                  │
│  🔄 渲染输出:  ☐渲染  路径: [_________] [浏览]  │
│                                                  │
│  📦 批量模式:  ☐按零件独立分组生成               │
│                                                  │
│  🏷 视图标注:  ☑视图名称 ☐比例 ☐图框            │
│                                                  │
│  🔗 Creo联动:  ☐接收Creo自动导入并生成          │
│                                                  │
│  [        生成专利图        ]                    │
│                                                  │
│  ▓▓▓▓▓▓▓▓▓▓░░░░░ 65%  正在生成俯视图...         │
└──────────────────────────────────────────────────┘
```

---

### 4.4 核心目标 4：CreoToRhino 功能增强

#### 4.4.1 配置面板扩展

新增"专利图设置"分区：

| 配置项 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| autoMake2D | bool | true | 导入后自动生成专利图 |
| make2dTolerance | enum | medium | 精度: high/medium/low |
| make2DViews | multiselect | [six, isoFront] | 视图模式 |
| make2DRender | bool | true | 是否渲染输出 |
| make2DExportDwg | bool | true | 是否导出 DWG |
| make2DExportPdf | bool | true | 是否导出 PDF |
| make2DOutputDir | string | (桌面) | 输出目录 |

#### 4.4.2 几何转换精度提升

| 改进项 | 说明 |
|--------|------|
| **扫掠曲面增强** | 增加对自交扫掠曲面的分面处理，避免拓扑丢失 |
| **缝合容差优化** | 引入自适应缝合容差，根据模型尺寸自动调整 |
| **装配体层级保留** | 改进装配体导出，保留组件层级为 Rhino 图层结构 |
| **基准特征转换** | 增加基准面、基准轴的转换支持（映射为 Rhino 构造平面） |

#### 4.4.3 错误恢复机制

- 导入失败时自动重试（切换导出模式：精确 → STEP → 网格）
- 详细的错误日志与用户可读的错误提示
- 临时文件清理保障（异常退出后下次启动自动清理）

---

### 4.5 核心目标 5：架构重构与代码质量

#### 4.5.1 模块化重构

将 AutoMake2D 的 PatentCore.cs (1355行) 拆分为独立模块：

```
PatentCore/                        (新目录结构)
├── PatentProjector.cs             — 视图投影 + HLD 隐线计算
├── CurveFusionEngine.cs           — 三阶段融合 + 碎线清洗
├── LayerDispatcher.cs             — 图层分发 + IsOuter 判定
├── RenderCaptureEngine.cs         — 渲染捕获 + 白底合成
├── LayoutComposer.cs              — 排版引擎 (工程排版 + 通用排版)
├── ExportManager.cs               — DWG/PDF/PNG 导出 (新增)
├── BatchProcessor.cs              — 批量处理 (新增)
├── AnnotationEngine.cs            — 视图标注 (新增)
├── EventReceiver.cs               — CreoToRhino 事件接收 (新增)
└── PatentCore.cs                  — 门面类，编排上述模块
```

#### 4.5.2 插件合并方案（推荐）

**方案 A：双插件共存（低风险）**
- AutoMake2D 和 CreoToRhino 保持各自独立的 `.rhp` 文件
- 通过 Named Pipe 事件通信（已有基础）
- AutoMake2D 新增 Pipe 监听线程，接收 CreoToRhino 的 `importAndMake2D` 消息
- 优点：改动最小，风险低
- 缺点：用户需安装两个插件

**方案 B：合并为单一插件（推荐）**
- 将 CreoToRhino Rhino端代码合并到 AutoMake2D 插件中
- 统一为一个 `.rhp` 文件，包含完整功能链
- AutoMake2D 内部直接调用 PatentCore，无需跨进程通信
- 优点：用户体验最佳，一键安装
- 缺点：代码合并工作量较大

**建议采用方案 B**，因为：
1. 消除双插件安装的复杂性
2. 消除 Named Pipe 通信的开销和潜在故障点
3. CreoToRhino Rhino端代码量不大（5个文件），合并成本低
4. 统一版本管理，避免兼容性问题

合并后的插件结构：

```
AutoMake2D 4.0 (单一 .rhp)
├── AutoMake2DPlugin.cs           — 插件入口 (合并 CreoReceiverPlugin)
├── AutoMake2DCommand.cs          — 命令定义
├── PatentUiPanel.cs              — UI 面板 (增强版)
├── PatentCore/                   — 核心引擎 (模块化)
│   ├── PatentProjector.cs
│   ├── CurveFusionEngine.cs
│   ├── LayerDispatcher.cs
│   ├── RenderCaptureEngine.cs
│   ├── LayoutComposer.cs
│   ├── ExportManager.cs          — 新增
│   ├── BatchProcessor.cs         — 新增
│   ├── AnnotationEngine.cs       — 新增
│   └── PatentCore.cs             — 门面类
├── CreoLink/                     — Creo 联动模块 (从 CreoToRhino 合并)
│   ├── PipeServer.cs             — Named Pipe 服务端
│   ├── ImportHandler.cs          — 导入处理
│   ├── CreoMessageModels.cs      — 消息模型
│   └── CreoLinkManager.cs        — 联动编排 (导入→生成专利图)
├── Common/
│   ├── Logger.cs                 — 统一日志
│   └── ConfigManager.cs          — 统一配置管理
└── AutoMake2D.csproj             — 项目配置
```

---

## 五、升级实施路线图

### Phase 1：版本统一与基础重构（预计 2 周）

| 任务 | 说明 | 产出 |
|------|------|------|
| RhinoCommon 版本升级 | AutoMake2D 从 7.35 升至 8.x，验证 API 兼容性 | 更新后的 .csproj |
| PatentCore 模块化拆分 | 将 1355 行 PatentCore.cs 拆分为 6 个独立模块 | 模块化源码 |
| 统一日志系统 | 合并两个插件的 Logger 为统一实现 | Common/Logger.cs |
| 统一配置管理 | 合并两个插件的配置体系 | Common/ConfigManager.cs |

### Phase 2：插件合并与端到端链路（预计 3 周）

| 任务 | 说明 | 产出 |
|------|------|------|
| CreoToRhino Rhino端代码合并 | 将 PipeServer/ImportHandler/Models 合并到 AutoMake2D | 合并后源码 |
| Named Pipe 消息协议扩展 | 新增 `importAndMake2D` 消息类型 | 协议文档 + 代码 |
| EventReceiver 模块 | 监听 Pipe 消息，触发自动生成流程 | CreoLink/ 模块 |
| PatentCore 新增 ExecuteFromImport() | 跳过手动框选，直接处理已导入对象 | 代码更新 |
| 端到端联调 | Creo → Rhino → 专利图 全流程测试 | 测试报告 |

### Phase 3：功能增强（预计 3 周）

| 任务 | 说明 | 产出 |
|------|------|------|
| DWG/PDF 导出 | ExportManager 模块实现 | 导出功能代码 |
| 批量处理 | BatchProcessor 模块实现 | 批量功能代码 |
| 视图标注 | AnnotationEngine 模块实现 | 标注功能代码 |
| UI 面板升级 | 新增导出/批量/标注/Creo联动控件 | 更新后的 PatentUiPanel.cs |
| Creo 端配置面板扩展 | 新增"专利图设置"分区 | 更新后的 ConfigDialog.cpp |

### Phase 4：质量保障与发布（预计 2 周）

| 任务 | 说明 | 产出 |
|------|------|------|
| 自动化测试框架 | 针对 PatentProjector / CurveFusionEngine 等模块的单元测试 | 测试项目 |
| 几何转换精度提升 | 扫掠曲面增强、缝合容差优化 | 更新后的 GeometryConverter.cpp |
| 错误恢复机制 | 导入失败重试、临时文件清理 | 代码更新 |
| 文档更新 | README / DEVELOPER / 用户手册 | 文档 |
| 最终发布 | 编译 Release 版本，打包交付 | AutoMake2D 4.0.rhp |

---

## 六、技术风险与应对

| 风险 | 影响 | 概率 | 应对措施 |
|------|------|------|----------|
| RhinoCommon 7→8 API 变更导致编译错误 | 高 | 中 | 提前进行 API 差异分析，使用条件编译处理差异 |
| HiddenLineDrawing 在 Rhino 8 中行为变化 | 高 | 中 | 对比测试 Rhino 7/8 的 HLD 输出，必要时做版本适配 |
| 插件合并后 Named Pipe 监听与 Rhino UI 线程冲突 | 中 | 中 | 确保所有 doc 操作通过 `InvokeOnUiThread` 调度 |
| DWG 导出格式与专利局要求不兼容 | 中 | 低 | 提前调研专利局 DWG 格式要求，使用 Rhino 原生导出 |
| Creo Toolkit 版本升级（Creo 6/7+） | 中 | 低 | 保持 Creo 5.0 兼容，后续版本按需适配 |
| 大型装配体性能瓶颈 | 中 | 高 | 实现并行投影计算，引入进度取消机制 |

---

## 七、验收标准总览

### 7.1 功能验收

| 编号 | 验收项 | 验收标准 |
|------|--------|----------|
| F-01 | 端到端自动化 | Creo 一键操作，自动完成导入→投影→线框→渲染→导出 |
| F-02 | Rhino 7/8 兼容 | 两版本均正常安装运行，无兼容性警告 |
| F-03 | DWG 导出 | 导出的 DWG 文件含 Patent_Silhouette / Patent_Structure 图层 |
| F-04 | PDF 导出 | 导出的 PDF 含线框图 + 渲染图，矢量质量 |
| F-05 | 批量处理 | 多零件独立分组生成，每个零件有独立图层和文件 |
| F-06 | 视图标注 | 各视图标注名称（前视图/俯视图等） |
| F-07 | Creo 配置面板 | 新增"专利图设置"分区，参数可配置可持久化 |
| F-08 | 手动模式保留 | 不使用 Creo 时，AutoMake2D 可独立使用，功能不退化 |

### 7.2 性能验收

| 编号 | 验收项 | 验收标准 |
|------|--------|----------|
| P-01 | 中小型模型（<100零件）端到端 | < 30秒完成全流程 |
| P-02 | 大型装配体（>500零件）端到端 | < 5分钟完成全流程 |
| P-03 | 渲染输出 | 单视图渲染 < 10秒 |
| P-04 | DWG 导出 | < 5秒（中小型模型） |

### 7.3 质量验收

| 编号 | 验收项 | 验收标准 |
|------|--------|----------|
| Q-01 | 单元测试覆盖率 | 核心模块 ≥ 60% |
| Q-02 | 无 P0/P1 级 Bug | 发布前零严重缺陷 |
| Q-03 | 日志完整 | 全链路有日志记录，可追溯问题 |
| Q-04 | 错误恢复 | 导入失败自动重试，不崩溃 |

---

## 八、交付物清单

| 交付物 | 路径 | 说明 |
|--------|------|------|
| AutoMake2D 4.0 插件 | `bin/Release/net48/AutoMake2D.rhp` | 合并后的完整插件 |
| CreoToRhino 2.0 Creo端 | `CreoPlugin/bin/Release/CreoToRhino.dll` | 升级后的 Creo 端插件 |
| 源码仓库 | — | 模块化重构后的完整源码 |
| README.md | — | 更新后的说明文档 |
| DEVELOPER.md | — | 更新后的开发者文档 |
| 用户手册 | — | 含端到端工作流使用指南 |
| 测试报告 | — | 功能/性能/兼容性测试报告 |
| 本计划书 | `upgrade-plan-v4.0.md` | 本文档 |

---

## 九、时间节点

| 里程碑 | 预计完成时间 | 交付物 |
|--------|-------------|--------|
| M1: 版本统一 + 模块化重构 | 第 2 周末 | 可编译的模块化代码 |
| M2: 插件合并 + 端到端链路 | 第 5 周末 | 可运行的端到端流程 |
| M3: 功能增强完成 | 第 8 周末 | 含全部新功能的版本 |
| M4: 测试 + 发布 | 第 10 周末 | 最终发布版本 |

**总工期：预计 10 周（2.5 个月）**

---

## 十、待审阅决策点

请审阅以下关键决策点，并给出您的意见：

| 编号 | 决策点 | 选项 | 建议 |
|------|--------|------|------|
| D-01 | 插件合并方案 | A: 双插件共存 / B: 合并为单一插件 | **建议 B** |
| D-02 | RhinoCommon 版本 | 7.35 保持 / 8.x 升级 / 双版本条件编译 | **建议 8.x + 条件编译** |
| D-03 | DWG 导出方式 | Rhino 原生导出 / 第三方库 (ACadSharp) | **建议 Rhino 原生** |
| D-04 | PDF 导出方式 | Rhino 原生 / iTextSharp / PdfSharp | **建议 Rhino 原生** |
| D-05 | Creo 版本兼容范围 | 仅 Creo 5.0 / Creo 5.0-7.0 / Creo 5.0+ | **建议仅 5.0（后续按需扩展）** |
| D-06 | 批量处理默认行为 | 默认开启 / 默认关闭 | **建议默认关闭** |
| D-07 | 视图标注默认行为 | 默认开启视图名称 / 默认关闭 | **建议默认开启视图名称** |
| D-08 | Phase 优先级 | 是否调整 Phase 顺序 | **建议按当前顺序** |

---

*AutoMake2D 4.0 + CreoToRhino 2.0 — 从 Creo 到专利图，一键贯通。*
