# AutoMake2D 2.0 插件分析报告

> 分析日期: 2026-07-09
> 分析对象: `AutoMake2D_2.0.zip`
> 分析方法: 解压后逐文件深度阅读全部源码 (4 个 C# 源文件 + 项目配置 + 构建产物)

---

## 1. 插件类型

**Rhino 3D 插件**（McNeel Rhinoceros），基于 **RhinoCommon / RhinoWindows** SDK 开发。

判定依据：
- `.csproj` 中 `TargetExt` 设为 `.rhp` —— 这是 Rhino 插件的标准编译输出扩展名
- 引用 NuGet 包 `RhinoCommon` 和 `RhinoWindows`（版本 7.35.23346.11001，对应 Rhino 7 SR35）
- 源码中大量使用 `Rhino.PlugIns.PlugIn`、`Rhino.Commands.Command`、`Rhino.UI.Panels` 等 Rhino SDK 类型
- 编译产物为 `.rhp` 文件（Rhino Plugin），而非 Unity 的 `.dll`/`.meta` 或 UE 的 `.uplugin`

---

## 2. 用途概述

AutoMake2D 是一款**专利图纸自动生成插件**，用于将 Rhino 中的 3D 模型自动投影为符合工程制图规范（"长对正、高平齐"）的**2D 线框图**，特别针对**专利申请图纸**的需求设计。

核心能力：
- 从 3D 模型自动提取零部件的二维投影线框
- 按零件名称分组，支持多零件独立分层
- 生成标准工程六视图 + 轴测图 + 当前视角图
- 自动工程排版（防重叠矩阵布局）
- 外轮廓优先融合 + 碎线清洗，产出干净的专利级线稿

---

## 3. 版本信息

| 属性 | 值 |
|---|---|
| 包名 | AutoMake2D_2.0 |
| 程序集版本 | 1.0.0.0 |
| 文件版本 | 1.0.0.0 |
| 信息版本 | 1.0.0 |
| 插件包标记版本 | 2.0（zip 文件名） |
| Rhino SDK 版本 | Rhino 7 SR35 (7.35.23346.11001) |

---

## 4. 技术栈

| 层面 | 技术 |
|---|---|
| 语言 | C# (LangVersion: latest) |
| 框架 | .NET Framework 4.8 (net48) — 主目标 |
| 编译实验 | 同时存在 net7.0-windows / net8.0-windows / net10.0 的 obj 产物（开发者尝试多版本编译） |
| 宿主 SDK | RhinoCommon 7.35 + RhinoWindows 7.35 |
| UI 框架 | Eto.Forms（跨平台 UI 框架，Rhino 原生支持） |
| 几何引擎 | Rhino.Geometry（HiddenLineDrawing 隐线计算引擎） |
| 构建系统 | MSBuild / .NET SDK 风格 .csproj |
| IDE | Visual Studio（存在 `.vs/` 目录及 slnx 解决方案文件） |

---

## 5. 依赖项

### NuGet 包

| 包名 | 版本 | IncludeAssets | 用途 |
|---|---|---|---|
| `RhinoCommon` | 7.35.23346.11001 | compile; build | Rhino 核心 API（几何、命令、文档） |
| `RhinoWindows` | 7.35.23346.11001 | (默认) | Rhino Windows 平台 API（UI 面板注册等） |

### 嵌入资源

| 文件 | 用途 |
|---|---|
| `icon1.ico` | 插件面板图标（24×24, 32bit），作为 EmbeddedResource 编入程序集 |

> 无其他第三方依赖。所有 UI 通过 Eto.Forms（随 RhinoWindows 提供）实现，未引入 WinForms / WPF。

---

## 6. 目录结构

```
AutoMake2D_2.0/
├── AutoMake2D.slnx                  # Visual Studio 解决方案（新版 slnx 格式）
├── AutoMake2D.csproj                # 项目文件（定义 .rhp 输出 + Rhino 依赖）
├── AutoMake2DPlugin.cs              # 插件入口：注册面板、自动弹窗   (74 行)
├── AutoMake2DCommand.cs             # Rhino 命令：AutoMake2D 开关面板  (28 行)
├── PatentUiPanel.cs                 # UI 面板：参数配置 + 进度显示    (150 行)
├── PatentCore.cs                    # 核心引擎：投影/清洗/排版/烘焙   (526 行)
├── icon1.ico                        # 面板图标（嵌入资源）
├── Creative Logo Design Tools for Every Vision.png  # 图标设计源文件
├── .vs/                             # Visual Studio IDE 缓存（非源码）
├── bin/Debug/                       # 编译输出（net48/net7/net8/net10 多版本）
│   └── net48/AutoMake2D_2.0.rhp     # 最终插件包
└── obj/                             # 中间编译产物
```

**核心源码仅 4 个文件，共 ~778 行 C# 代码。**

---

## 7. 核心源码深度分析

### 7.1 AutoMake2DPlugin.cs — 插件入口

```
继承链: PlugIn (Rhino.PlugIns) → AutoMake2DPlugin
```

**职责**：
1. **单例管理**：`Instance` 静态属性持有插件唯一实例
2. **图标加载**：`OnLoad` 时从嵌入资源 `AutoMake2D.icon1.ico` 读取并构造 `System.Drawing.Icon`
3. **面板注册**：调用 `Panels.RegisterPanel()` 注册 `PatentUiPanel`，面板标题为 `"AutoMake2D_DJ"`
4. **自动弹窗**：订阅 `RhinoApp.Idle` 事件，在 Rhino 首次空闲时自动打开面板（一次性触发，触发后立即取消订阅）
5. **错误兜底**：加载失败时返回 `LoadReturnCode.ErrorShowDialog` 并弹出错误信息

**关键设计**：
- 使用 `Guid("1F4B3C5D-...")` 作为程序集级别插件标识
- 图标资源路径格式：`{命名空间}.{文件名}` → `AutoMake2D.icon1.ico`

### 7.2 AutoMake2DCommand.cs — 命令

```
继承链: Command (Rhino.Commands) → AutoMake2DCommand
```

**职责**：
- 注册 Rhino 命令 `AutoMake2D`（EnglishName）
- 执行时切换面板可见性：已开则关，已关则开（toggle 行为）
- 提供命令行唤醒入口，无需通过菜单点击

### 7.3 PatentUiPanel.cs — 用户界面

```
继承链: Panel (Eto.Forms) + IPanel (Rhino.UI) → PatentUiPanel
```

**UI 组成**（Eto.Forms DynamicLayout）：

| 区域 | 控件 | 说明 |
|---|---|---|
| 信息提示 | Label | "请配置参数后点击下方按钮生成图纸" |
| 警告 | Label (橙色) | 提示不要带内部不可见零件，否则计算很慢 |
| 精度选择 | 3× RadioButton（互斥组） | 高(0.001) / 中(0.01，默认) / 低(0.1) |
| 视角选择 | 4× CheckBox（多选） | 六视图 / 前45°轴测 / 后45°轴测 / 当前视角 |
| 操作 | Button | "生成专利图" |
| 反馈 | ProgressBar + Label | 进度条 + 状态文本（默认隐藏） |

**默认勾选**：六视图 + 前45°轴测图 + 后45°轴测图

**交互流程**：
1. 用户勾选视角、选择精度
2. 点击"生成专利图"→ 校验至少勾选一个视角
3. 禁用按钮、显示进度条 → 调用 `PatentCore.ExecuteAsync()`（异步）
4. `Progress<int>` 回调更新进度条，`Progress<string>` 回调更新状态文本
5. 完成或异常后恢复按钮、隐藏进度条

**关键设计**：
- 顶部使用 `using` 别名锁定所有 Eto 类型（`Panel`, `Label`, `Button` 等），注释说明目的是"彻底物理屏蔽 System.Windows.Forms 的命名空间污染"
- `PanelId` 通过 `typeof(PatentUiPanel).GUID` 获取，确保唯一性

### 7.4 PatentCore.cs — 核心引擎（526 行，插件大脑）

这是整个插件最核心的文件，包含全部业务逻辑。以下逐方法分析：

#### 7.4.1 `ExecuteAsync()` — 主流程入口

**签名**：
```csharp
async Task ExecuteAsync(bool wantSix, bool wantIsoFront, bool wantIsoBack, 
                        bool wantCurrent, double tolerance, 
                        IProgress<int> progress, IProgress<string> status)
```

**流程**：
1. **模型选择**：`RhinoGet.GetMultipleObjects()` 让用户框选模型（支持 Surface / Polysurface / Mesh）
2. **几何提取**：遍历选中对象，提取 `GeometryBase` 列表 + 零件名称列表 + 全局包围盒
   - 无名称的零件自动命名为 `零件_N`
3. **视图平面构建**：根据用户选择，构建投影平面字典
4. **异步计算**：`Task.Run()` 后台遍历所有视图平面，逐个调用 `ComputeSingleViewEngine()`
   - 带 ETA 估算：根据已完成视图的平均耗时推算剩余时间
5. **排版**：`ArrangeEngineeringViewsGrouped()`
6. **烘焙**：`BakeToRhinoGrouped()` 将结果写入 Rhino 文档
7. **重绘**：`doc.Views.Redraw()`

#### 7.4.2 `GetViewPlane()` — 标准视图平面定义

根据视图名称返回投影平面（以模型中心为原点）：

| 视图 | 平面 X 轴 | 平面 Y 轴 |
|---|---|---|
| Top（俯视图） | +X | +Y |
| Bottom（仰视图） | -X | +Y |
| Front（正视图） | +X | +Z |
| Back（后视图） | -X | +Z |
| Left（左视图） | -Y | +Z |
| Right（右视图） | +Y | +Z |

#### 7.4.3 `GetIsoPlane()` — 轴测图平面

- 前45°轴测：法向量 `(1, -1, 1)` → 通过叉积构造正交平面
- 后45°轴测：法向量 `(-1, 1, -1)`（朝下）或 `(-1, 1, 1)`

#### 7.4.4 `ComputeSingleViewEngine()` — 单视图投影核心

这是**最复杂的方法**，完整流程：

1. **坐标变换**：`Transform.PlaneToPlane(viewPlane, WorldXY)` 将模型从视图平面变换到世界 XY 平面
2. **隐线计算**：
   - 构建 `HiddenLineDrawingParameters`：
     - `AbsoluteTolerance` = 用户选择的精度
     - `IncludeHiddenCurves = false`（不画隐藏线）
     - `IncludeTangentEdges = true`（含相切边）
   - 将每个几何体连同零件名（`Tag`）加入参数
   - 创建 `RhinoViewport`：平行投影 + 相机置于模型上方 Z+1000
   - 调用 `HiddenLineDrawing.Compute()` 执行隐线消隐计算
3. **可见段提取**：遍历 `hld.Segments`，仅保留 `SegmentVisibility == Visible` 的段
4. **零件归属识别**：通过 `seg.ParentCurve.SourceObject.Tag` 获取零件名
5. **外轮廓标记**：
   - 检测 `SilhouetteType.Projecting` 或 `SilhouetteType.Boundary`
   - 命中则用 `SetUserString("IsOuter", "true")` 打上"基因烙印"
6. **清洗与融合**（三步管线）：
   - **Step 1 — `CleanRawCurves()`**：RTree 空间索引去重 + 微小碎线过滤（长度 < 0.0001）
   - **Step 1.5 — 外轮廓特权隔离**：按 `IsOuter` 分流，外轮廓独立 `JoinCurves()` 闭环，防止内部线抢夺端点
   - **Step 2 — `JoinTangentCurvesPrioritized()`**：相切优先融合，按切线夹角从小到大排序贪心合并
   - **Step 3 — 最终闭合**：`Curve.JoinCurves()` 常规合并

#### 7.4.5 `CleanRawCurves()` — 去重清洗

- 过滤长度 < 0.0001 的微碎线
- 用 **RTree 空间索引**快速查找近似曲线（以曲线中点为锚点，半径 = tolerance × 0.5）
- 四端点距离比较：正向 `start-start + end-end` 和反向 `start-end + end-start`，配合中点距离判定重复

#### 7.4.6 `JoinTangentCurvesPrioritized()` — 相切优先融合

- 迭代式贪心合并：
  1. 计算所有曲线对的最小切线夹角（`GetMinTangentAngle`）
  2. 筛选夹角 ≤ `angleTolRad`（0.08 弧度 ≈ 4.6°）的候选对
  3. 按夹角升序排序，逐对尝试 `JoinCurves()`
  4. 已合并的曲线锁定，剩余未合并的进入下一代池
  5. 重复直到无新合并发生
- `GetMinTangentAngle()` 检查四种端点连接方式（end-start / end-end / start-start / start-end），取最小夹角

#### 7.4.7 `ArrangeEngineeringViewsGrouped()` — 工程排版

**布局规则**（以 Front 视图为基准，遵循"长对正、高平齐"）：

```
        ┌──────────┐
        │  Bottom  │
├───────┼──────────┼───────┬──────┐
│ Right │  Front   │ Left  │ Back │
├───────┼──────────┼───────┴──────┘
        │   Top    │
└───────┴──────────┘
                    ┌──────────┐
                    │ IsoFront │  (右侧延伸区)
                    ├──────────┤
                    │ IsoBack  │
                    ├──────────┤
                    │CurrentView│
                    └──────────┘
```

- 所有视图先平移到原点居中
- 以 Front 视图尺寸为参考宽高 (`refW`, `refH`)
- 间距 = `refW * 0.5` / `refH * 0.5`
- Top 在 Front 正下方，Bottom 在正上方，Right 在左侧，Left 在右侧，Back 在 Left 更右侧
- 轴测图和当前视角排在右侧延伸区，垂直堆叠

#### 7.4.8 `BakeToRhinoGrouped()` — 烘焙输出

- 创建/复用图层 `Patent_Drawings_2D`（黑色）
- 每个零件+视图组合创建一个 Rhino Group，命名为 `{零件名}_{视图名}`
- 曲线添加到对应图层和 Group

---

## 8. 使用方式

### 8.1 安装

1. 将编译产物 `AutoMake2D_2.0.rhp`（位于 `bin/Debug/net48/`）拖入 Rhino 7 窗口，或通过 `PackageManager` / `PlugInManager` 安装
2. 重启 Rhino 后插件自动加载

### 8.2 运行

**方式一：自动弹窗**
- 插件加载时通过 `RhinoApp.Idle` 自动打开面板，无需手动操作

**方式二：命令唤醒**
- 在 Rhino 命令行输入 `AutoMake2D` → 切换面板显示/隐藏

### 8.3 操作步骤

1. 在 Rhino 中打开/导入 3D 模型
2. 在 AutoMake2D 面板中选择：
   - **精度**：高(0.001) / 中(0.01) / 低(0.1)
   - **视角**：六视图 / 前45°轴测 / 后45°轴测 / 当前视角（可多选）
3. 点击"生成专利图"
4. 在 Rhino 视口中**框选**需要处理的模型（支持曲面/多重曲面/网格）
5. 等待后台计算（进度条 + ETA 实时显示）
6. 完成后结果自动烘焙到 `Patent_Drawings_2D` 图层，按 `{零件名}_{视图名}` 分组

### 8.4 注意事项

- ⚠️ 尽量不要带内部不可见的零件一起生成，否则计算时间会很长
- 零件名取自 Rhino 对象属性中的 Name 字段，未命名的自动编号为 `零件_N`
- 输出为纯 2D 曲线（线框），不含填充和标注

---

## 9. 功能模块总结

| 模块 | 文件 | 职责 |
|---|---|---|
| **插件入口** | `AutoMake2DPlugin.cs` | 生命周期管理、面板注册、自动弹窗、图标加载 |
| **命令系统** | `AutoMake2DCommand.cs` | Rhino 命令注册、面板 toggle |
| **用户界面** | `PatentUiPanel.cs` | Eto.Forms 面板：参数配置、进度反馈、异步触发 |
| **核心引擎** | `PatentCore.cs` | 完整业务逻辑（见下） |

### PatentCore.cs 内部模块

| 子模块 | 方法 | 职责 |
|---|---|---|
| 主流程编排 | `ExecuteAsync()` | 选择→投影→排版→烘焙 全流程串联 |
| 视图平面 | `GetViewPlane()` / `GetIsoPlane()` | 6 标准视图 + 2 轴测视图的投影平面定义 |
| 隐线投影 | `ComputeSingleViewEngine()` | HiddenLineDrawing 引擎调用、可见段提取、零件归属、外轮廓标记 |
| 线段清洗 | `CleanRawCurves()` | RTree 去重 + 碎线过滤 |
| 相切融合 | `JoinTangentCurvesPrioritized()` / `GetMinTangentAngle()` | 贪心式相切优先合并 |
| 外轮廓处理 | (内联于 ComputeSingleViewEngine) | SilhouetteType 判定 + 特权隔离闭环 |
| 工程排版 | `ArrangeEngineeringViewsGrouped()` | "长对正/高平齐"矩阵布局 + 轴测延伸区 |
| 烘焙输出 | `BakeToRhinoGrouped()` | 图层创建 + 分组烘焙 |

---

## 10. 技术亮点

1. **HiddenLineDrawing 隐线引擎**：利用 Rhino 原生隐线计算能力做精确投影消隐，仅保留可见轮廓
2. **外轮廓"基因烙印"机制**：通过 `SetUserString("IsOuter", "true")` 在曲线级别标记外轮廓，实现特权隔离——外轮廓先独立闭环，避免内部相交线干扰端点合并
3. **RTree 空间索引去重**：O(n·k) 的近邻查询替代 O(n²) 暴力比较，k 为局部邻居数
4. **相切优先贪心融合**：按切线夹角排序合并，角度最小的优先合并，模拟人工描线逻辑
5. **ETA 实时估算**：基于已完成视图的平均耗时动态推算剩余时间
6. **工程制图规范排版**：自动实现"长对正、高平齐"的三视图对齐布局

---

## 11. 构建与编译

### 构建命令

```bash
dotnet build AutoMake2D.csproj -c Release -f net48
```

### 编译产物

| 配置 | 目标框架 | 产物 |
|---|---|---|
| Debug | net48 | `bin/Debug/net48/AutoMake2D_2.0.rhp` |
| Debug | net7.0-windows | `bin/Debug/net7.0-windows/AutoMake2D.rhp` |
| Debug | net8.0-windows | `bin/Debug/net8.0-windows/AutoMake2D.rhp` |
| Debug | net10.0 | `bin/Debug/net10.0/AutoMake2D.dll` |

> `.csproj` 主目标为 `net48`，但 obj 目录显示开发者尝试过 net7/net8/net10 多版本编译。实际部署应使用 **net48** 的 `.rhp` 产物（与 Rhino 7 的 .NET 运行时兼容）。

### 运行环境要求

- Rhino 7 SR35+（Windows）
- .NET Framework 4.8 运行时

---

## 12. 潜在问题与改进建议

| 问题 | 说明 |
|---|---|
| net48 与 net7/8/10 混编译 | obj 目录残留多框架产物，建议清理不支持的 TFM，只保留 net48 |
| 无 README / 文档 | 项目内无任何说明文档，用户只能靠面板提示操作 |
| 零件名编码风险 | `groupName = componentName + "_" + viewName` 若零件名含特殊字符可能影响 Rhino Group 命名 |
| 异常处理粒度粗 | `OnGenerateClick` 的 catch 仅输出 Message，不含堆栈，调试困难 |
| 无版本号管理 | AssemblyInfo 全部为 1.0.0.0，与 zip 包名 "2.0" 不一致 |
| `.vs/` 目录打包 | IDE 缓存被误打入 zip，应通过 .gitignore 排除 |

---

*报告结束*
