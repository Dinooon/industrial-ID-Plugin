AutoMake2D 5.1 fix20

- 不再创建 TangentEdges 图层。
- 未被筛选的相切线与普通结构线统一放入 Patent_Drawings_2D。
- 仅筛选候选线放入红色 Filtered_TangentEdges 图层。
- 渲染隐藏/恢复逻辑中移除了 TangentEdges 图层依赖。
- 保留 fix19 的白底、安全裁图、防截断与紧凑排版优化。
