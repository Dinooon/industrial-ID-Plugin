AutoMake2D 5.1 fix18 - white background and compact render layout

Changes:
1. Prefer Rhino viewport native white background in Rendered/Shaded capture.
2. Disable gradient/document background through version-safe reflection.
3. Keep only a strict boundary-connected fallback background normalization (RGB max difference <= 12).
4. Avoid removing light gray / near-white model surfaces.
5. Per-view crop padding reduced from 28 px to 10 px.
6. Six-view layout gaps reduced to gapX=8 px and gapY=6 px.
7. Final composed canvas is trimmed again with 10 px padding.
8. Single-view image uses more of the available canvas.
9. Rhino 7 and Rhino 8 separate build projects are preserved.
