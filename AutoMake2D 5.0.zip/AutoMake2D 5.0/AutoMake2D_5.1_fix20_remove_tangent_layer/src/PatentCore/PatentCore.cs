using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using Rhino;
using Rhino.Geometry;
using Rhino.Input;
using Rhino.DocObjects;
using Rhino.Display;
using AutoMake2D.Common;

namespace AutoMake2D.PatentCore
{
    /// <summary>
    /// PatentCore 门面类 — 编排投影/融合/排版/渲染模块
    /// 对外接口 ExecuteAsync 签名与 3.0 完全一致
    /// </summary>
    public static class PatentCore
    {
        public static async Task ExecuteAsync(bool wantSix, bool wantIsoFront, bool wantIsoBack, bool wantCurrent, double tolerance, bool wantRender, string renderOutputPath, IProgress<int> progress, IProgress<string> status, bool wantAnnotation = false)
        {
            RhinoDoc doc = RhinoDoc.ActiveDoc;
            if (doc == null) return;

            var rc = RhinoGet.GetMultipleObjects("请框选需要生成零部件独立分组线框图的模型", true, ObjectType.Surface | ObjectType.PolysrfFilter | ObjectType.Mesh, out ObjRef[] objRefs);
            if (rc != Rhino.Commands.Result.Success || objRefs == null)
            {
                status?.Report("已取消选择。");
                return;
            }

            status?.Report("正在提取模型几何与零部件特征...");

            List<GeometryBase> pureGeos = new List<GeometryBase>();
            List<string> compNames = new List<string>();
            var selectedObjectIds = new HashSet<Guid>();
            BoundingBox globalBbox = BoundingBox.Empty;

            for (int i = 0; i < objRefs.Length; i++)
            {
                var geo = objRefs[i].Geometry();
                if (geo != null)
                {
                    pureGeos.Add(geo);
                    globalBbox.Union(geo.GetBoundingBox(true));

                    var rhinoObj = objRefs[i].Object();
                    if (rhinoObj != null) selectedObjectIds.Add(rhinoObj.Id);
                    string name = rhinoObj != null ? rhinoObj.Attributes.Name : null;
                    if (string.IsNullOrEmpty(name)) name = "零件_" + (i + 1);
                    compNames.Add(name);
                }
            }

            if (pureGeos.Count == 0 || !globalBbox.IsValid) return;
            Point3d center = globalBbox.Center;

            var planesToGenerate = new Dictionary<string, Plane>(StringComparer.OrdinalIgnoreCase);

            if (wantSix)
            {
                planesToGenerate["Front"] = PatentProjector.GetViewPlane("Front", center);
                planesToGenerate["Back"] = PatentProjector.GetViewPlane("Back", center);
                planesToGenerate["Top"] = PatentProjector.GetViewPlane("Top", center);
                planesToGenerate["Bottom"] = PatentProjector.GetViewPlane("Bottom", center);
                planesToGenerate["Left"] = PatentProjector.GetViewPlane("Left", center);
                planesToGenerate["Right"] = PatentProjector.GetViewPlane("Right", center);
            }
            if (wantIsoFront) planesToGenerate["IsoFront"] = PatentProjector.GetIsoPlane(center, isFront: true, isDown: false);
            if (wantIsoBack) planesToGenerate["IsoBack"] = PatentProjector.GetIsoPlane(center, isFront: false, isDown: true);
            if (wantCurrent)
            {
                var activeView = doc.Views.ActiveView;
                if (activeView != null)
                {
                    var vp = activeView.ActiveViewport;
                    planesToGenerate["CurrentView"] = new Plane(center, vp.CameraX, vp.CameraY);
                }
            }

            int totalViews = planesToGenerate.Count;
            if (totalViews == 0) return;

            int completedViews = 0;
            var stopwatch = Stopwatch.StartNew();

            status?.Report("准备进入后台超算引擎...");

            var viewsData = await Task.Run(() =>
            {
                var data = new Dictionary<string, Dictionary<string, List<Curve>>>(StringComparer.OrdinalIgnoreCase);

                foreach (var kvp in planesToGenerate)
                {
                    string etaStr = "计算中...";
                    if (completedViews > 0)
                    {
                        long elapsedMs = stopwatch.ElapsedMilliseconds;
                        long avgMs = elapsedMs / completedViews;
                        long remainingTotalMs = avgMs * (totalViews - completedViews);
                        long remainingSecs = remainingTotalMs / 1000;

                        if (remainingSecs > 60)
                            etaStr = $"总共还需约 {remainingSecs / 60}分{remainingSecs % 60}秒";
                        else
                            etaStr = $"总共还需约 {remainingSecs} 秒";
                    }

                    status?.Report($"🔄 正在死磕计算 [{kvp.Key}] 视图 ({completedViews + 1}/{totalViews}) | {etaStr}");

                    var curvesGroupedByComp = PatentProjector.ComputeSingleView(pureGeos, compNames, kvp.Value, tolerance);
                    data[kvp.Key] = curvesGroupedByComp;

                    completedViews++;
                    progress?.Report((int)((completedViews / (double)totalViews) * 100));
                }

                status?.Report("📐 所有视图计算完毕，正在进行二维矩阵防重叠左侧排版...");
                LayoutComposer.ArrangeEngineeringViewsGrouped(data);

                return data;
            });

            status?.Report("💾 正在按零件名称进行成组烘焙...");
            LayerDispatcher.BakeToRhinoGrouped(doc, viewsData);
            // 视图标注（可选）
            if (wantAnnotation)
            {
                status?.Report("🏷 正在添加视图标注...");
                AnnotationEngine.AddViewAnnotations(doc, viewsData);
                RhinoApp.WriteLine("🏷 视图标注已添加 (Patent_Annotation 图层)");
            }

            doc.Views.Redraw();
            RhinoApp.WriteLine("✅ 零部件分层打组——左侧矩阵版专利图输出完毕！");

            // ============================================================
            // 渲染输出（视图联动模式）
            // ============================================================
            if (wantRender)
            {
                status?.Report("🎨 正在准备渲染输出...");

                RhinoView currentView = doc.Views.ActiveView;
                var renderViews = RenderCaptureEngine.DetermineRenderViews(wantSix, wantIsoFront, wantIsoBack, wantCurrent, globalBbox, currentView);

                if (renderViews.Count == 0)
                {
                    status?.Report("未选定任何视图模式，跳过渲染输出");
                    RhinoApp.WriteLine("⚠️ 渲染输出已勾选但未选定视图模式，跳过渲染。");
                }
                else
                {
                    status?.Report($"🎨 正在捕获 {renderViews.Count} 张渲染图...");

                    var drawingLayer = doc.Layers.FindName("Patent_Drawings_2D");
                    var filteredLayer = doc.Layers.FindName("Filtered_TangentEdges");
                    bool drawingLayerWasVisible = drawingLayer != null && drawingLayer.IsVisible;
                    bool filteredLayerWasVisible = filteredLayer != null && filteredLayer.IsVisible;

                    if (drawingLayer != null) drawingLayer.IsVisible = false;
                    if (filteredLayer != null) filteredLayer.IsVisible = false;
                    doc.Views.Redraw();

                    var renderBitmaps = new Dictionary<string, Bitmap>(StringComparer.OrdinalIgnoreCase);
                    var temporarilyHiddenObjectIds = new List<Guid>();

                    // Rhino 会用黄色轮廓高亮当前选择对象。捕获前取消选择，结束后恢复，
                    // 这样渲染图只保留真实材质和黑色曲面边缘。
                    doc.Objects.UnselectAll();
                    doc.Views.Redraw();

                    // 渲染时只显示本次用户选择的实体。文档中其他模型、旧 PictureFrame、
                    // 辅助曲线等不能参与构图，也不能出现在截图里。
                    foreach (var obj in doc.Objects)
                    {
                        if (obj == null || !obj.Visible || selectedObjectIds.Contains(obj.Id)) continue;
                        if (doc.Objects.Hide(obj.Id, true))
                            temporarilyHiddenObjectIds.Add(obj.Id);
                    }
                    doc.Views.Redraw();

                    try
                    {
                        for (int i = 0; i < renderViews.Count; i++)
                        {
                            var rv = renderViews[i];
                            status?.Report($"🎨 正在渲染 [{rv.Name}] 视图 ({i + 1}/{renderViews.Count})...");
                            progress?.Report((int)((i / (double)renderViews.Count) * 100));

                            Bitmap bmp = RenderCaptureEngine.CaptureViewRender(
                                doc, rv.Plane, rv.Name, new Size(1400, 1050), globalBbox);
                            if (bmp != null)
                                renderBitmaps[rv.Name] = bmp;
                        }
                    }
                    finally
                    {
                        foreach (Guid id in temporarilyHiddenObjectIds)
                            doc.Objects.Show(id, true);

                        if (drawingLayer != null) drawingLayer.IsVisible = drawingLayerWasVisible;
                        if (filteredLayer != null) filteredLayer.IsVisible = filteredLayerWasVisible;

                        foreach (Guid id in selectedObjectIds)
                        {
                            RhinoObject selectedObject = doc.Objects.FindId(id);
                            if (selectedObject != null) selectedObject.Select(true);
                        }
                        doc.Views.Redraw();
                    }

                    if (renderBitmaps.Count > 0)
                    {
                        status?.Report($"📐 正在排版 {renderBitmaps.Count} 张渲染图...");
                        Bitmap composed = RenderCaptureEngine.ComposeRenderLayout(renderBitmaps, renderViews);

                        if (composed != null)
                        {
                            status?.Report("💾 正在将渲染图放入模型...");
                            try
                            {
                                string persistentRenderFile = renderOutputPath;
                                try
                                {
                                    string dir;
                                    if (string.IsNullOrWhiteSpace(persistentRenderFile))
                                    {
                                        dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "AutoMake2D", "Renders");
                                        persistentRenderFile = Path.Combine(dir, $"AutoMake2D_Render_{Guid.NewGuid():N}.png");
                                    }
                                    else
                                    {
                                        dir = Path.GetDirectoryName(persistentRenderFile);
                                    }
                                    if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                                        Directory.CreateDirectory(dir);
                                    composed.Save(persistentRenderFile, ImageFormat.Png);
                                }
                                catch
                                {
                                    string dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "AutoMake2D", "Renders");
                                    Directory.CreateDirectory(dir);
                                    persistentRenderFile = Path.Combine(dir, $"AutoMake2D_Render_{Guid.NewGuid():N}.png");
                                    composed.Save(persistentRenderFile, ImageFormat.Png);
                                }

                                BoundingBox modelBbox = globalBbox;
                                double offsetX = modelBbox.IsValid ? modelBbox.Max.X + modelBbox.Diagonal.Length * 0.3 : 100;
                                double offsetY = 0;
                                double offsetZ = 0;

                                double aspectRatio = (double)composed.Width / composed.Height;
                                double frameHeight = modelBbox.IsValid ? modelBbox.Diagonal.Length * 0.8 : 100;
                                double frameWidth = frameHeight * aspectRatio;

                                var framePlane = new Plane(
                                    new Point3d(offsetX, offsetY, offsetZ),
                                    Vector3d.XAxis, Vector3d.YAxis);

                                var pictureFrameId = doc.Objects.AddPictureFrame(framePlane, persistentRenderFile, true, frameWidth, frameHeight, false, false);

                                if (pictureFrameId != Guid.Empty)
                                {
                                    int renderLayerIndex = LayerDispatcher.EnsureLayer(doc, "Patent_Render", System.Drawing.Color.LightGray);

                                    var pfObj = doc.Objects.FindId(pictureFrameId);
                                    if (pfObj != null)
                                    {
                                        var attrs = pfObj.Attributes.Duplicate();
                                        attrs.LayerIndex = renderLayerIndex;
                                        doc.Objects.ModifyAttributes(pfObj, attrs, false);
                                    }

                                    status?.Report($"✅ 渲染图已放入模型 (Patent_Render 图层)");
                                    RhinoApp.WriteLine($"✅ 渲染图已放入模型 (Patent_Render 图层)，同时保存至: {persistentRenderFile}");
                                }
                                else
                                {
                                    status?.Report($"⚠️ PictureFrame 创建失败，渲染图仅保存为外部文件: {persistentRenderFile}");
                                }

                                // PictureFrame 需要持续访问图像文件；不得在创建后删除。
                                // 同时请求嵌入位图，以兼容 Rhino 7/8 的文档保存与重开。
                            }
                            catch (Exception ex)
                            {
                                status?.Report($"❌ 渲染图输出失败: {ex.Message}");
                                Logger.Error("渲染图输出失败", ex);
                            }
                        }
                    }
                }
            }
        }
    }
}
