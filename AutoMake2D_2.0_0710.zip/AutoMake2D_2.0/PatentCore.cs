﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Diagnostics;
using Rhino;
using Rhino.Geometry;
using Rhino.Input;
using Rhino.DocObjects;

namespace AutoMake2D
{
    public static class PatentCore
    {
        public static async Task ExecuteAsync(bool wantSix, bool wantIsoFront, bool wantIsoBack, bool wantCurrent, double tolerance, IProgress<int> progress, IProgress<string> status)
        {
            RhinoDoc doc = RhinoDoc.ActiveDoc;
            if (doc == null) return;

            var rc = RhinoGet.GetMultipleObjects("请框选需要生成零部件独立分组线框图的模型", true, ObjectType.Surface | ObjectType.PolysrfFilter | ObjectType.Mesh, out ObjRef[] objRefs);
            if (rc != Rhino.Commands.Result.Success || objRefs == null)
            {
                status?.Report("已取消选择。");
                return;
            }

            status?.Report("正在提取模型几何与零部件特征...");

            List<GeometryBase> pureGeos = new List<GeometryBase>();
            List<string> compNames = new List<string>();
            BoundingBox globalBbox = BoundingBox.Empty;

            for (int i = 0; i < objRefs.Length; i++)
            {
                var geo = objRefs[i].Geometry();
                if (geo != null)
                {
                    pureGeos.Add(geo);
                    globalBbox.Union(geo.GetBoundingBox(true));

                    var rhinoObj = objRefs[i].Object();
                    string name = rhinoObj != null ? rhinoObj.Attributes.Name : null;
                    if (string.IsNullOrEmpty(name)) name = "零件_" + (i + 1);
                    compNames.Add(name);
                }
            }

            if (pureGeos.Count == 0 || !globalBbox.IsValid) return;
            Point3d center = globalBbox.Center;

            var planesToGenerate = new Dictionary<string, Plane>(StringComparer.OrdinalIgnoreCase);

            if (wantSix)
            {
                planesToGenerate["Front"] = GetViewPlane("Front", center);
                planesToGenerate["Back"] = GetViewPlane("Back", center);
                planesToGenerate["Top"] = GetViewPlane("Top", center);
                planesToGenerate["Bottom"] = GetViewPlane("Bottom", center);
                planesToGenerate["Left"] = GetViewPlane("Left", center);
                planesToGenerate["Right"] = GetViewPlane("Right", center);
            }
            if (wantIsoFront) planesToGenerate["IsoFront"] = GetIsoPlane(center, isFront: true, isDown: false);
            if (wantIsoBack) planesToGenerate["IsoBack"] = GetIsoPlane(center, isFront: false, isDown: true);
            if (wantCurrent)
            {
                var activeView = doc.Views.ActiveView;
                if (activeView != null)
                {
                    var vp = activeView.ActiveViewport;
                    planesToGenerate["CurrentView"] = new Plane(center, vp.CameraX, vp.CameraY);
                }
            }

            int totalViews = planesToGenerate.Count;
            if (totalViews == 0) return;

            int completedViews = 0;
            var stopwatch = Stopwatch.StartNew();

            status?.Report("准备进入后台超算引擎...");

            var viewsData = await Task.Run(() =>
            {
                var data = new Dictionary<string, Dictionary<string, List<Curve>>>(StringComparer.OrdinalIgnoreCase);

                foreach (var kvp in planesToGenerate)
                {
                    string etaStr = "计算中...";
                    if (completedViews > 0)
                    {
                        long elapsedMs = stopwatch.ElapsedMilliseconds;
                        long avgMs = elapsedMs / completedViews;
                        long remainingTotalMs = avgMs * (totalViews - completedViews);
                        long remainingSecs = remainingTotalMs / 1000;

                        if (remainingSecs > 60)
                            etaStr = $"总共还需约 {remainingSecs / 60}分{remainingSecs % 60}秒";
                        else
                            etaStr = $"总共还需约 {remainingSecs} 秒";
                    }

                    status?.Report($"🔄 正在死磕计算 [{kvp.Key}] 视图 ({completedViews + 1}/{totalViews}) | {etaStr}");

                    var curvesGroupedByComp = ComputeSingleViewEngine(pureGeos, compNames, kvp.Value, tolerance);
                    data[kvp.Key] = curvesGroupedByComp;

                    completedViews++;
                    progress?.Report((int)((completedViews / (double)totalViews) * 100));
                }

                status?.Report("📐 所有视图计算完毕，正在进行二维矩阵防重叠左侧排版...");
                ArrangeEngineeringViewsGrouped(data);

                return data;
            });

            status?.Report("💾 正在按零件名称进行成组烘焙...");
            BakeToRhinoGrouped(doc, viewsData);
            doc.Views.Redraw();
            RhinoApp.WriteLine("✅ 零部件分层打组——左侧矩阵版专利图输出完毕！");
        }

        private static Plane GetIsoPlane(Point3d origin, bool isFront, bool isDown)
        {
            Vector3d normal;
            if (isFront)
            {
                normal = new Vector3d(1, -1, 1);
            }
            else
            {
                normal = isDown ? new Vector3d(-1, 1, -1) : new Vector3d(-1, 1, 1);
            }

            normal.Unitize();
            Vector3d planeX = Vector3d.CrossProduct(Vector3d.ZAxis, normal);
            planeX.Unitize();

            Vector3d planeY = Vector3d.CrossProduct(normal, planeX);
            planeY.Unitize();

            return new Plane(origin, planeX, planeY);
        }

        private static Dictionary<string, List<Curve>> ComputeSingleViewEngine(List<GeometryBase> geos, List<string> names, Plane viewPlane, double tolerance)
        {
            var rawGrouped = new Dictionary<string, List<Curve>>(StringComparer.OrdinalIgnoreCase);
            foreach (var name in names) rawGrouped[name] = new List<Curve>();

            var paramsHld = new HiddenLineDrawingParameters
            {
                AbsoluteTolerance = tolerance,
                IncludeHiddenCurves = false,
                IncludeTangentEdges = true,
                IncludeTangentSeams = true
            };

            Transform xformP2P = Transform.PlaneToPlane(viewPlane, Plane.WorldXY);
            BoundingBox transformedBbox = BoundingBox.Empty;

            for (int i = 0; i < geos.Count; i++)
            {
                paramsHld.AddGeometry(geos[i], xformP2P, names[i]);
                var dup = geos[i].Duplicate();
                dup.Transform(xformP2P);
                transformedBbox.Union(dup.GetBoundingBox(true));
            }

            var vp = new Rhino.Display.RhinoViewport();
            vp.ChangeToParallelProjection(true);
            double camZ = transformedBbox.IsValid ? transformedBbox.Max.Z + 1000 : 1000;
            vp.SetCameraLocation(new Point3d(0, 0, camZ), false);
            vp.SetCameraDirection(-Vector3d.ZAxis, false);
            vp.CameraUp = Vector3d.YAxis;
            vp.SetCameraTarget(Point3d.Origin, false);
            paramsHld.SetViewport(vp);

            var hld = HiddenLineDrawing.Compute(paramsHld, true);
            if (hld != null)
            {
                Transform xformFlatten = Transform.PlanarProjection(Plane.WorldXY);
                foreach (var seg in hld.Segments)
                {
                    if (seg != null && seg.CurveGeometry != null && seg.SegmentVisibility == HiddenLineDrawingSegment.Visibility.Visible)
                    {
                        string belongingComponent = "未知组件";
                        bool isOuterContour = false; // 【新增】：是否为外轮廓的判定旗帜

                        var hldCurve = seg.ParentCurve;
                        if (hldCurve != null)
                        {
                            var hldObj = hldCurve.SourceObject;
                            if (hldObj != null && hldObj.Tag != null)
                            {
                                belongingComponent = hldObj.Tag.ToString();
                            }

                            // 【核心新增】：精准捕获模型投影的最外轮廓或裸露边界
                            if (hldCurve.SilhouetteType == SilhouetteType.Projecting ||
                                hldCurve.SilhouetteType == SilhouetteType.Boundary)
                            {
                                isOuterContour = true;
                            }
                        }

                        if (!rawGrouped.ContainsKey(belongingComponent))
                        {
                            rawGrouped[belongingComponent] = new List<Curve>();
                        }

                        var crv = seg.CurveGeometry.DuplicateCurve();
                        crv.Transform(xformFlatten);

                        // 【核心新增】：为提取的线段打上基因烙印
                        if (isOuterContour)
                        {
                            crv.SetUserString("IsOuter", "true");
                        }

                        rawGrouped[belongingComponent].Add(crv);
                    }
                }
            }

            var finalCleanedGrouped = new Dictionary<string, List<Curve>>(StringComparer.OrdinalIgnoreCase);
            foreach (var kvp in rawGrouped)
            {
                var list = kvp.Value;
                if (list.Count == 0) continue;

                // Step 1: 物理去重和微小碎线清洗
                list = CleanRawCurves(list, tolerance);

                // ========================================================
                // 【新增 Step 1.5】：外轮廓特权隔离与优先独立组合
                // ========================================================
                List<Curve> outerCurves = new List<Curve>();
                List<Curve> innerCurves = new List<Curve>();
                foreach (var c in list)
                {
                    // 根据基因烙印分流
                    if (c.GetUserString("IsOuter") == "true") outerCurves.Add(c);
                    else innerCurves.Add(c);
                }

                // 仅对外轮廓进行独立闭环组合，杜绝内部相交线抢夺端点
                var joinedOuter = Curve.JoinCurves(outerCurves, tolerance);
                List<Curve> nextPool = new List<Curve>();

                if (joinedOuter != null)
                {
                    foreach (var jo in joinedOuter)
                    {
                        jo.SetUserString("IsOuter", "true"); // 继承外轮廓血统，以备后续调试
                        nextPool.Add(jo);
                    }
                }
                else
                {
                    nextPool.AddRange(outerCurves);
                }

                // 将内部线放回池子中，与已经“固若金汤”的外轮廓一起进入后续处理
                nextPool.AddRange(innerCurves);
                list = nextPool;

                // Step 2: 整体线组送入相切优先融合（此时外边界已经是一体的了，内部线只能依附）
                list = JoinTangentCurvesPrioritized(list, tolerance, 0.08);

                // Step 3: 常规直角与死角闭合
                var joinedArray = Curve.JoinCurves(list, tolerance);

                finalCleanedGrouped[kvp.Key] = joinedArray != null ? new List<Curve>(joinedArray) : list;
            }

            return finalCleanedGrouped;
        }

        private static List<Curve> CleanRawCurves(List<Curve> curves, double tolerance)
        {
            if (curves.Count == 0) return curves;
            List<Curve> validCurves = new List<Curve>();
            foreach (var c in curves) { if (c != null && c.GetLength() > 0.0001) validCurves.Add(c); }

            List<Curve> cleaned = new List<Curve>();
            RTree tree = new RTree();

            for (int i = 0; i < validCurves.Count; i++)
            {
                var c1 = validCurves[i];
                double len1 = c1.GetLength();
                Point3d midPt1 = c1.PointAtNormalizedLength(0.5);
                bool isDup = false;
                List<int> neighbors = new List<int>();

                tree.Search(new Sphere(midPt1, tolerance * 0.5), (sender, args) => { neighbors.Add(args.Id); });

                foreach (int j in neighbors)
                {
                    var c2 = cleaned[j];
                    if (Math.Abs(len1 - c2.GetLength()) > tolerance) continue;

                    double dFwd = c1.PointAtStart.DistanceTo(c2.PointAtStart) + c1.PointAtEnd.DistanceTo(c2.PointAtEnd);
                    double dRev = c1.PointAtStart.DistanceTo(c2.PointAtEnd) + c1.PointAtEnd.DistanceTo(c2.PointAtStart);
                    double dMid = midPt1.DistanceTo(c2.PointAtNormalizedLength(0.5));

                    if ((dFwd < tolerance && dMid < tolerance * 0.5) || (dRev < tolerance && dMid < tolerance * 0.5))
                    {
                        isDup = true;
                        break;
                    }
                }

                if (!isDup)
                {
                    tree.Insert(midPt1, cleaned.Count);
                    cleaned.Add(c1);
                }
            }
            return cleaned;
        }

        private static List<Curve> JoinTangentCurvesPrioritized(List<Curve> curves, double tolerance, double angleTolRad)
        {
            if (curves.Count < 2) return curves;

            List<Curve> pool = new List<Curve>();
            foreach (var c in curves) { if (c != null) pool.Add(c); }

            bool loopAgain = true;
            while (loopAgain)
            {
                loopAgain = false;
                List<MergeCandidate> candidates = new List<MergeCandidate>();

                for (int i = 0; i < pool.Count; i++)
                {
                    for (int j = i + 1; j < pool.Count; j++)
                    {
                        if (GetMinTangentAngle(pool[i], pool[j], tolerance, out double actualAngle))
                        {
                            if (actualAngle <= angleTolRad)
                            {
                                candidates.Add(new MergeCandidate { Index1 = i, Index2 = j, Angle = actualAngle });
                            }
                        }
                    }
                }

                if (candidates.Count == 0) break;

                candidates.Sort((a, b) => a.Angle.CompareTo(b.Angle));

                List<Curve> nextGenerationPool = new List<Curve>();
                bool[] indexLocked = new bool[pool.Count];

                foreach (var candidate in candidates)
                {
                    if (indexLocked[candidate.Index1] || indexLocked[candidate.Index2]) continue;

                    Curve[] res = Curve.JoinCurves(new Curve[] { pool[candidate.Index1], pool[candidate.Index2] }, tolerance);
                    if (res != null && res.Length == 1)
                    {
                        nextGenerationPool.Add(res[0]);
                        indexLocked[candidate.Index1] = true;
                        indexLocked[candidate.Index2] = true;
                        loopAgain = true;
                    }
                }

                for (int i = 0; i < pool.Count; i++)
                {
                    if (!indexLocked[i]) nextGenerationPool.Add(pool[i]);
                }

                pool = nextGenerationPool;
            }
            return pool;
        }

        private static bool GetMinTangentAngle(Curve c1, Curve c2, double tolerance, out double minAngle)
        {
            minAngle = double.MaxValue;
            bool isConnected = false;

            Point3d s1 = c1.PointAtStart; Point3d e1 = c1.PointAtEnd;
            Point3d s2 = c2.PointAtStart; Point3d e2 = c2.PointAtEnd;

            Vector3d tS1 = c1.TangentAtStart; Vector3d tE1 = c1.TangentAtEnd;
            Vector3d tS2 = c2.TangentAtStart; Vector3d tE2 = c2.TangentAtEnd;

            if (e1.DistanceTo(s2) <= tolerance) { double a = Vector3d.VectorAngle(tE1, tS2); if (a < minAngle) { minAngle = a; isConnected = true; } }
            if (e1.DistanceTo(e2) <= tolerance) { double a = Vector3d.VectorAngle(tE1, -tE2); if (a < minAngle) { minAngle = a; isConnected = true; } }
            if (s1.DistanceTo(s2) <= tolerance) { double a = Vector3d.VectorAngle(-tS1, tS2); if (a < minAngle) { minAngle = a; isConnected = true; } }
            if (s1.DistanceTo(e2) <= tolerance) { double a = Vector3d.VectorAngle(-tS1, -tE2); if (a < minAngle) { minAngle = a; isConnected = true; } }

            return isConnected;
        }

        private static void BakeToRhinoGrouped(RhinoDoc doc, Dictionary<string, Dictionary<string, List<Curve>>> viewsData)
        {
            string layerName = "Patent_Drawings_2D";
            var existingLayer = doc.Layers.FindName(layerName);
            int layerIndex = (existingLayer != null) ? existingLayer.Index : -1;

            if (layerIndex < 0)
            {
                var newLayer = new Layer { Name = layerName, Color = System.Drawing.Color.Black };
                layerIndex = doc.Layers.Add(newLayer);
            }

            foreach (var kvpView in viewsData)
            {
                string viewName = kvpView.Key;
                foreach (var kvpComp in kvpView.Value)
                {
                    string componentName = kvpComp.Key;
                    List<Curve> curves = kvpComp.Value;
                    if (curves.Count == 0) continue;

                    string groupName = componentName + "_" + viewName;
                    int groupIndex = doc.Groups.Add(groupName);

                    foreach (var crv in curves)
                    {
                        var attributes = new ObjectAttributes { LayerIndex = layerIndex };
                        attributes.AddToGroup(groupIndex);
                        doc.Objects.AddCurve(crv, attributes);
                    }
                }
            }
        }

        private static void ArrangeEngineeringViewsGrouped(Dictionary<string, Dictionary<string, List<Curve>>> vData)
        {
            var bboxes = new Dictionary<string, BoundingBox>(StringComparer.OrdinalIgnoreCase);
            double globalMaxW = 0, globalMaxH = 0;

            foreach (var kvpView in vData)
            {
                string viewName = kvpView.Key;
                BoundingBox viewBbox = BoundingBox.Empty;

                foreach (var kvpComp in kvpView.Value)
                {
                    foreach (var crv in kvpComp.Value) viewBbox.Union(crv.GetBoundingBox(true));
                }

                bboxes[viewName] = viewBbox;

                if (viewBbox.IsValid)
                {
                    globalMaxW = Math.Max(globalMaxW, viewBbox.Max.X - viewBbox.Min.X);
                    globalMaxH = Math.Max(globalMaxH, viewBbox.Max.Y - viewBbox.Min.Y);

                    Transform toOrigin = Transform.Translation(new Vector3d(-viewBbox.Center.X, -viewBbox.Center.Y, 0));
                    foreach (var kvpComp in kvpView.Value)
                    {
                        foreach (var crv in kvpComp.Value) crv.Transform(toOrigin);
                    }
                }
            }

            double refW = bboxes.ContainsKey("Front") && bboxes["Front"].IsValid ? (bboxes["Front"].Max.X - bboxes["Front"].Min.X) : globalMaxW;
            double refH = bboxes.ContainsKey("Front") && bboxes["Front"].IsValid ? (bboxes["Front"].Max.Y - bboxes["Front"].Min.Y) : globalMaxH;

            double gapX = refW * 0.5 == 0 ? 100 : refW * 0.5;
            double gapY = refH * 0.5 == 0 ? 100 : refH * 0.5;

            double getW(string name) => bboxes.ContainsKey(name) && bboxes[name].IsValid ? (bboxes[name].Max.X - bboxes[name].Min.X) : 0;
            double getH(string name) => bboxes.ContainsKey(name) && bboxes[name].IsValid ? (bboxes[name].Max.Y - bboxes[name].Min.Y) : 0;

            var offsets = new Dictionary<string, Vector3d>(StringComparer.OrdinalIgnoreCase);

            offsets["Front"] = new Vector3d(0, 0, 0);
            offsets["Top"] = new Vector3d(0, -(refH / 2.0 + gapY + getH("Top") / 2.0), 0);
            offsets["Bottom"] = new Vector3d(0, (refH / 2.0 + gapY + getH("Bottom") / 2.0), 0);
            offsets["Right"] = new Vector3d(-(refW / 2.0 + gapX + getW("Right") / 2.0), 0, 0);
            offsets["Left"] = new Vector3d((refW / 2.0 + gapX + getW("Left") / 2.0), 0, 0);
            offsets["Back"] = new Vector3d((refW / 2.0 + gapX + getW("Left") + gapX + getW("Back") / 2.0), 0, 0);

            double rightViewCenterX = -(refW / 2.0 + gapX + getW("Right") / 2.0);
            double extensionX = bboxes.ContainsKey("Right") && bboxes["Right"].IsValid
                ? (rightViewCenterX - getW("Right") / 2.0 - gapX - globalMaxW / 2.0)
                : -(refW / 2.0 + gapX + globalMaxW / 2.0);

            if (refW == 0) extensionX = -(globalMaxW + gapX);

            offsets["IsoFront"] = new Vector3d(extensionX, 0, 0);
            offsets["IsoBack"] = new Vector3d(extensionX, (globalMaxH + gapY), 0);
            offsets["CurrentView"] = new Vector3d(extensionX, -(globalMaxH + gapY), 0);

            foreach (var kvpView in vData)
            {
                if (offsets.TryGetValue(kvpView.Key, out Vector3d moveVec))
                {
                    Transform finalMove = Transform.Translation(moveVec);
                    foreach (var kvpComp in kvpView.Value)
                    {
                        foreach (var crv in kvpComp.Value) crv.Transform(finalMove);
                    }
                }
            }
        }

        private static Plane GetViewPlane(string name, Point3d origin)
        {
            name = name.Trim().ToLower();
            switch (name)
            {
                case "top": return new Plane(origin, Vector3d.XAxis, Vector3d.YAxis);
                case "bottom": return new Plane(origin, -Vector3d.XAxis, Vector3d.YAxis);
                case "front": return new Plane(origin, Vector3d.XAxis, Vector3d.ZAxis);
                case "back": return new Plane(origin, -Vector3d.XAxis, Vector3d.ZAxis);
                case "left": return new Plane(origin, -Vector3d.YAxis, Vector3d.ZAxis);
                case "right": return new Plane(origin, Vector3d.YAxis, Vector3d.ZAxis);
                default: return new Plane(origin, Vector3d.XAxis, Vector3d.YAxis);
            }
        }

        private class MergeCandidate
        {
            public int Index1 { get; set; }
            public int Index2 { get; set; }
            public double Angle { get; set; }
        }
    }
}