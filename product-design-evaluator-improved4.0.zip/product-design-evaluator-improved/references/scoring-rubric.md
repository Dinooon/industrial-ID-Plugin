# Concept Design Scoring Rubric

Use this 100-point rubric for enterprise internal concept-stage reviews. Emphasize direction, brand fit, visible concept quality, and risk discovery. Do not overweight late-stage engineering feasibility.

| Dimension | Points | Evaluate |
|---|---:|---|
| User scenario and concept direction fit | 15 | Target user clarity, scenario credibility, design intent, problem-solution match |
| Form proportion and product recognizability | 15 | Silhouette, volume balance, visual hierarchy, iconicity, category recognizability |
| Brand design language consistency | 20 | Brand family fit, proportion language, feature lines, interaction-area expression, CMF consistency, price-tier expression |
| CMF and perceived quality | 12 | Material logic, finish contrast, color blocking, premium/utility cues, cleanliness, durability impression |
| Category-specific experience hypothesis | 12 | Whether the visible concept supports the category's core use assumptions |
| Interaction, ergonomics, and use-risk visibility | 10 | Touchpoints, handles, buttons, display areas, status feedback, safety cues, misuse risk |
| Innovation and differentiation | 8 | Meaningful novelty, non-generic expression, defensible difference from competitors |
| Early structure/process risk alerts | 3 | Visible assembly, parting, openings, mechanisms, manufacturing ambiguity, but only as an early warning |
| Proposal expression completeness | 5 | Multi-view completeness, rendering clarity, scale cues, scenario/context clarity |

## Rating Bands

- 90-100: Excellent concept direction. Ready for deeper refinement and validation.
- 80-89: Strong direction. Proceed with targeted revisions.
- 70-79: Viable but uneven. Needs visible correction before next gate.
- 60-69: Weak concept maturity. Rework core design logic.
- Below 60: Not recommended for continuation in current form.

## Confidence-Based Score Cap

When confidence is `Low` (limited image angles, missing brand/category context, no patent comparison basis, or text-only input), cap the final score at 79. Add a note: "评分受限于输入信息不足，补充材料后评分可能显著变化。" This prevents overconfident high scores when evidence is weak.

## Category Weight Adjustment

Different categories emphasize different aspects. Apply these adjustments to scoring emphasis (not to the point allocation, but to the rigor of evaluation):

**For cleaning appliances:**
- Weight maintenance visibility and clean/dirty separation more heavily in the "Category-specific experience" and "Interaction, ergonomics" dimensions.
- Penalize designs that hide maintenance access or mix clean/dirty zones visually.
- Reward clear service-part intentionality and base/accessory integration.

**For consumer electronics:**
- Weight interaction hierarchy and precision more heavily in the "Form proportion" and "Interaction, ergonomics" dimensions.
- Penalize designs with unclear interface zones or excessive decorative seams.
- Reward precise integration of functional openings and consistent edge language.

**For adjacent or uncertain categories:**
- Use a general evaluation without category-specific emphasis.
- Note in the report which category-specific criteria were not applied.

## Scoring Examples

Use these examples to calibrate scoring consistency:

**User scenario and concept direction fit:**
- High score example: Target user (young urban renter) and scenario (small apartment daily cleaning) are clearly addressed; the concept solves a specific storage and quick-deploy problem.
- Low score example: The concept could serve many users and scenarios without clear focus; no specific problem-solution match is visible.

**Form proportion and product recognizability:**
- High score example: Clean D-shaped silhouette with balanced sensor tower; immediately recognizable as a premium robot vacuum from three-quarter view.
- Low score example: Ambiguous shape that could be any category; no memorable or iconic visual signature.

**Brand design language consistency:**
- High score example: Proportion language, radius system, and CMF treatment clearly extend the brand family; a customer could identify the brand without a logo.
- Low score example: The product could belong to many brands; dominant features resemble a competitor more than the stated brand.

**CMF and perceived quality:**
- High score example: Material hierarchy is logical (soft-touch handle, matte body, glossy accent); finish contrast reinforces premium positioning.
- Low score example: Random material choices without hierarchy; finish level does not match the implied price tier.

**Category-specific experience hypothesis:**
- High score example (floor washer): Handle angle, tank visibility, and roller access all support credible cleaning use; maintenance sequence is readable.
- Low score example (floor washer): Attractive shell but tank removal path is unclear; cleaning interface appears secondary.

**Interaction, ergonomics, and use-risk visibility:**
- High score example: Button placement follows natural thumb position; status LEDs are visible from normal use posture; misuse risk is minimized through form.
- Low score example: Controls are hidden or ambiguous; no visible feedback for key states; form invites incorrect grip.

**Innovation and differentiation:**
- High score example: A novel docking architecture that is both functional and brand-distinctive; no direct competitor uses this approach.
- Low score example: Generic category form with no defensible visual difference from market leaders.

**Early structure/process risk alerts:**
- High score example: Parting lines are intentional and minimal; assembly logic is visible and clean; no manufacturing red flags.
- Low score example: Complex multi-part shell with ambiguous seams; visible mechanisms suggest assembly difficulty.

**Proposal expression completeness:**
- High score example: Multiple clear views (front, side, three-quarter, detail); scale cues present; usage context shown.
- Low score example: Single ambiguous view; no scale reference; rendering obscures key features.

## Scoring Discipline

- Assign each dimension a numeric score and one sentence of evidence.
- Penalize missing evidence only when that missing information materially blocks judgment.
- Use confidence labels for each major judgment: high, medium, or low.
- Keep comments specific: name the exact silhouette, split line, interface zone, CMF decision, handle, dock, sensor zone, screen area, or accessory causing the score.
- When a dimension score is below 60% of its maximum, the evidence sentence must explicitly state what is wrong and what would need to change.
- **Recognition verification impact**: If a core visual attribute was misidentified during initial analysis and later corrected, all dimension scores must be recalculated. Common impacts:
  - Body shape correction (e.g., D-shaped → round) significantly affects "Form proportion and product recognizability" and "Brand design language consistency" scores.
  - Navigation sensor correction (e.g., has LiDAR → no LiDAR) affects "Category-specific experience hypothesis" and "Innovation and differentiation" scores.
  - Material finish correction affects "CMF and perceived quality" score.
- **Evidence text must be in Chinese** (one sentence per scoring row), using only brand names and technical terms in English as permitted by SKILL.md Language Rules.
