# Image Acquisition Guide For Patent/Design Comparison

This guide describes strategies for obtaining real competitor product images and patent drawings to include in the patent/design risk comparison section of the evaluation report. Always follow the confidentiality rules in SKILL.md — do not include confidential product names or brand identifiers in external search queries.

## Acquisition Priority

Use these sources in priority order. Move to the next source only if the previous one fails:

1. **User-provided images** — If the user supplies competitor reference images or patent drawings, use those directly.
2. **Company internal patent pool** — If the user confirms access to an internal patent database, use it for authoritative comparison.
3. **Official patent databases** — Search CNIPA, Espacenet, WIPO Hague Express, Google Patents for design drawings.
4. **Official brand websites** — Download product images from manufacturer official sites (e.g., eufy.com, roborock.com, ecovacs.com).
5. **E-commerce product pages** — Amazon, JD.com, Tmall product listing images (may have anti-scraping protections).
6. **Web search image results** — Use web search tools to find publicly available product images.
7. **SVG schematic fallback** — When all real-image sources fail, generate SVG schematic illustrations that represent the key visual features of each comparison object.

## Web Scraping Strategy

### Direct Download (curl/wget)

```bash
# Try direct download with timeout and user-agent
curl --connect-timeout 5 --max-time 10 -L -o output.jpg "IMAGE_URL" \
  -H "User-Agent: Mozilla/5.0" \
  -H "Accept: image/*"
```

**Limitations**: Many e-commerce and brand websites block direct curl/wget downloads via:
- SSL/TLS certificate pinning
- Anti-bot protection (Cloudflare, etc.)
- Rate limiting
- Redirect loops
- HTML responses instead of images

### Using Web Reader Tools

Use `info_reader_web` to fetch web page content, then extract image URLs from the returned HTML/markdown. This bypasses some anti-scraping measures because the tool renders pages server-side.

**Steps:**
1. Fetch the product page URL using `info_reader_web`.
2. Parse the returned content for image URLs (look for `img` tags, CDN paths, or `src` attributes).
3. Attempt to download the extracted image URLs using `curl`.
4. Validate downloaded files using `file` command to confirm they are actual images (not HTML error pages).

### Using Web Search Tools

Use `info_search_web` with generic category terms (not brand/product names for confidentiality):

```
Search query: "robot vacuum round black design" (generic, no brand names)
Search query: "扫地机器人 圆形 黑色 外观设计" (Chinese generic terms)
```

Extract image URLs from search results and attempt download.

## Image Processing

After downloading images:

1. **Validate**: Use `file` command to confirm the file is a valid image format (JPEG, PNG, WebP).
2. **Resize**: Use Python PIL/Pillow to resize large images to max 800x800px for embedding.
3. **Convert to base64**: Convert to base64 data URI for self-contained HTML embedding.
4. **Store**: Save processed images in a temporary `compare_images/` directory during report generation, then clean up after the report is generated.

```python
from PIL import Image
import base64, io

def process_image(filepath, max_size=800):
    """Resize and convert image to base64 data URI."""
    img = Image.open(filepath)
    img.thumbnail((max_size, max_size), Image.LANCZOS)
    buf = io.BytesIO()
    img.save(buf, format='PNG', optimize=True)
    b64 = base64.b64encode(buf.getvalue()).decode()
    return f"data:image/png;base64,{b64}"
```

## SVG Schematic Fallback

When real images cannot be obtained, generate SVG schematic illustrations that represent the key visual features of each comparison object. These are stylized representations, not exact copies.

### Mandatory Reference Link Rule

**When SVG schematics are used instead of real images, each comparison card MUST include a clickable reference URL** that allows the reader to jump directly to the competitor's product page or patent database entry to view the real product image.

The reference link must be:
- A publicly accessible URL (official brand product page, e-commerce listing, or patent database entry).
- Displayed as a clickable hyperlink in the comparison card, positioned below the SVG schematic.
- Labeled clearly, e.g., "查看实物图片 →" or "点击查看产品页面 →".
- Validated to the extent possible (the URL should point to a known, stable product page).

If a reference URL cannot be found for a specific comparison object, the card must state: "暂无公开链接，建议手动检索竞品实物图片。"

This rule ensures that even when the report uses SVG schematics (due to network restrictions or anti-scraping), the reader can still access real product images for precise visual comparison by following the link.

### SVG Generation Guidelines

- Use a consistent 300x280 viewBox for all schematics.
- Use a neutral light gray background (#f5f5f5).
- Represent the product's core silhouette shape (circle, D-shape, rectangle, etc.).
- Include key features (sensor tower, button, logo position, screen, etc.).
- Add a text annotation at the bottom describing the key visual characteristics.
- Convert SVG to base64 data URI: `data:image/svg+xml;base64,{base64_encoded_svg}`

### SVG Templates

Create reusable SVG templates for common product types:

- **Round robot vacuum**: Circle body, optional LiDAR tower, button, logo position.
- **D-shaped robot vacuum**: D-shape body, LiDAR tower, button, logo position.
- **Stick vacuum**: Vertical body, handle, motor housing, dustbin.
- **Floor washer**: Body, handle, tank, cleaning head.
- **Base station**: Rectangular/rounded body, screen, docking slot, logo.
- **Earbuds case**: Rounded rectangle, lid line, LED indicator.
- **Phone**: Rounded rectangle, camera module, screen area.

## Scripted Automation

When `scripts/fetch_competitor_images.py` is available, use it to automate the image acquisition process:

```bash
python scripts/fetch_competitor_images.py \
  --category "robot-vacuum" \
  --output-dir compare_images/ \
  --format base64
```

The script will:
1. Attempt to download real images from official brand websites and e-commerce pages.
2. Fall back to SVG schematic generation if downloads fail.
3. Return a JSON file with base64-encoded image data URIs for each comparison object.

## Confidentiality Compliance

- **Never** include the confidential product name, project codename, or brand identifier in any external search query or URL.
- Use generic category descriptions: "robot vacuum round design" instead of "[brand] [model] robot vacuum".
- When downloading from brand websites, access the public product page directly — do not transmit confidential input images or details.
- The `compare_images/` directory is temporary and should be cleaned up after report generation. Do not persist competitor images in the skill directory.

## Error Handling

If all image acquisition methods fail:
1. Generate SVG schematics for all comparison objects.
2. **For each comparison object, include a reference URL** to the competitor's product page or patent database entry. Use `info_reader_web` to fetch product page URLs from official brand websites — even if images cannot be downloaded, the page URLs themselves are valuable for the reader.
3. Note in the report: "由于网络限制无法获取竞品实物图片，使用示意图进行比对。点击各对比卡中的链接可查看竞品实物图片。建议在后续评审中补充实物图片。"
4. Do not leave any comparison card without a visual element.
5. Do not leave any SVG comparison card without a reference link.
