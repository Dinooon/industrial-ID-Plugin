# Quality Gate And Acceptance Criteria

Run this gate before delivering a report. Do not deliver final output until all Critical checks pass or unresolved gaps are explicitly disclosed.

Checks are divided into **Critical** (must pass before delivery) and **Recommended** (should pass, but non-blocking with disclosed caveat).

## Critical Checks (Must Pass)

- The report states whether multiple images are the same product, different states, variants, accessories, or separate concepts.
- Final scoring does not proceed until the intake gate is complete or assumptions are explicitly accepted and labeled.
- The report lists all material assumptions and distinguishes them from confirmed facts.
- The report asks for missing information that images cannot show.
- The report does not force category-specific scoring when product category is uncertain.
- The report includes design score, brand-language score, confidence level, and decision label.
- The report includes evidence for each score instead of only numeric ratings.
- The user-facing report does not include task boundaries, risk-boundary boilerplate, execution trace, human review workflow, or quality-gate process details.
- Task boundaries, risk boundaries, execution trace, human review workflow, and quality-gate details are saved in a separate developer log when a report is generated.
- The report includes an appearance patent/design-risk section or explicitly states why patent risk was not assessed.
- Patent/design risk is expressed qualitatively, not as a numeric score.
- The report includes next-round recommendations ordered by priority.
- The report includes visible feedback controls: `满意`, `一般`, `不满意`, and a short comment field.
- When an HTML report is expected, the HTML file exists and contains all required sections.
- The final verdict and next action are visually prominent above the fold.
- Patent-risk language does not sound like legal advice (no "definitely infringing", "legally safe", "patent invalid", or "no risk").
- If confidence is Low, the final score is capped at 79 and a note explains the cap.
- The report includes a version number in the header.
- Confidential product names or identifying details are not present in any external search query or tool call log.
- **The report embeds the original product image(s) being reviewed** in a dedicated section near the top, as base64 data URIs or accessible file paths.
- **The report includes a "已确认信息" (confirmed facts) section** listing all confirmed attributes and context.
- **The report includes a "待确认事项" (needs confirmation) section** listing all items requiring user confirmation, with impact notes.
- **All user-facing text is in Chinese** except brand names, technical terms, model numbers, and acronyms as defined in SKILL.md Language Rules.
- **Each patent/design comparison card includes a visual element** (real image, SVG schematic, or explicit placeholder with source note).
- **SVG comparison cards include a reference URL** — when SVG schematics are used instead of real images, each card must include a clickable link to the competitor's product page or patent database entry, labeled "查看实物图片 →". If no URL is available, the card must state "暂无公开链接，建议手动检索竞品实物图片。"
- **The report includes a "产品图片" (product image) section** between the header/KPIs and the executive summary.

## Recommended Checks (Should Pass)

- The executive summary is concise: no more than 3 bullets or one short paragraph.
- Patent/design comparison objects include image thumbnails when available, or a clear placeholder/source note when unavailable.
- If a frontend/report design skill was used, the user-facing report preserves all frozen evaluation content without changing scores, risk levels, assumptions, recommendations, or legal-risk wording.
- If a frontend/report design skill was unavailable, the developer log states that the local template/report UI guidelines were used as fallback.
- The report file name follows the convention: `design-review_{product-name-or-identifier}_{YYYY-MM-DD}.html`.
- The developer log includes version and iteration tracking fields.
- Image quality issues are noted where relevant views were excluded from scoring.
- If this is an iteration, the report references prior findings and highlights what changed.
- **List items in the report are concise**: each item is one sentence, maximum two. No dense paragraphs in list sections.
- **Scoring evidence text is one sentence per row** — no multi-sentence explanations.
- **Comparison images are real photos when obtainable**; SVG schematics are used as fallback; the report notes which type was used.
- **SVG comparison cards include reference links** — each SVG fallback card has a clickable "查看实物图片 →" link or an explicit "暂无公开链接" note.

## Automated Verification

When `scripts/quality_check.py` is available, run it to automate the following checks:

- HTML file exists and is well-formed.
- All required report sections are present (verdict, KPIs, executive summary, input confirmation, findings, brand language, scoring table, patent risk, recommendations, materials, feedback).
- Feedback buttons (`满意`, `一般`, `不满意`) are present in the HTML.
- No developer-log content (execution trace, quality-gate process, task boundaries) appears in the HTML.
- Patent risk is expressed as a qualitative label, not a numeric score.
- Version number is present in the header.

Run the script after generating the report:

```bash
python scripts/quality_check.py <report-html-path>
```

If the script is unavailable, perform these checks manually.

## Independent Review

For substantial reviews, use an independent subagent/reviewer when available.

Prompt pattern:

`Use $product-design-evaluator at <skill path> to review the generated report at <report path> against references/quality-gate.md. Check whether it responsibly handles image relationship, missing information, category uncertainty, brand-language evidence, risk boundaries, and HTML completeness. Return only pass/fail findings and required revisions. Use this checklist format:`

```json
{
  "critical_checks": [
    {"check": "check description", "result": "pass|fail", "evidence": "what was found"}
  ],
  "recommended_checks": [
    {"check": "check description", "result": "pass|fail|n/a", "evidence": "what was found"}
  ],
  "required_revisions": ["list of required fixes"],
  "overall": "pass|fail"
}
```

Do not tell the reviewer the intended score or desired conclusion.

If subagents are unavailable, run a self-review against the same checklist and state: `Independent subagent review unavailable; self-review completed.`

## Fail Conditions

Revise before delivery if any of these occur:

- Any Critical check fails.
- Category is selected without confirmation or clear visual basis.
- Missing information is not requested.
- Images are merged without confirming their relationship.
- Patent-risk language sounds like legal advice.
- Patent/design risk uses a numeric score.
- HTML report is promised but not created.
- Report lacks evidence for scores.
- Report lacks feedback controls.
- User-facing report includes process/audit material that belongs in the developer log.
- Low confidence score exceeds 79 without a cap note.

## Delivery Standard

The final chat response should include:

- Where the HTML report is saved, if generated.
- The overall score and decision.
- Any quality-gate caveat (e.g., "Recommended check X did not pass: [reason]").
- The feedback question for improving the next version.
