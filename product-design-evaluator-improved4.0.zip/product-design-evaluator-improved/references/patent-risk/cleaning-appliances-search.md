# Cleaning Appliance Patent Search Guidance

Use this guidance when screening robot vacuums, floor washers, vacuum cleaners, mite removers, window cleaners, cleaning bases, docks, and accessories.

## Search Keywords

Use Chinese and English terms as needed. Use generic category terms only; do not include brand or product names in search queries to maintain confidentiality:

- 扫地机器人, 清洁机器人, 拖地机器人, 洗地机, 吸尘器, 手持吸尘器, 无线吸尘器, 除螨仪, 擦窗机器人
- 基站, 清洁基站, 充电座, 自动集尘, 水箱, 尘盒, 滚刷, 吸嘴, 地刷, 手柄
- robot vacuum, floor washer, wet dry vacuum, stick vacuum, handheld vacuum, mite remover, window cleaning robot, cleaning dock, base station

## Recommended Databases

- **China**: CNIPA Patent Search (http://pss-system.cponline.cnipa.gov.cn) — search by Locarno Classification for cleaning appliance categories.
- **International**: Espacenet (https://worldwide.espacenet.com), WIPO Hague Express (https://www3.wipo.int/hague/en/).
- **Company internal**: Prioritize company-internal patent pools and prior design files when available.

## Compare These Features

- Overall body plan: round, D-shaped, tower, stick, canister, capsule, rectangular dock, vertical dock.
- Cleaning interface: roller, mop pad, suction opening, brush guard, edge-cleaning feature.
- Maintenance interface: tank/dustbin removal, filter door, dirty-water zone, release buttons.
- Dock/base station: footprint, tower height, lid, water/dust exchange zones, docking posture.
- Handle and grip: line, angle, trigger/control placement, battery/weight distribution.
- Sensor/navigation zones: bumper, LiDAR, camera, edge sensor, window suction pads.
- CMF hygiene cues: clean/dirty separation, translucent tanks, white/black contrast, water-contact color coding.

## Common High-Risk Patterns

- Round robot vacuum with identical top sensor placement and similar bumper segmentation.
- Floor washer body with matching tank split, handle line, and front cleaning-head silhouette.
- Dock/base station with closely matching front door, lid, and product docking posture.
- Stick vacuum with highly similar motor/battery/handle massing and dustbin orientation.

## Design-Around Levers

- Change the dominant silhouette and massing relationship, not only small surface details.
- Reposition or redesign highly visible service zones.
- Alter docking posture and base-station architecture.
- Redefine clean/dirty separation through new visual hierarchy.
- Create a distinctive cleaning-interface expression that remains functionally credible.

## Comparison Image Acquisition

For each comparison object, obtain a visual reference following `references/image-acquisition-guide.md`:

1. **Try real images first**: Download from official brand websites, e-commerce pages, or patent databases.
2. **Use web reader tools**: Fetch product pages to extract image URLs, then download.
3. **Fall back to SVG schematics**: Generate stylized illustrations representing the key visual features of each comparison object type.
4. **Never leave a comparison card without a visual**: Every card must have either a real image, an SVG schematic, or a clearly labeled placeholder with source note.
5. **Include reference links**: When SVG schematics are used, each card MUST include a clickable URL ("查看实物图片 →") to the competitor's product page or patent database entry.

Common comparison object types for cleaning appliances and their SVG templates:
- Round robot vacuum (with/without LiDAR tower)
- D-shaped robot vacuum
- Base station / charging dock
- Stick/handheld vacuum
- Floor washer

Use `scripts/fetch_competitor_images.py` to automate this process.

## Search Result Format

Format each search result for the report:

```
Comparison Object [N]:
- Name/Title: [patent title or generic product description]
- Source: [database, URL, or "user-provided"]
- Reference URL: [clickable link to product page or patent entry, for SVG fallback cards]
- Patent Number: [number, or "not available"]
- Legal Status: [active / expired / unknown]
- Category: [Locarno class, or "not available"]
- Thumbnail: [image, or "image unavailable"]
- Similar Points: [list]
- Different Points: [list]
- Risk Rationale: [explanation]
```
