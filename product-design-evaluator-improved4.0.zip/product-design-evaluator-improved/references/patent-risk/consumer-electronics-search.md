# Consumer Electronics Patent Search Guidance

Use this guidance when screening phones, earbuds, headphones, speakers, wearables, smart desktop devices, handheld electronics, connected hardware, cases, docks, and accessories.

## Search Keywords

Use Chinese and English terms as needed. Use generic category terms only; do not include brand or product names in search queries to maintain confidentiality:

- 手机, 平板, 耳机, 蓝牙耳机, 头戴耳机, 音箱, 智能手表, 智能手环, 智能戒指, 摄像头, 智能音箱, 充电盒, 充电座
- phone, tablet, earbuds, headphones, speaker, wearable, smartwatch, smart ring, smart band, charging case, dock, smart hub, camera

## Recommended Databases

- **China**: CNIPA Patent Search (http://pss-system.cponline.cnipa.gov.cn) — search by Locarno Classification for consumer electronics categories.
- **International**: Espacenet (https://worldwide.espacenet.com), WIPO Hague Express (https://www3.wipo.int/hague/en/).
- **Company internal**: Prioritize company-internal patent pools and prior design files when available.

## Compare These Features

- Main geometry: slab, capsule, pebble, cylinder, puck, band, ring, shell, clamshell.
- Dominant face: screen, grille, camera/sensor array, button/touch area, LED zone.
- Edge and corner language: radius size, chamfer, layered frame, raised rim, continuous glass, metal band.
- Openings and details: speaker holes, mic holes, port, hinge, strap lug, charging contacts.
- Accessory logic: case, dock, charging cradle, straps, cable exits, lid expression.
- Wear/hold/contact surfaces: ear tips, headband, wrist underside, palm grip, desk contact area.

## Common High-Risk Patterns

- Earbud stem/body/case proportions strongly matching a market leader.
- Phone or wearable front layout with close camera/sensor/screen arrangement.
- Speaker grille pattern and cylindrical proportion closely matching an active design.
- Charging case with matching hinge, lid split, cavity layout, and front indicator placement.

## Design-Around Levers

- Redesign the dominant front or top view, not only rear details.
- Change the relationship between body, interface zone, and accessory.
- Rework the recognizable edge/radius system.
- Create a brand-specific detail hierarchy for openings and controls.
- Ensure the product remains clearly different from competitor hero products in normal viewing angles.

## Comparison Image Acquisition

For each comparison object, obtain a visual reference following `references/image-acquisition-guide.md`:

1. **Try real images first**: Download from official brand websites, e-commerce pages, or patent databases.
2. **Use web reader tools**: Fetch product pages to extract image URLs, then download.
3. **Fall back to SVG schematics**: Generate stylized illustrations representing the key visual features of each comparison object type.
4. **Never leave a comparison card without a visual**: Every card must have either a real image, an SVG schematic, or a clearly labeled placeholder with source note.
5. **Include reference links**: When SVG schematics are used, each card MUST include a clickable URL ("查看实物图片 →") to the competitor's product page or patent database entry.

Common comparison object types for consumer electronics and their SVG templates:
- Phone (rounded rectangle, camera module, screen area)
- Earbuds case (rounded rectangle, lid line, LED indicator)
- Headphones (headband, ear cups)
- Speaker (cylinder, grille pattern)
- Smartwatch (rounded square, band attachments)

Use `scripts/fetch_competitor_images.py` to automate this process.

## Search Result Format

Format each search result for the report:

```
Comparison Object [N]:
- Name/Title: [patent title or generic product description]
- Source: [database, URL, or "user-provided"]
- Reference URL: [clickable link to product page or patent entry, for SVG fallback cards]
- Patent Number: [number, or "not available"]
- Legal Status: [active / expired / unknown]
- Category: [Locarno class, or "not available"]
- Thumbnail: [image, or "image unavailable"]
- Similar Points: [list]
- Different Points: [list]
- Risk Rationale: [explanation]
```
