# Changelog — v2.2.0

**Date**: 2026-07-07  
**Version**: 2.2.0  
**Based on**: 头戴式耳机设计方案评审（苹果品牌设计语言一致性评估）反馈

## 问题背景

在头戴式耳机评审报告中，由于沙盒环境的网络限制（搜索额度耗尽、SSL/TLS 超时、反爬保护），无法下载真实竞品产品图片作为专利对比参考。最终使用了4个SVG风格化示意图作为替代方案，但读者无法直接跳转查看竞品实物图片，降低了对比卡片的实用价值。

## 改进内容

### 1. SVG 对比卡强制附带竞品链接规则

**新增规则**：当SVG示意图被用作对比图片的替代方案时，每个对比卡必须附带一个可点击的竞品参考链接，格式为"查看实物图片 →"。该链接指向竞品的官方产品页面或专利数据库条目，使读者能够直接跳转查看实物图片。

- 如果无法找到公开链接，对比卡须标注"暂无公开链接，建议手动检索竞品实物图片。"
- 此规则确保即使因技术限制无法嵌入真实图片，读者仍可通过链接快速访问竞品实物图片。

**涉及文件**：
- `references/image-acquisition-guide.md` — 新增 "Mandatory Reference Link Rule" 章节
- `references/patent-risk/risk-rubric.md` — Comparison Image Rule 增加链接要求
- `references/patent-risk/consumer-electronics-search.md` — 对比卡格式增加 Reference URL 字段
- `references/patent-risk/cleaning-appliances-search.md` — 对比卡格式增加 Reference URL 字段
- `SKILL.md` — Patent Comparison Images 规则和 Workflow Step 6 更新

### 2. fetch_competitor_images.py 脚本增强

- 新增 `extract_product_page_urls()` 函数：通过 curl 获取品牌产品页面 HTML，提取稳定的页面 URL（即使图片下载失败，页面 URL 本身仍有参考价值）
- 输出格式从 `{key: base64_uri}` 升级为 `{key: {image, source_url, source_type, source_note}}`
- 每个对比对象现在携带 `source_url`（参考链接）和 `source_type`（real/svg）字段

### 3. 质量门禁新增检查项

- **新增 Critical 检查**（第18项）：SVG 对比卡必须包含参考链接（"查看实物图片"或"暂无公开链接"）
- **新增 Recommended 检查**（第9项）：SVG 对比卡参考链接验证
- 总计：18 Critical + 9 Recommended

**涉及文件**：`references/quality-gate.md`、`scripts/quality_check.py`

### 4. 当前报告更新

已为头戴式耳机评审报告的4个SVG对比卡分别添加了竞品参考链接：
- 苹果 AirPods Max → https://www.apple.com/airpods-max/
- Sony WH-1000XM5 → https://www.sony.com/electronics/headband-headphones/wh-1000xm5
- Bose NC700 → https://www.bose.com/en_us/products/headphones/over_ear_headphones.html
- Beats Studio → https://www.beatsbydre.com/headphones/studio

报告版本更新为 v1.1，专利部分说明文字更新为引导读者点击链接查看实物图片。

## 验证结果

- 技能文件验证：30/30 必需文件全部通过
- 报告质量门禁：18/18 Critical 全部通过，7/8 Recommended 通过
- SVG 对比卡链接：4/4 对比卡均包含"查看实物图片 →"链接
