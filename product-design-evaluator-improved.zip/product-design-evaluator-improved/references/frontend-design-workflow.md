# Frontend Design Workflow

Use this workflow after product-design evaluation content is frozen and before creating or polishing an HTML report.

This reference adapts the local `frontend-design` skill from `C:\Users\DINO\Documents\Codex\2026-07-06\sh\skills\frontend-design` for the Product Design Evaluator workflow. The source skill is provided under Apache License 2.0; a copy is preserved at `LICENSE.frontend-design.txt`.

## Role

Treat the report presentation as a deliberate design pass, not template decoration. Give the report a visual identity that fits the product category, brand context, and review purpose while preserving the quiet, decision-focused character of an internal enterprise review.

## Boundaries

- Do not change frozen evaluation content: verdict, scores, evidence, confidence, assumptions, patent/design-risk level, legal-risk wording, recommendations, or missing-material requests.
- Do not invent product facts, user research, market context, image details, patent references, or brand rules.
- Keep all user-facing report text in Chinese unless the user requested another language.
- Do not depend on remote scripts, CDNs, remote fonts, or network-only assets unless the user explicitly allows them.
- Keep process notes, design-plan notes, and self-critique out of the user-facing report. Record them in the developer log.

## Inputs

Use the frozen handoff pack from `references/report-rendering-handoff.md` plus:

- Product category and subcategory.
- Visible product materials, surfaces, colors, proportions, and interaction points.
- Brand or series cues confirmed by the user.
- Patent/design-risk level and confidence level, for status treatment only.
- Original product images and comparison thumbnails or schematics.

If the subject is under-specified, choose a concrete presentation subject from confirmed facts only, then record that choice as a presentation assumption in the developer log.

## Two-Pass Design Process

### 1. Plan the direction

Create a compact design plan before writing HTML/CSS:

- **Color**: 4-6 named hex tokens grounded in the product category, CMF cues, and status semantics. Avoid a one-note palette.
- **Type**: define display, body, and utility roles. Use system or bundled fonts unless local project assets provide more specific options.
- **Layout**: state the layout concept in one sentence. Keep the required report section order, but tune hierarchy, density, tables, and comparison cards.
- **Signature**: choose one memorable element tied to the subject, such as a product-view strip, silhouette-based divider, risk rail, material swatch row, or comparison-lens treatment.
- **Risk**: take one justified aesthetic risk that serves the subject, then keep surrounding UI disciplined.

### 2. Critique the plan before building

Check whether the plan could have been produced for any generic design report. Revise if it leans on default AI-design looks:

- Warm cream background plus high-contrast serif plus terracotta accent.
- Near-black page plus a single acid accent.
- Broadsheet-style hairline grid with dense newspaper columns.
- Big KPI cards, gradient accents, and decorative numbers without content reason.

Use these looks only when the brief or product subject truly calls for them. Spend boldness in one place and remove decoration that does not clarify the review.

### 3. Build the report

- Preserve the report order from `SKILL.md` and `references/report-ui-guidelines.md`.
- Use CSS custom properties for all color tokens.
- Keep stable dimensions for product images, comparison cards, score tables, badges, and feedback controls.
- Include responsive layout, visible focus states, reduced-motion handling, print styles, and dark-mode support.
- Use inline CSS and vanilla JavaScript for a self-contained HTML report.
- Ensure text does not overflow buttons, badges, cards, tables, or mobile layouts.
- Avoid nested cards and ornamental backgrounds that compete with product images.
- Use product images and comparison visuals as primary visual evidence, not as vague atmosphere.

## Writing Pass

Treat interface copy as part of the design:

- Use plain Chinese labels that name what the user controls or needs to decide.
- Use consistent action vocabulary across buttons, feedback states, and saved messages.
- Keep labels, captions, risks, and recommendations concise.
- For errors or missing information, state what is missing and how it affects the review.

## Visual QA

Before delivery, verify:

- The first viewport clearly shows verdict, version, next action, score, brand fit, patent/design-risk level, and confidence.
- The product image section is visible near the top and images are not distorted.
- Patent/design comparison cards include a visual element and source note; SVG/placeholder cards also include a visible source/detail/image lookup link.
- Mobile layout stacks cleanly without overlapping or truncated text.
- Print and dark-mode styles preserve contrast and report structure.
- The developer log records the design plan, self-critique result, and whether a separate frontend-design skill or only this integrated workflow was used.
