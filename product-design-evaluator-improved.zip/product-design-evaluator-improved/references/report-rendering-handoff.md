# Report Rendering Handoff

Use this reference when the final HTML report should be visually polished by a frontend/report design skill such as `frontend-design` or similar capability.

## Integration Rule

- Use frontend/report design only after the product-design evaluation content is frozen.
- Always load `references/frontend-design-workflow.md` before building or handing off the final HTML presentation.
- The product-design evaluator owns: conclusions, scores, evidence, assumptions, brand-language judgment, patent/design-risk level, legal-risk wording, recommendations, and missing-material requests.
- The frontend/report design skill owns: information hierarchy, layout, typography, spacing, responsive behavior, accessible components, visual emphasis, and HTML/CSS polish.
- If no frontend/report design skill is available, fall back to `assets/report-template.html` and `references/report-ui-guidelines.md`. Consider using `scripts/generate_report.py` to automate template variable replacement.

## Frozen Handoff Pack

Pass a structured handoff pack. The pack can be provided as a JSON object for programmatic processing:

```json
{
  "project_title": "string",
  "date": "YYYY-MM-DD",
  "version": "v1.0",
  "product_category": "string",
  "target_brand_language": "string",
  "target_jurisdiction": "string",
  "confidence": "High|Medium|Low",
  "product_image": "string (base64 data URI of the product image being reviewed)",
  "input_images": [
    {"path": "string", "caption": "string", "relationship": "string"}
  ],
  "image_relationship": "string",
  "verdict": "string",
  "decision_label": "Proceed|Proceed with revisions|Rework direction|Hold for IP/legal review",
  "next_action": "string",
  "design_score": "string (e.g., '85/100')",
  "brand_language_score": "Strong|Moderate|Weak|Contradictory",
  "patent_risk_level": "未评估|低|中|中高|高|极高",
  "executive_summary": ["bullet 1", "bullet 2", "bullet 3"],
  "confirmed_facts": ["string"],
  "assumptions": ["string"],
  "needs_confirmation": ["string"],
  "strengths": ["string (concise, one sentence each)"],
  "concerns": ["string (concise, one sentence each)"],
  "top_risks": ["string"],
  "brand_language_review": "string",
  "brand_language_reason": "string",
  "scoring_rows": [
    {"dimension": "string", "score": number, "max": number, "evidence": "string (one sentence, in Chinese)"}
  ],
  "patent_comparison_cards": [
    {
      "object_name": "string",
      "source": "string",
      "visual_type": "real|patent_drawing|svg_schematic|placeholder",
      "thumbnail": "string (base64 data URI: real image, patent drawing, SVG schematic, or empty for placeholder)",
      "comparison_url": "string (public patent/detail/product/search URL; required for svg_schematic or placeholder)",
      "image_reference_url": "string or null (direct image/source URL when different from comparison_url)",
      "similar_points": ["string (concise)"],
      "different_points": ["string (concise)"],
      "risk_rationale": "string"
    }
  ],
  "recommendations": ["string (concise, one sentence each)"],
  "next_round_materials": ["string"],
  "feedback_controls": {"options": ["满意", "一般", "不满意"], "comment_field": true},
  "developer_log_path": "string or null"
}
```

## Frontend Design Constraints

The frontend/report design skill may:

- Reorganize visual hierarchy while preserving the required report section order.
- Improve typography, spacing, badges, tables, comparison cards, image treatment, and responsive layout.
- Replace weak styling with a clean enterprise report interface.
- Apply the local frontend-design workflow: subject-grounded color/type/layout choices, one justified signature element, and a pre-build self-critique against generic AI-design defaults.
- Add simple client-side behavior for feedback buttons or tabs.
- Add print optimization and dark mode support.
- Use inline CSS and vanilla JavaScript for a self-contained HTML report.

The frontend/report design skill must not:

- Change the verdict, scores, risk levels, confidence, assumptions, evidence, or recommendations.
- Turn patent/design-risk language into legal advice.
- Add numeric patent-risk scores.
- Put execution trace, quality-gate details, task boundaries, risk-boundary boilerplate, or human-review workflow into the user-facing report.
- Depend on external scripts, remote fonts, CDNs, or network-only assets unless the user explicitly allows it.
- Hide missing-information requests or risk caveats in low-visibility footnotes.

## Prompt Pattern

Use this pattern when handing off to a frontend/report design skill or subagent:

`Use frontend-design for the final HTML presentation of this frozen product-design evaluation. Do not change any substantive assessment content, scores, patent/design-risk level, confidence, assumptions, recommendations, or legal-risk wording. Produce a self-contained responsive HTML report using the provided image paths and source links. Include print optimization and dark mode support. Keep process/audit content out of the user-facing report. Return the HTML file path and any visual-quality caveats.`

Add this local workflow requirement when possible:

`Before writing HTML, follow references/frontend-design-workflow.md: create a compact subject-grounded design plan, critique it against generic AI-design defaults, revise if needed, then build from the revised plan. Record the plan and critique result in the developer log, not in the user-facing report.`

## Quality Checks

Before delivery, verify:

- The first viewport shows verdict, version, next action, design score, brand-language fit, patent/design-risk level, and confidence.
- The report remains concise and scannable for enterprise design review.
- Images render with stable dimensions and do not distort the product.
- Comparison objects include a thumbnail, schematic, or clear placeholder/source note.
- If a comparison object uses an SVG schematic or placeholder instead of a real image/patent drawing, the card includes a visible clickable `comparison_url` or `image_reference_url` so users can inspect the public reference.
- Feedback controls are visible and usable, with localStorage persistence.
- Print styles are present and produce a clean printed output.
- Dark mode renders correctly with sufficient contrast.
- Visual direction is grounded in the product/category subject rather than a generic report template.
- The developer log records the design plan and self-critique result.
- The developer log, not the user report, records whether frontend-design was used or unavailable.
