#!/usr/bin/env python3
"""
quality_check.py — Automated quality gate checker for Product Design Evaluator.

Verifies that an HTML report meets the Critical and Recommended quality-gate
checks defined in references/quality-gate.md.

Usage:
    python quality_check.py <report-html-path>

Exit codes:
    0 — All Critical checks passed
    1 — One or more Critical checks failed
"""

import re
import sys
from pathlib import Path


# Qualitative patent risk labels (numeric scores should NOT appear)
PATENT_RISK_LABELS = ["未评估", "低", "中", "中高", "高", "极高", "视觉相似信号"]

# Forbidden legal-advice language in patent-risk sections
FORBIDDEN_LEGAL_TERMS = [
    "definitely infringing", "legally safe", "patent invalid", "no risk",
    "肯定侵权", "法律安全", "专利无效", "无风险",
]

# Required report sections (by heading text)
REQUIRED_SECTIONS = [
    "评审结论", "执行摘要", "输入确认", "主要发现",
    "品牌设计语言一致性", "分项评分", "外观专利",
    "优先修改建议", "下次补充材料", "反馈",
]

# Content that should NOT appear in user-facing report
FORBIDDEN_IN_REPORT = [
    "execution trace", "quality-gate", "task boundar", "risk boundar",
    "human review workflow", "执行追踪", "质量门禁", "任务边界",
    "风险边界", "人工评审工作流",
]


def load_html(path: str) -> str:
    p = Path(path)
    if not p.exists():
        print(f"Error: Report file not found: {path}", file=sys.stderr)
        sys.exit(1)
    return p.read_text(encoding="utf-8")


def check_critical(html: str) -> list:
    """Run all Critical checks. Returns list of (check_name, passed, evidence) tuples."""
    results = []

    # 1. Multiple image relationship stated
    has_image_relation = any(term in html for term in ["同一产品", "不同角度", "不同状态", "不同方案", "配件", "image relationship", "same product"])
    results.append(("Image relationship stated", has_image_relation,
                     "Found image relationship terms" if has_image_relation else "No image relationship language found"))

    # 2. Assumptions labeled
    has_assumptions = "假设" in html or "assumption" in html.lower()
    results.append(("Assumptions labeled", has_assumptions,
                     "Found assumption labeling" if has_assumptions else "No assumption labeling found"))

    # 3. Design score present
    has_score = bool(re.search(r"\d{1,3}\s*/\s*100", html))
    results.append(("Design score present", has_score,
                     "Found score in N/100 format" if has_score else "No score in N/100 format found"))

    # 4. Confidence level present
    has_confidence = any(term in html for term in ["High", "Medium", "Low", "高", "中", "低"])
    results.append(("Confidence level present", has_confidence,
                     "Found confidence label" if has_confidence else "No confidence label found"))

    # 5. Decision label present
    has_decision = any(term in html for term in ["Proceed", "Rework", "Hold", "通过", "返工", "暂缓"])
    results.append(("Decision label present", has_decision,
                     "Found decision label" if has_decision else "No decision label found"))

    # 6. Evidence for scores (check for text near score rows)
    has_evidence = "evidence" in html.lower() or "证据" in html or bool(re.search(r"font-size:13px.*?color:var\(--muted\)", html))
    results.append(("Evidence for scores", has_evidence,
                     "Found evidence text pattern" if has_evidence else "No evidence text pattern found"))

    # 7. Feedback controls present
    has_feedback = all(btn in html for btn in ["满意", "一般", "不满意"])
    results.append(("Feedback controls present", has_feedback,
                     "All three feedback buttons found" if has_feedback else "Missing feedback buttons"))

    # 8. Patent risk is qualitative (not numeric)
    # Check that patent risk section doesn't contain standalone numeric scores
    patent_section_match = re.search(r"外观专利.*?</section>", html, re.DOTALL)
    patent_section = patent_section_match.group(0) if patent_section_match else ""
    has_numeric_patent = bool(re.search(r"专利.*?\d{1,3}\s*分", patent_section))
    results.append(("Patent risk is qualitative", not has_numeric_patent,
                     "No numeric patent score found" if not has_numeric_patent else "Found numeric patent score"))

    # 9. No forbidden legal terms
    found_forbidden = [term for term in FORBIDDEN_LEGAL_TERMS if term in html.lower()]
    results.append(("No forbidden legal language", len(found_forbidden) == 0,
                     "No forbidden legal terms" if not found_forbidden else f"Found: {found_forbidden}"))

    # 10. Version number present
    has_version = bool(re.search(r"v\d+\.\d+", html))
    results.append(("Version number present", has_version,
                     "Found version number" if has_version else "No version number found"))

    # 11. No process/audit content in user report
    found_process = [term for term in FORBIDDEN_IN_REPORT if term.lower() in html.lower()]
    # Filter out the meta note which mentions "IP/法务" — that's acceptable
    found_process = [t for t in found_process if t not in ["risk boundar"]]
    results.append(("No process content in report", len(found_process) == 0,
                     "No process content found" if not found_process else f"Found: {found_process}"))

    # 12. All required sections present
    missing_sections = [s for s in REQUIRED_SECTIONS if s not in html]
    results.append(("All required sections present", len(missing_sections) == 0,
                     "All sections found" if not missing_sections else f"Missing: {missing_sections}"))

    # 13. Recommendations present
    has_recommendations = "建议" in html or "recommendation" in html.lower()
    results.append(("Recommendations present", has_recommendations,
                     "Found recommendations" if has_recommendations else "No recommendations found"))

    # 14. Product image embedded
    has_product_img = "data:image/png;base64," in html or "data:image/jpeg;base64," in html or "data:image/webp;base64," in html or "data:image/svg+xml;base64," in html
    has_product_section = "产品图片" in html or "product-showcase" in html
    results.append(("Product image embedded", has_product_img and has_product_section,
                     "Found embedded product image in product section" if has_product_img and has_product_section else "Missing product image or product section"))

    # 15. Confirmed facts section present
    has_confirmed = "已确认信息" in html or "confirmed_facts" in html.lower()
    results.append(("Confirmed facts section present", has_confirmed,
                     "Found confirmed facts section" if has_confirmed else "Missing confirmed facts section"))

    # 16. Needs confirmation section present
    has_needs_conf = "待确认事项" in html or "needs_confirmation" in html.lower() or "待确认" in html
    results.append(("Needs confirmation section present", has_needs_conf,
                     "Found needs-confirmation section" if has_needs_conf else "Missing needs-confirmation section"))

    # 17. Comparison cards have visual elements
    compare_cards = re.findall(r'<div class="compare-card">(.*?)</div>\s*</div>', html, re.DOTALL)
    has_compare_visuals = True
    if compare_cards:
        for card in compare_cards:
            has_img = "<img" in card or "data:image" in card or "image unavailable" in card.lower()
            if not has_img:
                has_compare_visuals = False
                break
    else:
        # If no compare cards, check if patent section has any images
        patent_section = re.search(r"外观专利.*?</section>", html, re.DOTALL)
        if patent_section:
            has_compare_visuals = "<img" in patent_section.group(0) or "data:image" in patent_section.group(0)
    results.append(("Comparison cards have visual elements", has_compare_visuals,
                     "All comparison cards have visual elements" if has_compare_visuals else "Some comparison cards lack visual elements"))

    return results


def check_recommended(html: str) -> list:
    """Run Recommended checks. Returns list of (check_name, passed, evidence) tuples."""
    results = []

    # Executive summary is concise (check for <li> count in summary section)
    summary_match = re.search(r"执行摘要.*?<ul[^>]*>(.*?)</ul>", html, re.DOTALL)
    if summary_match:
        li_count = len(re.findall(r"<li>", summary_match.group(1)))
        results.append(("Executive summary concise (≤3 bullets)", li_count <= 3,
                         f"Found {li_count} bullets" if li_count > 3 else f"Found {li_count} bullets (OK)"))
    else:
        results.append(("Executive summary concise (≤3 bullets)", False, "Executive summary section not found"))

    # Comparison thumbnails or placeholders
    has_comparison = "compare-card" in html or "compare-media" in html or "无比对对象" in html or "未评估" in html
    results.append(("Comparison thumbnails or placeholders", has_comparison,
                     "Found comparison cards or not-applicable note" if has_comparison else "No comparison handling found"))

    # File naming convention (check if <title> contains product name)
    has_title = bool(re.search(r"<title>.*?</title>", html))
    results.append(("Report has title", has_title,
                     "Found <title> tag" if has_title else "No <title> tag found"))

    # Print styles present
    has_print_css = "@media print" in html
    results.append(("Print optimization present", has_print_css,
                     "Found @media print styles" if has_print_css else "No print styles found"))

    # Dark mode support
    has_dark_mode = "prefers-color-scheme: dark" in html
    results.append(("Dark mode support", has_dark_mode,
                     "Found dark mode media query" if has_dark_mode else "No dark mode support found"))

    # localStorage for feedback
    has_localstorage = "localStorage" in html
    results.append(("Feedback localStorage persistence", has_localstorage,
                     "Found localStorage usage" if has_localstorage else "No localStorage usage found"))

    # Text conciseness: check that list items are not too long
    list_items = re.findall(r'<li[^>]*>(.*?)</li>', html, re.DOTALL)
    long_items = [item for item in list_items if len(item.strip()) > 300]
    results.append(("List items concise (≤300 chars)", len(long_items) <= 2,
                     f"Found {len(long_items)} long items" if long_items else "All list items concise"))

    # Comparison images are real or SVG (not just text placeholders)
    svg_count = html.count("data:image/svg+xml;base64,")
    real_img_count = html.count("data:image/png;base64,") + html.count("data:image/jpeg;base64,") + html.count("data:image/webp;base64,")
    has_any_comparison_img = (svg_count + real_img_count) > 0
    results.append(("Comparison images present (real or SVG)", has_any_comparison_img,
                     f"Found {real_img_count} real images, {svg_count} SVG schematics" if has_any_comparison_img else "No comparison images found"))

    return results


def main():
    if len(sys.argv) < 2:
        print("Usage: python quality_check.py <report-html-path>", file=sys.stderr)
        sys.exit(1)

    html_path = sys.argv[1]
    html = load_html(html_path)

    print("=" * 60)
    print("Product Design Evaluator — Quality Gate Check")
    print("=" * 60)
    print(f"\nReport: {html_path}\n")

    print("--- CRITICAL CHECKS ---\n")
    critical_results = check_critical(html)
    critical_pass = 0
    for name, passed, evidence in critical_results:
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"  {status} — {name}")
        print(f"         {evidence}")
        if passed:
            critical_pass += 1
    print(f"\n  Critical: {critical_pass}/{len(critical_results)} passed")

    print("\n--- RECOMMENDED CHECKS ---\n")
    recommended_results = check_recommended(html)
    recommended_pass = 0
    for name, passed, evidence in recommended_results:
        status = "✅ PASS" if passed else "⚠️  WARN"
        print(f"  {status} — {name}")
        print(f"         {evidence}")
        if passed:
            recommended_pass += 1
    print(f"\n  Recommended: {recommended_pass}/{len(recommended_results)} passed")

    print("\n" + "=" * 60)
    if critical_pass == len(critical_results):
        print("✅ ALL CRITICAL CHECKS PASSED — Report is ready for delivery.")
        sys.exit(0)
    else:
        failed = [name for name, passed, _ in critical_results if not passed]
        print(f"❌ {len(failed)} CRITICAL CHECK(S) FAILED:")
        for f in failed:
            print(f"   • {f}")
        print("\nRevise the report before delivery.")
        sys.exit(1)


if __name__ == "__main__":
    main()
