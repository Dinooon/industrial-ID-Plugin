# Collected Industrial Design Products - 2026-07-23

**Date:** 2026-07-23
**Total products:** 76
**Sources:** 7

## Summary by Source

| Source | Count |
|--------|-------|
| core77_awards | 15 |
| core77_blog | 12 |
| designboom_product | 15 |
| yanko_consumer_electronics | 8 |
| yanko_furniture | 8 |
| yanko_home | 10 |
| yanko_transportation | 8 |

## Product Details

### 1. DeFFs Diminutive Premium Pen

- **Source:** Core77 Blog
- **Source ID:** core77_blog
- **Page URL:** https://www.core77.com/posts/144823/DeFFs-Diminutive-Premium-Pen
- **Image URL:** https://s3files.core77.com/blog/images/lead_n_spotlight/1842555_lead_400_144823_.jpg

### 2. A Security Camera Designed to Indicate When Its Not Watching You

- **Source:** Core77 Blog
- **Source ID:** core77_blog
- **Page URL:** https://www.core77.com/posts/144821/A-Security-Camera-Designed-to-Indicate-When-Its-Not-Watching-You
- **Image URL:** https://s3files.core77.com/blog/images/lead_n_spotlight/1842530_lead_400_144821_.jpg

### 3. AIMs Deconstructed Kitchen Faucet

- **Source:** Core77 Blog
- **Source ID:** core77_blog
- **Page URL:** https://www.core77.com/posts/144819/AIMs-Deconstructed-Kitchen-Faucet
- **Image URL:** https://s3files.core77.com/blog/images/lead_n_spotlight/1842505_lead_400_144819_.jpg

### 4. John Mengs Found Object Cigar Ashtray

- **Source:** Core77 Blog
- **Source ID:** core77_blog
- **Page URL:** https://www.core77.com/posts/144807/John-Mengs-Found-Object-Cigar-Ashtray
- **Image URL:** https://s3files.core77.com/blog/images/lead_n_spotlight/1842390_lead_400_144807_.jpg

### 5. An Apple Vision Pro Seating Station at a Parisian Opera House

- **Source:** Core77 Blog
- **Source ID:** core77_blog
- **Page URL:** https://www.core77.com/posts/144806/An-Apple-Vision-Pro-Seating-Station-at-a-Parisian-Opera-House
- **Image URL:** https://s3files.core77.com/blog/images/lead_n_spotlight/1842363_lead_400_144806_.jpg

### 6. Announcing Fusion Forward Design for Home a New Competition from Core77 and Autodesk Fusion

- **Source:** Core77 Blog
- **Source ID:** core77_blog
- **Page URL:** https://www.core77.com/posts/144812/Announcing-Fusion-Forward-Design-for-Home-a-New-Competition-from-Core77-and-Autodesk-Fusion
- **Image URL:** https://s3files.core77.com/blog/images/lead_n_spotlight/1842604_lead_400_144812_.jpg

### 7. Humanoid Companion Robots are Launching This September

- **Source:** Core77 Blog
- **Source ID:** core77_blog
- **Page URL:** https://www.core77.com/posts/144775/Humanoid-Companion-Robots-are-Launching-This-September
- **Image URL:** https://s3files.core77.com/blog/images/lead_n_spotlight/1841981_lead_400_144775_.jpg

### 8. How to Unlock and Start Your Car When the Key Fob Battery is Dead

- **Source:** Core77 Blog
- **Source ID:** core77_blog
- **Page URL:** https://www.core77.com/posts/144717/How-to-Unlock-and-Start-Your-Car-When-the-Key-Fob-Battery-is-Dead
- **Image URL:** https://s3files.core77.com/blog/images/lead_n_spotlight/1841302_lead_400_144717_.jpg

### 9. The Killer App for Dog Bots Package Delivery

- **Source:** Core77 Blog
- **Source ID:** core77_blog
- **Page URL:** https://www.core77.com/posts/144756/The-Killer-App-for-Dog-Bots-Package-Delivery
- **Image URL:** https://s3files.core77.com/blog/images/lead_n_spotlight/1841660_lead_400_144756_.jpg

### 10. Snow Peaks Tiny LED Lantern

- **Source:** Core77 Blog
- **Source ID:** core77_blog
- **Page URL:** https://www.core77.com/posts/144751/Snow-Peaks-Tiny-LED-Lantern
- **Image URL:** https://s3files.core77.com/blog/images/lead_n_spotlight/1841618_lead_400_144751_.jpg

### 11. Striking Chinese Industrial Design Aulumus M10 Powerbank

- **Source:** Core77 Blog
- **Source ID:** core77_blog
- **Page URL:** https://www.core77.com/posts/144748/Striking-Chinese-Industrial-Design-Aulumus-M10-Powerbank
- **Image URL:** https://s3files.core77.com/blog/images/lead_n_spotlight/1841593_lead_400_144748_.png

### 12. Designs for Modular Homes that Disappear Into the Ground During Natural Disasters

- **Source:** Core77 Blog
- **Source ID:** core77_blog
- **Page URL:** https://www.core77.com/posts/144723/Designs-for-Modular-Homes-that-Disappear-Into-the-Ground-During-Natural-Disasters
- **Image URL:** https://s3files.core77.com/blog/images/lead_n_spotlight/1841376_lead_400_144723_.jpg

### 13. Core77 Design Awards Entry #400

- **Source:** Core77 Design Awards
- **Source ID:** core77_awards
- **Page URL:** https://designawards.core77.com/Apps-Platforms/142852/Future-Fizz
- **Image URL:** https://s3files.core77.com/blog/images/lead_n_spotlight/1819558_lead_400_142852_.png

### 14. Core77 Design Awards Entry #400

- **Source:** Core77 Design Awards
- **Source ID:** core77_awards
- **Page URL:** https://designawards.core77.com/Apps-Platforms/143437/MyMonthly-Designing-Shared-Awareness-in-Cycle-Health
- **Image URL:** https://s3files.core77.com/blog/images/lead_n_spotlight/1824945_lead_400_143437_.png

### 15. Core77 Design Awards Entry #400

- **Source:** Core77 Design Awards
- **Source ID:** core77_awards
- **Page URL:** https://designawards.core77.com/Apps-Platforms/141487/Arli
- **Image URL:** https://s3files.core77.com/blog/images/lead_n_spotlight/1803848_lead_400_141487_.jpg

### 16. Core77 Design Awards Entry #400

- **Source:** Core77 Design Awards
- **Source ID:** core77_awards
- **Page URL:** https://designawards.core77.com/Branding-Identity/143176/Cadence-Brand-Identity
- **Image URL:** https://s3files.core77.com/blog/images/lead_n_spotlight/1821573_lead_400_143176_.jpeg

### 17. Core77 Design Awards Entry #400

- **Source:** Core77 Design Awards
- **Source ID:** core77_awards
- **Page URL:** https://designawards.core77.com/Branding-Identity/142671/ARCHIPELAGO
- **Image URL:** https://s3files.core77.com/blog/images/lead_n_spotlight/1817293_lead_400_142671_.jpg

### 18. Core77 Design Awards Entry #400

- **Source:** Core77 Design Awards
- **Source ID:** core77_awards
- **Page URL:** https://designawards.core77.com/Built-Environment/140814/Earth-Court-Case-Study-001-Sanctum
- **Image URL:** https://s3files.core77.com/blog/images/lead_n_spotlight/1824632_lead_400_140814_.jpg

### 19. Core77 Design Awards Entry #400

- **Source:** Core77 Design Awards
- **Source ID:** core77_awards
- **Page URL:** https://designawards.core77.com/Built-Environment/140838/Turf-Design-Experience-Center
- **Image URL:** https://s3files.core77.com/blog/images/lead_n_spotlight/1796040_lead_400_140838_.jpg

### 20. Core77 Design Awards Entry #400

- **Source:** Core77 Design Awards
- **Source ID:** core77_awards
- **Page URL:** https://designawards.core77.com/Built-Environment/140431/URBN-HOOP-Rethinking-the-Streetball-Hoop-for-Public-Space
- **Image URL:** https://s3files.core77.com/blog/images/lead_n_spotlight/1791171_lead_400_140431_.jpg

### 21. Core77 Design Awards Entry #400

- **Source:** Core77 Design Awards
- **Source ID:** core77_awards
- **Page URL:** https://designawards.core77.com/Built-Environment/141314/Space-for-Grief
- **Image URL:** https://s3files.core77.com/blog/images/lead_n_spotlight/1821439_lead_400_141314_.jpg

### 22. Core77 Design Awards Entry #400

- **Source:** Core77 Design Awards
- **Source ID:** core77_awards
- **Page URL:** https://designawards.core77.com/Commercial-Equipment/140831/Concerto-Platform
- **Image URL:** https://s3files.core77.com/blog/images/lead_n_spotlight/1797951_lead_400_140831_.jpg

### 23. Core77 Design Awards Entry #400

- **Source:** Core77 Design Awards
- **Source ID:** core77_awards
- **Page URL:** https://designawards.core77.com/Commercial-Equipment/140593/Pendar-M1-Automated-Portable-Raman-Microscope
- **Image URL:** https://s3files.core77.com/blog/images/lead_n_spotlight/1808063_lead_400_140593_.jpg

### 24. Core77 Design Awards Entry #400

- **Source:** Core77 Design Awards
- **Source ID:** core77_awards
- **Page URL:** https://designawards.core77.com/Commercial-Equipment/142722/ecodan-Pro-CAHV-heat-pump-water-heater
- **Image URL:** https://s3files.core77.com/blog/images/lead_n_spotlight/1822465_lead_400_142722_.jpg

### 25. Core77 Design Awards Entry #400

- **Source:** Core77 Design Awards
- **Source ID:** core77_awards
- **Page URL:** https://designawards.core77.com/Commercial-Equipment/143428/MX-Surgical-Tactile-XR-Surgical-Training
- **Image URL:** https://s3files.core77.com/blog/images/lead_n_spotlight/1826682_lead_400_143428_.jpg

### 26. Core77 Design Awards Entry #400

- **Source:** Core77 Design Awards
- **Source ID:** core77_awards
- **Page URL:** https://designawards.core77.com/consumer-technology/140945/KARRI-Messenger
- **Image URL:** https://s3files.core77.com/blog/images/lead_n_spotlight/1810636_lead_400_140945_.jpg

### 27. Core77 Design Awards Entry #400

- **Source:** Core77 Design Awards
- **Source ID:** core77_awards
- **Page URL:** https://designawards.core77.com/consumer-technology/143398/Dreamie-by-Ambient
- **Image URL:** https://s3files.core77.com/blog/images/lead_n_spotlight/1825259_lead_400_143398_.png

### 28. achille castiglioni and bruno munari knew how to have a good time

- **Source:** Designboom
- **Source ID:** designboom_product
- **Page URL:** https://www.designboom.com/design/achille-castiglioni-bruno-munari-good-time/
- **Image URL:** https://static.designboom.com/wp-content/uploads/2026/07/castiglioni-foundation-play-designboom-600.jpg

### 29. giant flowers and twisting vines shape bureau betak's enchanted garden for chanel

- **Source:** Designboom
- **Source ID:** designboom_product
- **Page URL:** https://www.designboom.com/design/giant-flowers-twisting-vines-bureau-betak-enchanted-garden-chanel/
- **Image URL:** https://static.designboom.com/wp-content/uploads/2026/07/giant-flowers-twisting-vines-bureau-betak-enchanted-garden-chanel-designboom-700-560x448-22b08q85r134.jpg

### 30. how antoni gaudí's architecture found its way into schiaparelli haute couture

- **Source:** Designboom
- **Source ID:** designboom_product
- **Page URL:** https://www.designboom.com/design/antoni-gaudi-architecture-way-schiaparelli-haute-couture-daniel-roseberry/
- **Image URL:** https://static.designboom.com/wp-content/uploads/2026/07/antoni-gaudi-architecture-way-schiaparelli-haute-couture-daniel-roseberry-designboom-700-560x448-22b08q85r532.jpg

### 31. artificial stone produced from recycled textile waste composes furniture collection

- **Source:** Designboom
- **Source ID:** designboom_product
- **Page URL:** https://www.designboom.com/design/artificial-stone-recycled-textile-waste-furniture-collection-chromaterico-textile-objects-archeomaterico-chroma-composites/
- **Image URL:** https://static.designboom.com/wp-content/uploads/2026/06/chromaterico-textile-objects-collection-archeomaterico-chroma-composites-artificial-stone-recycled-textile-waste-designboom-700-560x448-22b08q85r936.jpg

### 32. jello lamp freezes the soft wobble of gelatin desserts into 3D printed sculptural table light

- **Source:** Designboom
- **Source ID:** designboom_product
- **Page URL:** https://www.designboom.com/design/jello-lamp-freezes-the-soft-wobble-of-gelatin-desserts-into-3d-printed-sculptural-table-light/
- **Image URL:** https://static.designboom.com/wp-content/uploads/2026/07/jello-lamp-maju-3d-printed-sculptural-table-light-designboom-700-250x200-22b08q85r623.jpg

### 33. how enzo mari’s 16 animali became an icon of learning through play

- **Source:** Designboom
- **Source ID:** designboom_product
- **Page URL:** https://www.designboom.com/design/enzo-mari-16-animali-icon-learning-through-play/
- **Image URL:** https://static.designboom.com/wp-content/uploads/2026/07/16-animali-enzo-mari-play-designboom-700-1-250x200-22b08q85r679.jpg

### 34. when care learns to play: how design is reshaping pediatric healthcare

- **Source:** Designboom
- **Source ID:** designboom_product
- **Page URL:** https://www.designboom.com/design/care-play-design-pediatric-healthcare/
- **Image URL:** https://static.designboom.com/wp-content/uploads/2026/07/care-play-design-pediatric-healthcare-designboom-700-250x200-22b08q85r875.jpg

### 35. why does creativity need play? lidewij edelkoort & philip fimmano discuss their 'inner child'

- **Source:** Designboom
- **Source ID:** designboom_product
- **Page URL:** https://www.designboom.com/design/creativity-play-lidewij-edelkoort-philip-fimmano-inner-child-artipelag-interview/
- **Image URL:** https://static.designboom.com/wp-content/uploads/2026/07/creativity-play-lidewij-edelkoort-philip-fimmano-inner-child-artipelag-interview-designboom-700-250x200-22b08q85r907.jpg

### 36. 20 winning projects spark submission for A’design award and competition 2027

- **Source:** Designboom
- **Source ID:** designboom_product
- **Page URL:** https://www.designboom.com/design/open-submission-a-design-award-and-competition-2027/
- **Image URL:** https://static.designboom.com/wp-content/uploads/2026/07/a-design-award_designboom_700-250x200-22b08q85r709.jpg

### 37. haus der kunst traces a playful art history written with children

- **Source:** Designboom
- **Source ID:** designboom_product
- **Page URL:** https://www.designboom.com/design/haus-der-kunst-history-for-children-stories-since-1968-play/
- **Image URL:** https://static.designboom.com/wp-content/uploads/2026/07/haus-der-kunst-for-children-art-stories-1968-exhibition-play-designboom-700-400x320-22b08q85r974.jpg

### 38. heat-pressed artificial wood melts into organic joints for mocky furniture series

- **Source:** Designboom
- **Source ID:** designboom_product
- **Page URL:** https://www.designboom.com/design/heat-pressed-artificial-wood-organic-joints-mocky-furniture-series-tact-inoue/
- **Image URL:** https://static.designboom.com/wp-content/uploads/2026/07/mocky-furniture-series-tact-inoue-artificial-wood-designboom-700-1-400x320-22b08q85r803.jpg

### 39. colorful furnishings and raw textures animate an open-plan flower shop

- **Source:** Designboom
- **Source ID:** designboom_product
- **Page URL:** https://www.designboom.com/readers/colorful-furnishings-raw-textures-flower-shop-moscow/
- **Image URL:** https://static.designboom.com/wp-content/dbsub/467043/2026-07-09/the-shop-vesnaflowers-700-6a4fef19eedc9-400x320-22b08q85r849.jpg

### 40. in praise of the useless path: how labyrinths turn disorientation into play

- **Source:** Designboom
- **Source ID:** designboom_product
- **Page URL:** https://www.designboom.com/design/useless-path-labyrinths-disorientation-play-maze-spiral-jetty-borges/
- **Image URL:** https://static.designboom.com/wp-content/uploads/2026/07/labyrinths-play-designboom-700-400x320-22b08q85r323.jpg

### 41. jia curated 2026 displays craft, design, and culture on bali’s beachfront

- **Source:** Designboom
- **Source ID:** designboom_product
- **Page URL:** https://www.designboom.com/design/jia-curated-2026-craft-culture-bali-beachfront/
- **Image URL:** https://static.designboom.com/wp-content/uploads/2026/07/jia-curated_designboom-700-400x320-22b08q85r980.jpg

### 42. public art keeps inviting us to play, so why is so little of it actually thrilling?

- **Source:** Designboom
- **Source ID:** designboom_product
- **Page URL:** https://www.designboom.com/design/public-art-keeps-inviting-us-to-play-so-why-is-so-little-of-it-actually-thrilling/
- **Image URL:** https://static.designboom.com/wp-content/uploads/2026/07/risky-play-designboom-700-400x320-22b08q85r414.jpg

### 43. The 3-in-1 Wireless Charger You’d Actually Want to Leave in View

- **Source:** Yanko Design
- **Source ID:** yanko_home
- **Page URL:** https://www.yankodesign.com/2026/07/22/the-3-in-1-wireless-charger-youd-actually-want-to-leave-in-view/
- **Image URL:** https://www.yankodesign.com/images/design_news/2026/07/the-3-in-1-wireless-charger-youd-actually-want-to-leave-in-view/ADAM_elements_Mag_3_Ultra_Qi2_25W_3_in_1_Foldable_Charger_hero-296x197.jpg

### 44. Samsung and Google Are Trying Smart Glasses Again, at the Worst Possible Time

- **Source:** Yanko Design
- **Source ID:** yanko_home
- **Page URL:** https://www.yankodesign.com/2026/07/22/samsung-and-google-are-trying-smart-glasses-again-at-the-worst-possible-time/
- **Image URL:** https://www.yankodesign.com/images/design_news/2026/07/637728/samsung_google_glass_1-296x197.jpg

### 45. Samsung’s Galaxy Watch Ultra2 Is Now Thinner Than the Apple Watch Ultra 3, and Its Battery Still Grew 35%

- **Source:** Yanko Design
- **Source ID:** yanko_home
- **Page URL:** https://www.yankodesign.com/2026/07/22/samsungs-galaxy-watch-ultra2-is-now-thinner-than-the-apple-watch-ultra-3-and-its-battery-still-grew-35/
- **Image URL:** https://www.yankodesign.com/images/design_news/2026/07/auto-draft/galaxy_watch_ultra2_1-296x197.jpg

### 46. Palm-sized drone edges one step closer to disappearing completely in flight behind enemy lines

- **Source:** Yanko Design
- **Source ID:** yanko_home
- **Page URL:** https://www.yankodesign.com/2026/07/22/palm-sized-drone-edges-one-step-closer-to-disappearing-completely-in-flight-behind-enemy-lines/
- **Image URL:** https://www.yankodesign.com/images/design_news/2026/07/palm-sized-drone-edges-one-step-closer-to-disappear-in-flight-behind-enemy-lines/Phantom-Twist-Drone-Invisible-Drone-by-Northwestern-University-1-296x197.jpg

### 47. Tesla Dropped a $225 Kids Bike That’s Already Worth $8,000

- **Source:** Yanko Design
- **Source ID:** yanko_home
- **Page URL:** https://www.yankodesign.com/2026/07/21/tesla-dropped-a-225-kids-bike-thats-already-worth-8000/
- **Image URL:** https://www.yankodesign.com/images/design_news/2026/07/tesla-dropped-a-225-kids-bike-thats-already-worth-8000/balance-bike-01-296x197.jpg

### 48. This teardrop camper’s wing-like awnings turn any campsite into a comfortable outdoor living room

- **Source:** Yanko Design
- **Source ID:** yanko_home
- **Page URL:** https://www.yankodesign.com/2026/07/20/this-teardrop-campers-wing-like-awnings-turn-any-campsite-into-a-comfortable-outdoor-living-room/
- **Image URL:** https://www.yankodesign.com/images/design_news/2026/07/this-teardrop-campers-wing-like-awnings-turn-any-campsite-into-a-comfortable-outdoor-living-room/2026-Stockman-Rover-2.0-prototype-_0011_Layer-14-296x197.jpg

### 49. Someone 3D-Printed A Scooter Small Enough To Fit Into Cabin Luggage

- **Source:** Yanko Design
- **Source ID:** yanko_home
- **Page URL:** https://www.yankodesign.com/2026/07/19/someone-3d-printed-a-scooter-small-enough-to-fit-into-cabin-luggage/
- **Image URL:** https://www.yankodesign.com/images/design_news/2026/07/auto-draft/mirandetta_3d_printed_scooter_1-296x197.jpeg

### 50. Tokyo Ballet House by Kenta SANO & Associates Is Where the City Becomes the Audience

- **Source:** Yanko Design
- **Source ID:** yanko_home
- **Page URL:** https://www.yankodesign.com/2026/07/22/tokyo-ballet-house-by-kenta-sano-associates-is-where-the-city-becomes-the-audience/
- **Image URL:** https://www.yankodesign.com/images/design_news/2026/07/draft-tokyo-ballet-house/tokyo_ballet_house_yanko_design_01-296x197.jpg

### 51. Escape Tiny Homes’ N2 Is the Tiny Home That Makes You Question Why You Ever Needed More Space

- **Source:** Yanko Design
- **Source ID:** yanko_home
- **Page URL:** https://www.yankodesign.com/2026/07/22/escape-tiny-homes-n2-is-the-tiny-home-that-makes-you-question-why-you-ever-needed-more-space/
- **Image URL:** https://www.yankodesign.com/images/design_news/2026/07/n2-home/n2_home_yanko_design_01-296x197.jpg

### 52. This Tiny Home Is a Wine-On-Tap, Off-Grid Luxury Retreat in the Australian Bush

- **Source:** Yanko Design
- **Source ID:** yanko_home
- **Page URL:** https://www.yankodesign.com/2026/07/21/this-tiny-home-is-a-wine-on-tap-off-grid-luxury-retreat-in-the-australian-bush/
- **Image URL:** https://www.yankodesign.com/images/design_news/2026/07/the-shak/the_shak_yanko_design_01-296x197.jpg

### 53. The 3-in-1 Wireless Charger You’d Actually Want to Leave in View

- **Source:** Yanko Design - Consumer Electronics
- **Source ID:** yanko_consumer_electronics
- **Page URL:** https://www.yankodesign.com/2026/07/22/the-3-in-1-wireless-charger-youd-actually-want-to-leave-in-view/
- **Image URL:** https://www.yankodesign.com/images/design_news/2026/07/the-3-in-1-wireless-charger-youd-actually-want-to-leave-in-view/ADAM_elements_Mag_3_Ultra_Qi2_25W_3_in_1_Foldable_Charger_hero-296x197.jpg

### 54. Samsung and Google Are Trying Smart Glasses Again, at the Worst Possible Time

- **Source:** Yanko Design - Consumer Electronics
- **Source ID:** yanko_consumer_electronics
- **Page URL:** https://www.yankodesign.com/2026/07/22/samsung-and-google-are-trying-smart-glasses-again-at-the-worst-possible-time/
- **Image URL:** https://www.yankodesign.com/images/design_news/2026/07/637728/samsung_google_glass_1-296x197.jpg

### 55. Samsung’s Galaxy Watch Ultra2 Is Now Thinner Than the Apple Watch Ultra 3, and Its Battery Still Grew 35%

- **Source:** Yanko Design - Consumer Electronics
- **Source ID:** yanko_consumer_electronics
- **Page URL:** https://www.yankodesign.com/2026/07/22/samsungs-galaxy-watch-ultra2-is-now-thinner-than-the-apple-watch-ultra-3-and-its-battery-still-grew-35/
- **Image URL:** https://www.yankodesign.com/images/design_news/2026/07/auto-draft/galaxy_watch_ultra2_1-296x197.jpg

### 56. Palm-sized drone edges one step closer to disappearing completely in flight behind enemy lines

- **Source:** Yanko Design - Consumer Electronics
- **Source ID:** yanko_consumer_electronics
- **Page URL:** https://www.yankodesign.com/2026/07/22/palm-sized-drone-edges-one-step-closer-to-disappearing-completely-in-flight-behind-enemy-lines/
- **Image URL:** https://www.yankodesign.com/images/design_news/2026/07/palm-sized-drone-edges-one-step-closer-to-disappear-in-flight-behind-enemy-lines/Phantom-Twist-Drone-Invisible-Drone-by-Northwestern-University-1-296x197.jpg

### 57. Tesla Dropped a $225 Kids Bike That’s Already Worth $8,000

- **Source:** Yanko Design - Consumer Electronics
- **Source ID:** yanko_consumer_electronics
- **Page URL:** https://www.yankodesign.com/2026/07/21/tesla-dropped-a-225-kids-bike-thats-already-worth-8000/
- **Image URL:** https://www.yankodesign.com/images/design_news/2026/07/tesla-dropped-a-225-kids-bike-thats-already-worth-8000/balance-bike-01-296x197.jpg

### 58. This teardrop camper’s wing-like awnings turn any campsite into a comfortable outdoor living room

- **Source:** Yanko Design - Consumer Electronics
- **Source ID:** yanko_consumer_electronics
- **Page URL:** https://www.yankodesign.com/2026/07/20/this-teardrop-campers-wing-like-awnings-turn-any-campsite-into-a-comfortable-outdoor-living-room/
- **Image URL:** https://www.yankodesign.com/images/design_news/2026/07/this-teardrop-campers-wing-like-awnings-turn-any-campsite-into-a-comfortable-outdoor-living-room/2026-Stockman-Rover-2.0-prototype-_0011_Layer-14-296x197.jpg

### 59. Someone 3D-Printed A Scooter Small Enough To Fit Into Cabin Luggage

- **Source:** Yanko Design - Consumer Electronics
- **Source ID:** yanko_consumer_electronics
- **Page URL:** https://www.yankodesign.com/2026/07/19/someone-3d-printed-a-scooter-small-enough-to-fit-into-cabin-luggage/
- **Image URL:** https://www.yankodesign.com/images/design_news/2026/07/auto-draft/mirandetta_3d_printed_scooter_1-296x197.jpeg

### 60. Tokyo Ballet House by Kenta SANO & Associates Is Where the City Becomes the Audience

- **Source:** Yanko Design - Consumer Electronics
- **Source ID:** yanko_consumer_electronics
- **Page URL:** https://www.yankodesign.com/2026/07/22/tokyo-ballet-house-by-kenta-sano-associates-is-where-the-city-becomes-the-audience/
- **Image URL:** https://www.yankodesign.com/images/design_news/2026/07/draft-tokyo-ballet-house/tokyo_ballet_house_yanko_design_01-296x197.jpg

### 61. The 3-in-1 Wireless Charger You’d Actually Want to Leave in View

- **Source:** Yanko Design - Furniture & Lighting
- **Source ID:** yanko_furniture
- **Page URL:** https://www.yankodesign.com/2026/07/22/the-3-in-1-wireless-charger-youd-actually-want-to-leave-in-view/
- **Image URL:** https://www.yankodesign.com/images/design_news/2026/07/the-3-in-1-wireless-charger-youd-actually-want-to-leave-in-view/ADAM_elements_Mag_3_Ultra_Qi2_25W_3_in_1_Foldable_Charger_hero-296x197.jpg

### 62. Samsung and Google Are Trying Smart Glasses Again, at the Worst Possible Time

- **Source:** Yanko Design - Furniture & Lighting
- **Source ID:** yanko_furniture
- **Page URL:** https://www.yankodesign.com/2026/07/22/samsung-and-google-are-trying-smart-glasses-again-at-the-worst-possible-time/
- **Image URL:** https://www.yankodesign.com/images/design_news/2026/07/637728/samsung_google_glass_1-296x197.jpg

### 63. Samsung’s Galaxy Watch Ultra2 Is Now Thinner Than the Apple Watch Ultra 3, and Its Battery Still Grew 35%

- **Source:** Yanko Design - Furniture & Lighting
- **Source ID:** yanko_furniture
- **Page URL:** https://www.yankodesign.com/2026/07/22/samsungs-galaxy-watch-ultra2-is-now-thinner-than-the-apple-watch-ultra-3-and-its-battery-still-grew-35/
- **Image URL:** https://www.yankodesign.com/images/design_news/2026/07/auto-draft/galaxy_watch_ultra2_1-296x197.jpg

### 64. Palm-sized drone edges one step closer to disappearing completely in flight behind enemy lines

- **Source:** Yanko Design - Furniture & Lighting
- **Source ID:** yanko_furniture
- **Page URL:** https://www.yankodesign.com/2026/07/22/palm-sized-drone-edges-one-step-closer-to-disappearing-completely-in-flight-behind-enemy-lines/
- **Image URL:** https://www.yankodesign.com/images/design_news/2026/07/palm-sized-drone-edges-one-step-closer-to-disappear-in-flight-behind-enemy-lines/Phantom-Twist-Drone-Invisible-Drone-by-Northwestern-University-1-296x197.jpg

### 65. Tesla Dropped a $225 Kids Bike That’s Already Worth $8,000

- **Source:** Yanko Design - Furniture & Lighting
- **Source ID:** yanko_furniture
- **Page URL:** https://www.yankodesign.com/2026/07/21/tesla-dropped-a-225-kids-bike-thats-already-worth-8000/
- **Image URL:** https://www.yankodesign.com/images/design_news/2026/07/tesla-dropped-a-225-kids-bike-thats-already-worth-8000/balance-bike-01-296x197.jpg

### 66. This teardrop camper’s wing-like awnings turn any campsite into a comfortable outdoor living room

- **Source:** Yanko Design - Furniture & Lighting
- **Source ID:** yanko_furniture
- **Page URL:** https://www.yankodesign.com/2026/07/20/this-teardrop-campers-wing-like-awnings-turn-any-campsite-into-a-comfortable-outdoor-living-room/
- **Image URL:** https://www.yankodesign.com/images/design_news/2026/07/this-teardrop-campers-wing-like-awnings-turn-any-campsite-into-a-comfortable-outdoor-living-room/2026-Stockman-Rover-2.0-prototype-_0011_Layer-14-296x197.jpg

### 67. Someone 3D-Printed A Scooter Small Enough To Fit Into Cabin Luggage

- **Source:** Yanko Design - Furniture & Lighting
- **Source ID:** yanko_furniture
- **Page URL:** https://www.yankodesign.com/2026/07/19/someone-3d-printed-a-scooter-small-enough-to-fit-into-cabin-luggage/
- **Image URL:** https://www.yankodesign.com/images/design_news/2026/07/auto-draft/mirandetta_3d_printed_scooter_1-296x197.jpeg

### 68. Tokyo Ballet House by Kenta SANO & Associates Is Where the City Becomes the Audience

- **Source:** Yanko Design - Furniture & Lighting
- **Source ID:** yanko_furniture
- **Page URL:** https://www.yankodesign.com/2026/07/22/tokyo-ballet-house-by-kenta-sano-associates-is-where-the-city-becomes-the-audience/
- **Image URL:** https://www.yankodesign.com/images/design_news/2026/07/draft-tokyo-ballet-house/tokyo_ballet_house_yanko_design_01-296x197.jpg

### 69. The 3-in-1 Wireless Charger You’d Actually Want to Leave in View

- **Source:** Yanko Design - Transportation
- **Source ID:** yanko_transportation
- **Page URL:** https://www.yankodesign.com/2026/07/22/the-3-in-1-wireless-charger-youd-actually-want-to-leave-in-view/
- **Image URL:** https://www.yankodesign.com/images/design_news/2026/07/the-3-in-1-wireless-charger-youd-actually-want-to-leave-in-view/ADAM_elements_Mag_3_Ultra_Qi2_25W_3_in_1_Foldable_Charger_hero-296x197.jpg

### 70. Samsung and Google Are Trying Smart Glasses Again, at the Worst Possible Time

- **Source:** Yanko Design - Transportation
- **Source ID:** yanko_transportation
- **Page URL:** https://www.yankodesign.com/2026/07/22/samsung-and-google-are-trying-smart-glasses-again-at-the-worst-possible-time/
- **Image URL:** https://www.yankodesign.com/images/design_news/2026/07/637728/samsung_google_glass_1-296x197.jpg

### 71. Samsung’s Galaxy Watch Ultra2 Is Now Thinner Than the Apple Watch Ultra 3, and Its Battery Still Grew 35%

- **Source:** Yanko Design - Transportation
- **Source ID:** yanko_transportation
- **Page URL:** https://www.yankodesign.com/2026/07/22/samsungs-galaxy-watch-ultra2-is-now-thinner-than-the-apple-watch-ultra-3-and-its-battery-still-grew-35/
- **Image URL:** https://www.yankodesign.com/images/design_news/2026/07/auto-draft/galaxy_watch_ultra2_1-296x197.jpg

### 72. Palm-sized drone edges one step closer to disappearing completely in flight behind enemy lines

- **Source:** Yanko Design - Transportation
- **Source ID:** yanko_transportation
- **Page URL:** https://www.yankodesign.com/2026/07/22/palm-sized-drone-edges-one-step-closer-to-disappearing-completely-in-flight-behind-enemy-lines/
- **Image URL:** https://www.yankodesign.com/images/design_news/2026/07/palm-sized-drone-edges-one-step-closer-to-disappear-in-flight-behind-enemy-lines/Phantom-Twist-Drone-Invisible-Drone-by-Northwestern-University-1-296x197.jpg

### 73. Tesla Dropped a $225 Kids Bike That’s Already Worth $8,000

- **Source:** Yanko Design - Transportation
- **Source ID:** yanko_transportation
- **Page URL:** https://www.yankodesign.com/2026/07/21/tesla-dropped-a-225-kids-bike-thats-already-worth-8000/
- **Image URL:** https://www.yankodesign.com/images/design_news/2026/07/tesla-dropped-a-225-kids-bike-thats-already-worth-8000/balance-bike-01-296x197.jpg

### 74. This teardrop camper’s wing-like awnings turn any campsite into a comfortable outdoor living room

- **Source:** Yanko Design - Transportation
- **Source ID:** yanko_transportation
- **Page URL:** https://www.yankodesign.com/2026/07/20/this-teardrop-campers-wing-like-awnings-turn-any-campsite-into-a-comfortable-outdoor-living-room/
- **Image URL:** https://www.yankodesign.com/images/design_news/2026/07/this-teardrop-campers-wing-like-awnings-turn-any-campsite-into-a-comfortable-outdoor-living-room/2026-Stockman-Rover-2.0-prototype-_0011_Layer-14-296x197.jpg

### 75. Someone 3D-Printed A Scooter Small Enough To Fit Into Cabin Luggage

- **Source:** Yanko Design - Transportation
- **Source ID:** yanko_transportation
- **Page URL:** https://www.yankodesign.com/2026/07/19/someone-3d-printed-a-scooter-small-enough-to-fit-into-cabin-luggage/
- **Image URL:** https://www.yankodesign.com/images/design_news/2026/07/auto-draft/mirandetta_3d_printed_scooter_1-296x197.jpeg

### 76. Tokyo Ballet House by Kenta SANO & Associates Is Where the City Becomes the Audience

- **Source:** Yanko Design - Transportation
- **Source ID:** yanko_transportation
- **Page URL:** https://www.yankodesign.com/2026/07/22/tokyo-ballet-house-by-kenta-sano-associates-is-where-the-city-becomes-the-audience/
- **Image URL:** https://www.yankodesign.com/images/design_news/2026/07/draft-tokyo-ballet-house/tokyo_ballet_house_yanko_design_01-296x197.jpg

