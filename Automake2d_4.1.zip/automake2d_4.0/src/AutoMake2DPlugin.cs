using System;
using System.IO;
using System.Reflection;
using Rhino;
using Rhino.PlugIns;
using Rhino.UI;
using AutoMake2D.Common;

[assembly: System.Runtime.InteropServices.Guid("1F4B3C5D-9E8A-42F1-B7D6-C4A5E8F9B0A1")]

namespace AutoMake2D
{
    public class AutoMake2DPlugin : PlugIn
    {
        public static AutoMake2DPlugin Instance { get; private set; } = null;

        private static Stream _gIconStream = null;
        private static System.Drawing.Icon _gPermanentIcon = null;

        public AutoMake2DPlugin()
        {
            Instance = this;
        }

        protected override LoadReturnCode OnLoad(ref string errorMessage)
        {
            try
            {
                var assembly = Assembly.GetExecutingAssembly();

                string resourceName = "AutoMake2D.icon1.ico";

                _gIconStream = assembly.GetManifestResourceStream(resourceName);
                if (_gIconStream != null)
                {
                    _gPermanentIcon = new System.Drawing.Icon(_gIconStream);
                }

                Panels.RegisterPanel(this, typeof(PatentUiPanel), "AutoMake2D_DJ", _gPermanentIcon);

                RhinoApp.Idle += RhinoApp_OnIdle;

                Logger.Info("AutoMake2D 4.0 插件已加载");
            }
            catch (Exception ex)
            {
                errorMessage = $"自动出图面板加载失败: {ex.Message}";
                return LoadReturnCode.ErrorShowDialog;
            }

            return LoadReturnCode.Success;
        }

        private void RhinoApp_OnIdle(object sender, EventArgs e)
        {
            RhinoApp.Idle -= RhinoApp_OnIdle;

            try
            {
                var targetPanelId = PatentUiPanel.PanelId;
                if (!Panels.IsPanelVisible(targetPanelId))
                {
                    Panels.OpenPanel(targetPanelId);
                }
            }
            catch (Exception ex)
            {
                RhinoApp.WriteLine($"[AutoMake2D] 延迟弹窗被安全拦截: {ex.Message}");
            }
        }
    }
}
