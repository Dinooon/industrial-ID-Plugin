using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using Rhino;
using Rhino.Geometry;
using Rhino.Input;
using Rhino.DocObjects;
using Rhino.Display;
using AutoMake2D.Common;

namespace AutoMake2D.PatentCore
{
    /// <summary>
    /// PatentCore 门面类 — 编排投影/融合/排版/渲染模块
    /// 对外接口 ExecuteAsync 签名与 3.0 完全一致
    /// </summary>
    public static class PatentCore
    {
        public static async Task ExecuteAsync(bool wantSix, bool wantIsoFront, bool wantIsoBack, bool wantCurrent, double tolerance, bool wantRender, string renderOutputPath, IProgress<int> progress, IProgress<string> status, bool wantAnnotation = false)
        {
            RhinoDoc doc = RhinoDoc.ActiveDoc;
            if (doc == null) return;

            var rc = RhinoGet.GetMultipleObjects("请框选需要生成零部件独立分组线框图的模型", true, ObjectType.Surface | ObjectType.PolysrfFilter | ObjectType.Mesh, out ObjRef[] objRefs);
            if (rc != Rhino.Commands.Result.Success || objRefs == null)
            {
                status?.Report("已取消选择。");
                return;
            }

            status?.Report("正在提取模型几何与零部件特征...");

            List<GeometryBase> pureGeos = new List<GeometryBase>();
            List<string> compNames = new List<string>();
            BoundingBox globalBbox = BoundingBox.Empty;

            for (int i = 0; i < objRefs.Length; i++)
            {
                var geo = objRefs[i].Geometry();
                if (geo != null)
                {
                    pureGeos.Add(geo);
                    globalBbox.Union(geo.GetBoundingBox(true));

                    var rhinoObj = objRefs[i].Object();
                    string name = rhinoObj != null ? rhinoObj.Attributes.Name : null;
                    if (string.IsNullOrEmpty(name)) name = "零件_" + (i + 1);
                    compNames.Add(name);
                }
            }

            if (pureGeos.Count == 0 || !globalBbox.IsValid) return;
            Point3d center = globalBbox.Center;

            var planesToGenerate = new Dictionary<string, Plane>(StringComparer.OrdinalIgnoreCase);

            if (wantSix)
            {
                planesToGenerate["Front"] = PatentProjector.GetViewPlane("Front", center);
                planesToGenerate["Back"] = PatentProjector.GetViewPlane("Back", center);
                planesToGenerate["Top"] = PatentProjector.GetViewPlane("Top", center);
                planesToGenerate["Bottom"] = PatentProjector.GetViewPlane("Bottom", center);
                planesToGenerate["Left"] = PatentProjector.GetViewPlane("Left", center);
                planesToGenerate["Right"] = PatentProjector.GetViewPlane("Right", center);
            }
            if (wantIsoFront) planesToGenerate["IsoFront"] = PatentProjector.GetIsoPlane(center, isFront: true, isDown: false);
            if (wantIsoBack) planesToGenerate["IsoBack"] = PatentProjector.GetIsoPlane(center, isFront: false, isDown: true);
            if (wantCurrent)
            {
                var activeView = doc.Views.ActiveView;
                if (activeView != null)
                {
                    var vp = activeView.ActiveViewport;
                    planesToGenerate["CurrentView"] = new Plane(center, vp.CameraX, vp.CameraY);
                }
            }

            int totalViews = planesToGenerate.Count;
            if (totalViews == 0) return;

            int completedViews = 0;
            var stopwatch = Stopwatch.StartNew();

            status?.Report("准备进入后台超算引擎...");

            var viewsData = await Task.Run(() =>
            {
                var data = new Dictionary<string, Dictionary<string, List<Curve>>>(StringComparer.OrdinalIgnoreCase);

                foreach (var kvp in planesToGenerate)
                {
                    string etaStr = "计算中...";
                    if (completedViews > 0)
                    {
                        long elapsedMs = stopwatch.ElapsedMilliseconds;
                        long avgMs = elapsedMs / completedViews;
                        long remainingTotalMs = avgMs * (totalViews - completedViews);
                        long remainingSecs = remainingTotalMs / 1000;

                        if (remainingSecs > 60)
                            etaStr = $"总共还需约 {remainingSecs / 60}分{remainingSecs % 60}秒";
                        else
                            etaStr = $"总共还需约 {remainingSecs} 秒";
                    }

                    status?.Report($"🔄 正在死磕计算 [{kvp.Key}] 视图 ({completedViews + 1}/{totalViews}) | {etaStr}");

                    var curvesGroupedByComp = PatentProjector.ComputeSingleView(pureGeos, compNames, kvp.Value, tolerance);
                    data[kvp.Key] = curvesGroupedByComp;

                    completedViews++;
                    progress?.Report((int)((completedViews / (double)totalViews) * 100));
                }

                status?.Report("📐 所有视图计算完毕，正在进行二维矩阵防重叠左侧排版...");
                LayoutComposer.ArrangeEngineeringViewsGrouped(data);

                return data;
            });

            status?.Report("💾 正在按零件名称进行成组烘焙...");
            LayerDispatcher.BakeToRhinoGrouped(doc, viewsData);
            // 视图标注（可选）
            if (wantAnnotation)
            {
                status?.Report("🏷 正在添加视图标注...");
                AnnotationEngine.AddViewAnnotations(doc, viewsData);
                RhinoApp.WriteLine("🏷 视图标注已添加 (Patent_Annotation 图层)");
            }

            doc.Views.Redraw();
            RhinoApp.WriteLine("✅ 零部件分层打组——左侧矩阵版专利图输出完毕！");

            // ============================================================
            // 渲染输出（视图联动模式）
            // ============================================================
            if (wantRender)
            {
                status?.Report("🎨 正在准备渲染输出...");

                RhinoView currentView = doc.Views.ActiveView;
                var renderViews = RenderCaptureEngine.DetermineRenderViews(wantSix, wantIsoFront, wantIsoBack, wantCurrent, globalBbox, currentView);

                if (renderViews.Count == 0)
                {
                    status?.Report("未选定任何视图模式，跳过渲染输出");
                    RhinoApp.WriteLine("⚠️ 渲染输出已勾选但未选定视图模式，跳过渲染。");
                }
                else
                {
                    status?.Report($"🎨 正在捕获 {renderViews.Count} 张渲染图...");

                    var drawingLayer = doc.Layers.FindName("Patent_Drawings_2D");
                    var tangentLayer = doc.Layers.FindName("TangentEdges");
                    bool drawingLayerWasVisible = drawingLayer != null && drawingLayer.IsVisible;
                    bool tangentLayerWasVisible = tangentLayer != null && tangentLayer.IsVisible;

                    if (drawingLayer != null) drawingLayer.IsVisible = false;
                    if (tangentLayer != null) tangentLayer.IsVisible = false;
                    doc.Views.Redraw();

                    var renderBitmaps = new Dictionary<string, Bitmap>(StringComparer.OrdinalIgnoreCase);

                    try
                    {
                        for (int i = 0; i < renderViews.Count; i++)
                        {
                            var rv = renderViews[i];
                            status?.Report($"🎨 正在渲染 [{rv.Name}] 视图 ({i + 1}/{renderViews.Count})...");
                            progress?.Report((int)((i / (double)renderViews.Count) * 100));

                            Bitmap bmp = RenderCaptureEngine.CaptureViewRender(doc, rv.Plane, rv.Name, new Size(1200, 900));
                            if (bmp != null)
                                renderBitmaps[rv.Name] = bmp;
                        }
                    }
                    finally
                    {
                        if (drawingLayer != null) drawingLayer.IsVisible = drawingLayerWasVisible;
                        if (tangentLayer != null) tangentLayer.IsVisible = tangentLayerWasVisible;
                        doc.Views.Redraw();
                    }

                    if (renderBitmaps.Count > 0)
                    {
                        status?.Report($"📐 正在排版 {renderBitmaps.Count} 张渲染图...");
                        Bitmap composed = RenderCaptureEngine.ComposeRenderLayout(renderBitmaps);

                        if (composed != null)
                        {
                            status?.Report("💾 正在将渲染图放入模型...");
                            try
                            {
                                string tempDir = Path.GetTempPath();
                                string tempRenderFile = Path.Combine(tempDir, $"AutoMake2D_Render_{Guid.NewGuid():N}.png");
                                composed.Save(tempRenderFile, ImageFormat.Png);

                                try
                                {
                                    string dir = Path.GetDirectoryName(renderOutputPath);
                                    if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                                        Directory.CreateDirectory(dir);
                                    composed.Save(renderOutputPath, ImageFormat.Png);
                                }
                                catch { }

                                BoundingBox modelBbox = globalBbox;
                                double offsetX = modelBbox.IsValid ? modelBbox.Max.X + modelBbox.Diagonal.Length * 0.3 : 100;
                                double offsetY = 0;
                                double offsetZ = 0;

                                double aspectRatio = (double)composed.Width / composed.Height;
                                double frameHeight = modelBbox.IsValid ? modelBbox.Diagonal.Length * 0.8 : 100;
                                double frameWidth = frameHeight * aspectRatio;

                                var framePlane = new Plane(
                                    new Point3d(offsetX, offsetY, offsetZ),
                                    Vector3d.XAxis, Vector3d.YAxis);

                                var pictureFrameId = doc.Objects.AddPictureFrame(framePlane, tempRenderFile, false, frameWidth, frameHeight, false, false);

                                if (pictureFrameId != Guid.Empty)
                                {
                                    int renderLayerIndex = LayerDispatcher.EnsureLayer(doc, "Patent_Render", System.Drawing.Color.LightGray);

                                    var pfObj = doc.Objects.FindId(pictureFrameId);
                                    if (pfObj != null)
                                    {
                                        var attrs = pfObj.Attributes.Duplicate();
                                        attrs.LayerIndex = renderLayerIndex;
                                        doc.Objects.ModifyAttributes(pfObj, attrs, false);
                                    }

                                    status?.Report($"✅ 渲染图已放入模型 (Patent_Render 图层)");
                                    RhinoApp.WriteLine($"✅ 渲染图已放入模型 (Patent_Render 图层)，同时保存至: {renderOutputPath}");
                                }
                                else
                                {
                                    status?.Report($"⚠️ PictureFrame 创建失败，渲染图仅保存为外部文件: {renderOutputPath}");
                                }

                                try { if (File.Exists(tempRenderFile)) File.Delete(tempRenderFile); } catch { }
                            }
                            catch (Exception ex)
                            {
                                status?.Report($"❌ 渲染图输出失败: {ex.Message}");
                                Logger.Error("渲染图输出失败", ex);
                            }
                        }
                    }
                }
            }
        }
    }
}
