using System;
using System.Collections.Generic;
using Rhino;
using Rhino.Geometry;
using Rhino.DocObjects;
using Rhino.Display;

namespace AutoMake2D.PatentCore
{
    /// <summary>
    /// 视图投影模块 — 视图平面计算 + HiddenLineDrawing 隐线计算引擎
    /// 从 PatentCore.cs 提取，负责将 3D 几何投影为 2D 线框
    /// </summary>
    public static class PatentProjector
    {
        /// <summary>
        /// 根据视图名称计算视图平面
        /// </summary>
        public static Plane GetViewPlane(string name, Point3d origin)
        {
            name = name.Trim().ToLower();
            switch (name)
            {
                case "top": return new Plane(origin, Vector3d.XAxis, Vector3d.YAxis);
                case "bottom": return new Plane(origin, -Vector3d.XAxis, Vector3d.YAxis);
                case "front": return new Plane(origin, Vector3d.XAxis, Vector3d.ZAxis);
                case "back": return new Plane(origin, -Vector3d.XAxis, Vector3d.ZAxis);
                case "left": return new Plane(origin, -Vector3d.YAxis, Vector3d.ZAxis);
                case "right": return new Plane(origin, Vector3d.YAxis, Vector3d.ZAxis);
                default: return new Plane(origin, Vector3d.XAxis, Vector3d.YAxis);
            }
        }

        /// <summary>
        /// 计算轴测视图平面
        /// </summary>
        public static Plane GetIsoPlane(Point3d origin, bool isFront, bool isDown)
        {
            Vector3d normal;
            if (isFront)
            {
                normal = new Vector3d(1, -1, 1);
            }
            else
            {
                normal = isDown ? new Vector3d(-1, 1, -1) : new Vector3d(-1, 1, 1);
            }

            normal.Unitize();
            Vector3d planeX = Vector3d.CrossProduct(Vector3d.ZAxis, normal);
            planeX.Unitize();

            Vector3d planeY = Vector3d.CrossProduct(normal, planeX);
            planeY.Unitize();

            return new Plane(origin, planeX, planeY);
        }

        /// <summary>
        /// 对一组几何体执行单视图投影，返回按零件名分组的曲线集合
        /// 包含 HLD 隐线计算、正切边缘识别、外轮廓判定
        /// </summary>
        public static Dictionary<string, List<Curve>> ComputeSingleView(
            List<GeometryBase> geos, List<string> names, Plane viewPlane, double tolerance)
        {
            var rawGrouped = new Dictionary<string, List<Curve>>(StringComparer.OrdinalIgnoreCase);
            foreach (var name in names) rawGrouped[name] = new List<Curve>();

            var paramsHld = new HiddenLineDrawingParameters
            {
                AbsoluteTolerance = tolerance,
                IncludeHiddenCurves = false,
                IncludeTangentEdges = true,
                IncludeTangentSeams = true
            };

            Transform xformP2P = Transform.PlaneToPlane(viewPlane, Plane.WorldXY);
            BoundingBox transformedBbox = BoundingBox.Empty;

            for (int i = 0; i < geos.Count; i++)
            {
                paramsHld.AddGeometry(geos[i], xformP2P, names[i]);
                var dup = geos[i].Duplicate();
                dup.Transform(xformP2P);
                transformedBbox.Union(dup.GetBoundingBox(true));
            }

            var vp = new Rhino.Display.RhinoViewport();
            vp.ChangeToParallelProjection(true);
            double camZ = transformedBbox.IsValid ? transformedBbox.Max.Z + 1000 : 1000;
            vp.SetCameraLocation(new Point3d(0, 0, camZ), false);
            vp.SetCameraDirection(-Vector3d.ZAxis, false);
            vp.CameraUp = Vector3d.YAxis;
            vp.SetCameraTarget(Point3d.Origin, false);
            paramsHld.SetViewport(vp);

            var hld = HiddenLineDrawing.Compute(paramsHld, true);
            if (hld != null)
            {
                Transform xformFlatten = Transform.PlanarProjection(Plane.WorldXY);
                foreach (var seg in hld.Segments)
                {
                    if (seg != null && seg.CurveGeometry != null && seg.SegmentVisibility == HiddenLineDrawingSegment.Visibility.Visible)
                    {
                        string belongingComponent = "未知组件";
                        bool isOuterContour = false;
                        bool isTangentEdge = false;

                        var hldCurve = seg.ParentCurve;
                        if (hldCurve != null)
                        {
                            var hldObj = hldCurve.SourceObject;
                            if (hldObj != null && hldObj.Tag != null)
                            {
                                belongingComponent = hldObj.Tag.ToString();
                            }

                            if (hldCurve.SilhouetteType == SilhouetteType.Projecting ||
                                hldCurve.SilhouetteType == SilhouetteType.Boundary)
                            {
                                isOuterContour = true;
                            }

                            if (!isOuterContour)
                            {
                                var st = hldCurve.SilhouetteType;

                                if (st == SilhouetteType.Tangent ||
                                    st == SilhouetteType.NonSilhouetteTangent)
                                {
                                    isTangentEdge = true;
                                }
                                else if (st == SilhouetteType.None)
                                {
                                    var crvGeom = seg.CurveGeometry;
                                    if (crvGeom != null &&
                                        (crvGeom.IsArc() || crvGeom.SpanCount > 1))
                                    {
                                        isTangentEdge = true;
                                    }
                                }
                            }
                        }

                        if (!rawGrouped.ContainsKey(belongingComponent))
                        {
                            rawGrouped[belongingComponent] = new List<Curve>();
                        }

                        var crv = seg.CurveGeometry.DuplicateCurve();
                        crv.Transform(xformFlatten);

                        if (isOuterContour)
                        {
                            crv.SetUserString("IsOuter", "true");
                        }
                        if (isTangentEdge)
                        {
                            crv.SetUserString("IsTangent", "true");
                        }

                        rawGrouped[belongingComponent].Add(crv);
                    }
                }
            }

            // 送入曲线融合引擎处理
            var finalCleanedGrouped = new Dictionary<string, List<Curve>>(StringComparer.OrdinalIgnoreCase);
            foreach (var kvp in rawGrouped)
            {
                var list = kvp.Value;
                if (list.Count == 0) continue;

                list = CurveFusionEngine.CleanRawCurves(list, tolerance);

                // 外轮廓特权隔离与优先独立组合
                List<Curve> outerCurves = new List<Curve>();
                List<Curve> innerCurves = new List<Curve>();
                foreach (var c in list)
                {
                    if (c.GetUserString("IsOuter") == "true") outerCurves.Add(c);
                    else innerCurves.Add(c);
                }

                var joinedOuter = Curve.JoinCurves(outerCurves, tolerance);
                List<Curve> nextPool = new List<Curve>();

                if (joinedOuter != null)
                {
                    foreach (var jo in joinedOuter)
                    {
                        CurveFusionEngine.PropagateUserStrings(outerCurves.ToArray(), jo);
                        jo.SetUserString("IsOuter", "true");
                        nextPool.Add(jo);
                    }
                }
                else
                {
                    nextPool.AddRange(outerCurves);
                }

                nextPool.AddRange(innerCurves);
                list = nextPool;

                list = CurveFusionEngine.JoinTangentCurvesPrioritized(list, tolerance, 0.08);

                var joinedArray = Curve.JoinCurves(list, tolerance);

                if (joinedArray != null)
                {
                    var finalList = new List<Curve>();
                    foreach (var jc in joinedArray)
                    {
                        CurveFusionEngine.PropagateUserStrings(list.ToArray(), jc);
                        finalList.Add(jc);
                    }
                    finalCleanedGrouped[kvp.Key] = finalList;
                }
                else
                {
                    finalCleanedGrouped[kvp.Key] = list;
                }
            }

            return finalCleanedGrouped;
        }
    }
}
