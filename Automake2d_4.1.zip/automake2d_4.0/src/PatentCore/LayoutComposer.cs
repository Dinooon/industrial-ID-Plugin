using System;
using System.Collections.Generic;
using Rhino.Geometry;

namespace AutoMake2D.PatentCore
{
    /// <summary>
    /// 排版引擎 — 工程视图防重叠矩阵布局
    /// 从 PatentCore.cs 提取，负责将多视图线框按工程制图规范排版
    /// </summary>
    public static class LayoutComposer
    {
        /// <summary>
        /// 工程视图分组排版 — 按长对正、高平齐规则排列
        /// </summary>
        public static void ArrangeEngineeringViewsGrouped(Dictionary<string, Dictionary<string, List<Curve>>> vData)
        {
            var bboxes = new Dictionary<string, BoundingBox>(StringComparer.OrdinalIgnoreCase);
            double globalMaxW = 0, globalMaxH = 0;

            foreach (var kvpView in vData)
            {
                string viewName = kvpView.Key;
                BoundingBox viewBbox = BoundingBox.Empty;

                foreach (var kvpComp in kvpView.Value)
                {
                    foreach (var crv in kvpComp.Value) viewBbox.Union(crv.GetBoundingBox(true));
                }

                bboxes[viewName] = viewBbox;

                if (viewBbox.IsValid)
                {
                    globalMaxW = Math.Max(globalMaxW, viewBbox.Max.X - viewBbox.Min.X);
                    globalMaxH = Math.Max(globalMaxH, viewBbox.Max.Y - viewBbox.Min.Y);

                    Transform toOrigin = Transform.Translation(new Vector3d(-viewBbox.Center.X, -viewBbox.Center.Y, 0));
                    foreach (var kvpComp in kvpView.Value)
                    {
                        foreach (var crv in kvpComp.Value) crv.Transform(toOrigin);
                    }
                }
            }

            double refW = bboxes.ContainsKey("Front") && bboxes["Front"].IsValid ? (bboxes["Front"].Max.X - bboxes["Front"].Min.X) : globalMaxW;
            double refH = bboxes.ContainsKey("Front") && bboxes["Front"].IsValid ? (bboxes["Front"].Max.Y - bboxes["Front"].Min.Y) : globalMaxH;

            double gapX = refW * 0.5 == 0 ? 100 : refW * 0.5;
            double gapY = refH * 0.5 == 0 ? 100 : refH * 0.5;

            double getW(string name) => bboxes.ContainsKey(name) && bboxes[name].IsValid ? (bboxes[name].Max.X - bboxes[name].Min.X) : 0;
            double getH(string name) => bboxes.ContainsKey(name) && bboxes[name].IsValid ? (bboxes[name].Max.Y - bboxes[name].Min.Y) : 0;

            var offsets = new Dictionary<string, Vector3d>(StringComparer.OrdinalIgnoreCase);

            offsets["Front"] = new Vector3d(0, 0, 0);
            offsets["Top"] = new Vector3d(0, -(refH / 2.0 + gapY + getH("Top") / 2.0), 0);
            offsets["Bottom"] = new Vector3d(0, (refH / 2.0 + gapY + getH("Bottom") / 2.0), 0);
            offsets["Right"] = new Vector3d(-(refW / 2.0 + gapX + getW("Right") / 2.0), 0, 0);
            offsets["Left"] = new Vector3d((refW / 2.0 + gapX + getW("Left") / 2.0), 0, 0);
            offsets["Back"] = new Vector3d((refW / 2.0 + gapX + getW("Left") + gapX + getW("Back") / 2.0), 0, 0);

            double rightViewCenterX = -(refW / 2.0 + gapX + getW("Right") / 2.0);
            double extensionX = bboxes.ContainsKey("Right") && bboxes["Right"].IsValid
                ? (rightViewCenterX - getW("Right") / 2.0 - gapX - globalMaxW / 2.0)
                : -(refW / 2.0 + gapX + globalMaxW / 2.0);

            if (refW == 0) extensionX = -(globalMaxW + gapX);

            offsets["IsoFront"] = new Vector3d(extensionX, 0, 0);
            offsets["IsoBack"] = new Vector3d(extensionX, (globalMaxH + gapY), 0);
            offsets["CurrentView"] = new Vector3d(extensionX, -(globalMaxH + gapY), 0);

            foreach (var kvpView in vData)
            {
                if (offsets.TryGetValue(kvpView.Key, out Vector3d moveVec))
                {
                    Transform finalMove = Transform.Translation(moveVec);
                    foreach (var kvpComp in kvpView.Value)
                    {
                        foreach (var crv in kvpComp.Value) crv.Transform(finalMove);
                    }
                }
            }
        }
    }
}
