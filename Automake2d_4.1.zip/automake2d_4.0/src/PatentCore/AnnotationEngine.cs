using System;
using System.Collections.Generic;
using Rhino;
using Rhino.Geometry;
using Rhino.DocObjects;

namespace AutoMake2D.PatentCore
{
    /// <summary>
    /// 视图标注引擎 — 在各视图线框旁添加中文名称标注
    /// 可选功能，用户通过 UI 开关按需启用
    /// </summary>
    public static class AnnotationEngine
    {
        /// <summary>
        /// 视图名称中文映射
        /// </summary>
        private static readonly Dictionary<string, string> ViewNameMap = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            { "Front", "前视图" },
            { "Back", "后视图" },
            { "Top", "俯视图" },
            { "Bottom", "仰视图" },
            { "Left", "左视图" },
            { "Right", "右视图" },
            { "IsoFront", "前轴测图" },
            { "IsoBack", "后轴测图" },
            { "CurrentView", "当前视角" }
        };

        /// <summary>
        /// 为各视图添加中文名称标注
        /// 标注以 TextDot 形式放置在视图线框的左上角
        /// </summary>
        /// <param name="doc">Rhino 文档</param>
        /// <param name="viewsData">各视图的曲线数据（已完成排版）</param>
        public static void AddViewAnnotations(RhinoDoc doc, Dictionary<string, Dictionary<string, List<Curve>>> viewsData)
        {
            if (doc == null || viewsData == null || viewsData.Count == 0) return;

            // 确保标注图层存在
            string layerName = "Patent_Annotation";
            var existingLayer = doc.Layers.FindName(layerName);
            int layerIndex;
            if (existingLayer != null)
            {
                layerIndex = existingLayer.Index;
            }
            else
            {
                var layer = new Layer { Name = layerName, Color = System.Drawing.Color.DarkGreen };
                layerIndex = doc.Layers.Add(layer);
            }

            foreach (var kvpView in viewsData)
            {
                string viewKey = kvpView.Key;
                if (!ViewNameMap.TryGetValue(viewKey, out string chineseName))
                    chineseName = viewKey;

                // 计算该视图所有曲线的包围盒
                BoundingBox viewBbox = BoundingBox.Empty;
                foreach (var kvpComp in kvpView.Value)
                {
                    foreach (var crv in kvpComp.Value)
                    {
                        if (crv != null)
                            viewBbox.Union(crv.GetBoundingBox(true));
                    }
                }

                if (!viewBbox.IsValid) continue;

                // 在视图左上角放置标注
                Point3d labelPosition = new Point3d(
                    viewBbox.Min.X,
                    viewBbox.Max.Y,
                    0);

                var textDot = new TextDot(chineseName, labelPosition);
                var attributes = new ObjectAttributes { LayerIndex = layerIndex };
                doc.Objects.AddTextDot(textDot, attributes);
            }

            doc.Views.Redraw();
        }
    }
}
