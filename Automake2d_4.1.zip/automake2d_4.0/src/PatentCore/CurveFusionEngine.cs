using System;
using System.Collections.Generic;
using Rhino.Geometry;

namespace AutoMake2D.PatentCore
{
    /// <summary>
    /// 曲线融合引擎 — 三阶段融合策略 + 碎线清洗 + 交叉感知
    /// 从 PatentCore.cs 提取，负责曲线去重、融合、连续性保障
    /// </summary>
    public static class CurveFusionEngine
    {
        /// <summary>
        /// 物理去重和微小碎线清洗
        /// </summary>
        public static List<Curve> CleanRawCurves(List<Curve> curves, double tolerance)
        {
            if (curves.Count == 0) return curves;
            List<Curve> validCurves = new List<Curve>();
            foreach (var c in curves) { if (c != null && c.GetLength() > 0.0001) validCurves.Add(c); }

            List<Curve> cleaned = new List<Curve>();
            RTree tree = new RTree();

            for (int i = 0; i < validCurves.Count; i++)
            {
                var c1 = validCurves[i];
                double len1 = c1.GetLength();
                Point3d midPt1 = c1.PointAtNormalizedLength(0.5);
                bool isDup = false;
                List<int> neighbors = new List<int>();

                tree.Search(new Sphere(midPt1, tolerance * 0.5), (sender, args) => { neighbors.Add(args.Id); });

                foreach (int j in neighbors)
                {
                    var c2 = cleaned[j];
                    if (Math.Abs(len1 - c2.GetLength()) > tolerance) continue;

                    double dFwd = c1.PointAtStart.DistanceTo(c2.PointAtStart) + c1.PointAtEnd.DistanceTo(c2.PointAtEnd);
                    double dRev = c1.PointAtStart.DistanceTo(c2.PointAtEnd) + c1.PointAtEnd.DistanceTo(c2.PointAtStart);
                    double dMid = midPt1.DistanceTo(c2.PointAtNormalizedLength(0.5));

                    if ((dFwd < tolerance && dMid < tolerance * 0.5) || (dRev < tolerance && dMid < tolerance * 0.5))
                    {
                        isDup = true;
                        break;
                    }
                }

                if (!isDup)
                {
                    tree.Insert(midPt1, cleaned.Count);
                    cleaned.Add(c1);
                }
            }
            return cleaned;
        }

        /// <summary>
        /// 交叉感知融合 — 三阶段策略
        /// 阶段0: 仅正常线互相组合（全局贪心）
        /// 阶段1: 交叉节点处相切线局部合并
        /// 阶段2: 全局贪心融合剩余所有线
        /// </summary>
        public static List<Curve> JoinTangentCurvesPrioritized(List<Curve> curves, double tolerance, double angleTolRad)
        {
            if (curves.Count < 2) return curves;

            var normalCurves = new List<Curve>();
            var tangentCurves = new List<Curve>();
            foreach (var c in curves)
            {
                if (c == null) continue;
                if (c.GetUserString("IsTangent") == "true")
                    tangentCurves.Add(c);
                else
                    normalCurves.Add(c);
            }

            var mergedNormals = JoinTangentCurvesPrioritized_Original(normalCurves, tolerance, angleTolRad);

            var pool = new List<Curve>(mergedNormals);
            pool.AddRange(tangentCurves);

            var junctions = DetectJunctionPoints(pool, ComputeJunctionDistTol(tolerance, pool));
            var mergedIndices = new HashSet<int>();
            var stage1Results = new List<Curve>();

            foreach (var junction in junctions)
            {
                var tangentPairs = new List<MergeCandidate>();
                for (int a = 0; a < junction.CurveIndices.Count; a++)
                {
                    for (int b = a + 1; b < junction.CurveIndices.Count; b++)
                    {
                        int ci = junction.CurveIndices[a];
                        int cj = junction.CurveIndices[b];
                        if (mergedIndices.Contains(ci) || mergedIndices.Contains(cj)) continue;

                        bool ciTangent = pool[ci].GetUserString("IsTangent") == "true";
                        bool cjTangent = pool[cj].GetUserString("IsTangent") == "true";
                        if (!ciTangent && !cjTangent) continue;

                        if (GetMinTangentAngle(pool[ci], pool[cj], tolerance, out double actualAngle))
                        {
                            if (actualAngle <= angleTolRad)
                            {
                                tangentPairs.Add(new MergeCandidate { Index1 = ci, Index2 = cj, Angle = actualAngle });
                            }
                        }
                    }
                }

                tangentPairs.Sort((a, b) => a.Angle.CompareTo(b.Angle));
                foreach (var pair in tangentPairs)
                {
                    if (mergedIndices.Contains(pair.Index1) || mergedIndices.Contains(pair.Index2)) continue;
                    Curve[] res = Curve.JoinCurves(new Curve[] { pool[pair.Index1], pool[pair.Index2] }, tolerance);
                    if (res != null && res.Length == 1)
                    {
                        PropagateUserStrings(new[] { pool[pair.Index1], pool[pair.Index2] }, res[0]);
                        stage1Results.Add(res[0]);
                        mergedIndices.Add(pair.Index1);
                        mergedIndices.Add(pair.Index2);
                    }
                }
            }

            var remaining = new List<Curve>();
            for (int i = 0; i < pool.Count; i++)
            {
                if (!mergedIndices.Contains(i)) remaining.Add(pool[i]);
            }
            remaining.AddRange(stage1Results);

            return JoinTangentCurvesPrioritized_Original(remaining, tolerance, angleTolRad);
        }

        private static double ComputeJunctionDistTol(double baseTolerance, List<Curve> curves)
        {
            BoundingBox bbox = BoundingBox.Empty;
            foreach (var c in curves)
            {
                if (c == null) continue;
                bbox.Union(c.PointAtStart);
                bbox.Union(c.PointAtEnd);
            }

            if (!bbox.IsValid) return baseTolerance * 100;

            double diagonal = bbox.Diagonal.Length;
            double adaptiveTol = diagonal * 0.005;
            double minTol = baseTolerance * 10;
            double maxTol = diagonal * 0.02;

            return Math.Max(minTol, Math.Min(adaptiveTol, maxTol));
        }

        private static List<Curve> JoinTangentCurvesPrioritized_Original(List<Curve> curves, double tolerance, double angleTolRad)
        {
            if (curves.Count < 2) return curves;

            var junctions = DetectJunctionPoints(curves, ComputeJunctionDistTol(tolerance, curves));
            var junctionCurves = new HashSet<int>();
            foreach (var j in junctions)
            {
                foreach (var idx in j.CurveIndices)
                    junctionCurves.Add(idx);
            }
            for (int i = 0; i < curves.Count; i++)
            {
                curves[i].SetUserString("InJunction", junctionCurves.Contains(i) ? "true" : "false");
            }

            List<Curve> pool = new List<Curve>();
            foreach (var c in curves) { if (c != null) pool.Add(c); }

            bool loopAgain = true;
            while (loopAgain)
            {
                loopAgain = false;
                List<MergeCandidate> candidates = new List<MergeCandidate>();

                for (int i = 0; i < pool.Count; i++)
                {
                    for (int j = i + 1; j < pool.Count; j++)
                    {
                        if (GetMinTangentAngle(pool[i], pool[j], tolerance, out double actualAngle))
                        {
                            bool iInJunction = pool[i].GetUserString("InJunction") == "true";
                            bool jInJunction = pool[j].GetUserString("InJunction") == "true";
                            if (iInJunction && jInJunction && actualAngle > angleTolRad * 3)
                                continue;

                            if (actualAngle <= angleTolRad)
                            {
                                candidates.Add(new MergeCandidate { Index1 = i, Index2 = j, Angle = actualAngle });
                            }
                        }
                    }
                }

                if (candidates.Count == 0) break;

                candidates.Sort((a, b) => a.Angle.CompareTo(b.Angle));

                List<Curve> nextGenerationPool = new List<Curve>();
                bool[] indexLocked = new bool[pool.Count];

                foreach (var candidate in candidates)
                {
                    if (indexLocked[candidate.Index1] || indexLocked[candidate.Index2]) continue;

                    Curve[] res = Curve.JoinCurves(new Curve[] { pool[candidate.Index1], pool[candidate.Index2] }, tolerance);
                    if (res != null && res.Length == 1)
                    {
                        PropagateUserStrings(new[] { pool[candidate.Index1], pool[candidate.Index2] }, res[0]);
                        nextGenerationPool.Add(res[0]);
                        indexLocked[candidate.Index1] = true;
                        indexLocked[candidate.Index2] = true;
                        loopAgain = true;
                    }
                }

                for (int i = 0; i < pool.Count; i++)
                {
                    if (!indexLocked[i]) nextGenerationPool.Add(pool[i]);
                }

                pool = nextGenerationPool;
            }
            return pool;
        }

        /// <summary>
        /// 计算两条曲线在端点连接处的最小切线夹角
        /// </summary>
        public static bool GetMinTangentAngle(Curve c1, Curve c2, double tolerance, out double minAngle)
        {
            minAngle = double.MaxValue;

            Point3d s1 = c1.PointAtStart; Point3d e1 = c1.PointAtEnd;
            Point3d s2 = c2.PointAtStart; Point3d e2 = c2.PointAtEnd;

            Vector3d tS1 = c1.TangentAtStart; Vector3d tE1 = c1.TangentAtEnd;
            Vector3d tS2 = c2.TangentAtStart; Vector3d tE2 = c2.TangentAtEnd;

            var angles = new List<double>();

            if (e1.DistanceTo(s2) <= tolerance) angles.Add(Vector3d.VectorAngle(tE1, tS2));
            if (e1.DistanceTo(e2) <= tolerance) angles.Add(Vector3d.VectorAngle(tE1, -tE2));
            if (s1.DistanceTo(s2) <= tolerance) angles.Add(Vector3d.VectorAngle(-tS1, tS2));
            if (s1.DistanceTo(e2) <= tolerance) angles.Add(Vector3d.VectorAngle(-tS1, -tE2));

            if (angles.Count == 0) return false;

            minAngle = angles[0];
            double maxAngle = angles[0];
            for (int i = 1; i < angles.Count; i++)
            {
                if (angles[i] < minAngle) minAngle = angles[i];
                if (angles[i] > maxAngle) maxAngle = angles[i];
            }

            if (angles.Count >= 2)
            {
                const double nearVerticalRad = 80.0 * Math.PI / 180.0;
                if (maxAngle >= nearVerticalRad)
                    return false;
            }

            const double absoluteMaxAngle = 60.0 * Math.PI / 180.0;
            if (minAngle > absoluteMaxAngle) return false;

            return true;
        }

        /// <summary>
        /// 检测交叉节点: 端点 distTol 范围内 ≥3 条曲线交汇的位置
        /// </summary>
        public static List<JunctionInfo> DetectJunctionPoints(List<Curve> curves, double distTol)
        {
            var rtree = new RTree();
            var endpoints = new List<(Point3d Point, int CurveIndex)>(curves.Count * 2);

            for (int i = 0; i < curves.Count; i++)
            {
                if (curves[i] == null) continue;
                var start = curves[i].PointAtStart;
                var end = curves[i].PointAtEnd;
                rtree.Insert(start, i * 2);
                rtree.Insert(end, i * 2 + 1);
                endpoints.Add((start, i));
                endpoints.Add((end, i));
            }

            var junctions = new List<JunctionInfo>();
            var seenPositions = new HashSet<string>();

            for (int i = 0; i < endpoints.Count; i++)
            {
                var neighbors = new HashSet<int>();
                rtree.Search(new Sphere(endpoints[i].Point, distTol), (sender, args) =>
                {
                    int curveIdx = args.Id / 2;
                    neighbors.Add(curveIdx);
                });

                if (neighbors.Count >= 3)
                {
                    string posKey = $"{endpoints[i].Point.X:F4}_{endpoints[i].Point.Y:F4}_{endpoints[i].Point.Z:F4}";
                    if (seenPositions.Add(posKey))
                    {
                        junctions.Add(new JunctionInfo
                        {
                            Position = endpoints[i].Point,
                            CurveIndices = new List<int>(neighbors)
                        });
                    }
                }
            }
            return junctions;
        }

        /// <summary>
        /// 将源曲线的语义标记传播到合并后的曲线
        /// </summary>
        public static void PropagateUserStrings(Curve[] sources, Curve target)
        {
            foreach (var src in sources)
            {
                if (src == null) continue;
                var val = src.GetUserString("IsOuter");
                if (!string.IsNullOrEmpty(val))
                {
                    target.SetUserString("IsOuter", val);
                    break;
                }
            }

            bool allTangent = true;
            bool anyTangent = false;
            foreach (var src in sources)
            {
                if (src == null) continue;
                bool isTangent = src.GetUserString("IsTangent") == "true";
                if (!isTangent) allTangent = false;
                else anyTangent = true;
            }
            if (allTangent && anyTangent)
            {
                target.SetUserString("IsTangent", "true");
            }

            foreach (var src in sources)
            {
                if (src == null) continue;
                var val = src.GetUserString("ComponentName");
                if (!string.IsNullOrEmpty(val))
                {
                    target.SetUserString("ComponentName", val);
                    break;
                }
            }
        }
    }

    public class MergeCandidate
    {
        public int Index1 { get; set; }
        public int Index2 { get; set; }
        public double Angle { get; set; }
    }

    public class JunctionInfo
    {
        public Point3d Position { get; set; }
        public List<int> CurveIndices { get; set; } = new List<int>();
    }
}
