using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using Rhino;
using Rhino.Geometry;
using Rhino.Display;

namespace AutoMake2D.PatentCore
{
    /// <summary>
    /// 渲染捕获引擎 — 渲染捕获 + 白底合成 + PictureFrame 嵌入 + 渲染排版
    /// 从 PatentCore.cs 提取，负责生成渲染效果图
    /// </summary>
    public static class RenderCaptureEngine
    {
        public class RenderViewInfo
        {
            public string Name { get; set; } = "";
            public Plane Plane { get; set; }
        }

        /// <summary>
        /// 根据用户选定的视图模式参数动态确定要渲染的视图列表
        /// </summary>
        public static List<RenderViewInfo> DetermineRenderViews(
            bool wantSix, bool wantIsoFront, bool wantIsoBack, bool wantCurrent,
            BoundingBox modelBox, RhinoView currentView)
        {
            var views = new List<RenderViewInfo>();
            Point3d center = modelBox.IsValid ? modelBox.Center : Point3d.Origin;

            if (wantSix)
            {
                views.Add(new RenderViewInfo { Name = "Front", Plane = PatentProjector.GetViewPlane("Front", center) });
                views.Add(new RenderViewInfo { Name = "Top", Plane = PatentProjector.GetViewPlane("Top", center) });
                views.Add(new RenderViewInfo { Name = "Bottom", Plane = PatentProjector.GetViewPlane("Bottom", center) });
                views.Add(new RenderViewInfo { Name = "Left", Plane = PatentProjector.GetViewPlane("Left", center) });
                views.Add(new RenderViewInfo { Name = "Right", Plane = PatentProjector.GetViewPlane("Right", center) });
                views.Add(new RenderViewInfo { Name = "Back", Plane = PatentProjector.GetViewPlane("Back", center) });
            }

            if (wantIsoFront)
                views.Add(new RenderViewInfo { Name = "IsoFront", Plane = PatentProjector.GetIsoPlane(center, isFront: true, isDown: false) });

            if (wantIsoBack)
                views.Add(new RenderViewInfo { Name = "IsoBack", Plane = PatentProjector.GetIsoPlane(center, isFront: false, isDown: true) });

            if (wantCurrent && currentView != null)
            {
                var vp = currentView.ActiveViewport;
                views.Add(new RenderViewInfo { Name = "CurrentView", Plane = new Plane(center, vp.CameraX, vp.CameraY) });
            }

            return views;
        }

        /// <summary>
        /// 捕获指定视图平面的渲染位图
        /// </summary>
        public static Bitmap CaptureViewRender(RhinoDoc doc, Plane viewPlane, string viewName, Size imageSize)
        {
            Bitmap result = null;
            RhinoView tempView = null;

            try
            {
                tempView = doc.Views.Add(viewName, DefinedViewportProjection.Perspective,
                    new Rectangle(0, 0, imageSize.Width, imageSize.Height), false);

                if (tempView == null)
                {
                    RhinoApp.WriteLine($"⚠️ 无法创建临时视口 [{viewName}]，跳过渲染。");
                    return null;
                }

                var vp = tempView.ActiveViewport;

                vp.SetProjection(DefinedViewportProjection.Perspective, viewName, false);
                vp.ChangeToParallelProjection(true);

                Point3d target = viewPlane.Origin;
                Point3d cameraLocation = viewPlane.Origin + viewPlane.ZAxis * 1000;
                vp.SetCameraLocation(cameraLocation, false);
                vp.SetCameraDirection(-viewPlane.ZAxis, false);
                vp.CameraUp = viewPlane.YAxis;
                vp.SetCameraTarget(target, true);

                BoundingBox modelBox = doc.Views.ActiveView != null
                    ? GetModelBoundingBox(doc)
                    : BoundingBox.Empty;
                if (modelBox.IsValid)
                {
                    Transform xform = Transform.PlaneToPlane(viewPlane, Plane.WorldXY);
                    BoundingBox viewBbox = modelBox;
                    viewBbox.Transform(xform);
                    if (viewBbox.IsValid)
                        vp.ZoomBoundingBox(viewBbox);
                }

                DisplayModeDescription renderMode = DisplayModeDescription.FindByName("Rendered");
                if (renderMode == null)
                    renderMode = DisplayModeDescription.FindByName("Articulated");
                if (renderMode == null)
                    renderMode = DisplayModeDescription.FindByName("Shaded");

                if (renderMode != null)
                    vp.DisplayMode = renderMode;

                tempView.Redraw();

                var captureSettings = new ViewCaptureSettings(tempView, imageSize, 72.0);
                captureSettings.DrawGrid = false;
                captureSettings.DrawAxis = false;
                captureSettings.DrawBackground = true;
                captureSettings.RasterMode = true;

                result = ViewCapture.CaptureToBitmap(captureSettings);

                if (result == null && renderMode != null)
                    result = tempView.CaptureToBitmap(imageSize, renderMode);
            }
            catch (Exception ex)
            {
                RhinoApp.WriteLine($"⚠️ 渲染捕获 [{viewName}] 异常: {ex.Message}");
                result = null;
            }
            finally
            {
                if (tempView != null)
                {
                    tempView.Close();
                }
            }

            return result;
        }

        /// <summary>
        /// 获取文档中所有可见物体的包围盒
        /// </summary>
        public static BoundingBox GetModelBoundingBox(RhinoDoc doc)
        {
            BoundingBox bbox = BoundingBox.Empty;
            foreach (var obj in doc.Objects)
            {
                if (obj == null || !obj.Visible) continue;
                var geo = obj.Geometry;
                if (geo != null)
                    bbox.Union(geo.GetBoundingBox(true));
            }
            return bbox;
        }

        /// <summary>
        /// 渲染图片动态排版
        /// </summary>
        public static Bitmap ComposeRenderLayout(Dictionary<string, Bitmap> viewBitmaps)
        {
            if (viewBitmaps.Count == 0)
                return null;

            if (viewBitmaps.Count == 1)
            {
                using (var enumerator = viewBitmaps.Values.GetEnumerator())
                {
                    if (enumerator.MoveNext())
                        return enumerator.Current;
                }
                return null;
            }

            int refW = 0, refH = 0;
            foreach (var bmp in viewBitmaps.Values)
            {
                if (bmp.Width > refW) refW = bmp.Width;
                if (bmp.Height > refH) refH = bmp.Height;
            }
            double gap = refW * 0.3;

            if (viewBitmaps.Count == 6 && IsSixStandardViews(viewBitmaps))
                return ComposeSixViewLayout(viewBitmaps, refW, refH, gap);
            else if (viewBitmaps.Count == 3 && HasThreeOrthoViews(viewBitmaps))
                return ComposeThreeViewLayout(viewBitmaps, refW, refH, gap);
            else
                return ComposeGenericLayout(viewBitmaps, refW, refH, gap);
        }

        private static bool IsSixStandardViews(Dictionary<string, Bitmap> viewBitmaps)
        {
            string[] required = { "Front", "Top", "Bottom", "Left", "Right", "Back" };
            foreach (var name in required)
                if (!viewBitmaps.ContainsKey(name)) return false;
            return true;
        }

        private static bool HasThreeOrthoViews(Dictionary<string, Bitmap> viewBitmaps)
        {
            return viewBitmaps.ContainsKey("Front") && viewBitmaps.ContainsKey("Top") && viewBitmaps.ContainsKey("Right");
        }

        private static Bitmap ComposeSixViewLayout(Dictionary<string, Bitmap> viewBitmaps,
            int refW, int refH, double gap)
        {
            int canvasW = (int)(4 * refW + 3 * gap);
            int canvasH = (int)(3 * refH + 2 * gap);
            var canvas = new Bitmap(canvasW, canvasH);

            using (var g = Graphics.FromImage(canvas))
            {
                g.Clear(Color.White);
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;

                double centerColX = refW + gap;
                double centerRowY = refH + gap;

                if (viewBitmaps.ContainsKey("Front")) DrawAt(g, viewBitmaps["Front"], centerColX, centerRowY, refW, refH);
                if (viewBitmaps.ContainsKey("Top")) DrawAt(g, viewBitmaps["Top"], centerColX, centerRowY + refH + gap, refW, refH);
                if (viewBitmaps.ContainsKey("Bottom")) DrawAt(g, viewBitmaps["Bottom"], centerColX, centerRowY - refH - gap, refW, refH);
                if (viewBitmaps.ContainsKey("Left")) DrawAt(g, viewBitmaps["Left"], centerColX + refW + gap, centerRowY, refW, refH);
                if (viewBitmaps.ContainsKey("Right")) DrawAt(g, viewBitmaps["Right"], centerColX - refW - gap, centerRowY, refW, refH);
                if (viewBitmaps.ContainsKey("Back")) DrawAt(g, viewBitmaps["Back"], centerColX + 2 * (refW + gap), centerRowY, refW, refH);
            }

            return canvas;
        }

        private static Bitmap ComposeThreeViewLayout(Dictionary<string, Bitmap> viewBitmaps,
            int refW, int refH, double gap)
        {
            int canvasW = (int)(2 * refW + gap);
            int canvasH = (int)(2 * refH + gap);
            var canvas = new Bitmap(canvasW, canvasH);

            using (var g = Graphics.FromImage(canvas))
            {
                g.Clear(Color.White);
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;

                if (viewBitmaps.ContainsKey("Front")) DrawAt(g, viewBitmaps["Front"], 0, 0, refW, refH);
                if (viewBitmaps.ContainsKey("Top")) DrawAt(g, viewBitmaps["Top"], 0, refH + gap, refW, refH);
                if (viewBitmaps.ContainsKey("Right")) DrawAt(g, viewBitmaps["Right"], refW + gap, 0, refW, refH);
            }

            return canvas;
        }

        private static Bitmap ComposeGenericLayout(Dictionary<string, Bitmap> viewBitmaps,
            int refW, int refH, double gap)
        {
            int cols = (int)Math.Ceiling(Math.Sqrt(viewBitmaps.Count));
            int rows = (int)Math.Ceiling((double)viewBitmaps.Count / cols);
            int canvasW = (int)(cols * refW + (cols - 1) * gap);
            int canvasH = (int)(rows * refH + (rows - 1) * gap);
            var canvas = new Bitmap(canvasW, canvasH);

            using (var g = Graphics.FromImage(canvas))
            {
                g.Clear(Color.White);
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;

                int idx = 0;
                foreach (var kvp in viewBitmaps)
                {
                    int col = idx % cols;
                    int row = idx / cols;
                    double x = col * (refW + gap);
                    double y = row * (refH + gap);
                    DrawAt(g, kvp.Value, x, y, refW, refH);
                    idx++;
                }
            }

            return canvas;
        }

        private static void DrawAt(Graphics g, Bitmap bmp, double x, double y, int refW, int refH)
        {
            if (bmp == null) return;
            g.DrawImage(bmp, (float)x, (float)y, refW, refH);
        }
    }
}
