using Rhino;
using Rhino.Commands;
using Rhino.UI;

namespace AutoMake2D
{
    public class AutoMake2DCommand : Command
    {
        public override string EnglishName => "AutoMake2D";

        protected override Result RunCommand(RhinoDoc doc, RunMode mode)
        {
            var panelId = PatentUiPanel.PanelId;
            bool isVisible = Panels.IsPanelVisible(panelId);

            if (!isVisible)
            {
                Panels.OpenPanel(panelId);
            }
            else
            {
                Panels.ClosePanel(panelId);
            }

            return Result.Success;
        }
    }
}
