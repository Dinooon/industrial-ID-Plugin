using System;
using System.IO;

namespace AutoMake2D.Common
{
    /// <summary>
    /// 统一日志系统 — 线程安全文件日志
    /// 日志文件位于 %APPDATA%\AutoMake2D\logs\ 目录下，按日期分文件
    /// </summary>
    public static class Logger
    {
        private static readonly object _lock = new object();
        private static string _logDir = string.Empty;

        private static string LogDir
        {
            get
            {
                if (string.IsNullOrEmpty(_logDir))
                {
                    _logDir = Path.Combine(
                        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                        "AutoMake2D", "logs");
                    if (!Directory.Exists(_logDir))
                        Directory.CreateDirectory(_logDir);
                }
                return _logDir;
            }
        }

        public static void Info(string message)
        {
            Write("INFO", message);
        }

        public static void Warn(string message)
        {
            Write("WARN", message);
        }

        public static void Error(string message)
        {
            Write("ERROR", message);
        }

        public static void Error(string message, Exception ex)
        {
            Write("ERROR", $"{message} | Exception: {ex.GetType().Name}: {ex.Message}\n{ex.StackTrace}");
        }

        private static void Write(string level, string message)
        {
            try
            {
                string fileName = $"AutoMake2D_{DateTime.Now:yyyyMMdd}.log";
                string filePath = Path.Combine(LogDir, fileName);
                string logLine = $"[{DateTime.Now:HH:mm:ss.fff}] [{level}] {message}";

                lock (_lock)
                {
                    File.AppendAllText(filePath, logLine + Environment.NewLine);
                }

                // 同时输出到 Rhino 命令行
                Rhino.RhinoApp.WriteLine($"[AutoMake2D] {logLine}");
            }
            catch
            {
                // 日志写入失败不应影响主流程
            }
        }
    }
}
