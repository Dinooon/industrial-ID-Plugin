# AutoMake2D 4.0

> Rhino 3D 专利图纸自动生成插件 4.0 — 含 Creo 导入功能

---

## 版本说明

AutoMake2D 4.0 在 3.0 (V8) 基础上进行以下升级：

1. **PatentCore 模块化重构**：将 1355 行的 PatentCore.cs 拆分为 7 个独立模块
2. **新增 Creo 导入功能**：参照 CreoImporter.py，用 C# 实现固定路径文件导入
3. **新增视图标注功能**：可选功能，在各视图旁添加中文名称标注
4. **RhinoCommon 升级至 8.x**：兼容 Rhino 7 SR35+ 和 Rhino 8
5. **统一日志系统**：新增 Common/Logger.cs

## 项目结构

```
src/
├── AutoMake2DPlugin.cs           — 插件入口 (72行)
├── AutoMake2DCommand.cs          — 命令定义 (28行)
├── PatentUiPanel.cs              — UI 面板 (346行，含 Creo 导入功能区)
├── AutoMake2D.csproj             — 项目配置 (RhinoCommon 8.x)
├── icon1.ico                     — 插件图标 (需从 3.0 复制)
├── PatentCore/                   — 核心引擎 (模块化)
│   ├── PatentCore.cs             — 门面类 (259行)
│   ├── PatentProjector.cs        — 视图投影 + HLD (228行)
│   ├── CurveFusionEngine.cs      — 曲线融合 (381行)
│   ├── LayerDispatcher.cs        — 图层分发 (78行)
│   ├── LayoutComposer.cs         — 排版引擎 (88行)
│   ├── RenderCaptureEngine.cs    — 渲染捕获 (284行)
│   ├── AnnotationEngine.cs       — 视图标注 (88行)
│   └── CreoImporter.cs           — Creo 导入 (176行)
└── Common/
    └── Logger.cs                 — 统一日志 (73行)
```

## 编译方法

### 环境要求
- .NET SDK (含 .NET Framework 4.8 Targeting Pack)
- MSBuild 16.x+ (Visual Studio 2019+ 自带)
- Rhino 7 SR35+ 或 Rhino 8

### 编译步骤

```bash
cd src/
dotnet restore AutoMake2D.csproj
dotnet build AutoMake2D.csproj -c Release
# 产物: src/bin/Release/net48/AutoMake2D.rhp
```

### 注意事项
- 编译前需将 3.0 版本的 `icon1.ico` 复制到 `src/` 目录
- TargetExt 已设为 `.rhp`，编译产物直接为 Rhino 插件格式
- 如使用 Visual Studio，可直接打开 `.csproj` 编译

## 新功能使用说明

### Creo 导入
1. 在 Creo 中将模型导出为 STEP 文件，保存到 `C:\Temp\creo_sync.step`
2. 在 AutoMake2D 面板顶部"Creo 导入"区域，确认文件路径
3. 点击"从 Creo 导入模型"按钮
4. 等待导入完成，状态显示"导入成功，共 N 个对象"
5. 导入与生成专利图是独立操作，用户自行决定何时生成

### 视图标注
1. 勾选"视图标注（各视图名称）"开关
2. 点击"生成专利图"正常生成
3. 各视图旁会自动出现中文名称标注（Patent_Annotation 图层）

## CreoImporter.py 对照

| 对比项 | CreoImporter.py | AutoMake2D 4.0 C# 实现 |
|--------|-----------------|----------------------|
| 语言 | Python | C# (RhinoCommon) |
| 集成方式 | 独立脚本 | 插件 UI 面板一键点击 |
| 文件路径 | 硬编码 | UI 可配置 |
| 导入后操作 | 无 | 仅反馈结果，不自动衔接 |
| 图层 | Creo_Live_Import | 相同 |
| 错误处理 | 弹窗 | 面板状态 + 日志 |

## 许可证

本项目源码仅供授权使用，未经许可不得分发。
