# CreoToRhino 3.0（免 TOOLKIT 许可证）

CreoToRhino 通过 Creo 5.0 Mapkey、Windows STEP 监听桥接程序和 Rhino 7/8 接收插件，实现近似 KeyShot 的一键模型传输。该版本不在 Creo 内加载自定义 DLL，因此开发、安装和运行均不依赖 Creo TOOLKIT 许可证。

## 工作方式

```text
Creo 5.0 Ribbon 中的 Mapkey 按钮
        │
        ├─ Creo 原生“保存副本为 STEP”
        ▼
C:\Users\Public\Documents\CreoToRhino\Exchange
        │
        ├─ CreoBridge 检测文件写入完成
        ├─ 自动启动或连接 Rhino 7/8
        ▼
CreoReceiver.rhp
        ├─ 在 Rhino UI 线程导入 STEP
        ├─ 标记来源模型
        └─ 新模型成功后替换同来源旧模型
```

Bridge 只处理 `.stp` 和 `.step`。导入失败时保留 Rhino 中的旧模型；成功后只替换同名 Creo 来源对象，不清空 Rhino 文档，也不删除用户自己创建的对象。

## 快速安装

1. 运行根目录的 `build.bat`，或直接使用已经生成的 `dist`。
2. 双击 `dist\install.bat`。
3. 按提示完成 Rhino 插件安装。
4. 根据自动打开的 `Mapkey-Setup.md`，在目标 Creo 5.0 中录制一次 Mapkey。
5. 将该 Mapkey 添加到 Creo Ribbon。

安装位置：

```text
%LOCALAPPDATA%\CreoToRhino\App
```

默认 STEP 交换目录：

```text
C:\Users\Public\Documents\CreoToRhino\Exchange
```

## 使用

1. 在 Creo 打开 `.prt` 或 `.asm`。
2. 点击 Ribbon 中的 `SendToRhino` Mapkey。
3. Creo 使用内置转换器导出 STEP。
4. Bridge 自动发现文件并连接 Rhino。
5. 首次发送创建 `CreoLink_模型名` 图层；再次发送同名模型时替换旧版本。

Bridge 默认在登录后自动启动，位于 Windows 通知区域。右键图标可以：

- 查看状态；
- 打开 STEP 交换目录；
- 手动选择并发送 STEP；
- 打开日志或配置；
- 开启或关闭登录后自动启动。

## Rhino 命令

```text
CreoReceiverStatus
CreoReceiverRestart
```

## 配置

Bridge 配置文件：

```text
%APPDATA%\CreoToRhino\bridge.json
```

默认内容包含：

```json
{
  "exchangeDirectory": "C:\\Users\\Public\\Documents\\CreoToRhino\\Exchange",
  "rhinoPath": "C:\\Program Files\\Rhino 8\\System\\Rhino.exe",
  "autoLaunchRhino": true,
  "launchTimeoutSeconds": 120,
  "deleteAfterImport": true,
  "autoZoom": true
}
```

修改配置后退出并重新启动 Bridge。

## 构建

只需要 .NET SDK；不需要 Visual Studio C++、Creo TOOLKIT 头文件或 TOOLKIT 许可证。

```powershell
build.bat
```

构建产物：

```text
dist/
  Bridge/CreoBridge.exe
  RhinoPlugin/CreoReceiver_v3.rhp
  Mapkey/README.md
  install.bat
  uninstall.bat
```

Rhino 插件以 `.NET Framework 4.8 + RhinoCommon 7.36` 为兼容基线，可由 Rhino 7 和 Rhino 8 加载。

## 日志

```text
%APPDATA%\CreoToRhino\logs\Bridge_YYYYMMDD.log
%APPDATA%\CreoToRhino\logs\RhinoPlugin_YYYYMMDD.log
```

## 已知限制

- Mapkey 与 Creo 语言、日期代码和界面布局相关，需要在每类目标环境录制一次。
- 该方案同步的是 Creo 原生 STEP 导出的整模型，不传输 Creo 参数、特征树、约束或材质关联。
- 同一个 Rhino 文档中，同名 Creo 模型被视为同一来源。
- 装配体的 STEP 内容由 Creo 当前 STEP 导出配置决定。
- 若 Creo 的“保存副本”对话框流程发生变化，需要重新录制 Mapkey。
