@echo off
setlocal

set "CONFIGURATION=Release"

where dotnet >nul 2>&1
if errorlevel 1 (
  echo [ERROR] dotnet was not found.
  exit /b 1
)

echo [1/2] Building license-free STEP bridge...
dotnet restore "Bridge\CreoBridge.csproj"
if errorlevel 1 exit /b 1
dotnet build "Bridge\CreoBridge.csproj" -c %CONFIGURATION% --no-restore
if errorlevel 1 exit /b 1

echo [2/2] Building Rhino 7/8 receiver...
dotnet restore "RhinoPlugin\RhinoPlugin.csproj"
if errorlevel 1 exit /b 1
dotnet build "RhinoPlugin\RhinoPlugin.csproj" -c %CONFIGURATION% --no-restore
if errorlevel 1 exit /b 1

if exist "dist\CreoPlugin" rmdir /S /Q "dist\CreoPlugin"
if not exist "dist\Bridge" mkdir "dist\Bridge"
if not exist "dist\RhinoPlugin" mkdir "dist\RhinoPlugin"
if not exist "dist\Mapkey" mkdir "dist\Mapkey"
if exist "dist\RhinoPlugin\CreoReceiver.rhp" del /Q "dist\RhinoPlugin\CreoReceiver.rhp" >nul 2>&1

copy /Y "bin\%CONFIGURATION%\Bridge\CreoBridge.exe" "dist\Bridge\CreoBridge.exe" >nul
if errorlevel 1 exit /b 1
copy /Y "bin\%CONFIGURATION%\Bridge\CreoBridge.exe.config" "dist\Bridge\CreoBridge.exe.config" >nul
if errorlevel 1 exit /b 1
copy /Y "bin\%CONFIGURATION%\CreoReceiver.dll" "dist\RhinoPlugin\CreoReceiver_v3.rhp" >nul
if errorlevel 1 exit /b 1
copy /Y "CreoMapkey\README.md" "dist\Mapkey\README.md" >nul
if errorlevel 1 exit /b 1
copy /Y "Installer\install.bat" "dist\install.bat" >nul
if errorlevel 1 exit /b 1
copy /Y "Installer\uninstall.bat" "dist\uninstall.bat" >nul
if errorlevel 1 exit /b 1
copy /Y "Installer\README-FIRST.txt" "dist\README-FIRST.txt" >nul
if errorlevel 1 exit /b 1

echo [OK] Build complete: dist\
exit /b 0
