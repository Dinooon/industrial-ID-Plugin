using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using Rhino;
using Rhino.DocObjects;

namespace CreoToRhino.RhinoPlugin
{
    /// <summary>
    /// Imports a STEP file on Rhino's UI thread and replaces only objects managed
    /// by the same Creo source model. Existing user geometry is never cleared.
    /// </summary>
    public sealed class ImportHandler
    {
        public const string SourceIdKey = "CreoToRhino.SourceId";
        public const string ModelNameKey = "CreoToRhino.ModelName";
        private static readonly TimeSpan UiTimeout = TimeSpan.FromMinutes(10);

        public ImportResponse ProcessImport(ImportMessage message)
        {
            ImportResponse response = null;
            Exception dispatchError = null;

            using (var completed = new ManualResetEventSlim(false))
            {
                RhinoApp.InvokeOnUiThread(new Action(() =>
                {
                    try
                    {
                        response = ProcessOnUiThread(message);
                    }
                    catch (Exception ex)
                    {
                        dispatchError = ex;
                    }
                    finally
                    {
                        completed.Set();
                    }
                }));

                if (!completed.Wait(UiTimeout))
                {
                    return Error("等待 Rhino UI 线程处理导入超时");
                }
            }

            if (dispatchError != null)
            {
                Logger.Error($"同步异常: {dispatchError}");
                return Error($"Rhino 同步异常: {dispatchError.Message}");
            }
            return response ?? Error("Rhino 未返回导入结果");
        }

        private static ImportResponse ProcessOnUiThread(ImportMessage message)
        {
            if (message == null) return Error("同步请求为空");
            if (message.ProtocolVersion != 2) return Error("不支持的通信协议版本");
            if (!string.Equals(message.Action, "sync", StringComparison.OrdinalIgnoreCase))
                return Error("不支持的操作");
            if (string.IsNullOrWhiteSpace(message.SourceId)) return Error("缺少 Creo 模型标识");
            if (string.IsNullOrWhiteSpace(message.FilePath) || !File.Exists(message.FilePath))
                return Error($"STEP 文件不存在: {message.FilePath}");

            string extension = Path.GetExtension(message.FilePath);
            if (!string.Equals(extension, ".stp", StringComparison.OrdinalIgnoreCase) &&
                !string.Equals(extension, ".step", StringComparison.OrdinalIgnoreCase))
                return Error("当前版本只接受 STEP 文件");

            RhinoDoc doc = RhinoDoc.ActiveDoc;
            if (doc == null) return Error("Rhino 没有活动文档");

            var oldObjectIds = doc.Objects
                .Where(o => string.Equals(
                    o.Attributes.GetUserString(SourceIdKey),
                    message.SourceId,
                    StringComparison.Ordinal))
                .Select(o => o.Id)
                .ToList();
            var beforeIds = new HashSet<Guid>(doc.Objects.Select(o => o.Id));

            uint undoRecord = doc.BeginUndoRecord("Update model from Creo");
            List<Guid> importedObjectIds = null;
            bool committed = false;
            try
            {
                string escapedPath = message.FilePath.Replace("\"", "\"\"");
                bool commandSucceeded = RhinoApp.RunScript(
                    $"_-Import \"{escapedPath}\" _Enter", false);

                var importedObjects = doc.Objects
                    .Where(o => !beforeIds.Contains(o.Id))
                    .ToList();
                importedObjectIds = importedObjects.Select(o => o.Id).ToList();

                if (!commandSucceeded || importedObjects.Count == 0)
                {
                    foreach (RhinoObject partialObject in importedObjects)
                        doc.Objects.Delete(partialObject.Id, true);
                    return Error(commandSucceeded
                        ? "STEP 中没有可导入的几何对象"
                        : "Rhino STEP 导入命令失败");
                }

                string layerName = NormalizeLayerName(
                    message.Config?.LayerName,
                    message.ModelName);
                Layer existingLayer = doc.Layers.FindName(layerName);
                int layerIndex = existingLayer?.Index ?? -1;
                if (layerIndex < 0)
                {
                    layerIndex = doc.Layers.Add(layerName, System.Drawing.Color.FromArgb(74, 144, 217));
                }
                if (layerIndex < 0) throw new InvalidOperationException("无法创建 CreoLink 图层");

                foreach (RhinoObject importedObject in importedObjects)
                {
                    ObjectAttributes attributes = importedObject.Attributes.Duplicate();
                    attributes.LayerIndex = layerIndex;
                    attributes.SetUserString(SourceIdKey, message.SourceId);
                    attributes.SetUserString(ModelNameKey, message.ModelName ?? string.Empty);
                    if (!doc.Objects.ModifyAttributes(importedObject.Id, attributes, true))
                        throw new InvalidOperationException("无法标记导入对象");
                }

                // Delete the previous revision only after the new revision is valid.
                foreach (Guid oldObjectId in oldObjectIds)
                    doc.Objects.Delete(oldObjectId, true);

                committed = true;

                try
                {
                    if (message.Config == null || message.Config.AutoZoom)
                        doc.Views.ActiveView?.ActiveViewport.ZoomExtents();
                    doc.Views.Redraw();
                }
                catch (Exception viewError)
                {
                    Logger.Warning($"模型已同步，但视图更新失败: {viewError.Message}");
                }

                Logger.Info($"同步完成: source={message.SourceId}, objects={importedObjects.Count}");
                return new ImportResponse
                {
                    Status = "success",
                    ObjectCount = importedObjects.Count,
                    Message = oldObjectIds.Count > 0 ? "模型已更新" : "模型已发送"
                };
            }
            catch (Exception ex)
            {
                if (!committed && importedObjectIds != null)
                {
                    foreach (Guid importedObjectId in importedObjectIds)
                        doc.Objects.Delete(importedObjectId, true);
                }
                Logger.Error($"导入事务失败: {ex}");
                return Error($"导入事务失败: {ex.Message}");
            }
            finally
            {
                if (undoRecord != 0) doc.EndUndoRecord(undoRecord);
            }
        }

        private static string NormalizeLayerName(string requestedName, string modelName)
        {
            string name = string.IsNullOrWhiteSpace(requestedName)
                ? $"CreoLink_{modelName ?? "Model"}"
                : requestedName;
            foreach (char invalid in new[] { ':', '\\', '/', '<', '>', '"', '|', '?', '*' })
                name = name.Replace(invalid, '_');
            return name.Trim();
        }

        private static ImportResponse Error(string message)
        {
            return new ImportResponse { Status = "error", Message = message, ObjectCount = 0 };
        }
    }
}
