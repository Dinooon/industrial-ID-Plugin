using System;
using Rhino;
using Rhino.Commands;
using Rhino.PlugIns;

namespace CreoToRhino.RhinoPlugin
{
    /// <summary>
    /// CreoReceiver — Rhino 端插件主类
    /// 
    /// 功能：
    /// - 在 Rhino 启动时自动加载
    /// - 启动 Named Pipe 服务端监听 Creo 端的导入请求
    /// - 接收请求后通过 ImportHandler 执行文件导入
    /// - 提供状态查询命令 CreoReceiverStatus
    /// </summary>
    public class CreoReceiverPlugin : PlugIn
    {
        public static CreoReceiverPlugin Instance { get; private set; }

        private PipeServer _pipeServer;
        private readonly ImportHandler _importHandler = new ImportHandler();

        /// <summary>
        /// 插件是否正在运行
        /// </summary>
        public bool IsRunning => _pipeServer?.IsRunning == true;

        /// <summary>
        /// 插件版本号
        /// </summary>
        public string PluginVersion => "3.0.0";

        public CreoReceiverPlugin()
        {
            Instance = this;
            Logger.Info("=== CreoReceiver 插件实例创建 ===");
        }

        /// <summary>
        /// 插件加载时调用
        /// </summary>
        protected override LoadReturnCode OnLoad(ref string errorMessage)
        {
            Logger.Info("=== CreoReceiver 插件加载 ===");

            try
            {
                // 启动 Named Pipe 服务端
                _pipeServer = new PipeServer();
                _pipeServer.OnImportRequested = _importHandler.ProcessImport;
                _pipeServer.Start();

                Logger.Info("CreoReceiver 插件加载成功，Pipe 服务端已启动");

                // 注册状态查询命令
                // 命令注册通过 Command 类的属性自动完成

                return LoadReturnCode.Success;
            }
            catch (Exception ex)
            {
                errorMessage = $"CreoReceiver 加载失败: {ex.Message}";
                Logger.Error($"插件加载异常: {ex.Message}\n{ex.StackTrace}");
                return LoadReturnCode.ErrorShowDialog;
            }
        }

        /// <summary>
        /// 插件卸载时调用
        /// </summary>
        protected override void OnShutdown()
        {
            Logger.Info("=== CreoReceiver 插件卸载 ===");

            try
            {
                _pipeServer?.Dispose();
                _pipeServer = null;
            }
            catch (Exception ex)
            {
                Logger.Error($"插件卸载异常: {ex.Message}");
            }

            base.OnShutdown();
        }

        /// <summary>
        /// 插件是否应该在关闭 Rhino 时保持加载
        /// </summary>
        public override PlugInLoadTime LoadTime => PlugInLoadTime.AtStartup;

        /// <summary>
        /// 停止 Pipe 服务端（供命令调用）
        /// </summary>
        public void StopPipeServer()
        {
            _pipeServer?.Stop();
        }

        /// <summary>
        /// 启动 Pipe 服务端（供命令调用）
        /// </summary>
        public void StartPipeServer()
        {
            if (_pipeServer == null)
            {
                _pipeServer = new PipeServer();
                _pipeServer.OnImportRequested = _importHandler.ProcessImport;
            }
            _pipeServer.Start();
        }
    }

    /// <summary>
    /// 状态查询命令 — 用户可以输入 CreoReceiverStatus 查看插件运行状态
    /// </summary>
    [Rhino.Commands.CommandStyle(Rhino.Commands.Style.DoNotRepeat)]
    public class CreoReceiverStatusCommand : Rhino.Commands.Command
    {
        public override string EnglishName => "CreoReceiverStatus";

        protected override Rhino.Commands.Result RunCommand(RhinoDoc doc, RunMode mode)
        {
            var plugin = CreoReceiverPlugin.Instance;

            if (plugin == null)
            {
                RhinoApp.WriteLine("CreoReceiver 插件未加载");
                return Rhino.Commands.Result.Failure;
            }

            RhinoApp.WriteLine("═══════════════════════════════════════");
            RhinoApp.WriteLine("  CreoReceiver — 状态信息");
            RhinoApp.WriteLine("═══════════════════════════════════════");
            RhinoApp.WriteLine($"  插件版本: {plugin.PluginVersion}");
            RhinoApp.WriteLine($"  运行状态: {(plugin.IsRunning ? "运行中 ✓" : "已停止 ✗")}");
            RhinoApp.WriteLine($"  管道名称: \\\\.\\pipe\\{PipeServer.PipeName}");
            RhinoApp.WriteLine($"  当前文档: {doc.Name ?? "(未命名)"}");
            RhinoApp.WriteLine($"  文档单位: {doc.ModelUnitSystem}");
            RhinoApp.WriteLine($"  对象数量: {doc.Objects.Count}");
            RhinoApp.WriteLine($"  图层数量: {doc.Layers.Count}");
            RhinoApp.WriteLine("═══════════════════════════════════════");

            if (plugin.IsRunning)
            {
                RhinoApp.WriteLine("  插件正常运行中，正在监听 Creo 端连接...");
            }
            else
            {
                RhinoApp.WriteLine("  警告: Pipe 服务端未运行！");
            }
            RhinoApp.WriteLine("═══════════════════════════════════════");

            return Rhino.Commands.Result.Success;
        }
    }

    /// <summary>
    /// 手动重启 Pipe 服务端命令
    /// </summary>
    [Rhino.Commands.CommandStyle(Rhino.Commands.Style.DoNotRepeat)]
    public class CreoReceiverRestartCommand : Rhino.Commands.Command
    {
        public override string EnglishName => "CreoReceiverRestart";

        protected override Rhino.Commands.Result RunCommand(RhinoDoc doc, RunMode mode)
        {
            var plugin = CreoReceiverPlugin.Instance;
            if (plugin == null)
            {
                RhinoApp.WriteLine("CreoReceiver 插件未加载");
                return Rhino.Commands.Result.Failure;
            }

            RhinoApp.WriteLine("正在重启 Pipe 服务端...");

            // 停止现有服务端
            plugin.StopPipeServer();

            // 重新启动
            plugin.StartPipeServer();

            RhinoApp.WriteLine($"Pipe 服务端已{(plugin.IsRunning ? "重启成功" : "重启失败")}");

            return plugin.IsRunning ? Rhino.Commands.Result.Success : Rhino.Commands.Result.Failure;
        }
    }
}
