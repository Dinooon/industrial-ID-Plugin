using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;

namespace CreoToRhino.RhinoPlugin
{
    [DataContract]
    public sealed class ImportMessage
    {
        [DataMember(Name = "protocolVersion", EmitDefaultValue = false)]
        public int ProtocolVersion { get; set; }

        [DataMember(Name = "action")]
        public string Action { get; set; }

        [DataMember(Name = "filePath")]
        public string FilePath { get; set; }

        [DataMember(Name = "sourceId")]
        public string SourceId { get; set; }

        [DataMember(Name = "modelName")]
        public string ModelName { get; set; }

        [DataMember(Name = "config")]
        public ImportConfig Config { get; set; } = new ImportConfig();
    }

    [DataContract]
    public sealed class ImportConfig
    {
        [DataMember(Name = "layerName")]
        public string LayerName { get; set; }

        [DataMember(Name = "autoZoom")]
        public bool AutoZoom { get; set; } = true;
    }

    [DataContract]
    public sealed class ImportResponse
    {
        [DataMember(Name = "status")]
        public string Status { get; set; } = "error";

        [DataMember(Name = "objectCount")]
        public int ObjectCount { get; set; }

        [DataMember(Name = "message")]
        public string Message { get; set; } = string.Empty;
    }

    public static class JsonHelper
    {
        public static ImportMessage DeserializeMessage(string json)
        {
            return Deserialize<ImportMessage>(json);
        }

        public static string Serialize(ImportResponse response)
        {
            var serializer = new DataContractJsonSerializer(typeof(ImportResponse));
            using (var stream = new MemoryStream())
            {
                serializer.WriteObject(stream, response);
                return Encoding.UTF8.GetString(stream.ToArray());
            }
        }

        private static T Deserialize<T>(string json)
        {
            var serializer = new DataContractJsonSerializer(typeof(T));
            using (var stream = new MemoryStream(Encoding.UTF8.GetBytes(json)))
            {
                return (T)serializer.ReadObject(stream);
            }
        }
    }
}
