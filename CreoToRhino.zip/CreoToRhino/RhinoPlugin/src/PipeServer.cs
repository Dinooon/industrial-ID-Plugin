using System;
using System.IO;
using System.IO.Pipes;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CreoToRhino.RhinoPlugin
{
    public sealed class PipeServer : IDisposable
    {
        public const string PipeName = "CreoToRhino";
        private const int BufferSize = 4096;
        private const int MaximumRequestBytes = 1024 * 1024;

        private readonly object _stateLock = new object();
        private CancellationTokenSource _cts;
        private Task _listenTask;
        private bool _disposed;

        public Func<ImportMessage, ImportResponse> OnImportRequested { get; set; }

        public bool IsRunning
        {
            get
            {
                lock (_stateLock)
                    return _cts != null && !_cts.IsCancellationRequested &&
                           _listenTask != null && !_listenTask.IsCompleted;
            }
        }

        public void Start()
        {
            lock (_stateLock)
            {
                if (_disposed) throw new ObjectDisposedException(nameof(PipeServer));
                if (IsRunning) return;
                _cts?.Dispose();
                _cts = new CancellationTokenSource();
                _listenTask = Task.Run(() => ListenLoopAsync(_cts.Token));
            }
            Logger.Info($"Named Pipe 服务已启动: {PipeName}");
        }

        public void Stop()
        {
            CancellationTokenSource cts;
            Task task;
            lock (_stateLock)
            {
                cts = _cts;
                task = _listenTask;
                if (cts == null) return;
                cts.Cancel();
            }

            // Unblock WaitForConnectionAsync on older .NET Framework builds.
            try
            {
                using (var client = new NamedPipeClientStream(".", PipeName, PipeDirection.InOut))
                    client.Connect(250);
            }
            catch { }

            try { task?.Wait(2000); } catch { }
            lock (_stateLock)
            {
                if (ReferenceEquals(_cts, cts))
                {
                    _cts.Dispose();
                    _cts = null;
                    _listenTask = null;
                }
            }
            Logger.Info("Named Pipe 服务已停止");
        }

        private async Task ListenLoopAsync(CancellationToken token)
        {
            while (!token.IsCancellationRequested)
            {
                try
                {
                    using (var server = new NamedPipeServerStream(
                        PipeName,
                        PipeDirection.InOut,
                        1,
                        PipeTransmissionMode.Message,
                        PipeOptions.Asynchronous,
                        BufferSize,
                        BufferSize))
                    {
                        await server.WaitForConnectionAsync(token).ConfigureAwait(false);
                        if (token.IsCancellationRequested) return;
                        await ProcessRequestAsync(server, token).ConfigureAwait(false);
                    }
                }
                catch (OperationCanceledException) when (token.IsCancellationRequested)
                {
                    return;
                }
                catch (Exception ex)
                {
                    Logger.Error($"Pipe 监听异常: {ex.Message}");
                    try { await Task.Delay(500, token).ConfigureAwait(false); }
                    catch (OperationCanceledException) { return; }
                }
            }
        }

        private async Task ProcessRequestAsync(NamedPipeServerStream server, CancellationToken token)
        {
            ImportResponse response;
            try
            {
                string json = await ReadMessageAsync(server, token).ConfigureAwait(false);
                ImportMessage request = JsonHelper.DeserializeMessage(json);
                response = OnImportRequested != null
                    ? OnImportRequested(request)
                    : Error("导入处理器未注册");
            }
            catch (Exception ex)
            {
                Logger.Error($"Pipe 请求失败: {ex.Message}");
                response = Error($"请求处理失败: {ex.Message}");
            }

            try
            {
                byte[] bytes = Encoding.UTF8.GetBytes(JsonHelper.Serialize(response));
                await server.WriteAsync(bytes, 0, bytes.Length, token).ConfigureAwait(false);
                await server.FlushAsync(token).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                Logger.Warning($"无法发送 Pipe 回复: {ex.Message}");
            }
        }

        private static async Task<string> ReadMessageAsync(
            NamedPipeServerStream server,
            CancellationToken token)
        {
            using (var memory = new MemoryStream())
            {
                var buffer = new byte[BufferSize];
                do
                {
                    int read = await server.ReadAsync(buffer, 0, buffer.Length, token).ConfigureAwait(false);
                    if (read == 0) throw new EndOfStreamException("Creo 已断开连接");
                    memory.Write(buffer, 0, read);
                    if (memory.Length > MaximumRequestBytes)
                        throw new InvalidDataException("同步请求超过大小限制");
                } while (!server.IsMessageComplete);
                return Encoding.UTF8.GetString(memory.ToArray());
            }
        }

        private static ImportResponse Error(string message)
        {
            return new ImportResponse { Status = "error", Message = message };
        }

        public void Dispose()
        {
            if (_disposed) return;
            Stop();
            _disposed = true;
        }
    }
}
