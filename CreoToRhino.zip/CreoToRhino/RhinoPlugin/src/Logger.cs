using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;

namespace CreoToRhino.RhinoPlugin
{
    /// <summary>
    /// 日志级别枚举
    /// </summary>
    public enum LogLevel
    {
        Debug,
        Info,
        Warning,
        Error
    }

    /// <summary>
    /// 线程安全的文件日志记录器
    /// 日志文件位置：%APPDATA%\CreoToRhino\logs\RhinoPlugin_YYYYMMDD.log
    /// </summary>
    public static class Logger
    {
        private static readonly object _lock = new object();
        private static LogLevel _minLevel = LogLevel.Debug;
        private static readonly string _logDir;

        static Logger()
        {
            string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            _logDir = Path.Combine(appData, "CreoToRhino", "logs");
            try
            {
                if (!Directory.Exists(_logDir))
                {
                    Directory.CreateDirectory(_logDir);
                }
            }
            catch { }
        }

        public static void SetMinLevel(LogLevel level)
        {
            _minLevel = level;
        }

        public static void Log(LogLevel level, string message, [System.Runtime.CompilerServices.CallerFilePath] string file = "", [System.Runtime.CompilerServices.CallerLineNumber] int line = 0)
        {
            if (level < _minLevel) return;

            lock (_lock)
            {
                try
                {
                    string logFile = Path.Combine(_logDir, $"RhinoPlugin_{DateTime.Now:yyyyMMdd}.log");
                    string filename = Path.GetFileName(file);
                    string levelStr = level.ToString().ToUpper();
                    string timeStr = DateTime.Now.ToString("HH:mm:ss.fff");

                    string logLine = $"[{timeStr}] [{levelStr}] [{filename}:{line}] {message}";

                    File.AppendAllText(logFile, logLine + Environment.NewLine, Encoding.UTF8);
                }
                catch { }
            }
        }

        public static void Debug(string msg) => Log(LogLevel.Debug, msg);
        public static void Info(string msg) => Log(LogLevel.Info, msg);
        public static void Warning(string msg) => Log(LogLevel.Warning, msg);
        public static void Error(string msg) => Log(LogLevel.Error, msg);
    }
}
