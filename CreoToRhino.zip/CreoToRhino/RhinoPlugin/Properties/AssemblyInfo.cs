using System.Reflection;
using System.Runtime.InteropServices;

// 程序集属性
[assembly: AssemblyTitle("CreoReceiver")]
[assembly: AssemblyDescription("Creo Mapkey STEP bridge receiver for Rhino 7/8")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyCompany("CreoToRhino")]
[assembly: AssemblyProduct("CreoReceiver")]
[assembly: AssemblyCopyright("Copyright © 2026")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]
[assembly: Guid("b3c4d5e6-f7a8-9012-bcde-f23456789012")]

[assembly: AssemblyVersion("3.0.0.0")]
[assembly: AssemblyFileVersion("3.0.0.0")]
