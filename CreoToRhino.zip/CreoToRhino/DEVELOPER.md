# Developer Notes

## Components

- `Bridge/`: .NET Framework 4.8 tray application. Watches Creo STEP exports and acts as the named-pipe client.
- `RhinoPlugin/`: RhinoCommon plug-in. Owns the named-pipe server and performs transactional imports on Rhino's UI thread.
- `CreoMapkey/`: target-machine recording and Ribbon setup instructions.
- `Installer/`: per-user install and uninstall scripts used by the release package.

The old Pro/TOOLKIT C++ DLL was intentionally removed. No code is injected into the Creo process.

## Pipe protocol

Pipe name:

```text
\\.\pipe\CreoToRhino
```

Request example:

```json
{
  "protocolVersion": 2,
  "action": "sync",
  "filePath": "C:\\Users\\Public\\Documents\\CreoToRhino\\Exchange\\housing.stp",
  "sourceId": "creo-mapkey:HOUSING",
  "modelName": "housing",
  "config": {
    "layerName": "CreoLink_housing",
    "autoZoom": true
  }
}
```

Response example:

```json
{
  "status": "success",
  "objectCount": 12,
  "message": "Model updated"
}
```

Each JSON payload is serialized to memory and sent with one named-pipe write so Windows message boundaries remain intact.

## Watcher guarantees

- Accepts only `.stp` and `.step`.
- Debounces multiple filesystem events for the same path.
- Serializes imports so Rhino receives one model at a time.
- Requires a non-empty file with stable size and write timestamp before sending.
- Waits up to 60 seconds for Creo to release the export.
- Deletes a STEP only after Rhino reports success and only when the file is inside the configured exchange directory.
- Manual sends outside the exchange directory are never deleted.

## Rhino transaction guarantees

- Import runs on the Rhino UI thread.
- New object IDs are determined by a before/after snapshot.
- New objects receive `CreoToRhino.SourceId` and `CreoToRhino.ModelName` user strings.
- Previous objects with the same source ID are deleted only after the new import succeeds.
- Partial imports are removed on failure.
- User-created objects and objects from other Creo sources remain untouched.

## Build and verification

```powershell
dotnet restore Bridge\CreoBridge.csproj
dotnet build Bridge\CreoBridge.csproj -c Release --no-restore
dotnet restore RhinoPlugin\RhinoPlugin.csproj
dotnet build RhinoPlugin\RhinoPlugin.csproj -c Release --no-restore
```

For isolated pipe testing, set these optional environment variables:

```text
CREO_TO_RHINO_PIPE_NAME
CREO_TO_RHINO_DATA_DIR
CREO_TO_RHINO_EXCHANGE_DIR
```

One-shot test entry point:

```powershell
CreoBridge.exe --send C:\path\model.stp
```

The test fixture `tests/fixtures/housing.prt.stp` verifies that nested Creo extensions are normalized to model name `housing`.
