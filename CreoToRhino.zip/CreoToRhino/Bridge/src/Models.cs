using System.Runtime.Serialization;

namespace CreoToRhino.Bridge
{
    [DataContract]
    internal sealed class ImportMessage
    {
        [DataMember(Name = "protocolVersion")]
        public int ProtocolVersion { get; set; } = 2;

        [DataMember(Name = "action")]
        public string Action { get; set; } = "sync";

        [DataMember(Name = "filePath")]
        public string FilePath { get; set; }

        [DataMember(Name = "sourceId")]
        public string SourceId { get; set; }

        [DataMember(Name = "modelName")]
        public string ModelName { get; set; }

        [DataMember(Name = "config")]
        public ImportConfig Config { get; set; } = new ImportConfig();
    }

    [DataContract]
    internal sealed class ImportConfig
    {
        [DataMember(Name = "layerName")]
        public string LayerName { get; set; }

        [DataMember(Name = "autoZoom")]
        public bool AutoZoom { get; set; } = true;
    }

    [DataContract]
    internal sealed class ImportResponse
    {
        [DataMember(Name = "status")]
        public string Status { get; set; }

        [DataMember(Name = "objectCount")]
        public int ObjectCount { get; set; }

        [DataMember(Name = "message")]
        public string Message { get; set; }
    }

    internal sealed class SendResult
    {
        public bool Success { get; set; }
        public int ObjectCount { get; set; }
        public string Message { get; set; }

        public static SendResult Error(string message) => new SendResult
        {
            Success = false,
            Message = message ?? "Unknown error"
        };
    }
}
