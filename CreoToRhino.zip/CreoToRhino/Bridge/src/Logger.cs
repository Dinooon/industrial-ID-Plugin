using System;
using System.IO;
using System.Text;

namespace CreoToRhino.Bridge
{
    internal static class Logger
    {
        private static readonly object Gate = new object();

        public static string LogDirectory => Path.Combine(BridgeConfig.DataDirectory, "logs");
        public static string CurrentLogPath => Path.Combine(LogDirectory, $"Bridge_{DateTime.Now:yyyyMMdd}.log");

        public static void Info(string message) => Write("INFO", message);
        public static void Warning(string message) => Write("WARN", message);
        public static void Error(string message) => Write("ERROR", message);

        private static void Write(string level, string message)
        {
            try
            {
                lock (Gate)
                {
                    Directory.CreateDirectory(LogDirectory);
                    File.AppendAllText(
                        CurrentLogPath,
                        $"{DateTime.Now:yyyy-MM-dd HH:mm:ss.fff} [{level}] {message}{Environment.NewLine}",
                        new UTF8Encoding(false));
                }
            }
            catch { }
        }
    }
}
