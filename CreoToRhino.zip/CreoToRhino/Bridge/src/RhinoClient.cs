using System;
using System.Diagnostics;
using System.IO;
using System.IO.Pipes;
using System.Runtime.Serialization.Json;
using System.Threading;

namespace CreoToRhino.Bridge
{
    internal sealed class RhinoClient
    {
        private const int MaximumResponseBytes = 1024 * 1024;
        private readonly BridgeConfig _config;

        private static string PipeName
        {
            get
            {
                string overrideName = Environment.GetEnvironmentVariable("CREO_TO_RHINO_PIPE_NAME");
                return string.IsNullOrWhiteSpace(overrideName) ? "CreoToRhino" : overrideName;
            }
        }

        public RhinoClient(BridgeConfig config)
        {
            _config = config;
        }

        public SendResult Send(string stepPath, string modelName)
        {
            ImportMessage request = new ImportMessage
            {
                FilePath = stepPath,
                ModelName = modelName,
                SourceId = "creo-mapkey:" + modelName.ToUpperInvariant(),
                Config = new ImportConfig
                {
                    LayerName = "CreoLink_" + modelName,
                    AutoZoom = _config.AutoZoom
                }
            };

            NamedPipeClientStream pipe = TryConnect(1000);
            if (pipe == null)
            {
                bool rhinoRunning = Process.GetProcessesByName("Rhino").Length > 0;
                if (!rhinoRunning)
                {
                    if (!_config.AutoLaunchRhino)
                        return SendResult.Error("Rhino is not running and automatic launch is disabled.");
                    if (string.IsNullOrWhiteSpace(_config.RhinoPath) || !File.Exists(_config.RhinoPath))
                        return SendResult.Error("Rhino 7/8 was not found. Set rhinoPath in bridge.json.");

                    try
                    {
                        Process.Start(new ProcessStartInfo(_config.RhinoPath) { UseShellExecute = true });
                        Logger.Info("Started Rhino: " + _config.RhinoPath);
                    }
                    catch (Exception ex)
                    {
                        return SendResult.Error("Could not start Rhino: " + ex.Message);
                    }
                }

                DateTime deadline = DateTime.UtcNow.AddSeconds(_config.LaunchTimeoutSeconds);
                while (DateTime.UtcNow < deadline && pipe == null)
                {
                    Thread.Sleep(500);
                    pipe = TryConnect(500);
                }
            }

            if (pipe == null)
            {
                return SendResult.Error(
                    "Rhino receiver is unavailable. Install CreoReceiver.rhp and run CreoReceiverStatus in Rhino.");
            }

            using (pipe)
            {
                try
                {
                    var requestSerializer = new DataContractJsonSerializer(typeof(ImportMessage));
                    byte[] requestBytes;
                    using (var requestMemory = new MemoryStream())
                    {
                        requestSerializer.WriteObject(requestMemory, request);
                        requestBytes = requestMemory.ToArray();
                    }
                    pipe.Write(requestBytes, 0, requestBytes.Length);
                    pipe.Flush();

                    using (var memory = new MemoryStream())
                    {
                        byte[] buffer = new byte[4096];
                        do
                        {
                            int read = pipe.Read(buffer, 0, buffer.Length);
                            if (read == 0) throw new EndOfStreamException("Rhino closed the pipe before replying.");
                            memory.Write(buffer, 0, read);
                            if (memory.Length > MaximumResponseBytes)
                                throw new InvalidDataException("Rhino response exceeded the size limit.");
                        } while (!pipe.IsMessageComplete);

                        memory.Position = 0;
                        var responseSerializer = new DataContractJsonSerializer(typeof(ImportResponse));
                        var response = (ImportResponse)responseSerializer.ReadObject(memory);
                        return new SendResult
                        {
                            Success = string.Equals(response?.Status, "success", StringComparison.OrdinalIgnoreCase),
                            ObjectCount = response?.ObjectCount ?? 0,
                            Message = response?.Message ?? "Rhino returned an empty response."
                        };
                    }
                }
                catch (Exception ex)
                {
                    return SendResult.Error("Communication with Rhino failed: " + ex.Message);
                }
            }
        }

        private static NamedPipeClientStream TryConnect(int timeoutMilliseconds)
        {
            var pipe = new NamedPipeClientStream(
                ".", PipeName, PipeDirection.InOut, PipeOptions.None);
            try
            {
                pipe.Connect(timeoutMilliseconds);
                pipe.ReadMode = PipeTransmissionMode.Message;
                return pipe;
            }
            catch
            {
                pipe.Dispose();
                return null;
            }
        }
    }
}
