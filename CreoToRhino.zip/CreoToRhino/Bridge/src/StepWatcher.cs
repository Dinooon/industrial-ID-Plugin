using System;
using System.Collections.Concurrent;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace CreoToRhino.Bridge
{
    internal sealed class StepWatcher : IDisposable
    {
        private readonly BridgeConfig _config;
        private readonly RhinoClient _client;
        private readonly FileSystemWatcher _watcher;
        private readonly ConcurrentDictionary<string, CancellationTokenSource> _pending =
            new ConcurrentDictionary<string, CancellationTokenSource>(StringComparer.OrdinalIgnoreCase);
        private readonly SemaphoreSlim _sendLock = new SemaphoreSlim(1, 1);
        private bool _disposed;

        public event Action<string, bool> StatusChanged;

        public StepWatcher(BridgeConfig config)
        {
            _config = config;
            _client = new RhinoClient(config);
            Directory.CreateDirectory(config.ExchangeDirectory);
            _watcher = new FileSystemWatcher(config.ExchangeDirectory)
            {
                Filter = "*.*",
                IncludeSubdirectories = false,
                NotifyFilter = NotifyFilters.FileName | NotifyFilters.LastWrite |
                               NotifyFilters.Size | NotifyFilters.CreationTime,
                EnableRaisingEvents = false
            };
            _watcher.Created += OnFileEvent;
            _watcher.Changed += OnFileEvent;
            _watcher.Renamed += OnRenamed;
            _watcher.Error += OnWatcherError;
        }

        public void Start()
        {
            _watcher.EnableRaisingEvents = true;
            Logger.Info("Watching STEP exchange directory: " + _config.ExchangeDirectory);
            RaiseStatus("正在监听 Creo STEP 导出目录", false);
        }

        public void QueueFile(string path)
        {
            if (_disposed || !IsStep(path)) return;

            string fullPath;
            try { fullPath = Path.GetFullPath(path); }
            catch { return; }

            var next = new CancellationTokenSource();
            _pending.AddOrUpdate(
                fullPath,
                next,
                (_, previous) =>
                {
                    previous.Cancel();
                    previous.Dispose();
                    return next;
                });

            Task.Run(async () =>
            {
                try
                {
                    await Task.Delay(750, next.Token).ConfigureAwait(false);
                    await ProcessFileAsync(fullPath, next.Token).ConfigureAwait(false);
                }
                catch (OperationCanceledException) { }
                finally
                {
                    if (_pending.TryGetValue(fullPath, out CancellationTokenSource current) &&
                        ReferenceEquals(current, next))
                    {
                        _pending.TryRemove(fullPath, out _);
                        next.Dispose();
                    }
                }
            });
        }

        private async Task ProcessFileAsync(string path, CancellationToken token)
        {
            await _sendLock.WaitAsync(token).ConfigureAwait(false);
            try
            {
                if (!await WaitUntilStableAsync(path, token).ConfigureAwait(false))
                {
                    RaiseStatus("STEP 文件没有完成写入：" + Path.GetFileName(path), true);
                    return;
                }

                string modelName = GetModelName(path);
                RaiseStatus("正在发送 " + modelName + " 到 Rhino", false);
                Logger.Info("Sending STEP: " + path);
                SendResult result = _client.Send(path, modelName);
                if (!result.Success)
                {
                    Logger.Error($"Send failed for {path}: {result.Message}");
                    RaiseStatus("发送失败：" + result.Message, true);
                    return;
                }

                Logger.Info($"Send completed: model={modelName}, objects={result.ObjectCount}");
                RaiseStatus($"{modelName} 已发送到 Rhino（{result.ObjectCount} 个对象）", true);

                if (_config.DeleteAfterImport && IsInsideExchangeDirectory(path))
                {
                    try { File.Delete(path); }
                    catch (Exception ex) { Logger.Warning("Could not delete imported STEP: " + ex.Message); }
                }
            }
            finally
            {
                _sendLock.Release();
            }
        }

        private static async Task<bool> WaitUntilStableAsync(string path, CancellationToken token)
        {
            long previousLength = -1;
            DateTime previousWrite = DateTime.MinValue;
            int stableSamples = 0;
            DateTime deadline = DateTime.UtcNow.AddSeconds(60);

            while (DateTime.UtcNow < deadline)
            {
                token.ThrowIfCancellationRequested();
                try
                {
                    var file = new FileInfo(path);
                    if (!file.Exists)
                    {
                        await Task.Delay(300, token).ConfigureAwait(false);
                        continue;
                    }

                    long length = file.Length;
                    DateTime write = file.LastWriteTimeUtc;
                    using (FileStream stream = File.Open(path, FileMode.Open, FileAccess.Read, FileShare.Read))
                    {
                        if (length > 0 && length == previousLength && write == previousWrite)
                            stableSamples++;
                        else
                            stableSamples = 0;
                    }

                    if (stableSamples >= 2) return true;
                    previousLength = length;
                    previousWrite = write;
                }
                catch (IOException)
                {
                    stableSamples = 0;
                }
                catch (UnauthorizedAccessException)
                {
                    stableSamples = 0;
                }

                await Task.Delay(400, token).ConfigureAwait(false);
            }
            return false;
        }

        private bool IsInsideExchangeDirectory(string path)
        {
            string root = Path.GetFullPath(_config.ExchangeDirectory)
                .TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + Path.DirectorySeparatorChar;
            string candidate = Path.GetFullPath(path);
            return candidate.StartsWith(root, StringComparison.OrdinalIgnoreCase);
        }

        internal static string GetModelName(string path)
        {
            string name = Path.GetFileNameWithoutExtension(path);
            string nestedExtension = Path.GetExtension(name);
            if (string.Equals(nestedExtension, ".prt", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(nestedExtension, ".asm", StringComparison.OrdinalIgnoreCase))
            {
                name = Path.GetFileNameWithoutExtension(name);
            }
            return string.IsNullOrWhiteSpace(name) ? "CreoModel" : name;
        }

        private static bool IsStep(string path)
        {
            string extension = Path.GetExtension(path);
            return string.Equals(extension, ".stp", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(extension, ".step", StringComparison.OrdinalIgnoreCase);
        }

        private void OnFileEvent(object sender, FileSystemEventArgs e) => QueueFile(e.FullPath);
        private void OnRenamed(object sender, RenamedEventArgs e) => QueueFile(e.FullPath);

        private void OnWatcherError(object sender, ErrorEventArgs e)
        {
            Logger.Error("STEP watcher error: " + e.GetException()?.Message);
            RaiseStatus("交换目录监听异常，请重新启动桥接程序", true);
        }

        private void RaiseStatus(string message, bool notify)
        {
            StatusChanged?.Invoke(message, notify);
        }

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
            _watcher.Dispose();
            foreach (CancellationTokenSource token in _pending.Values)
            {
                token.Cancel();
                token.Dispose();
            }
            _pending.Clear();
            _sendLock.Dispose();
        }
    }
}
