using System;
using System.IO;
using System.Threading;
using System.Windows.Forms;

namespace CreoToRhino.Bridge
{
    internal static class Program
    {
        private const string MutexName = "Local\\CreoToRhinoBridge_3_0";

        [STAThread]
        private static int Main(string[] args)
        {
            if (args.Length == 2 && string.Equals(args[0], "--send", StringComparison.OrdinalIgnoreCase))
                return SendOnce(args[1]);

            bool createdNew;
            using (var mutex = new Mutex(true, MutexName, out createdNew))
            {
                if (!createdNew)
                {
                    MessageBox.Show(
                        "CreoToRhino Bridge 已经在运行，请查看 Windows 通知区域。",
                        "CreoToRhino",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    return 0;
                }

                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new BridgeApplicationContext());
                GC.KeepAlive(mutex);
            }
            return 0;
        }

        private static int SendOnce(string path)
        {
            try
            {
                string fullPath = Path.GetFullPath(path);
                if (!File.Exists(fullPath))
                {
                    Logger.Error("STEP file does not exist: " + fullPath);
                    return 2;
                }

                string extension = Path.GetExtension(fullPath);
                if (!string.Equals(extension, ".stp", StringComparison.OrdinalIgnoreCase) &&
                    !string.Equals(extension, ".step", StringComparison.OrdinalIgnoreCase))
                {
                    Logger.Error("Only STEP files can be sent: " + fullPath);
                    return 2;
                }

                BridgeConfig config = BridgeConfig.Load();
                SendResult result = new RhinoClient(config).Send(fullPath, StepWatcher.GetModelName(fullPath));
                if (result.Success)
                {
                    Logger.Info("One-shot send completed: " + fullPath);
                    return 0;
                }
                Logger.Error("One-shot send failed: " + result.Message);
                return 1;
            }
            catch (Exception ex)
            {
                Logger.Error("One-shot send exception: " + ex);
                return 1;
            }
        }
    }
}
