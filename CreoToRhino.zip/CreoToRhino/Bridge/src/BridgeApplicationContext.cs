using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Microsoft.Win32;

namespace CreoToRhino.Bridge
{
    internal sealed class BridgeApplicationContext : ApplicationContext
    {
        private const string RunKeyPath = @"Software\Microsoft\Windows\CurrentVersion\Run";
        private const string RunValueName = "CreoToRhinoBridge";

        private readonly BridgeConfig _config;
        private readonly StepWatcher _watcher;
        private readonly NotifyIcon _notifyIcon;
        private readonly Control _dispatcher;
        private readonly ToolStripMenuItem _statusItem;
        private readonly ToolStripMenuItem _startupItem;
        private string _lastStatus;

        public BridgeApplicationContext()
        {
            _config = BridgeConfig.Load();
            _lastStatus = "正在启动";
            _dispatcher = new Control();
            _dispatcher.CreateControl();

            _statusItem = new ToolStripMenuItem("状态：正在启动") { Enabled = false };
            _startupItem = new ToolStripMenuItem("登录后自动启动")
            {
                Checked = IsStartupEnabled(),
                CheckOnClick = true
            };
            _startupItem.Click += (_, __) => SetStartupEnabled(_startupItem.Checked);

            var menu = new ContextMenuStrip();
            menu.Items.Add(_statusItem);
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add("打开 STEP 交换目录", null, (_, __) => OpenPath(_config.ExchangeDirectory));
            menu.Items.Add("手动发送 STEP...", null, (_, __) => SelectAndSendStep());
            menu.Items.Add("打开日志目录", null, (_, __) => OpenPath(Logger.LogDirectory));
            menu.Items.Add("打开配置文件", null, (_, __) => OpenPath(BridgeConfig.ConfigPath));
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add(_startupItem);
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add("退出", null, (_, __) => ExitThread());

            _notifyIcon = new NotifyIcon
            {
                Icon = SystemIcons.Application,
                Text = "CreoToRhino Bridge",
                ContextMenuStrip = menu,
                Visible = true
            };
            _notifyIcon.DoubleClick += (_, __) => ShowStatus();

            _watcher = new StepWatcher(_config);
            _watcher.StatusChanged += OnStatusChanged;
            _watcher.Start();
            Logger.Info("CreoToRhino Bridge 3.0 started.");
        }

        private void OnStatusChanged(string message, bool notify)
        {
            if (_notifyIcon == null) return;
            if (_dispatcher.InvokeRequired)
            {
                _dispatcher.BeginInvoke(new Action(() => OnStatusChanged(message, notify)));
                return;
            }

            _lastStatus = message;
            _statusItem.Text = "状态：" + Truncate(message, 45);
            _notifyIcon.Text = Truncate("CreoToRhino - " + message, 63);
            if (notify)
            {
                _notifyIcon.BalloonTipTitle = "CreoToRhino";
                _notifyIcon.BalloonTipText = message;
                _notifyIcon.BalloonTipIcon = message.Contains("失败") || message.Contains("异常")
                    ? ToolTipIcon.Error
                    : ToolTipIcon.Info;
                _notifyIcon.ShowBalloonTip(5000);
            }
        }

        private void SelectAndSendStep()
        {
            using (var dialog = new OpenFileDialog
            {
                Filter = "STEP files (*.stp;*.step)|*.stp;*.step",
                InitialDirectory = _config.ExchangeDirectory,
                Multiselect = false,
                CheckFileExists = true
            })
            {
                if (dialog.ShowDialog() == DialogResult.OK)
                    _watcher.QueueFile(dialog.FileName);
            }
        }

        private void ShowStatus()
        {
            MessageBox.Show(
                "运行状态：" + _lastStatus + Environment.NewLine + Environment.NewLine +
                "STEP 目录：" + _config.ExchangeDirectory + Environment.NewLine +
                "Rhino：" + (string.IsNullOrWhiteSpace(_config.RhinoPath) ? "未检测到" : _config.RhinoPath),
                "CreoToRhino Bridge",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        private static void OpenPath(string path)
        {
            try
            {
                if (string.Equals(Path.GetExtension(path), ".json", StringComparison.OrdinalIgnoreCase))
                    Process.Start(new ProcessStartInfo("notepad.exe", "\"" + path + "\"") { UseShellExecute = true });
                else
                {
                    Directory.CreateDirectory(path);
                    Process.Start(new ProcessStartInfo("explorer.exe", "\"" + path + "\"") { UseShellExecute = true });
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "无法打开", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private static bool IsStartupEnabled()
        {
            using (RegistryKey key = Registry.CurrentUser.OpenSubKey(RunKeyPath))
                return key?.GetValue(RunValueName) != null;
        }

        private static void SetStartupEnabled(bool enabled)
        {
            try
            {
                using (RegistryKey key = Registry.CurrentUser.CreateSubKey(RunKeyPath))
                {
                    if (enabled)
                        key.SetValue(RunValueName, "\"" + Application.ExecutablePath + "\"");
                    else
                        key.DeleteValue(RunValueName, false);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "无法修改自动启动设置", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private static string Truncate(string value, int maximum)
        {
            if (string.IsNullOrEmpty(value) || value.Length <= maximum) return value;
            return value.Substring(0, maximum - 1) + "…";
        }

        protected override void ExitThreadCore()
        {
            Logger.Info("CreoToRhino Bridge stopped.");
            _watcher?.Dispose();
            if (_notifyIcon != null) _notifyIcon.Visible = false;
            _notifyIcon?.Dispose();
            _dispatcher?.Dispose();
            base.ExitThreadCore();
        }
    }
}
