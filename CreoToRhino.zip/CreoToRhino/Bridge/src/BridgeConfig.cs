using System;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using Microsoft.Win32;

namespace CreoToRhino.Bridge
{
    [DataContract]
    internal sealed class BridgeConfig
    {
        [DataMember(Name = "exchangeDirectory")]
        public string ExchangeDirectory { get; set; }

        [DataMember(Name = "rhinoPath")]
        public string RhinoPath { get; set; }

        [DataMember(Name = "autoLaunchRhino")]
        public bool AutoLaunchRhino { get; set; } = true;

        [DataMember(Name = "launchTimeoutSeconds")]
        public int LaunchTimeoutSeconds { get; set; } = 120;

        [DataMember(Name = "deleteAfterImport")]
        public bool DeleteAfterImport { get; set; } = true;

        [DataMember(Name = "autoZoom")]
        public bool AutoZoom { get; set; } = true;

        public static string DataDirectory
        {
            get
            {
                string overridePath = Environment.GetEnvironmentVariable("CREO_TO_RHINO_DATA_DIR");
                return string.IsNullOrWhiteSpace(overridePath)
                    ? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "CreoToRhino")
                    : Path.GetFullPath(Environment.ExpandEnvironmentVariables(overridePath));
            }
        }

        public static string ConfigPath => Path.Combine(DataDirectory, "bridge.json");

        public static BridgeConfig Load()
        {
            BridgeConfig config = CreateDefault();
            try
            {
                if (File.Exists(ConfigPath))
                {
                    var serializer = new DataContractJsonSerializer(typeof(BridgeConfig));
                    using (var stream = File.OpenRead(ConfigPath))
                        config = (BridgeConfig)serializer.ReadObject(stream) ?? config;
                }
            }
            catch (Exception ex)
            {
                Logger.Warning("Invalid bridge configuration; defaults will be used: " + ex.Message);
                config = CreateDefault();
            }

            config.Validate();
            config.Save();
            return config;
        }

        public void Save()
        {
            Directory.CreateDirectory(DataDirectory);
            Directory.CreateDirectory(ExchangeDirectory);
            var serializer = new DataContractJsonSerializer(typeof(BridgeConfig));
            using (var stream = File.Create(ConfigPath))
                serializer.WriteObject(stream, this);
        }

        private static BridgeConfig CreateDefault()
        {
            string exchangeOverride = Environment.GetEnvironmentVariable("CREO_TO_RHINO_EXCHANGE_DIR");
            return new BridgeConfig
            {
                ExchangeDirectory = string.IsNullOrWhiteSpace(exchangeOverride)
                    ? Path.Combine(
                        Environment.GetFolderPath(Environment.SpecialFolder.CommonDocuments),
                        "CreoToRhino",
                        "Exchange")
                    : exchangeOverride,
                RhinoPath = FindRhino()
            };
        }

        private void Validate()
        {
            if (string.IsNullOrWhiteSpace(ExchangeDirectory))
            {
                ExchangeDirectory = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.CommonDocuments),
                    "CreoToRhino",
                    "Exchange");
            }
            ExchangeDirectory = Path.GetFullPath(Environment.ExpandEnvironmentVariables(ExchangeDirectory));
            if (LaunchTimeoutSeconds < 10) LaunchTimeoutSeconds = 10;
            if (LaunchTimeoutSeconds > 600) LaunchTimeoutSeconds = 600;
            if (string.IsNullOrWhiteSpace(RhinoPath) || !File.Exists(RhinoPath))
                RhinoPath = FindRhino();
        }

        private static string FindRhino()
        {
            string[] versions = { "8.0", "7.0" };
            foreach (RegistryHive hive in new[] { RegistryHive.LocalMachine, RegistryHive.CurrentUser })
            {
                try
                {
                    using (RegistryKey baseKey = RegistryKey.OpenBaseKey(hive, RegistryView.Registry64))
                    {
                        foreach (string version in versions)
                        {
                            using (RegistryKey key = baseKey.OpenSubKey($@"SOFTWARE\McNeel\Rhinoceros\{version}\Install"))
                            {
                                string root = key?.GetValue("Path") as string;
                                if (string.IsNullOrWhiteSpace(root)) continue;
                                string candidate = Path.Combine(root, "System", "Rhino.exe");
                                if (File.Exists(candidate)) return candidate;
                            }
                        }
                    }
                }
                catch { }
            }

            foreach (string candidate in new[]
            {
                @"C:\Program Files\Rhino 8\System\Rhino.exe",
                @"C:\Program Files\Rhino 7\System\Rhino.exe",
                @"C:\Program Files\Rhinoceros 8\System\Rhino.exe",
                @"C:\Program Files\Rhinoceros 7\System\Rhino.exe"
            })
            {
                if (File.Exists(candidate)) return candidate;
            }
            return string.Empty;
        }
    }
}
