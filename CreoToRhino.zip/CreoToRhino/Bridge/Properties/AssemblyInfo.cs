using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CreoToRhino Bridge")]
[assembly: AssemblyDescription("License-free STEP watcher bridge for Creo Parametric and Rhino")]
[assembly: AssemblyCompany("CreoToRhino")]
[assembly: AssemblyProduct("CreoToRhino Bridge")]
[assembly: AssemblyVersion("3.0.0.0")]
[assembly: AssemblyFileVersion("3.0.0.0")]
[assembly: ComVisible(false)]
[assembly: Guid("4e84501f-442a-48d5-831e-fcaa23bbca3d")]
