@echo off
setlocal

set "INSTALL_ROOT=%LOCALAPPDATA%\CreoToRhino"

reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v CreoToRhinoBridge /f >nul 2>&1
taskkill /IM CreoBridge.exe /F >nul 2>&1

if exist "%INSTALL_ROOT%\App" rmdir /S /Q "%INSTALL_ROOT%\App"

echo CreoToRhino Bridge was removed.
echo Your STEP exchange directory and logs were preserved.
echo Remove CreoReceiver from Rhino PlugInManager if required.
pause
exit /b 0
