CreoToRhino 3.0 安装

1. 先关闭 Rhino 7/8。
2. 双击 install.bat。
3. 完成 Rhino 插件安装提示。
4. 按自动打开的 Mapkey-Setup.md 在 Creo 5.0 中录制 Mapkey。

本版本不需要 Creo TOOLKIT 许可证。
请使用 install.bat，不要手动选择发布目录中的旧版 RHP 文件。
