@echo off
setlocal

set "PACKAGE_DIR=%~dp0"
set "INSTALL_DIR=%LOCALAPPDATA%\CreoToRhino\App"
set "EXCHANGE_DIR=%PUBLIC%\Documents\CreoToRhino\Exchange"

tasklist /FI "IMAGENAME eq Rhino.exe" 2>nul | find /I "Rhino.exe" >nul
if not errorlevel 1 (
  echo [ACTION REQUIRED] Close Rhino 7/8 before installing the receiver.
  pause
  exit /b 2
)

if not exist "%PACKAGE_DIR%Bridge\CreoBridge.exe" (
  echo [ERROR] Bridge\CreoBridge.exe was not found.
  pause
  exit /b 1
)
if not exist "%PACKAGE_DIR%RhinoPlugin\CreoReceiver_v3.rhp" (
  echo [ERROR] RhinoPlugin\CreoReceiver_v3.rhp was not found.
  pause
  exit /b 1
)

if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
if not exist "%EXCHANGE_DIR%" mkdir "%EXCHANGE_DIR%"

copy /Y "%PACKAGE_DIR%Bridge\CreoBridge.exe" "%INSTALL_DIR%\CreoBridge.exe" >nul
copy /Y "%PACKAGE_DIR%Bridge\CreoBridge.exe.config" "%INSTALL_DIR%\CreoBridge.exe.config" >nul
copy /Y "%PACKAGE_DIR%RhinoPlugin\CreoReceiver_v3.rhp" "%INSTALL_DIR%\CreoReceiver.rhp" >nul
if errorlevel 1 exit /b 1
copy /Y "%PACKAGE_DIR%Mapkey\README.md" "%INSTALL_DIR%\Mapkey-Setup.md" >nul

reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v CreoToRhinoBridge /t REG_SZ /d "\"%INSTALL_DIR%\CreoBridge.exe\"" /f >nul

start "CreoToRhino Bridge" "%INSTALL_DIR%\CreoBridge.exe"
start "Rhino plug-in installer" "%INSTALL_DIR%\CreoReceiver.rhp"
start "Mapkey setup" notepad.exe "%INSTALL_DIR%\Mapkey-Setup.md"

echo.
echo [OK] CreoToRhino Bridge was installed.
echo STEP exchange directory: %EXCHANGE_DIR%
echo Complete the Rhino prompt, then follow Mapkey-Setup.md.
pause
exit /b 0
