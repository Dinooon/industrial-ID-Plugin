# Creo 5.0 一键发送 Mapkey 设置

该方案不加载 Creo TOOLKIT DLL，因此不需要 TOOLKIT 开发或运行许可证。Creo 只负责使用自己的“保存副本”命令导出 STEP；后台 Bridge 负责发现 STEP 并发送给 Rhino。

## 固定交换目录

```text
C:\Users\Public\Documents\CreoToRhino\Exchange
```

安装程序会创建这个目录。不要更改目录，除非同时修改 `%APPDATA%\CreoToRhino\bridge.json` 中的 `exchangeDirectory`。

## 录制 Mapkey

Mapkey 与 Creo 的语言、日期代码和界面布局有关，所以必须在目标 Creo 5.0 上录制一次，不能可靠地预制通用的 `config.pro` 指令串。

1. 确认 Windows 通知区域中存在 `CreoToRhino Bridge` 图标。
2. 在 Creo 5.0 中打开一个简单的零件。
3. 进入 `文件 > 选项 > 环境 > Mapkey 设置`。
4. 点击“新建”，键盘序列建议填写 `cr`，名称填写 `SendToRhino`。
5. 点击“录制”。
6. 执行 `文件 > 另存为 > 保存副本`。
7. 类型选择 `STEP (*.stp)`。
8. 输出目录选择：

   ```text
   C:\Users\Public\Documents\CreoToRhino\Exchange
   ```

9. 保留 Creo 自动给出的当前模型文件名，不要录入固定的零件名。
10. 确认 STEP 导出选项并完成导出。
11. 停止 Mapkey 录制并保存设置。

Bridge 在 Rhino 成功导入后会删除交换目录中的临时 STEP，因此正常使用时不会反复出现覆盖确认。如果录制期间出现覆盖确认，请先清空交换目录，再重新录制。

## 添加到 Ribbon

1. 进入 `文件 > 选项 > 自定义功能区`。
2. 在目标选项卡中新建一个组，例如 `Rhino`。
3. 将“从下列位置选择命令”切换到 `Mapkeys`。
4. 选择 `SendToRhino (cr)`，添加到新建组。
5. 保存 Creo 配置。

以后打开 `.prt` 或 `.asm` 后，点击这个按钮即可导出当前窗口模型。Bridge 会自动启动或连接 Rhino，并将同名模型更新到 `CreoLink_模型名` 图层。

## 首次验证

1. 打开 Rhino，运行 `CreoReceiverStatus`，确认接收服务正在运行。
2. 打开 Creo 零件并点击 `SendToRhino`。
3. 等待 Windows 通知“已发送到 Rhino”。
4. 修改 Creo 尺寸并重新生成，再点击一次。
5. 确认 Rhino 中旧模型被替换、没有重复叠加，用户自行创建的对象没有被删除。

若失败，请检查：

```text
%APPDATA%\CreoToRhino\logs\Bridge_日期.log
%APPDATA%\CreoToRhino\logs\RhinoPlugin_日期.log
```
