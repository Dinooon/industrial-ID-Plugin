#!/usr/bin/env python3
"""
orchestrate_review.py — Multi-agent orchestration script (Architecture A).

State-machine driven orchestrator that coordinates 4 specialized sub-agents:
1. Image Analyst (step 1) — product image recognition
2. Patent Scout (step 2) — patent risk screening (parallel with step 3)
3. Brand Judge (step 3) — brand language consistency review (parallel with step 2)
4. Report Builder (step 4) — scoring + HTML report + quality gate

Uses file-based JSON communication in a session directory.
Falls back to single-agent mode if any sub-agent fails (atomic fallback).

Usage:
    python orchestrate_review.py --coordinator-input coordinator_input.json [--session-dir /tmp/review_session_xxx]

The coordinator_input.json should contain:
    {
        "image_paths": ["/path/to/image.png"],
        "user_context": {
            "category_hint": "cleaning_appliance",
            "brand_reference": "eufy",
            "target_market": "中国大陆",
            ...
        },
        "output_requirement": "html_report"
    }
"""

import argparse
import json
import os
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

# Add scripts directory to path for imports
SCRIPT_DIR = Path(__file__).parent
sys.path.insert(0, str(SCRIPT_DIR))


# State machine states
STATE_INIT = "INIT"
STATE_IMAGE_ANALYST = "IMAGE_ANALYST"
STATE_PARALLEL = "PARALLEL"  # Patent Scout + Brand Judge
STATE_REPORT_BUILDER = "REPORT_BUILDER"
STATE_COMPLETE = "COMPLETE"
STATE_FALLBACK = "FALLBACK"

# Timeout per agent call (seconds)
AGENT_TIMEOUT = 180


def log_entry(session_dir: str, step: str, status: str, **details):
    """Write a JSONL log entry to orchestration_log.jsonl."""
    entry = {
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "step": step,
        "status": status,
        **details,
    }
    log_path = Path(session_dir) / "orchestration_log.jsonl"
    with open(log_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")
    print(f"  [{step}] {status}" + (f" — {details}" if details else ""))


def create_session_dir(base: str = "/tmp") -> str:
    """Create a session directory with timestamp."""
    session_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    session_dir = f"{base}/review_session_{session_id}"
    Path(session_dir).mkdir(parents=True, exist_ok=True)
    return session_dir


def load_json(path: str) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def save_json(path: str, data: dict):
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def run_agent_input_generator(coordinator_input: str, session_dir: str, step: int, **kwargs) -> bool:
    """Run agent_input_generator.py to create input JSON for a specific step."""
    cmd = [
        sys.executable, str(SCRIPT_DIR / "agent_input_generator.py"),
        "--coordinator-input", coordinator_input,
        "--session-dir", session_dir,
        "--step", str(step),
    ]
    if "step1_output" in kwargs:
        cmd.extend(["--step1-output", kwargs["step1_output"]])
    if "step2_output" in kwargs:
        cmd.extend(["--step2-output", kwargs["step2_output"]])
    if "step3_output" in kwargs:
        cmd.extend(["--step3-output", kwargs["step3_output"]])

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode != 0:
            print(f"  Input generator error: {result.stderr}", file=sys.stderr)
            return False
        return True
    except subprocess.TimeoutExpired:
        print("  Input generator timed out", file=sys.stderr)
        return False


def parse_agent_output(raw_path: str, agent_name: str, output_path: str) -> dict | None:
    """Run agent_output_parser.py to parse and validate agent output."""
    cmd = [
        sys.executable, str(SCRIPT_DIR / "agent_output_parser.py"),
        "--input", raw_path,
        "--agent", agent_name,
        "--output", output_path,
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode != 0:
            print(f"  Parser error: {result.stderr}", file=sys.stderr)
        # Even with errors, the parser writes fallback output
        if Path(output_path).exists():
            return load_json(output_path)
    except subprocess.TimeoutExpired:
        print("  Parser timed out", file=sys.stderr)
    return None


def call_agent_via_acp(task_description: str, working_dir: str, output_file: str) -> bool:
    """
    Call a sub-agent via acp_agent_exec.

    In the actual environment, this would use the acp_agent_exec tool.
    In this script, we simulate the call and check if the output file was created.

    Returns True if output file exists and is non-empty, False otherwise.
    """
    # NOTE: In the real environment, the coordinator (main agent) calls acp_agent_exec.
    # This script is a helper that the coordinator invokes.
    # The actual acp_agent_exec call is done by the coordinator in the conversation,
    # not by this script directly.

    # For now, check if the output file exists (it would be created by the coordinator's acp call)
    output_path = Path(output_file)
    if output_path.exists() and output_path.stat().st_size > 0:
        return True

    print(f"  Output file not found or empty: {output_file}", file=sys.stderr)
    return False


def wait_for_agent_output(output_file: str, timeout: int = AGENT_TIMEOUT) -> bool:
    """Wait for an agent output file to appear, up to timeout seconds."""
    start = time.time()
    while time.time() - start < timeout:
        p = Path(output_file)
        if p.exists() and p.stat().st_size > 0:
            return True
        time.sleep(2)
    return False


def run_single_agent_fallback(coordinator_input_path: str, session_dir: str) -> dict:
    """
    Fallback to single-agent mode when multi-agent architecture fails.
    Returns a minimal result structure indicating fallback was used.
    """
    log_entry(session_dir, "fallback", "started", reason="Multi-agent architecture failed")

    coordinator = load_json(coordinator_input_path)

    fallback_result = {
        "fallback_mode": True,
        "reason": "Multi-agent architecture unavailable; fell back to single-agent v3.1.0 workflow",
        "coordinator_input": coordinator,
        "session_dir": session_dir,
        "message": "协调者应按照 SKILL.md v3.1.0 单Agent工作流执行完整评审",
    }

    log_entry(session_dir, "fallback", "complete", mode="single_agent_v3.1")
    return fallback_result


def orchestrate(coordinator_input_path: str, session_dir: str = None) -> dict:
    """
    Main orchestration function. Runs the state machine.
    Returns the final result (either multi-agent output or fallback).
    """
    if session_dir is None:
        session_dir = create_session_dir()

    log_path = Path(session_dir) / "orchestration_log.jsonl"
    log_path.write_text("", encoding="utf-8")  # Clear log

    log_entry(session_dir, "orchestration", "started", session_dir=session_dir)

    state = STATE_INIT
    coordinator = load_json(coordinator_input_path)

    # Save coordinator input
    save_json(f"{session_dir}/coordinator_input.json", coordinator)

    while state != STATE_COMPLETE and state != STATE_FALLBACK:
        if state == STATE_INIT:
            # Step 1: Generate Image Analyst input
            log_entry(session_dir, "input_generation", "started", step=1, agent="image_analyst")
            if not run_agent_input_generator(coordinator_input_path, session_dir, step=1):
                log_entry(session_dir, "input_generation", "failed", step=1)
                state = STATE_FALLBACK
                continue
            log_entry(session_dir, "input_generation", "success", step=1)
            state = STATE_IMAGE_ANALYST

        elif state == STATE_IMAGE_ANALYST:
            # Call Image Analyst Agent
            log_entry(session_dir, "agent_call", "started", agent="image_analyst")

            input_file = f"{session_dir}/input_image_analyst.json"
            output_file = f"{session_dir}/step1_image_analysis.json"

            # The coordinator (main agent) should call acp_agent_exec here
            # This script prepares the input and waits for the output
            task_desc = (
                f"You are the Image Analyst Agent defined in agents/image-analyst/SOUL.md. "
                f"Read the input from {input_file}. "
                f"Analyze the product images and produce the structured JSON output defined in your SOUL.md. "
                f"Write your output to {output_file}."
            )

            # In real usage, coordinator calls acp_agent_exec(task=task_desc, working_directory=SKILL_DIR)
            # For this script, we check if output exists
            if not wait_for_agent_output(output_file, AGENT_TIMEOUT):
                log_entry(session_dir, "agent_call", "failed", agent="image_analyst", reason="timeout or no output")
                state = STATE_FALLBACK
                continue

            # Parse and validate output
            parsed = parse_agent_output(output_file, "image_analyst", f"{session_dir}/step1_image_analysis_parsed.json")
            if parsed is None or parsed.get("_parse_error"):
                log_entry(session_dir, "agent_call", "failed", agent="image_analyst", reason="output parse failed")
                state = STATE_FALLBACK
                continue

            log_entry(session_dir, "agent_call", "success", agent="image_analyst")
            state = STATE_PARALLEL

        elif state == STATE_PARALLEL:
            # Steps 2 & 3: Patent Scout + Brand Judge (can run in parallel)
            step1_output = f"{session_dir}/step1_image_analysis_parsed.json"

            # Generate inputs for both agents
            log_entry(session_dir, "input_generation", "started", step=2, agent="patent_scout")
            if not run_agent_input_generator(coordinator_input_path, session_dir, step=2, step1_output=step1_output):
                log_entry(session_dir, "input_generation", "failed", step=2)
                state = STATE_FALLBACK
                continue

            log_entry(session_dir, "input_generation", "started", step=3, agent="brand_judge")
            if not run_agent_input_generator(coordinator_input_path, session_dir, step=3, step1_output=step1_output):
                log_entry(session_dir, "input_generation", "failed", step=3)
                state = STATE_FALLBACK
                continue

            log_entry(session_dir, "input_generation", "success", steps=[2, 3])

            # Call both agents (in real usage, these would be parallel acp_agent_exec calls)
            ps_output = f"{session_dir}/step2_patent_scout.json"
            bj_output = f"{session_dir}/step3_brand_judge.json"

            log_entry(session_dir, "agent_call", "started", agent="patent_scout")
            log_entry(session_dir, "agent_call", "started", agent="brand_judge")

            # Wait for both outputs
            ps_ok = wait_for_agent_output(ps_output, AGENT_TIMEOUT)
            bj_ok = wait_for_agent_output(bj_output, AGENT_TIMEOUT)

            if not ps_ok or not bj_ok:
                failed = []
                if not ps_ok:
                    failed.append("patent_scout")
                if not bj_ok:
                    failed.append("brand_judge")
                log_entry(session_dir, "agent_call", "failed", agents=failed, reason="timeout or no output")
                state = STATE_FALLBACK
                continue

            # Parse both outputs
            ps_parsed = parse_agent_output(ps_output, "patent_scout", f"{session_dir}/step2_patent_scout_parsed.json")
            bj_parsed = parse_agent_output(bj_output, "brand_judge", f"{session_dir}/step3_brand_judge_parsed.json")

            if ps_parsed is None or ps_parsed.get("_parse_error"):
                log_entry(session_dir, "agent_call", "failed", agent="patent_scout", reason="output parse failed")
                state = STATE_FALLBACK
                continue
            if bj_parsed is None or bj_parsed.get("_parse_error"):
                log_entry(session_dir, "agent_call", "failed", agent="brand_judge", reason="output parse failed")
                state = STATE_FALLBACK
                continue

            log_entry(session_dir, "agent_call", "success", agents=["patent_scout", "brand_judge"])
            state = STATE_REPORT_BUILDER

        elif state == STATE_REPORT_BUILDER:
            # Step 4: Report Builder (requires all previous outputs)
            step1 = f"{session_dir}/step1_image_analysis_parsed.json"
            step2 = f"{session_dir}/step2_patent_scout_parsed.json"
            step3 = f"{session_dir}/step3_brand_judge_parsed.json"

            log_entry(session_dir, "input_generation", "started", step=4, agent="report_builder")
            if not run_agent_input_generator(coordinator_input_path, session_dir, step=4,
                                              step1_output=step1, step2_output=step2, step3_output=step3):
                log_entry(session_dir, "input_generation", "failed", step=4)
                state = STATE_FALLBACK
                continue
            log_entry(session_dir, "input_generation", "success", step=4)

            rb_output = f"{session_dir}/step4_report_builder.json"
            log_entry(session_dir, "agent_call", "started", agent="report_builder")

            if not wait_for_agent_output(rb_output, AGENT_TIMEOUT):
                log_entry(session_dir, "agent_call", "failed", agent="report_builder", reason="timeout or no output")
                state = STATE_FALLBACK
                continue

            rb_parsed = parse_agent_output(rb_output, "report_builder", f"{session_dir}/step4_report_builder_parsed.json")
            if rb_parsed is None or rb_parsed.get("_parse_error"):
                log_entry(session_dir, "agent_call", "failed", agent="report_builder", reason="output parse failed")
                state = STATE_FALLBACK
                continue

            log_entry(session_dir, "agent_call", "success", agent="report_builder")
            state = STATE_COMPLETE

    if state == STATE_FALLBACK:
        result = run_single_agent_fallback(coordinator_input_path, session_dir)
        result["session_dir"] = session_dir
        log_entry(session_dir, "orchestration", "complete", mode="fallback")
        return result

    # Load final result
    final = load_json(f"{session_dir}/step4_report_builder_parsed.json")
    final["session_dir"] = session_dir
    final["fallback_mode"] = False
    final["agents_used"] = ["image_analyst", "patent_scout", "brand_judge", "report_builder"]

    log_entry(session_dir, "orchestration", "complete", mode="multi_agent", agents=4)
    return final


def main():
    parser = argparse.ArgumentParser(description="Multi-agent orchestration for Product Design Evaluator (Architecture A).")
    parser.add_argument("--coordinator-input", required=True, help="Path to coordinator_input.json")
    parser.add_argument("--session-dir", help="Session directory (auto-created if not specified)")
    parser.add_argument("--output", help="Path to write final result JSON (default: stdout)")
    args = parser.parse_args()

    result = orchestrate(args.coordinator_input, args.session_dir)

    output_json = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        Path(args.output).write_text(output_json, encoding="utf-8")
        print(f"\nResult written to: {args.output}", file=sys.stderr)
    else:
        print(output_json)

    # Exit code: 0 for success (multi-agent), 1 for fallback
    sys.exit(0 if not result.get("fallback_mode") else 1)


if __name__ == "__main__":
    main()
