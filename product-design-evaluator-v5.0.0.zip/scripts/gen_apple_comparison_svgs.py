#!/usr/bin/env python3
"""Generate SVG schematics for Apple Watch / TWS comparison objects."""
import base64
from pathlib import Path

OUTPUT_DIR = Path("/tmp/apple_comparison_svgs")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

svgs = {
    "apple_watch_series": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 320" width="300" height="320">
  <defs>
    <linearGradient id="case" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#e8e8e8"/><stop offset="100%" stop-color="#c0c0c0"/>
    </linearGradient>
    <linearGradient id="screen" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#1a1a2e"/><stop offset="100%" stop-color="#0d0d1a"/>
    </linearGradient>
  </defs>
  <rect width="300" height="320" fill="#f8f8f8" rx="12"/>
  <!-- Strap top -->
  <rect x="110" y="10" width="80" height="50" rx="8" fill="#3a3a3c"/>
  <!-- Strap bottom -->
  <rect x="110" y="260" width="80" height="50" rx="8" fill="#3a3a3c"/>
  <!-- Watch case (rounded square) -->
  <rect x="80" y="55" width="140" height="210" rx="48" ry="48" fill="url(#case)" stroke="#999" stroke-width="1.5"/>
  <!-- Screen -->
  <rect x="92" y="67" width="116" height="186" rx="38" ry="38" fill="url(#screen)"/>
  <!-- Digital crown -->
  <rect x="220" y="130" width="12" height="30" rx="4" fill="#888"/>
  <rect x="222" y="135" width="8" height="20" rx="2" fill="#aaa"/>
  <!-- Side button -->
  <rect x="220" y="175" width="10" height="22" rx="3" fill="#888"/>
  <!-- Time display -->
  <text x="150" y="150" text-anchor="middle" font-family="-apple-system,Helvetica,Arial,sans-serif" font-size="36" font-weight="600" fill="white">10:09</text>
  <text x="150" y="175" text-anchor="middle" font-family="-apple-system,Helvetica,Arial,sans-serif" font-size="11" fill="#888">Friday 23</text>
  <text x="150" y="305" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="#666">Apple Watch Series</text>
</svg>''',

    "apple_watch_se": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 320" width="300" height="320">
  <defs>
    <linearGradient id="case2" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#d4d4d4"/><stop offset="100%" stop-color="#b0b0b0"/>
    </linearGradient>
    <linearGradient id="screen2" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#1a1a2e"/><stop offset="100%" stop-color="#0d0d1a"/>
    </linearGradient>
  </defs>
  <rect width="300" height="320" fill="#f8f8f8" rx="12"/>
  <rect x="110" y="10" width="80" height="50" rx="8" fill="#1c1c1e"/>
  <rect x="110" y="260" width="80" height="50" rx="8" fill="#1c1c1e"/>
  <rect x="80" y="55" width="140" height="210" rx="44" ry="44" fill="url(#case2)" stroke="#999" stroke-width="1.5"/>
  <rect x="92" y="67" width="116" height="186" rx="34" ry="34" fill="url(#screen2)"/>
  <rect x="220" y="130" width="12" height="30" rx="4" fill="#777"/>
  <rect x="220" y="175" width="10" height="22" rx="3" fill="#777"/>
  <text x="150" y="150" text-anchor="middle" font-family="-apple-system,Helvetica,Arial,sans-serif" font-size="36" font-weight="600" fill="white">10:09</text>
  <text x="150" y="175" text-anchor="middle" font-family="-apple-system,Helvetica,Arial,sans-serif" font-size="11" fill="#888">Friday 23</text>
  <text x="150" y="305" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="#666">Apple Watch SE</text>
</svg>''',

    "airpods_case": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 280" width="300" height="280">
  <defs>
    <linearGradient id="airpod_case" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#ffffff"/><stop offset="100%" stop-color="#e8e8e8"/>
    </linearGradient>
    <filter id="shadow1"><feGaussianBlur stdDeviation="3"/></filter>
  </defs>
  <rect width="300" height="280" fill="#f8f8f8" rx="12"/>
  <!-- Case body - rounded rectangle, white -->
  <rect x="95" y="80" width="110" height="120" rx="28" ry="28" fill="url(#airpod_case)" stroke="#ccc" stroke-width="1.5"/>
  <!-- Lid line -->
  <line x1="105" y1="95" x2="195" y2="95" stroke="#ddd" stroke-width="1"/>
  <!-- LED indicator -->
  <circle cx="150" cy="178" r="4" fill="#4cd964" opacity="0.6"/>
  <!-- AirPods visible above lid (hint) -->
  <ellipse cx="125" cy="75" rx="10" ry="14" fill="#f0f0f0" stroke="#ddd" stroke-width="0.8"/>
  <ellipse cx="175" cy="75" rx="10" ry="14" fill="#f0f0f0" stroke="#ddd" stroke-width="0.8"/>
  <text x="150" y="255" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="#666">AirPods Charging Case</text>
</svg>''',

    "noise_champ_watch": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 320" width="300" height="320">
  <defs>
    <linearGradient id="noise_case" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#1a1a1a"/><stop offset="100%" stop-color="#2a2a2a"/>
    </linearGradient>
    <linearGradient id="noise_strap" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#98e8c8"/><stop offset="100%" stop-color="#80d8b0"/>
    </linearGradient>
  </defs>
  <rect width="300" height="320" fill="#f8f8f8" rx="12"/>
  <!-- Green strap -->
  <rect x="100" y="8" width="100" height="52" rx="10" fill="url(#noise_strap)"/>
  <rect x="100" y="260" width="100" height="52" rx="10" fill="url(#noise_strap)"/>
  <!-- Watch case - dark with green border -->
  <rect x="75" y="55" width="150" height="210" rx="42" ry="42" fill="url(#noise_case)" stroke="#98e8c8" stroke-width="3"/>
  <!-- Screen -->
  <rect x="88" y="68" width="124" height="184" rx="32" ry="32" fill="#000"/>
  <!-- UI: time -->
  <text x="150" y="148" text-anchor="middle" font-family="-apple-system,Helvetica,Arial,sans-serif" font-size="34" font-weight="700" fill="white">09:41</text>
  <text x="150" y="172" text-anchor="middle" font-family="-apple-system,Helvetica,Arial,sans-serif" font-size="10" fill="#888">Friday 23</text>
  <!-- Cartoony high-five -->
  <circle cx="130" cy="210" r="14" fill="#e8c4a0" opacity="0.8"/>
  <circle cx="170" cy="210" r="14" fill="#f4d8c0" opacity="0.8"/>
  <text x="150" y="305" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="#666">Noise Champ 3 (Smart Band)</text>
</svg>''',

    "tws_case_mint": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 280" width="300" height="280">
  <defs>
    <linearGradient id="tws_mint" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#b8e8d8"/><stop offset="100%" stop-color="#98d8c0"/>
    </linearGradient>
    <linearGradient id="tws_inner" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#1a1a2e"/><stop offset="100%" stop-color="#0d0d1a"/>
    </linearGradient>
  </defs>
  <rect width="300" height="280" fill="#f8f8f8" rx="12"/>
  <!-- Case body - mint green, tall rounded rectangle -->
  <rect x="110" y="50" width="80" height="180" rx="20" ry="20" fill="url(#tws_mint)" stroke="#7ac8a8" stroke-width="1.5"/>
  <!-- Pebble-textured button area -->
  <rect x="130" y="95" width="40" height="25" rx="10" fill="url(#tws_inner)" opacity="0.85"/>
  <!-- Texture dots on button -->
  <circle cx="138" cy="108" r="1.5" fill="#444"/>
  <circle cx="145" cy="103" r="1.5" fill="#444"/>
  <circle cx="152" cy="110" r="1.5" fill="#444"/>
  <circle cx="160" cy="105" r="1.5" fill="#444"/>
  <circle cx="142" cy="112" r="1.5" fill="#444"/>
  <circle cx="155" cy="102" r="1.5" fill="#444"/>
  <!-- Lid line -->
  <line x1="118" y1="65" x2="182" y2="65" stroke="#7ac8a8" stroke-width="0.8" opacity="0.5"/>
  <text x="150" y="255" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="#666">TWS Earbuds Case (Mint Green)</text>
</svg>''',

    "apple_watch_ultra": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 340" width="300" height="340">
  <defs>
    <linearGradient id="ultra_case" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#6a6a6a"/><stop offset="100%" stop-color="#4a4a4a"/>
    </linearGradient>
    <linearGradient id="ultra_screen" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#1a1a2e"/><stop offset="100%" stop-color="#0d0d1a"/>
    </linearGradient>
  </defs>
  <rect width="300" height="340" fill="#f8f8f8" rx="12"/>
  <rect x="100" y="8" width="100" height="52" rx="8" fill="#2a2a2a"/>
  <rect x="100" y="280" width="100" height="52" rx="8" fill="#2a2a2a"/>
  <!-- Titanium case - flat sides, rounded corners -->
  <rect x="70" y="55" width="160" height="228" rx="32" ry="32" fill="url(#ultra_case)" stroke="#888" stroke-width="1.5"/>
  <!-- Flat edge highlight -->
  <rect x="72" y="57" width="6" height="224" fill="#7a7a7a" opacity="0.5"/>
  <rect x="222" y="57" width="6" height="224" fill="#7a7a7a" opacity="0.5"/>
  <rect x="86" y="70" width="128" height="198" rx="24" ry="24" fill="url(#ultra_screen)"/>
  <!-- Larger digital crown -->
  <rect x="230" y="125" width="14" height="36" rx="5" fill="#aaa"/>
  <rect x="232" y="130" width="10" height="26" rx="2" fill="#ccc"/>
  <!-- Action button -->
  <rect x="58" y="125" width="12" height="36" rx="4" fill="#ff6b35"/>
  <text x="150" y="155" text-anchor="middle" font-family="-apple-system,Helvetica,Arial,sans-serif" font-size="38" font-weight="600" fill="#ff6b35">10:09</text>
  <text x="150" y="325" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="#666">Apple Watch Ultra</text>
</svg>''',
}

results = {}
for name, svg_content in svgs.items():
    svg_bytes = svg_content.encode("utf-8")
    b64 = base64.b64encode(svg_bytes).decode()
    data_uri = f"data:image/svg+xml;base64,{b64}"
    # Save SVG file
    svg_path = OUTPUT_DIR / f"{name}.svg"
    svg_path.write_text(svg_content, encoding="utf-8")
    results[name] = {
        "svg_path": str(svg_path),
        "data_uri": data_uri,
        "b64_length": len(b64),
    }
    print(f"Generated: {name}.svg ({len(svg_bytes)} bytes, b64={len(b64)})")

# Save results JSON
import json
results_path = OUTPUT_DIR / "comparison_svgs.json"
results_path.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"\nAll SVGs saved to: {OUTPUT_DIR}")