#!/usr/bin/env python3
"""
fetch_competitor_images.py — Automated competitor image acquisition for patent/design comparison.

Attempts to download real competitor product images from public sources.
Falls back to SVG schematic generation when downloads fail.
Each result includes source_type, visual_type, source_url, comparison_url,
source_note, download_status, and failure_reason fields for full traceability.

Usage:
    python fetch_competitor_images.py --category robot-vacuum --output-dir compare_images/ --format base64
    python fetch_competitor_images.py --from-agent-input input_patent_scout.json --output-dir compare_images/

Output:
    A JSON file (competitor_images.json) containing base64-encoded image data URIs
    for each comparison object, with full traceability metadata.

v4.1.0 changes:
    - PIL-based image validation (replaces `file` command dependency)
    - Web page image candidate extraction (og:image, twitter:image, JSON-LD, srcset, lazy-load)
    - Relative URL to absolute URL conversion
    - Complete browser HTTP headers
    - Unified output data structure with full traceability fields
    - Download failure reason classification
    - Invalid image filtering (logo/favicon/tracking pixel/small images)
    - Dynamic candidate URL construction
    - SVG schematic watermark ("示意图")
"""

import argparse
import base64
import json
import os
import re
import subprocess
import sys
from pathlib import Path
from urllib.parse import urljoin, urlparse


# ============================================================================
# HTTP request headers — mimics a real browser to reduce blocking
# ============================================================================

BROWSER_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/120.0.0.0 Safari/537.36"
)
BROWSER_ACCEPT = "image/avif,image/webp,image/apng,image/*,*/*;q=0.8"
BROWSER_ACCEPT_LANG = "en-US,en;q=0.9,zh-CN;q=0.8"


# ============================================================================
# SVG schematic templates for common product types
# Each template includes a "示意图" watermark in the top-right corner (v4.1.0)
# ============================================================================

_SVG_WATERMARK = '''<text x="285" y="18" text-anchor="end" font-family="Arial,sans-serif" font-size="9" fill="#bbb" opacity="0.6">示意图</text>'''

SVG_TEMPLATES = {
    "round_robot_no_lidar": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 280" width="300" height="280">
  <defs><radialGradient id="g" cx="50%" cy="40%"><stop offset="0%" stop-color="#2c2c2c" stop-opacity="0.95"/><stop offset="100%" stop-color="#3a3a3a"/></radialGradient></defs>
  <rect width="300" height="280" fill="#f5f5f5"/>
  <circle cx="150" cy="130" r="100" fill="url(#g)" stroke="#555" stroke-width="2"/>
  <circle cx="150" cy="130" r="75" fill="none" stroke="#555" stroke-width="1.5" opacity="0.5"/>
  <circle cx="150" cy="105" r="22" fill="#1a1a1a" stroke="#444" stroke-width="1"/>
  <circle cx="150" cy="105" r="14" fill="#0a0a0a"/>
  <circle cx="150" cy="185" r="8" fill="#555" stroke="#777" stroke-width="1"/>
  <text x="150" y="260" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="#888">{label}</text>
  <text x="285" y="18" text-anchor="end" font-family="Arial,sans-serif" font-size="9" fill="#bbb" opacity="0.6">示意图</text>
</svg>''',

    "round_robot_with_lidar": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 280" width="300" height="280">
  <defs><radialGradient id="g" cx="50%" cy="40%"><stop offset="0%" stop-color="#333" stop-opacity="0.95"/><stop offset="100%" stop-color="#444"/></radialGradient></defs>
  <rect width="300" height="280" fill="#f5f5f5"/>
  <circle cx="150" cy="135" r="100" fill="url(#g)" stroke="#555" stroke-width="2"/>
  <circle cx="150" cy="100" r="30" fill="#222" stroke="#555" stroke-width="1.5"/>
  <circle cx="150" cy="100" r="20" fill="#111"/>
  <circle cx="150" cy="100" r="12" fill="#333" stroke="#555" stroke-width="1"/>
  <circle cx="150" cy="195" r="8" fill="#555" stroke="#777" stroke-width="1"/>
  <text x="150" y="260" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="#888">{label}</text>
  <text x="285" y="18" text-anchor="end" font-family="Arial,sans-serif" font-size="9" fill="#bbb" opacity="0.6">示意图</text>
</svg>''',

    "d_shape_robot": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 280" width="300" height="280">
  <defs><radialGradient id="g" cx="50%" cy="40%"><stop offset="0%" stop-color="#2a2a2a" stop-opacity="0.95"/><stop offset="100%" stop-color="#3a3a3a"/></radialGradient></defs>
  <rect width="300" height="280" fill="#f5f5f5"/>
  <path d="M 100 80 L 200 80 Q 250 80 250 130 Q 250 200 150 220 Q 50 200 50 130 Q 50 80 100 80 Z" fill="url(#g)" stroke="#555" stroke-width="2"/>
  <circle cx="150" cy="120" r="28" fill="#222" stroke="#555" stroke-width="1.5"/>
  <circle cx="150" cy="120" r="18" fill="#111"/>
  <text x="150" y="260" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="#888">{label}</text>
  <text x="285" y="18" text-anchor="end" font-family="Arial,sans-serif" font-size="9" fill="#bbb" opacity="0.6">示意图</text>
</svg>''',

    "base_station": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 280" width="300" height="280">
  <rect width="300" height="280" fill="#f5f5f5"/>
  <rect x="80" y="50" width="140" height="200" rx="20" ry="20" fill="#454545" stroke="#555" stroke-width="2"/>
  <rect x="90" y="60" width="120" height="60" rx="10" fill="#3a3a3a" stroke="#555" stroke-width="1"/>
  <rect x="115" y="180" width="70" height="30" rx="3" fill="#1a1a1a" stroke="#333" stroke-width="1"/>
  <rect x="120" y="186" width="60" height="18" rx="2" fill="#0a1520"/>
  <rect x="105" y="220" width="90" height="25" rx="5" fill="#1a1a1a" stroke="#333" stroke-width="1"/>
  <text x="150" y="265" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="#888">{label}</text>
  <text x="285" y="18" text-anchor="end" font-family="Arial,sans-serif" font-size="9" fill="#bbb" opacity="0.6">示意图</text>
</svg>''',

    "stick_vacuum": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 280" width="300" height="280">
  <rect width="300" height="280" fill="#f5f5f5"/>
  <rect x="130" y="30" width="40" height="60" rx="15" fill="#3a3a3a" stroke="#555" stroke-width="2"/>
  <rect x="140" y="85" width="20" height="120" fill="#555" stroke="#666" stroke-width="1"/>
  <ellipse cx="150" cy="225" rx="50" ry="20" fill="#333" stroke="#555" stroke-width="2"/>
  <text x="150" y="265" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="#888">{label}</text>
  <text x="285" y="18" text-anchor="end" font-family="Arial,sans-serif" font-size="9" fill="#bbb" opacity="0.6">示意图</text>
</svg>''',

    "phone": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 280" width="300" height="280">
  <rect width="300" height="280" fill="#f5f5f5"/>
  <rect x="100" y="40" width="100" height="200" rx="18" ry="18" fill="#3a3a3a" stroke="#555" stroke-width="2"/>
  <rect x="108" y="48" width="84" height="160" rx="6" fill="#1a1a2e" stroke="#333" stroke-width="1"/>
  <rect x="120" y="220" width="60" height="12" rx="6" fill="#222"/>
  <text x="150" y="265" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="#888">{label}</text>
  <text x="285" y="18" text-anchor="end" font-family="Arial,sans-serif" font-size="9" fill="#bbb" opacity="0.6">示意图</text>
</svg>''',

    "earbuds_case": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 280" width="300" height="280">
  <rect width="300" height="280" fill="#f5f5f5"/>
  <rect x="90" y="100" width="120" height="80" rx="40" ry="40" fill="#3a3a3a" stroke="#555" stroke-width="2"/>
  <line x1="90" y1="140" x2="210" y2="140" stroke="#555" stroke-width="1.5"/>
  <circle cx="150" cy="165" r="4" fill="#0a0a0a"/>
  <text x="150" y="210" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="#888">{label}</text>
  <text x="285" y="18" text-anchor="end" font-family="Arial,sans-serif" font-size="9" fill="#bbb" opacity="0.6">示意图</text>
</svg>''',

    "headphones": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 280" width="300" height="280">
  <rect width="300" height="280" fill="#f5f5f5"/>
  <path d="M 80 180 Q 80 60 150 60 Q 220 60 220 180" fill="none" stroke="#555" stroke-width="6" stroke-linecap="round"/>
  <ellipse cx="80" cy="190" rx="28" ry="35" fill="#3a3a3a" stroke="#555" stroke-width="2"/>
  <ellipse cx="220" cy="190" rx="28" ry="35" fill="#3a3a3a" stroke="#555" stroke-width="2"/>
  <text x="150" y="260" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="#888">{label}</text>
  <text x="285" y="18" text-anchor="end" font-family="Arial,sans-serif" font-size="9" fill="#bbb" opacity="0.6">示意图</text>
</svg>''',

    "speaker": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 280" width="300" height="280">
  <rect width="300" height="280" fill="#f5f5f5"/>
  <rect x="110" y="50" width="80" height="180" rx="12" fill="#3a3a3a" stroke="#555" stroke-width="2"/>
  <circle cx="150" cy="120" r="22" fill="#1a1a1a" stroke="#444" stroke-width="1"/>
  <circle cx="150" cy="120" r="12" fill="#0a0a0a"/>
  <circle cx="150" cy="180" r="14" fill="#222" stroke="#444" stroke-width="1"/>
  <text x="150" y="260" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="#888">{label}</text>
  <text x="285" y="18" text-anchor="end" font-family="Arial,sans-serif" font-size="9" fill="#bbb" opacity="0.6">示意图</text>
</svg>''',

    "smartwatch": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 280" width="300" height="280">
  <rect width="300" height="280" fill="#f5f5f5"/>
  <rect x="115" y="80" width="70" height="70" rx="18" fill="#3a3a3a" stroke="#555" stroke-width="2"/>
  <rect x="122" y="87" width="56" height="56" rx="10" fill="#1a1a2e" stroke="#333" stroke-width="1"/>
  <rect x="135" y="50" width="30" height="30" fill="#444" stroke="#555" stroke-width="1"/>
  <rect x="135" y="150" width="30" height="30" fill="#444" stroke="#555" stroke-width="1"/>
  <text x="150" y="210" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="#888">{label}</text>
  <text x="285" y="18" text-anchor="end" font-family="Arial,sans-serif" font-size="9" fill="#bbb" opacity="0.6">示意图</text>
</svg>''',

    "hair_dryer": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 280" width="300" height="280">
  <rect width="300" height="280" fill="#f5f5f5"/>
  <rect x="100" y="70" width="90" height="50" rx="20" fill="#3a3a3a" stroke="#555" stroke-width="2"/>
  <circle cx="180" cy="95" r="22" fill="none" stroke="#555" stroke-width="2"/>
  <circle cx="180" cy="95" r="15" fill="#222" stroke="#444" stroke-width="1"/>
  <rect x="120" y="120" width="25" height="80" rx="10" fill="#444" stroke="#555" stroke-width="1.5"/>
  <text x="150" y="260" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="#888">{label}</text>
  <text x="285" y="18" text-anchor="end" font-family="Arial,sans-serif" font-size="9" fill="#bbb" opacity="0.6">示意图</text>
</svg>''',

    "electric_toothbrush": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 280" width="300" height="280">
  <rect width="300" height="280" fill="#f5f5f5"/>
  <rect x="130" y="30" width="40" height="40" rx="6" fill="#555" stroke="#666" stroke-width="1"/>
  <rect x="135" y="70" width="30" height="140" rx="12" fill="#3a3a3a" stroke="#555" stroke-width="2"/>
  <circle cx="150" cy="140" r="6" fill="#1a1a1a" stroke="#444" stroke-width="1"/>
  <rect x="133" y="210" width="34" height="10" rx="3" fill="#222" stroke="#444" stroke-width="1"/>
  <text x="150" y="260" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="#888">{label}</text>
  <text x="285" y="18" text-anchor="end" font-family="Arial,sans-serif" font-size="9" fill="#bbb" opacity="0.6">示意图</text>
</svg>''',

    "shaver": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 280" width="300" height="280">
  <rect width="300" height="280" fill="#f5f5f5"/>
  <rect x="115" y="40" width="70" height="40" rx="15" fill="#3a3a3a" stroke="#555" stroke-width="2"/>
  <circle cx="135" cy="60" r="8" fill="#555" stroke="#666" stroke-width="1"/>
  <circle cx="165" cy="60" r="8" fill="#555" stroke="#666" stroke-width="1"/>
  <rect x="125" y="80" width="50" height="120" rx="20" fill="#444" stroke="#555" stroke-width="2"/>
  <text x="150" y="260" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="#888">{label}</text>
  <text x="285" y="18" text-anchor="end" font-family="Arial,sans-serif" font-size="9" fill="#bbb" opacity="0.6">示意图</text>
</svg>''',

    "generic_device": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 280" width="300" height="280">
  <rect width="300" height="280" fill="#f5f5f5"/>
  <rect x="80" y="60" width="140" height="160" rx="15" ry="15" fill="#3a3a3a" stroke="#555" stroke-width="2"/>
  <text x="150" y="150" text-anchor="middle" font-family="Arial,sans-serif" font-size="14" fill="#888">产品示意图</text>
  <text x="150" y="260" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="#888">{label}</text>
  <text x="285" y="18" text-anchor="end" font-family="Arial,sans-serif" font-size="9" fill="#bbb" opacity="0.6">示意图</text>
</svg>''',
}


# ============================================================================
# Candidate download URLs for each comparison object type.
# Uses generic category terms only — no brand or product names for confidentiality.
# Google Patents search URLs are public and safe to use.
# ============================================================================

CANDIDATE_URLS = {
    "robot-vacuum": [
        ("comp_round_no_lidar", "round_robot_no_lidar", "圆形机身 · 顶部平整 · 无LiDAR塔",
         ["https://patents.google.com/?q=robot+vacuum+round+no+lidar",
          "https://www.amazon.com/s?k=robot+vacuum+round+flat+top"]),
        ("comp_round_with_lidar", "round_robot_with_lidar", "圆形机身 · 顶部有LiDAR塔",
         ["https://patents.google.com/?q=robot+vacuum+lidar+tower",
          "https://www.amazon.com/s?k=robot+vacuum+lidar+navigation"]),
        ("comp_d_shape", "d_shape_robot", "D形机身 · 顶部有LiDAR塔 · 沿边清洁导向",
         ["https://patents.google.com/?q=robot+vacuum+D-shaped",
          "https://www.amazon.com/s?k=robot+vacuum+D+shape"]),
        ("comp_base_station", "base_station", "自动集尘基站 · 圆润形态 · LCD屏幕",
         ["https://patents.google.com/?q=robot+vacuum+base+station+dock",
          "https://www.amazon.com/s?k=robot+vacuum+auto+empty+station"]),
    ],
    "cleaning-appliances": [
        ("comp_round_no_lidar", "round_robot_no_lidar", "圆形机身 · 顶部平整 · 无LiDAR塔",
         ["https://patents.google.com/?q=robot+vacuum+round+no+lidar",
          "https://www.amazon.com/s?k=robot+vacuum+round+flat+top"]),
        ("comp_round_with_lidar", "round_robot_with_lidar", "圆形机身 · 顶部有LiDAR塔",
         ["https://patents.google.com/?q=robot+vacuum+lidar+tower",
          "https://www.amazon.com/s?k=robot+vacuum+lidar+navigation"]),
        ("comp_d_shape", "d_shape_robot", "D形机身 · 顶部有LiDAR塔 · 沿边清洁导向",
         ["https://patents.google.com/?q=robot+vacuum+D-shaped",
          "https://www.amazon.com/s?k=robot+vacuum+D+shape"]),
        ("comp_base_station", "base_station", "自动集尘基站 · 圆润形态 · LCD屏幕",
         ["https://patents.google.com/?q=robot+vacuum+base+station+dock",
          "https://www.amazon.com/s?k=robot+vacuum+auto+empty+station"]),
    ],
    "stick-vacuum": [
        ("comp_stick", "stick_vacuum", "手持/杆式吸尘器示意图",
         ["https://patents.google.com/?q=stick+vacuum+cleaner+design",
          "https://www.amazon.com/s?k=stick+vacuum+cleaner"]),
        ("comp_base_station", "base_station", "充电基站示意图",
         ["https://patents.google.com/?q=vacuum+cleaner+charging+dock",
          "https://www.amazon.com/s?k=vacuum+charging+dock"]),
    ],
    "floor-washer": [
        ("comp_stick", "stick_vacuum", "洗地机示意图",
         ["https://patents.google.com/?q=floor+washer+wet+dry+vacuum",
          "https://www.amazon.com/s?k=floor+washer+wet+dry"]),
        ("comp_base_station", "base_station", "充电基站示意图",
         ["https://patents.google.com/?q=floor+washer+base+station",
          "https://www.amazon.com/s?k=floor+washer+station"]),
    ],
    "consumer-electronics": [
        ("comp_phone", "phone", "智能手机示意图",
         ["https://patents.google.com/?q=phone+design+patent",
          "https://www.amazon.com/s?k=smartphone+design"]),
        ("comp_earbuds", "earbuds_case", "真无线耳机充电盒示意图",
         ["https://patents.google.com/?q=wireless+earbuds+charging+case",
          "https://www.amazon.com/s?k=wireless+earbuds+case"]),
        ("comp_headphones", "headphones", "头戴式耳机示意图",
         ["https://patents.google.com/?q=headphones+design+patent",
          "https://www.amazon.com/s?k=over+ear+headphones"]),
        ("comp_speaker", "speaker", "智能音箱示意图",
         ["https://patents.google.com/?q=smart+speaker+design",
          "https://www.amazon.com/s?k=smart+speaker"]),
    ],
    "earbuds-headphones": [
        ("comp_earbuds", "earbuds_case", "真无线耳机充电盒示意图",
         ["https://patents.google.com/?q=wireless+earbuds+charging+case",
          "https://www.amazon.com/s?k=wireless+earbuds+case"]),
        ("comp_headphones", "headphones", "头戴式耳机示意图",
         ["https://patents.google.com/?q=headphones+design+patent",
          "https://www.amazon.com/s?k=over+ear+headphones"]),
    ],
    "personal-care": [
        ("comp_hair_dryer", "hair_dryer", "吹风机示意图",
         ["https://patents.google.com/?q=hair+dryer+design+patent",
          "https://www.amazon.com/s?k=hair+dryer"]),
        ("comp_toothbrush", "electric_toothbrush", "电动牙刷示意图",
         ["https://patents.google.com/?q=electric+toothbrush+design",
          "https://www.amazon.com/s?k=electric+toothbrush"]),
        ("comp_shaver", "shaver", "剃须刀示意图",
         ["https://patents.google.com/?q=electric+shaver+design",
          "https://www.amazon.com/s?k=electric+shaver"]),
    ],
}

# URL patterns to skip when filtering image candidates
_INVALID_URL_PATTERNS = [
    r'logo', r'favicon', r'icon[\._\-/]', r'pixel', r'track', r'beacon',
    r'sprite', r'button', r'arrow', r'breadcrumb', r'placeholder',
    r'blank\.(gif|png|jpg)', r'transparent', r'1x1',
]

# Minimum image dimension in pixels
MIN_IMAGE_SIZE = 100


# ============================================================================
# Image validation (T-01) — PIL-based, with file command fallback
# ============================================================================

def validate_image(filepath: str, min_size: int = MIN_IMAGE_SIZE) -> tuple:
    """Validate an image file using PIL/Pillow.

    Returns (is_valid: bool, mime_or_error: str).

    Validation rules:
    1. File can be opened by PIL
    2. Format is JPEG, PNG, WebP, or GIF
    3. Width and height are both >= min_size
    4. File size is not zero
    """
    try:
        from PIL import Image
        img = Image.open(filepath)
        img.verify()  # Verify file integrity
        img = Image.open(filepath)  # Re-open for attribute access
        w, h = img.size
        if w < min_size or h < min_size:
            return False, f"image_too_small:{w}x{h}"
        fmt = img.format.upper()
        mime_map = {
            "JPEG": "image/jpeg",
            "PNG": "image/png",
            "WEBP": "image/webp",
            "GIF": "image/gif",
        }
        mime = mime_map.get(fmt)
        if not mime:
            return False, f"unsupported_format:{fmt}"
        return True, mime
    except ImportError:
        # Fallback: use `file` command when PIL is unavailable
        result = subprocess.run(
            ["file", "--mime-type", filepath],
            capture_output=True, text=True
        )
        mime = result.stdout.lower()
        for t in ["image/jpeg", "image/png", "image/webp", "image/gif"]:
            if t in mime:
                return True, t
        return False, "pil_unavailable_and_file_failed"
    except Exception as e:
        return False, f"validation_error:{str(e)[:100]}"


# ============================================================================
# Invalid image candidate filtering (T-06, C-10)
# ============================================================================

def is_valid_image_candidate(url: str) -> bool:
    """Check if an image URL is worth downloading.

    Skips:
    - logo/favicon URLs
    - tracking pixel URLs
    - base64 data URIs that are small icons (length < 500)
    - UI decoration images (sprite/button/arrow/breadcrumb)
    - 1x1 transparent images
    """
    if not url:
        return False

    # Skip base64 data URIs that are too short (likely small icons)
    if url.startswith("data:image/"):
        if len(url) < 500:
            return False
        return True

    url_lower = url.lower()
    for pattern in _INVALID_URL_PATTERNS:
        if re.search(pattern, url_lower):
            return False

    # Skip URLs without a valid scheme
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https", ""):
        return False

    return True


# ============================================================================
# Download failure classification (T-05, C-11)
# ============================================================================

def classify_download_failure(url: str, error_msg: str, http_code: str = "") -> str:
    """Classify download failure reason.

    Returns one of:
    - "network_restricted": network permission issue (timeout, DNS, connection refused)
    - "http_error": HTTP error status (403/404/500 etc.)
    - "not_an_image": downloaded content is not an image (HTML error page, captcha)
    - "validation_failed": downloaded but validation failed (too small, unsupported format)
    - "script_error": unexpected script logic error
    """
    err_lower = (error_msg or "").lower()

    # Network-level failures
    network_indicators = [
        "timeout", "timed out", "connection refused", "connection reset",
        "could not resolve", "name resolution", "no route to host",
        "network is unreachable", "ssl certificate", "handshake",
        "connection aborted", "broken pipe",
    ]
    for indicator in network_indicators:
        if indicator in err_lower:
            return "network_restricted"

    # HTTP error codes
    if http_code:
        code = http_code.strip()
        if code in ("403", "401"):
            return "http_error"
        if code in ("404", "410"):
            return "http_error"
        if code.startswith("5"):
            return "http_error"

    # Not an image
    not_image_indicators = [
        "text/html", "not_an_image", "html_error", "captcha",
        "unsupported_format", "validation_error",
    ]
    for indicator in not_image_indicators:
        if indicator in err_lower:
            return "not_an_image"

    # Validation failures
    if "image_too_small" in err_lower:
        return "validation_failed"

    # Default
    return "script_error"


# ============================================================================
# Web page image candidate extraction (T-02, C-02, C-03)
# ============================================================================

def extract_image_candidates_from_html(html_content: str, page_url: str) -> list:
    """Extract image candidate URLs from a web page's HTML.

    Extraction order (priority high to low):
    1. meta[property="og:image"]
    2. meta[name="twitter:image"]
    3. JSON-LD "image" fields
    4. <source srcset> entries
    5. <img srcset> entries
    6. <img src> attributes
    7. Lazy-load fields: data-src, data-original, data-lazy-src, data-image

    Returns: [{"url": "absolute_url", "source": "og:image", "priority": 1}, ...]
    Candidates are filtered by is_valid_image_candidate() and capped at 10.
    """
    candidates = []
    seen_urls = set()

    def add_candidate(url, source, priority):
        """Add a candidate if valid and not already seen."""
        if not url:
            return
        # Convert relative URL to absolute
        if not url.startswith(("http://", "https://", "data:")):
            url = urljoin(page_url, url)
        if url in seen_urls:
            return
        if not is_valid_image_candidate(url):
            return
        seen_urls.add(url)
        candidates.append({"url": url, "source": source, "priority": priority})

    # 1. meta[property="og:image"]
    for m in re.finditer(r'<meta\s+[^>]*property=["\']og:image["\'][^>]*content=["\']([^"\']+)["\']', html_content, re.IGNORECASE):
        add_candidate(m.group(1), "og:image", 1)
    # Also check content before property
    for m in re.finditer(r'<meta\s+[^>]*content=["\']([^"\']+)["\'][^>]*property=["\']og:image["\']', html_content, re.IGNORECASE):
        add_candidate(m.group(1), "og:image", 1)

    # 2. meta[name="twitter:image"]
    for m in re.finditer(r'<meta\s+[^>]*name=["\']twitter:image["\'][^>]*content=["\']([^"\']+)["\']', html_content, re.IGNORECASE):
        add_candidate(m.group(1), "twitter:image", 2)
    for m in re.finditer(r'<meta\s+[^>]*content=["\']([^"\']+)["\'][^>]*name=["\']twitter:image["\']', html_content, re.IGNORECASE):
        add_candidate(m.group(1), "twitter:image", 2)

    # 3. JSON-LD "image" fields
    for m in re.finditer(r'"image"\s*:\s*"([^"]+)"', html_content):
        add_candidate(m.group(1), "json-ld", 3)

    # 4. <source srcset>
    for m in re.finditer(r'<source[^>]*srcset=["\']([^"\']+)["\']', html_content, re.IGNORECASE):
        srcset = m.group(1)
        _parse_srcset(srcset, page_url, "source_srcset", 4, add_candidate)

    # 5. <img srcset>
    for m in re.finditer(r'<img[^>]*srcset=["\']([^"\']+)["\']', html_content, re.IGNORECASE):
        srcset = m.group(1)
        _parse_srcset(srcset, page_url, "img_srcset", 5, add_candidate)

    # 6. <img src>
    for m in re.finditer(r'<img[^>]*\ssrc=["\']([^"\']+)["\']', html_content, re.IGNORECASE):
        add_candidate(m.group(1), "img_src", 6)

    # 7. Lazy-load fields
    lazy_attrs = ["data-src", "data-original", "data-lazy-src", "data-image"]
    for i, attr in enumerate(lazy_attrs):
        pattern = rf'<img[^>]*{attr}=["\']([^"\']+)["\']'
        for m in re.finditer(pattern, html_content, re.IGNORECASE):
            add_candidate(m.group(1), f"lazy:{attr}", 7 + i * 0.1)

    # Sort by priority and cap at 10
    candidates.sort(key=lambda c: c["priority"])
    return candidates[:10]


def _parse_srcset(srcset_str, page_url, source_name, priority, add_fn):
    """Parse a srcset attribute value and add candidates.

    srcset format: "url1 1x, url2 2x" or "url1 300w, url2 600w"
    Prefers larger width or higher density.
    """
    entries = srcset_str.split(",")
    parsed = []
    for entry in entries:
        parts = entry.strip().split()
        if not parts:
            continue
        url = parts[0]
        descriptor = parts[1] if len(parts) > 1 else "1x"
        # Extract numeric value for sorting
        try:
            num = float(re.search(r'[\d.]+', descriptor).group())
        except (AttributeError, ValueError):
            num = 0
        parsed.append((url, num, descriptor))

    # Sort by numeric value descending (prefer larger/higher)
    parsed.sort(key=lambda x: x[1], reverse=True)

    for url, num, desc in parsed:
        add_fn(url, f"{source_name}:{desc}", priority)


# ============================================================================
# Dynamic candidate URL construction (T-07, R-01, R-04)
# ============================================================================

def build_candidate_urls(category: str, visual_attributes: dict) -> list:
    """Build dynamic candidate URLs based on category and product visual attributes.

    Strategy:
    1. Start with static CANDIDATE_URLS for the category
    2. Add Google Patents search URLs using category + feature keywords
    3. Add public article/review search URLs (avoid direct patent site scraping)
    4. Add e-commerce search URLs with generic terms

    Returns: list of (key, svg_template, label, [urls]) tuples
    """
    # Start with static candidates
    base_candidates = list(CANDIDATE_URLS.get(category, []))

    # Build dynamic search URLs from visual attributes
    body_shape = visual_attributes.get("body_shape", "")
    material = visual_attributes.get("material", "")

    # Category-specific search term mapping
    category_search_terms = {
        "robot-vacuum": "robot vacuum",
        "cleaning-appliances": "cleaning appliance",
        "consumer-electronics": "consumer electronics device",
        "earbuds-headphones": "wireless earbuds headphones",
        "personal-care": "personal care device",
    }
    base_term = category_search_terms.get(category, category.replace("-", " "))

    # Add feature-based Google Patents search
    if body_shape:
        patent_search = f"https://patents.google.com/?q={base_term}+{body_shape.replace(' ', '+')}"
        # Add to the first candidate's URL list if available
        if base_candidates:
            key, svg, label, urls = base_candidates[0]
            if patent_search not in urls:
                urls = list(urls) + [patent_search]
                base_candidates[0] = (key, svg, label, urls)

    return base_candidates


# ============================================================================
# Core download function (T-01, T-03) — PIL validation + browser headers
# ============================================================================

def try_download_image(url: str, output_path: str, timeout: int = 15) -> tuple:
    """Attempt to download an image from a URL.

    Returns (success: bool, metadata: dict) where metadata contains:
    - mime: image MIME type on success
    - error: error message on failure
    - http_code: HTTP status code
    - failure_class: classified failure reason
    """
    try:
        result = subprocess.run(
            ["curl", "--connect-timeout", "5", "--max-time", str(timeout),
             "-L", "-o", output_path, url,
             "-H", f"User-Agent: {BROWSER_UA}",
             "-H", f"Accept: {BROWSER_ACCEPT}",
             "-H", f"Accept-Language: {BROWSER_ACCEPT_LANG}",
             "-s", "-w", "%{http_code}"],
            capture_output=True, text=True, timeout=timeout + 10
        )
        http_code = result.stdout.strip() if result.stdout else ""

        if result.returncode != 0:
            err_msg = result.stderr or "curl_returned_nonzero"
            failure_class = classify_download_failure(url, err_msg, http_code)
            return False, {"error": err_msg, "http_code": http_code, "failure_class": failure_class}

        # Validate the downloaded file using PIL
        is_valid, mime_or_err = validate_image(output_path)
        if is_valid:
            return True, {"mime": mime_or_err, "http_code": http_code}
        else:
            failure_class = classify_download_failure(url, mime_or_err, http_code)
            return False, {"error": mime_or_err, "http_code": http_code, "failure_class": failure_class}

    except subprocess.TimeoutExpired:
        failure_class = classify_download_failure(url, "timeout", "")
        return False, {"error": "timeout", "http_code": "", "failure_class": failure_class}
    except Exception as e:
        failure_class = classify_download_failure(url, str(e), "")
        return False, {"error": str(e), "http_code": "", "failure_class": failure_class}


# ============================================================================
# Web page fetching and image extraction (T-02, R-05)
# ============================================================================

def fetch_page_html(url: str, timeout: int = 15) -> tuple:
    """Fetch a web page's HTML content.

    Returns (html_content: str, error: str or None).
    """
    try:
        result = subprocess.run(
            ["curl", "--connect-timeout", "5", "--max-time", str(timeout),
             "-L", url,
             "-H", f"User-Agent: {BROWSER_UA}",
             "-H", f"Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
             "-H", f"Accept-Language: {BROWSER_ACCEPT_LANG}",
             "-s"],
            capture_output=True, text=True, timeout=timeout + 10
        )
        if result.returncode != 0:
            return "", result.stderr or "curl_failed"
        html = result.stdout
        if not html or len(html) < 100:
            return "", "empty_or_short_response"
        return html, None
    except Exception as e:
        return "", str(e)


def try_fetch_image_from_page(page_url: str, output_dir: str, key: str) -> tuple:
    """Fetch a web page, extract image candidates, and try downloading the best one.

    Returns (success: bool, metadata: dict).
    """
    html, err = fetch_page_html(page_url)
    if err:
        return False, {"error": f"page_fetch_failed:{err}", "failure_class": classify_download_failure(page_url, err)}

    candidates = extract_image_candidates_from_html(html, page_url)
    if not candidates:
        return False, {"error": "no_image_candidates_found", "failure_class": "not_an_image"}

    # Try each candidate
    for i, cand in enumerate(candidates):
        temp_path = os.path.join(output_dir, f"{key}_cand_{i}.jpg")
        success, meta = try_download_image(cand["url"], temp_path)
        if success:
            # Move to final path
            final_path = os.path.join(output_dir, f"{key}_real.jpg")
            os.rename(temp_path, final_path)
            meta["source_url"] = cand["url"]
            meta["source_extracted_from"] = cand["source"]
            meta["page_url"] = page_url
            return True, meta
        # Clean up temp file
        if os.path.exists(temp_path):
            os.remove(temp_path)

    return False, {"error": "all_candidates_failed", "failure_class": "not_an_image"}


# ============================================================================
# Image to base64 conversion (T-01, R-02) — with min size check
# ============================================================================

def image_to_base64(filepath: str, max_size: int = 800) -> str:
    """Resize and convert image to base64 data URI.

    Validates image dimensions before conversion.
    Returns empty string on failure.
    """
    try:
        from PIL import Image
        import io
        img = Image.open(filepath)
        if img.mode != "RGBA":
            img = img.convert("RGB")
        w, h = img.size
        if w < MIN_IMAGE_SIZE or h < MIN_IMAGE_SIZE:
            print(f"  ⚠️ Image too small: {w}x{h}, skipping", file=sys.stderr)
            return ""
        img.thumbnail((max_size, max_size), Image.LANCZOS)
        buf = io.BytesIO()
        img.save(buf, format="PNG", optimize=True)
        b64 = base64.b64encode(buf.getvalue()).decode()
        return f"data:image/png;base64,{b64}"
    except ImportError:
        # Fallback if PIL is not available
        with open(filepath, "rb") as f:
            b64 = base64.b64encode(f.read()).decode()
        ext = Path(filepath).suffix.lower().lstrip(".")
        mime = f"image/{ext}" if ext in ["jpeg", "jpg", "png", "webp", "gif"] else "image/png"
        return f"data:{mime};base64,{b64}"
    except Exception:
        return ""


def svg_to_base64(svg_content: str) -> str:
    """Convert SVG string to base64 data URI."""
    b64 = base64.b64encode(svg_content.encode("utf-8")).decode()
    return f"data:image/svg+xml;base64,{b64}"


def generate_svg_schematic(template_key: str, label: str = "") -> str:
    """Generate an SVG schematic for a given product type."""
    template = SVG_TEMPLATES.get(template_key, SVG_TEMPLATES["generic_device"])
    return svg_to_base64(template.format(label=label))


# ============================================================================
# Main image acquisition function (T-04, T-05) — unified output + failure classification
# ============================================================================

def fetch_images_for_category(category: str, output_dir: str, visual_attributes: dict = None) -> dict:
    """
    Main function: attempt to fetch real images, fall back to SVG schematics.

    Returns a dict with full traceability fields for each comparison object:
    - source_type: "real" | "svg"
    - visual_type: "real" | "svg_schematic"
    - source_url: actual download URL (for real images)
    - comparison_url: public source page URL
    - image_reference_url: backup image source URL
    - source_note: human-readable source description
    - download_status: MIME type or failure description
    - failure_reason: classified failure reason (for SVG fallback)
    - label: product description label
    """
    os.makedirs(output_dir, exist_ok=True)
    results = {}
    visual_attributes = visual_attributes or {}

    # Get comparison objects — use dynamic building if visual attributes available
    if visual_attributes:
        comparisons = build_candidate_urls(category, visual_attributes)
    else:
        comparisons = CANDIDATE_URLS.get(category, [
            ("comp_generic_1", "generic_device", "竞品示意图1",
             ["https://patents.google.com/"]),
            ("comp_generic_2", "generic_device", "竞品示意图2",
             ["https://patents.google.com/"]),
        ])

    download_attempts = 0
    download_successes = 0
    total_failure_reasons = []

    for key, svg_template, label, candidate_urls in comparisons:
        real_image = None
        actual_download_url = ""
        download_mime = ""
        best_url = candidate_urls[0] if candidate_urls else ""
        image_ref_url = candidate_urls[1] if len(candidate_urls) > 1 else best_url
        failure_reason = "no_candidates"
        total_attempts_for_key = 0

        # Phase 1: Try direct image URL download from candidate URLs
        for url in candidate_urls:
            if not is_valid_image_candidate(url):
                continue
            download_attempts += 1
            total_attempts_for_key += 1
            temp_path = os.path.join(output_dir, f"{key}_temp.jpg")
            print(f"  Trying direct: {url[:80]}...", file=sys.stderr)

            success, meta = try_download_image(url, temp_path)
            if success:
                real_image = image_to_base64(temp_path)
                actual_download_url = url
                download_mime = meta.get("mime", "image/jpeg")
                if os.path.exists(temp_path):
                    os.remove(temp_path)
                if real_image:
                    download_successes += 1
                    failure_reason = ""
                    print(f"  ✅ Downloaded real image for {key}", file=sys.stderr)
                    break
                else:
                    print(f"  ⚠️ Download OK but base64 conversion failed for {key}", file=sys.stderr)
            else:
                failure_reason = meta.get("failure_class", "script_error")
                total_failure_reasons.append(failure_reason)
                print(f"  ❌ Download failed for {key}: {meta.get('error', 'unknown')[:60]}", file=sys.stderr)
                if os.path.exists(temp_path):
                    os.remove(temp_path)

        # Phase 2: If direct download failed, try fetching from page and extracting images
        if not real_image:
            for url in candidate_urls[:2]:  # Try first 2 URLs as pages
                if not is_valid_image_candidate(url):
                    continue
                download_attempts += 1
                total_attempts_for_key += 1
                print(f"  Trying page extraction: {url[:80]}...", file=sys.stderr)

                success, meta = try_fetch_image_from_page(url, output_dir, key)
                if success:
                    final_path = os.path.join(output_dir, f"{key}_real.jpg")
                    real_image = image_to_base64(final_path)
                    actual_download_url = meta.get("source_url", url)
                    download_mime = meta.get("mime", "image/jpeg")
                    if os.path.exists(final_path):
                        os.remove(final_path)
                    if real_image:
                        download_successes += 1
                        failure_reason = ""
                        print(f"  ✅ Extracted real image from page for {key}", file=sys.stderr)
                        break
                    else:
                        print(f"  ⚠️ Page extraction OK but base64 failed for {key}", file=sys.stderr)
                else:
                    failure_reason = meta.get("failure_class", "script_error")
                    total_failure_reasons.append(failure_reason)
                    print(f"  ❌ Page extraction failed for {key}: {meta.get('error', 'unknown')[:60]}", file=sys.stderr)

        # Build result object with unified structure
        if real_image:
            results[key] = {
                "image": real_image,
                "source_type": "real",
                "visual_type": "real",
                "source_url": actual_download_url,
                "comparison_url": best_url,
                "image_reference_url": image_ref_url,
                "source_note": "已抓取真实图片并转为 base64。",
                "download_status": download_mime,
                "label": label,
            }
        else:
            # Determine dominant failure reason
            if total_failure_reasons:
                # Count failure reasons
                from collections import Counter
                reason_counts = Counter(total_failure_reasons[-total_attempts_for_key:])
                failure_reason = reason_counts.most_common(1)[0][0]

            results[key] = {
                "image": generate_svg_schematic(svg_template, label),
                "source_type": "svg",
                "visual_type": "svg_schematic",
                "comparison_url": best_url,
                "image_reference_url": image_ref_url,
                "source_note": "未能下载真实图片，已使用示意图；请点击来源链接查看公开实物/专利图片。",
                "download_status": f"no downloadable image among {total_attempts_for_key} candidates",
                "label": label,
                "failure_reason": failure_reason,
            }

    # Save results to JSON
    output_json = os.path.join(output_dir, "competitor_images.json")
    with open(output_json, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    svg_count = len(results) - download_successes
    print(f"\nGenerated {len(results)} comparison images "
          f"({download_successes} real, {svg_count} SVG fallback)", file=sys.stderr)
    print(f"Download attempts: {download_attempts}, successes: {download_successes}", file=sys.stderr)

    # Print failure reason summary
    if total_failure_reasons:
        from collections import Counter
        reason_summary = Counter(total_failure_reasons)
        print(f"Failure reasons: {dict(reason_summary)}", file=sys.stderr)
        if reason_summary.get("network_restricted", 0) > 0:
            print("⚠️  网络受限：当前环境网络权限可能导致下载失败，建议在允许联网后重新测试。", file=sys.stderr)

    print(f"Output: {output_json}", file=sys.stderr)
    return results


# ============================================================================
# Agent input mode (T-04) — sync output structure
# ============================================================================

def fetch_from_agent_input(input_path: str, output_dir: str) -> str:
    """Fetch competitor images based on Patent Scout Agent input JSON (v4.0.0+).

    Reads the agent input JSON, extracts product category and comparison object names,
    calls fetch_images_for_category, and writes results to output_dir.
    Returns the path to the JSON results file.
    """
    input_data = json.loads(Path(input_path).read_text(encoding="utf-8"))

    # Extract category from agent input
    product_context = input_data.get("product_context", {})
    category = product_context.get("category", "unknown")

    # Map internal category keys to script category names
    category_map = {
        "cleaning_appliances": "cleaning-appliances",
        "consumer_electronics": "consumer-electronics",
        "personal_care": "personal-care",
    }
    script_category = category_map.get(category, category)

    # Also extract subcategory and visual attributes from image_analysis if available
    image_analysis = input_data.get("image_analysis", {})
    product_id = image_analysis.get("product_identification", {})
    subcategory = product_id.get("subcategory", "")
    visual_attributes = image_analysis.get("visual_attributes", {})

    # Adjust category based on subcategory
    if subcategory == "robot_vacuum":
        script_category = "robot-vacuum"
    elif subcategory == "earbuds_headphones":
        script_category = "earbuds-headphones"
    elif subcategory == "toothbrush_steriliser":
        script_category = "personal-care"

    # Fetch images with visual attributes for dynamic URL building
    results = fetch_images_for_category(script_category, output_dir, visual_attributes)

    # Write results to file
    output_path = Path(output_dir) / "competitor_images.json"
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")

    return str(output_path)


# ============================================================================
# CLI entry point
# ============================================================================

def main():
    parser = argparse.ArgumentParser(description="Fetch competitor images for patent comparison.")
    parser.add_argument("--category",
                        help="Product category (robot-vacuum, cleaning-appliances, consumer-electronics, "
                             "earbuds-headphones, personal-care, etc.)")
    parser.add_argument("--from-agent-input",
                        help="Path to Patent Scout Agent input JSON (v4.0.0+ mode)")
    parser.add_argument("--output-dir", default="compare_images", help="Output directory for images")
    parser.add_argument("--format", choices=["base64", "file"], default="base64", help="Output format")
    args = parser.parse_args()

    if args.from_agent_input:
        # v4.0.0+ agent mode
        output_path = fetch_from_agent_input(args.from_agent_input, args.output_dir)
        print(f"Competitor images JSON written to: {output_path}", file=sys.stderr)
        # Also output to stdout for parsing
        results = json.loads(Path(output_path).read_text(encoding="utf-8"))
        print(json.dumps(results, ensure_ascii=False, indent=2))
    elif args.category:
        results = fetch_images_for_category(args.category, args.output_dir)
        if args.format == "base64":
            print(json.dumps(results, ensure_ascii=False, indent=2))
    else:
        print("Error: Either --category or --from-agent-input must be provided", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
