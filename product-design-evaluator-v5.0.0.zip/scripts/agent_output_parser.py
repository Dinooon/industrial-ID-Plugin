#!/usr/bin/env python3
"""
agent_output_parser.py — Parse and validate sub-agent output with fault tolerance.

Attempts multiple strategies to extract valid JSON from sub-agent output:
1. Direct JSON parse
2. Markdown code block extraction (```json ... ```)
3. Brace-matching extraction
4. Fallback to default structure with error logging

Usage:
    python agent_output_parser.py --input <output_file> --agent <agent_name> [--output <parsed_file>]

Agent names: image_analyst, brand_judge, patent_scout, report_builder
"""

import argparse
import json
import re
import sys
from pathlib import Path
from datetime import datetime


def get_default_output(agent_name: str) -> dict:
    """Return a default/minimal output structure for each agent type."""
    defaults = {
        "image_analyst": {
            "product_identification": {
                "product_type": "未知产品",
                "category": "uncertain",
                "subcategory": "unknown",
                "confidence": "低",
            },
            "visual_attributes": {
                "body_shape": "无法识别",
                "body_shape_confidence": "低",
                "silhouette": "无法识别",
                "top_surface": "无法识别",
                "top_surface_confidence": "低",
                "cmf_cues": {"material": "未知", "color": "未知", "finish": "未知"},
                "key_features": [],
                "seams_and_openings": "无法识别",
                "visible_sensors": [],
                "wheels_or_tracks": "无法识别",
            },
            "recognition_verification": {
                "verification_pass": False,
                "critical_attributes_checked": [],
                "ambiguous_attributes": [{"attribute": "all", "issue": "Agent输出解析失败，无法验证"}],
            },
            "needs_user_confirmation": ["图片识别失败，请确认产品信息"],
            "image_relationship": "not_applicable",
            "image_relationship_notes": "Agent输出解析失败",
            "_parse_error": True,
        },
        "brand_judge": {
            "brand_language_review": {
                "consistency_level": "中等",
                "strong_points": ["无法解析Agent输出"],
                "deviations": ["无法解析Agent输出"],
                "risk_signals": [],
                "family_extension_judgment": "Agent输出解析失败，无法评估",
            },
            "recommendations": ["请重新运行品牌评审"],
            "_parse_error": True,
        },
        "patent_scout": {
            "patent_risk_assessment": {
                "risk_level": "未评估",
                "comparison_objects": [],
                "design_around_suggestions": [],
                "legal_disclaimer": "本评估为内部初步筛查，不构成法律意见",
                "requires_legal_review": False,
            },
            "_parse_error": True,
        },
        "report_builder": {
            "report": {
                "file_path": "",
                "verdict": "修改后推进",
                "total_score": 0,
                "confidence": "低",
                "brand_consistency": "中等",
                "patent_risk": "未评估",
                "version": "v1.0",
            },
            "quality_gate_result": {
                "critical_checks": {"total": 0, "passed": 0, "failed": 0, "failed_items": ["Agent输出解析失败"]},
                "recommended_checks": {"total": 0, "passed": 0, "failed": 0, "failed_items": []},
                "overall_pass": False,
            },
            "scoring_breakdown": [],
            "executive_summary": ["Agent输出解析失败"],
            "recommendations": [],
            "developer_log_path": "",
            "_parse_error": True,
        },
    }
    return defaults.get(agent_name, {"_parse_error": True, "error": f"Unknown agent: {agent_name}"})


def try_direct_parse(text: str) -> dict | None:
    """Strategy 1: Direct JSON parse."""
    try:
        return json.loads(text)
    except (json.JSONDecodeError, TypeError):
        return None


def try_codeblock_parse(text: str) -> dict | None:
    """Strategy 2: Extract from markdown code blocks."""
    patterns = [
        r'```json\s*\n(.*?)\n\s*```',
        r'```\s*\n(.*?)\n\s*```',
        r'```json\s*\n(.*?)```',
        r'```\s*\n(.*?)```',
    ]
    for pattern in patterns:
        matches = re.findall(pattern, text, re.DOTALL)
        for match in matches:
            try:
                return json.loads(match.strip())
            except json.JSONDecodeError:
                continue
    return None


def try_brace_parse(text: str) -> dict | None:
    """Strategy 3: Brace-matching extraction."""
    # Find the first '{' and try to match to the closing '}'
    start = text.find('{')
    if start == -1:
        return None

    depth = 0
    in_string = False
    escape = False
    for i in range(start, len(text)):
        char = text[i]
        if escape:
            escape = False
            continue
        if char == '\\':
            escape = True
            continue
        if char == '"':
            in_string = not in_string
            continue
        if in_string:
            continue
        if char == '{':
            depth += 1
        elif char == '}':
            depth -= 1
            if depth == 0:
                candidate = text[start:i + 1]
                try:
                    return json.loads(candidate)
                except json.JSONDecodeError:
                    # Try the next '{'
                    next_start = text.find('{', start + 1)
                    if next_start != -1:
                        return try_brace_parse(text[next_start:])
                    return None
    return None


def validate_output(data: dict, agent_name: str) -> list:
    """Validate the parsed output against expected schema. Returns list of issues."""
    issues = []

    if agent_name == "image_analyst":
        if "product_identification" not in data:
            issues.append("Missing 'product_identification' key")
        if "visual_attributes" not in data:
            issues.append("Missing 'visual_attributes' key")
        if "recognition_verification" not in data:
            issues.append("Missing 'recognition_verification' key")

    elif agent_name == "brand_judge":
        if "brand_language_review" not in data:
            issues.append("Missing 'brand_language_review' key")
        else:
            review = data["brand_language_review"]
            # v5.0.0: Support both string and structured dict formats
            if isinstance(review, dict):
                if "key_conclusion" not in review:
                    issues.append("Missing 'key_conclusion' in structured brand_language_review")
            elif isinstance(review, str):
                # Legacy string format — check consistency_level separately
                pass
            else:
                issues.append("brand_language_review must be string or dict")
            # Check consistency_level in either the dict or top-level
            consistency = review.get("consistency_level") if isinstance(review, dict) else data.get("consistency_level", review.get("consistency_level") if isinstance(review, dict) else "")
            valid_levels = ["强", "中等", "弱", "矛盾", "Strong", "Moderate", "Weak", "Contradictory"]
            if consistency and consistency not in valid_levels:
                issues.append(f"Invalid consistency_level: {consistency}")

    elif agent_name == "patent_scout":
        if "patent_risk_assessment" not in data:
            issues.append("Missing 'patent_risk_assessment' key")
        else:
            assessment = data["patent_risk_assessment"]
            if "risk_level" not in assessment:
                issues.append("Missing 'risk_level' in patent_risk_assessment")
            valid_levels = ["低", "中", "中高", "高", "极高", "未评估", "视觉相似信号"]
            if assessment.get("risk_level") not in valid_levels:
                issues.append(f"Invalid risk_level: {assessment.get('risk_level')}")

    elif agent_name == "report_builder":
        if "report" not in data:
            issues.append("Missing 'report' key")
        if "quality_gate_result" not in data:
            issues.append("Missing 'quality_gate_result' key")

    return issues


def parse_agent_output(raw_text: str, agent_name: str) -> tuple[dict, list]:
    """
    Parse sub-agent output with fault tolerance.
    Returns (parsed_data, list_of_strategies_tried).
    """
    strategies = []

    # Strategy 1: Direct parse
    result = try_direct_parse(raw_text)
    strategies.append("direct_parse")
    if result is not None:
        issues = validate_output(result, agent_name)
        if not issues:
            return result, strategies
        # Has structure but some issues — still return it, note issues
        result["_validation_issues"] = issues
        return result, strategies

    # Strategy 2: Code block extraction
    result = try_codeblock_parse(raw_text)
    strategies.append("codeblock_parse")
    if result is not None:
        issues = validate_output(result, agent_name)
        if not issues:
            return result, strategies
        result["_validation_issues"] = issues
        return result, strategies

    # Strategy 3: Brace matching
    result = try_brace_parse(raw_text)
    strategies.append("brace_parse")
    if result is not None:
        issues = validate_output(result, agent_name)
        if not issues:
            return result, strategies
        result["_validation_issues"] = issues
        return result, strategies

    # All strategies failed — return default
    default = get_default_output(agent_name)
    default["_parse_strategies_tried"] = strategies
    default["_parse_error_detail"] = f"All {len(strategies)} strategies failed"
    return default, strategies


def main():
    parser = argparse.ArgumentParser(description="Parse sub-agent output with fault tolerance.")
    parser.add_argument("--input", required=True, help="Path to raw agent output file")
    parser.add_argument("--agent", required=True, choices=["image_analyst", "brand_judge", "patent_scout", "report_builder"],
                        help="Agent name")
    parser.add_argument("--output", help="Path to write parsed JSON (default: stdout)")
    args = parser.parse_args()

    p = Path(args.input)
    if not p.exists():
        print(f"Error: Input file not found: {args.input}", file=sys.stderr)
        sys.exit(1)

    raw_text = p.read_text(encoding="utf-8")
    parsed, strategies = parse_agent_output(raw_text, args.agent)

    has_error = parsed.get("_parse_error", False)
    if has_error:
        print(f"⚠️  Parse failed for {args.agent}. Strategies tried: {', '.join(strategies)}", file=sys.stderr)
        print(f"   Using default fallback output.", file=sys.stderr)
    else:
        issues = parsed.get("_validation_issues", [])
        if issues:
            print(f"⚠️  Parsed with validation issues for {args.agent}:", file=sys.stderr)
            for issue in issues:
                print(f"   - {issue}", file=sys.stderr)
        else:
            print(f"✅ Successfully parsed {args.agent} output (strategy: {strategies[-1]})", file=sys.stderr)

    output_json = json.dumps(parsed, ensure_ascii=False, indent=2)
    if args.output:
        Path(args.output).write_text(output_json, encoding="utf-8")
        print(f"Written: {args.output}", file=sys.stderr)
    else:
        print(output_json)


if __name__ == "__main__":
    main()
