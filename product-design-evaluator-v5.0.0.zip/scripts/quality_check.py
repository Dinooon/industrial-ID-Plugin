#!/usr/bin/env python3
"""
quality_check.py — Automated quality gate checker for Product Design Evaluator.

Verifies that an HTML report meets the Critical and Recommended quality-gate
checks defined in references/quality-gate.md.

Supports two modes:
1. Direct mode: python quality_check.py <report-html-path>
2. Report Builder mode (v4.0.0): python quality_check.py --from-report-builder <agent-output-json>
   In Report Builder mode, the script reads the agent's embedded self-check result
   and performs additional independent verification.

Exit codes:
    0 — All Critical checks passed
    1 — One or more Critical checks failed
"""

import json
import re
import sys
from pathlib import Path


# Qualitative patent risk labels (numeric scores should NOT appear)
PATENT_RISK_LABELS = ["未评估", "低", "中", "中高", "高", "极高", "视觉相似信号"]

# Forbidden legal-advice language in patent-risk sections
FORBIDDEN_LEGAL_TERMS = [
    "definitely infringing", "legally safe", "patent invalid", "no risk",
    "肯定侵权", "法律安全", "专利无效", "无风险",
]

# Required report sections (by heading text)
REQUIRED_SECTIONS = [
    "评审结论", "执行摘要", "输入确认", "主要发现",
    "品牌设计语言一致性", "分项评分", "外观专利",
    "优先修改建议", "下次补充材料", "反馈",
]

# Content that should NOT appear in user-facing report
FORBIDDEN_IN_REPORT = [
    "execution trace", "quality-gate", "task boundar", "risk boundar",
    "human review workflow", "执行追踪", "质量门禁", "任务边界",
    "风险边界", "人工评审工作流",
]

# Template residue patterns that must not appear in final report (v4.1.0)
TEMPLATE_RESIDUE_PATTERNS = [
    "Template Variable Guide",
    "Template version:",
    "TEMPLATE_VAR_GUIDE_START",
    "TEMPLATE_VAR_GUIDE_END",
]


def load_html(path: str) -> str:
    p = Path(path)
    if not p.exists():
        print(f"Error: Report file not found: {path}", file=sys.stderr)
        sys.exit(1)
    return p.read_text(encoding="utf-8")


def extract_patent_section(html: str) -> str:
    """Return the patent-risk section when it can be isolated."""
    section_match = re.search(r'<section[^>]*id=["\']patent-risk["\'][^>]*>.*?</section>', html, re.DOTALL | re.IGNORECASE)
    if section_match:
        return section_match.group(0)

    section_match = re.search(r"外观专利.*?</section>", html, re.DOTALL)
    if section_match:
        return section_match.group(0)

    return html


def fallback_visual_links_ok(html: str) -> tuple:
    """Check fallback patent comparison visuals include a clickable lookup/source URL."""
    patent_section = extract_patent_section(html)
    if "compare-card" not in patent_section and "compare-media" not in patent_section:
        return True, "No patent comparison cards found"

    fallback_matches = list(re.finditer(r"data:image/svg\+xml;base64,|image unavailable|source-missing", patent_section, re.IGNORECASE))
    if not fallback_matches:
        return True, "No fallback SVG or placeholder comparison visuals found"

    missing = 0
    for match in fallback_matches:
        card_start = patent_section.rfind('<div class="compare-card"', 0, match.start())
        if card_start == -1:
            card_start = max(0, match.start() - 1200)
        next_card = patent_section.find('<div class="compare-card"', match.start() + 1)
        card_end = next_card if next_card != -1 else min(len(patent_section), match.start() + 5000)
        card_html = patent_section[card_start:card_end]
        has_clickable_source = bool(re.search(r'<a\s+[^>]*href=["\']https?://', card_html, re.IGNORECASE))
        if not has_clickable_source:
            missing += 1

    checked = len(fallback_matches)
    if missing:
        return False, f"{missing}/{checked} fallback comparison visuals lack clickable source/detail/image links"
    return True, f"All {checked} fallback comparison visuals include clickable source/detail/image links"


def check_critical(html: str) -> list:
    """Run all Critical checks. Returns list of (check_name, passed, evidence) tuples."""
    results = []

    # 1. Multiple image relationship stated
    has_image_relation = any(term in html for term in ["同一产品", "不同角度", "不同状态", "不同方案", "配件", "image relationship", "same product"])
    results.append(("Image relationship stated", has_image_relation,
                     "Found image relationship terms" if has_image_relation else "No image relationship language found"))

    # 2. Assumptions labeled
    has_assumptions = "假设" in html or "assumption" in html.lower()
    results.append(("Assumptions labeled", has_assumptions,
                     "Found assumption labeling" if has_assumptions else "No assumption labeling found"))

    # 3. Design score present
    has_score = bool(re.search(r"\d{1,3}\s*/\s*100", html))
    results.append(("Design score present", has_score,
                     "Found score in N/100 format" if has_score else "No score in N/100 format found"))

    # 4. Confidence level present
    has_confidence = any(term in html for term in ["High", "Medium", "Low", "高", "中", "低"])
    results.append(("Confidence level present", has_confidence,
                     "Found confidence label" if has_confidence else "No confidence label found"))

    # 5. Decision label present
    has_decision = any(term in html for term in ["Proceed", "Rework", "Hold", "通过", "返工", "暂缓", "推进", "重做方向", "修改后推进", "暂缓待IP", "暂缓待法务"])
    results.append(("Decision label present", has_decision,
                     "Found decision label" if has_decision else "No decision label found"))

    # 6. Evidence for scores (check for text near score rows)
    has_evidence = "evidence" in html.lower() or "证据" in html or bool(re.search(r"font-size:13px.*?color:var\(--muted\)", html))
    results.append(("Evidence for scores", has_evidence,
                     "Found evidence text pattern" if has_evidence else "No evidence text pattern found"))

    # 7. Feedback controls present
    has_feedback = all(btn in html for btn in ["满意", "一般", "不满意"])
    results.append(("Feedback controls present", has_feedback,
                     "All three feedback buttons found" if has_feedback else "Missing feedback buttons"))

    # 8. Patent risk is qualitative (not numeric)
    # Check that patent risk section doesn't contain standalone numeric scores
    patent_section_match = re.search(r"外观专利.*?</section>", html, re.DOTALL)
    patent_section = patent_section_match.group(0) if patent_section_match else ""
    has_numeric_patent = bool(re.search(r"专利.*?\d{1,3}\s*分", patent_section))
    results.append(("Patent risk is qualitative", not has_numeric_patent,
                     "No numeric patent score found" if not has_numeric_patent else "Found numeric patent score"))

    # 9. No forbidden legal terms
    found_forbidden = [term for term in FORBIDDEN_LEGAL_TERMS if term in html.lower()]
    results.append(("No forbidden legal language", len(found_forbidden) == 0,
                     "No forbidden legal terms" if not found_forbidden else f"Found: {found_forbidden}"))

    # 10. Version number present
    has_version = bool(re.search(r"v\d+\.\d+", html))
    results.append(("Version number present", has_version,
                     "Found version number" if has_version else "No version number found"))

    # 11. No process/audit content in user report
    found_process = [term for term in FORBIDDEN_IN_REPORT if term.lower() in html.lower()]
    # Filter out the meta note which mentions "IP/法务" — that's acceptable
    found_process = [t for t in found_process if t not in ["risk boundar"]]
    results.append(("No process content in report", len(found_process) == 0,
                     "No process content found" if not found_process else f"Found: {found_process}"))

    # 12. All required sections present
    missing_sections = [s for s in REQUIRED_SECTIONS if s not in html]
    results.append(("All required sections present", len(missing_sections) == 0,
                     "All sections found" if not missing_sections else f"Missing: {missing_sections}"))

    # 13. Recommendations present
    has_recommendations = "建议" in html or "recommendation" in html.lower()
    results.append(("Recommendations present", has_recommendations,
                     "Found recommendations" if has_recommendations else "No recommendations found"))

    # 14. Product image embedded
    has_product_img = "data:image/png;base64," in html or "data:image/jpeg;base64," in html or "data:image/webp;base64," in html or "data:image/svg+xml;base64," in html
    has_product_section = "产品图片" in html or "product-showcase" in html
    results.append(("Product image embedded", has_product_img and has_product_section,
                     "Found embedded product image in product section" if has_product_img and has_product_section else "Missing product image or product section"))

    # 15. Confirmed facts section present
    has_confirmed = "已确认信息" in html or "confirmed_facts" in html.lower()
    results.append(("Confirmed facts section present", has_confirmed,
                     "Found confirmed facts section" if has_confirmed else "Missing confirmed facts section"))

    # 16. Needs confirmation section present
    has_needs_conf = "待确认事项" in html or "needs_confirmation" in html.lower() or "待确认" in html
    results.append(("Needs confirmation section present", has_needs_conf,
                     "Found needs-confirmation section" if has_needs_conf else "Missing needs-confirmation section"))

    # 17. Comparison cards have visual elements
    compare_cards = re.findall(r'<div class="compare-card"[^>]*>(.*?)</div>\s*</div>', html, re.DOTALL)
    has_compare_visuals = True
    if compare_cards:
        for card in compare_cards:
            has_img = "<img" in card or "data:image" in card or "image unavailable" in card.lower()
            if not has_img:
                has_compare_visuals = False
                break
    else:
        # If no compare cards matched by regex, check if compare-card divs exist at all
        compare_card_count = html.count('class="compare-card"')
        if compare_card_count > 0:
            # Cards exist but regex didn't match — check if patent section has images
            patent_section = re.search(r"外观专利.*?</section>", html, re.DOTALL)
            if patent_section:
                has_compare_visuals = "<img" in patent_section.group(0) or "data:image" in patent_section.group(0)
            else:
                has_compare_visuals = True  # Assume OK if we can't extract section
        else:
            # No compare cards at all — check if patent section has any images
            patent_section = re.search(r"外观专利.*?</section>", html, re.DOTALL)
            if patent_section:
                has_compare_visuals = "<img" in patent_section.group(0) or "data:image" in patent_section.group(0)
    results.append(("Comparison cards have visual elements", has_compare_visuals,
                     "All comparison cards have visual elements" if has_compare_visuals else "Some comparison cards lack visual elements"))

    # 18. Fallback patent visuals include lookup/source links
    fallback_links_pass, fallback_links_evidence = fallback_visual_links_ok(html)
    results.append(("Fallback comparison visuals include lookup links", fallback_links_pass, fallback_links_evidence))

    # 19. Chinese labels check (v4.0.0 multi-agent)
    cn_ok, cn_evidence = check_chinese_labels(html)
    results.append(("Chinese labels in user-facing areas", cn_ok, cn_evidence))

    # 20. Image source statistics present (v4.1.0)
    has_image_stats = "image-stats" in html or "图片来源统计" in html or "realCount" in html or "svgCount" in html
    results.append(("Image source statistics present", has_image_stats,
                     "Found image source statistics" if has_image_stats else "Missing image source statistics"))

    # 21. No template residue (v4.1.0)
    found_residue = [pat for pat in TEMPLATE_RESIDUE_PATTERNS if pat in html]
    results.append(("No template residue in report", len(found_residue) == 0,
                     "No template residue found" if not found_residue else f"Found: {found_residue}"))

    # 22. Score progress bar uses --bar-w CSS variable (v5.0.0)
    has_bar_w = "--bar-w" in html
    results.append(("Score progress bar uses --bar-w variable", has_bar_w,
                     "Found --bar-w CSS variable" if has_bar_w else "Missing --bar-w CSS variable"))

    # 23. Score summary row present (v5.0.0)
    has_score_summary = "score-summary" in html or "score_summary" in html.lower()
    results.append(("Score summary row present", has_score_summary,
                     "Found score summary row" if has_score_summary else "Missing score summary row"))

    # 24. Findings grid uses non-symmetric layout (v5.0.0)
    has_findings_grid = "findings-grid" in html
    results.append(("Findings grid non-symmetric layout", has_findings_grid,
                     "Found findings-grid class" if has_findings_grid else "Missing findings-grid class"))

    return results


def check_recommended(html: str) -> list:
    """Run Recommended checks. Returns list of (check_name, passed, evidence) tuples."""
    results = []

    # Executive summary is concise (check for <li> count in summary section)
    summary_match = re.search(r"执行摘要.*?<ul[^>]*>(.*?)</ul>", html, re.DOTALL)
    if summary_match:
        li_count = len(re.findall(r"<li>", summary_match.group(1)))
        results.append(("Executive summary concise (≤3 bullets)", li_count <= 3,
                         f"Found {li_count} bullets" if li_count > 3 else f"Found {li_count} bullets (OK)"))
    else:
        results.append(("Executive summary concise (≤3 bullets)", False, "Executive summary section not found"))

    # Comparison thumbnails or placeholders
    has_comparison = "compare-card" in html or "compare-media" in html or "无比对对象" in html or "未评估" in html
    results.append(("Comparison thumbnails or placeholders", has_comparison,
                     "Found comparison cards or not-applicable note" if has_comparison else "No comparison handling found"))

    # File naming convention (check if <title> contains product name)
    has_title = bool(re.search(r"<title>.*?</title>", html))
    results.append(("Report has title", has_title,
                     "Found <title> tag" if has_title else "No <title> tag found"))

    # Print styles present
    has_print_css = "@media print" in html
    results.append(("Print optimization present", has_print_css,
                     "Found @media print styles" if has_print_css else "No print styles found"))

    # Dark mode support
    has_dark_mode = "prefers-color-scheme: dark" in html
    results.append(("Dark mode support", has_dark_mode,
                     "Found dark mode media query" if has_dark_mode else "No dark mode support found"))

    # localStorage for feedback
    has_localstorage = "localStorage" in html
    results.append(("Feedback localStorage persistence", has_localstorage,
                     "Found localStorage usage" if has_localstorage else "No localStorage usage found"))

    # Text conciseness: check that list items are not too long
    list_items = re.findall(r'<li[^>]*>(.*?)</li>', html, re.DOTALL)
    long_items = [item for item in list_items if len(item.strip()) > 300]
    results.append(("List items concise (≤300 chars)", len(long_items) <= 2,
                     f"Found {len(long_items)} long items" if long_items else "All list items concise"))

    # Comparison images are real or SVG (not just text placeholders)
    svg_count = html.count("data:image/svg+xml;base64,")
    real_img_count = html.count("data:image/png;base64,") + html.count("data:image/jpeg;base64,") + html.count("data:image/webp;base64,")
    has_any_comparison_img = (svg_count + real_img_count) > 0
    results.append(("Comparison images present (real or SVG)", has_any_comparison_img,
                     f"Found {real_img_count} real images, {svg_count} SVG schematics" if has_any_comparison_img else "No comparison images found"))

    # Real image cards have "真实图片" badge (v4.1.0)
    has_real_badge = "真实图片" in html or 'data-source-type="real"' in html
    results.append(("Real image cards labeled", has_real_badge,
                     "Found real image label" if has_real_badge else "No real image label found"))

    # SVG fallback cards have "示意图" label (v4.1.0)
    has_svg_badge = "示意图" in html or 'data-source-type="svg"' in html
    results.append(("SVG fallback cards labeled", has_svg_badge,
                     "Found SVG fallback label" if has_svg_badge else "No SVG fallback label found"))

    # v5.0.0: H2 auto-numbering present
    has_h2_counter = "counter-reset" in html and "h2-counter" in html
    results.append(("H2 auto-numbering present", has_h2_counter,
                     "Found H2 counter CSS" if has_h2_counter else "No H2 counter CSS found"))

    # v5.0.0: Brand review structured component
    has_brand_review = "brand-review" in html or "brand-dna" in html or "brand-verdict" in html
    results.append(("Brand review structured component", has_brand_review,
                     "Found structured brand review" if has_brand_review else "Missing structured brand review"))

    # v5.0.0: Patent risk badge separated from text
    has_patent_header = "patent-risk-header" in html
    results.append(("Patent risk badge separated", has_patent_header,
                     "Found patent-risk-header" if has_patent_header else "Missing patent-risk-header"))

    # v5.0.0: Comparison grid uses auto-fill
    has_auto_fill = "auto-fill" in html
    results.append(("Comparison grid auto-fill", has_auto_fill,
                     "Found auto-fill in grid" if has_auto_fill else "Missing auto-fill in grid"))

    return results


def check_chinese_labels(html: str) -> tuple:
    """Check that user-facing labels are in Chinese (v4.0.0 multi-agent check)."""
    # Check for English labels in user-visible areas
    english_label_patterns = [
        (r'>\s*(?:Proceed|Proceed with revisions|Rework direction|Hold for IP)\s*<', "English decision label found"),
        (r'>\s*(?:High|Medium|Low)\s*<', "English confidence label found"),
        (r'>\s*(?:Strong|Moderate|Weak|Contradictory)\s*<', "English brand consistency label found"),
    ]
    for pattern, msg in english_label_patterns:
        if re.search(pattern, html):
            return False, msg
    return True, "All user-facing labels are in Chinese"


def main():
    if len(sys.argv) < 2:
        print("Usage: python quality_check.py <report-html-path>", file=sys.stderr)
        print("       python quality_check.py --from-report-builder <agent-output-json> [report-html-path]", file=sys.stderr)
        sys.exit(1)

    # Report Builder mode
    if sys.argv[1] == "--from-report-builder":
        if len(sys.argv) < 3:
            print("Error: --from-report-builder requires a JSON file path", file=sys.stderr)
            sys.exit(1)
        agent_json_path = sys.argv[2]
        agent_data = json.loads(Path(agent_json_path).read_text(encoding="utf-8"))
        
        # Show the embedded self-check result
        qg = agent_data.get("quality_gate_result", {})
        print("=" * 60)
        print("Product Design Evaluator — Quality Gate Check (Report Builder Mode)")
        print("=" * 60)
        print(f"\nAgent self-check result:")
        critical = qg.get("critical_checks", {})
        recommended = qg.get("recommended_checks", {})
        print(f"  Critical: {critical.get('passed', 0)}/{critical.get('total', 0)} passed")
        print(f"  Recommended: {recommended.get('passed', 0)}/{recommended.get('total', 0)} passed")
        print(f"  Overall: {'PASS' if qg.get('overall_pass') else 'FAIL'}")
        
        # If HTML report path is also provided, run independent check
        if len(sys.argv) >= 4:
            report_path = sys.argv[3]
            print(f"\n--- INDEPENDENT VERIFICATION ---\n")
            html = load_html(report_path)
            
            # Run independent critical checks
            critical_results = check_critical(html)
            # Also check Chinese labels (v4.0.0)
            cn_ok, cn_evidence = check_chinese_labels(html)
            critical_results.append(("Chinese labels (v4.0.0)", cn_ok, cn_evidence))
            
            critical_pass = sum(1 for _, p, _ in critical_results if p)
            print(f"Independent Critical: {critical_pass}/{len(critical_results)} passed")
            
            for name, passed, evidence in critical_results:
                status = "✅ PASS" if passed else "❌ FAIL"
                print(f"  {status} — {name}: {evidence}")
            
            # Compare with agent self-check
            if critical_pass == len(critical_results) and qg.get("overall_pass"):
                print("\n✅ Independent verification matches agent self-check — PASS")
                sys.exit(0)
            else:
                print("\n⚠️  Independent verification differs from agent self-check")
                sys.exit(1)
        else:
            sys.exit(0 if qg.get("overall_pass") else 1)

    # Direct mode
    html_path = sys.argv[1]
    html = load_html(html_path)

    print("=" * 60)
    print("Product Design Evaluator — Quality Gate Check")
    print("=" * 60)
    print(f"\nReport: {html_path}\n")

    print("--- CRITICAL CHECKS ---\n")
    critical_results = check_critical(html)
    critical_pass = 0
    for name, passed, evidence in critical_results:
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"  {status} — {name}")
        print(f"         {evidence}")
        if passed:
            critical_pass += 1
    print(f"\n  Critical: {critical_pass}/{len(critical_results)} passed")

    print("\n--- RECOMMENDED CHECKS ---\n")
    recommended_results = check_recommended(html)
    recommended_pass = 0
    for name, passed, evidence in recommended_results:
        status = "✅ PASS" if passed else "⚠️  WARN"
        print(f"  {status} — {name}")
        print(f"         {evidence}")
        if passed:
            recommended_pass += 1
    print(f"\n  Recommended: {recommended_pass}/{len(recommended_results)} passed")

    print("\n" + "=" * 60)
    if critical_pass == len(critical_results):
        print("✅ ALL CRITICAL CHECKS PASSED — Report is ready for delivery.")
        sys.exit(0)
    else:
        failed = [name for name, passed, _ in critical_results if not passed]
        print(f"❌ {len(failed)} CRITICAL CHECK(S) FAILED:")
        for f in failed:
            print(f"   • {f}")
        print("\nRevise the report before delivery.")
        sys.exit(1)


if __name__ == "__main__":
    main()
