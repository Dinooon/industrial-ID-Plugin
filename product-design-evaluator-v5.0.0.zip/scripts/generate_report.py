#!/usr/bin/env python3
"""
generate_report.py — Automated report generation for Product Design Evaluator.

Reads a JSON data file and an HTML template, replaces all {{PLACEHOLDER}}
variables, and writes the final HTML report.

Supports two modes:
1. Direct mode (legacy): --data report_data.json --template ... --output ...
2. Agent JSON mode (v4.0.0): --from-agent-json agent_output.json --template ... --output ...

v5.0.0 changes:
  - Structured brand_language_review (dict with brand_dna_summary, brand_dna_points,
    product_diagnosis, critical_gaps, key_conclusion, annotation_images)
  - Weighted strengths/concerns (list of {point, weight} dicts)
  - Priority-tagged recommendations (list of {action, priority, rationale} dicts)
  - Score summary row with total
  - Multi-image product showcase grid
  - Unified progress bar CSS variable (--bar-w) with max-width cap
  - Patent risk badge/text separated
  - Backward compatible: falls back to string/legacy rendering for old data formats

Usage:
    python generate_report.py --data report_data.json --template assets/report-template.html --output report.html
    python generate_report.py --from-agent-json step4_report_builder.json --template assets/report-template.html --output report.html
"""

import argparse
import html as html_lib
import json
import re
import sys
from datetime import datetime
from pathlib import Path


# ─── Label translation map ──────────────────────────────────────────
label_map = {
    "Proceed": "推进",
    "Proceed with revisions": "修改后推进",
    "Rework direction": "重做方向",
    "Hold for IP/legal review": "暂缓待IP/法务审核",
    "High": "高",
    "Medium": "中等",
    "Low": "低",
    "Strong": "强",
    "Moderate": "中等",
    "Weak": "弱",
    "Contradictory": "矛盾",
}


def to_cn(value: str) -> str:
    """Translate English labels to Chinese using label_map."""
    if not value:
        return ""
    return label_map.get(value, value)


def load_template(template_path: str) -> str:
    """Load the HTML template file."""
    path = Path(template_path)
    if not path.exists():
        print(f"Error: Template file not found: {template_path}", file=sys.stderr)
        sys.exit(1)
    return path.read_text(encoding="utf-8")


def load_data(data_path: str) -> dict:
    """Load the JSON data file."""
    path = Path(data_path)
    if not path.exists():
        print(f"Error: Data file not found: {data_path}", file=sys.stderr)
        sys.exit(1)
    return json.loads(path.read_text(encoding="utf-8"))


def esc(value) -> str:
    """Escape small text values used inside generated card markup."""
    return html_lib.escape(str(value or ""), quote=True)


def build_executive_summary_items(bullets: list) -> str:
    """Convert list of strings into HTML <li> items."""
    if not bullets:
        return "<li>（无摘要内容）</li>"
    return "\n".join(f"<li>{b}</li>" for b in bullets)


# ─── v5.0.0: Weighted list items ────────────────────────────────────
def build_weighted_list_items(items: list) -> str:
    """Convert list of strings or {point, weight} dicts into HTML <li> items.

    Supports weight classes: critical, high, medium, normal, highlight.
    Falls back to plain <li> for string items.
    """
    if not items:
        return "<li>（无）</li>"
    html_parts = []
    for item in items:
        if isinstance(item, dict):
            point = item.get("point", "")
            weight = item.get("weight", "normal")
            if weight in ("critical", "high", "medium", "highlight"):
                html_parts.append(f'<li class="weight-{weight}">{esc(point)}</li>')
            else:
                html_parts.append(f"<li>{esc(point)}</li>")
        else:
            html_parts.append(f"<li>{esc(item)}</li>")
    return "\n".join(html_parts)


# ─── v5.0.0: Priority-tagged recommendation items ───────────────────
def build_priority_list_items(items: list) -> str:
    """Convert list of strings or {action, priority, rationale} dicts into HTML <li> items.

    Supports priority levels: P0 (critical), P1 (important), P2 (normal).
    Falls back to plain <li> for string items.
    """
    if not items:
        return "<li>（无建议）</li>"
    html_parts = []
    for item in items:
        if isinstance(item, dict):
            action = item.get("action", "")
            priority = item.get("priority", "P2")
            rationale = item.get("rationale", "")
            priority_lower = priority.lower()
            tag_html = f'<span class="rec-priority-tag">{esc(priority)}</span>' if priority in ("P0", "P1", "P2") else ""
            rationale_html = f'<span class="rec-rationale">{esc(rationale)}</span>' if rationale else ""
            if priority_lower in ("p0", "p1", "p2"):
                html_parts.append(f'<li class="rec-{priority_lower}">{tag_html}{esc(action)}{rationale_html}</li>')
            else:
                html_parts.append(f"<li>{esc(action)}</li>")
        else:
            html_parts.append(f"<li>{esc(item)}</li>")
    return "\n".join(html_parts)


# ─── v5.0.0: Structured brand review HTML builder ───────────────────
def build_brand_review_html(review_data, brand_fit_label: str, brand_reason: str) -> str:
    """Build structured HTML for the brand language review section.

    Supports two modes:
    1. Structured (dict): renders DNA points, diagnosis, gap cards, conclusion bar
    2. Legacy (string): renders as single <p> (backward compatible)
    """
    # Legacy fallback: if review_data is a string, render as plain paragraph
    if isinstance(review_data, str):
        parts = []
        parts.append(f'<div class="brand-review"><p>{esc(review_data)}</p>')
        if brand_fit_label:
            parts.append(f'<p>{brand_fit_label}</p>')
        if brand_reason:
            parts.append(f'<p>{esc(brand_reason)}</p>')
        parts.append('</div>')
        return "\n".join(parts)

    # Structured mode
    if not isinstance(review_data, dict):
        return f'<div class="brand-review"><p>{esc(str(review_data))}</p></div>'

    html_parts = ['<div class="brand-review">']

    # Conclusion bar (verdict + key conclusion)
    key_conclusion = review_data.get("key_conclusion", "")
    html_parts.append('<div class="brand-verdict-bar">')
    if brand_fit_label:
        html_parts.append(brand_fit_label)
    if key_conclusion:
        html_parts.append(f'<span class="brand-conclusion">{esc(key_conclusion)}</span>')
    html_parts.append('</div>')

    # Brand DNA section
    dna_summary = review_data.get("brand_dna_summary", "")
    dna_points = review_data.get("brand_dna_points", [])
    if dna_summary or dna_points:
        html_parts.append('<div class="brand-dna-section">')
        html_parts.append('<h3 class="section-subtitle">品牌设计DNA</h3>')
        if dna_summary:
            html_parts.append(f'<p class="brand-dna-summary">{esc(dna_summary)}</p>')
        if dna_points:
            if isinstance(dna_points, list):
                points_html = "".join(f"<li>{esc(p)}</li>" for p in dna_points)
            else:
                points_html = f"<li>{esc(str(dna_points))}</li>"
            html_parts.append(f'<ul class="brand-dna-list">{points_html}</ul>')
        html_parts.append('</div>')

    # Product diagnosis section
    diagnosis = review_data.get("product_diagnosis", "")
    critical_gaps = review_data.get("critical_gaps", [])
    if diagnosis or critical_gaps:
        html_parts.append('<div class="brand-diagnosis-section">')
        html_parts.append('<h3 class="section-subtitle">产品诊断</h3>')
        if diagnosis:
            html_parts.append(f'<p class="brand-diagnosis-text">{esc(diagnosis)}</p>')
        if critical_gaps:
            if isinstance(critical_gaps, list):
                gap_cards_html = []
                for gap in critical_gaps:
                    if isinstance(gap, dict):
                        issue = gap.get("issue", "")
                        severity = gap.get("severity", "low")
                        gap_cards_html.append(
                            f'<div class="gap-card severity-{esc(severity)}">{esc(issue)}</div>'
                        )
                    else:
                        gap_cards_html.append(f'<div class="gap-card severity-low">{esc(str(gap))}</div>')
                html_parts.append(f'<div class="gap-cards">{"".join(gap_cards_html)}</div>')
            html_parts.append('</div>')

    # Annotation images (optional, T-02)
    annotation_images = review_data.get("annotation_images", [])
    if annotation_images and isinstance(annotation_images, list):
        html_parts.append('<div class="brand-annotation-grid">')
        for img in annotation_images:
            if isinstance(img, dict):
                img_src = img.get("image", "")
                caption = img.get("caption", "")
                if img_src:
                    html_parts.append(
                        f'<div class="annotation-item">'
                        f'<img src="{esc(img_src)}" alt="{esc(caption)}">'
                        f'<div class="caption">{esc(caption)}</div>'
                        f'</div>'
                    )
        html_parts.append('</div>')

    html_parts.append('</div>')
    return "\n".join(html_parts)


# ─── v5.0.0: Score rows with unified --bar-w CSS variable ──────────
def build_score_rows(scoring_rows: list) -> str:
    """Build HTML for scoring table rows with progress bars.

    Uses --bar-w CSS variable (unified with template CSS).
    Caps percentage at 100% to prevent overflow (P-07 fix).
    """
    if not scoring_rows:
        return "<p>（无评分数据）</p>"
    html_parts = []
    for row in scoring_rows:
        dimension = row.get("dimension", "")
        score = row.get("score", 0)
        max_score = row.get("max", 100)
        evidence = row.get("evidence", "")
        percentage = (score / max_score * 100) if max_score > 0 else 0
        # P-07 fix: cap at 100% to prevent overflow
        percentage = min(percentage, 100)
        html_parts.append(
            f'<div class="score-row">'
            f'<div><strong>{esc(dimension)}</strong></div>'
            f'<div><div class="bar"><span style="--bar-w: {percentage:.0f}%"></span></div>'
            f'<p class="score-evidence">{esc(evidence)}</p></div>'
            f'<div style="text-align:right; font-weight:700;">{score}/{max_score}</div>'
            f'</div>'
        )
    return "\n".join(html_parts)


# ─── v5.0.0: Score summary row ──────────────────────────────────────
def build_score_summary(design_score: str) -> str:
    """Build HTML for the score summary row at the bottom of the scoring section."""
    if not design_score or design_score == "—":
        return ""
    return (
        f'<div class="score-summary">'
        f'<span class="label">总分</span>'
        f'<span class="value">{esc(design_score)}</span>'
        f'</div>'
    )


# ─── v5.0.0: Multi-image product showcase grid ──────────────────────
def build_product_images_grid(data: dict) -> str:
    """Build HTML for the product images section.

    Supports two modes:
    1. Multi-image: data['product_images'] is a list of {path/caption/relationship}
    2. Single image (legacy): data['product_image'] is a base64 string
    """
    product_images = data.get("product_images", [])
    input_images = data.get("input_images", [])

    # Mode 1: product_images list
    if product_images and isinstance(product_images, list) and len(product_images) > 1:
        html_parts = ['<div class="product-images-grid">']
        for img in product_images:
            if isinstance(img, dict):
                src = img.get("path", "") or img.get("image", "") or img.get("data_uri", "")
                caption = img.get("caption", "")
                if src:
                    alt = esc(caption) if caption else "待评审产品图片"
                    html_parts.append(f'<img src="{esc(src)}" alt="{alt}">')
            elif isinstance(img, str) and img:
                html_parts.append(f'<img src="{esc(img)}" alt="待评审产品图片">')
        html_parts.append('</div>')
        return "\n".join(html_parts)

    # Mode 2: input_images list (from report-rendering-handoff schema)
    if input_images and isinstance(input_images, list) and len(input_images) > 1:
        html_parts = ['<div class="product-images-grid">']
        for img in input_images:
            if isinstance(img, dict):
                src = img.get("path", "") or img.get("image", "") or img.get("data_uri", "")
                caption = img.get("caption", "")
                if src:
                    alt = esc(caption) if caption else "待评审产品图片"
                    html_parts.append(f'<img src="{esc(src)}" alt="{alt}">')
            elif isinstance(img, str) and img:
                html_parts.append(f'<img src="{esc(img)}" alt="待评审产品图片">')
        html_parts.append('</div>')
        return "\n".join(html_parts)

    # Mode 3: single image (legacy)
    product_image = data.get("product_image", "")
    if product_image:
        return f'<img src="{esc(product_image)}" alt="待评审产品图片">'

    return '<p style="padding:20px;color:var(--muted);">（未提供产品图片）</p>'


# ─── v5.0.0: Brand fit badge builder ────────────────────────────────
def build_brand_fit_badge(brand_fit_label: str) -> str:
    """Build the complete badge HTML for brand fit.

    Returns a self-contained <span class="badge ..."> element.
    This replaces the old pattern of nesting badge inside another badge.
    """
    if not brand_fit_label:
        return ""
    # If already an HTML element, return as-is
    if brand_fit_label.strip().startswith("<"):
        return brand_fit_label
    # Otherwise, wrap in appropriate badge class
    label_cn = to_cn(brand_fit_label)
    # Determine badge class based on label
    if label_cn in ("矛盾", "弱"):
        return f'<span class="badge risk">品牌一致性：{label_cn}</span>'
    elif label_cn == "中等":
        return f'<span class="badge warn">品牌一致性：{label_cn}</span>'
    else:
        return f'<span class="badge ok">品牌一致性：{label_cn}</span>'


# ─── Comparison cards builder (updated for v5.0.0) ──────────────────
def build_comparison_cards(cards: list) -> str:
    """Build HTML for patent comparison cards."""
    if not cards:
        return "<p>（无比对对象）</p>"
    html_parts = []
    for i, card in enumerate(cards, 1):
        name = card.get("object_name", f"Comparison Object {i}")
        source = card.get("source", "")
        thumbnail = card.get("thumbnail")
        visual_type = card.get("visual_type", "")
        comparison_url = card.get("comparison_url") or card.get("source_url") or card.get("url") or ""
        image_reference_url = card.get("image_reference_url") or ""
        similar = card.get("similar_points", [])
        different = card.get("different_points", [])
        rationale = card.get("risk_rationale", "")

        is_fallback = (
            visual_type in {"svg_schematic", "placeholder"}
            or (isinstance(thumbnail, str) and thumbnail.startswith("data:image/svg+xml"))
            or not thumbnail
        )

        source_type = "svg" if is_fallback else "real"
        source_note = card.get("source_note", "")
        if not source_note:
            source_note = "已抓取真实图片并转为 base64。" if not is_fallback else "未能下载真实图片，已使用示意图；请点击来源链接查看公开实物/专利图片。"
        badge_text = "真实图片" if not is_fallback else "示意图"

        media_html = f'<img src="{esc(thumbnail)}" alt="{esc(name)}">' if thumbnail else "image unavailable"
        link_html = []
        if comparison_url:
            link_html.append(f'<a href="{esc(comparison_url)}" target="_blank" rel="noopener">查看公开对象</a>')
        if image_reference_url and image_reference_url != comparison_url:
            link_html.append(f'<a href="{esc(image_reference_url)}" target="_blank" rel="noopener">查看图片来源</a>')
        if is_fallback and not link_html:
            link_html.append('<span class="source-missing">缺少可跳转来源链接</span>')
        actions_html = f'<div class="compare-actions">{"".join(link_html)}</div>' if link_html else ""

        # v5.0.0: Add compact-list class to lists + use ✓/✗ markers
        similar_html = "".join(f"<li>✓ {esc(s)}</li>" for s in similar) if similar else "<li>（无）</li>"
        different_html = "".join(f"<li>✗ {esc(d)}</li>" for d in different) if different else "<li>（无）</li>"

        html_parts.append(
            f'<div class="compare-card" data-source-type="{source_type}">'
            f'<div class="compare-media">{media_html}</div>'
            f'<div class="compare-body">'
            f'<span class="source-badge">{badge_text}</span>'
            f'<h3>{esc(name)}</h3>'
            f'<p class="source-note-text">{esc(source_note)}</p>'
            f'<p><strong>来源：</strong>{esc(source)}</p>'
            f'{actions_html}'
            f'<p><strong>相似点：</strong></p><ul class="compact-list">{similar_html}</ul>'
            f'<p><strong>差异点：</strong></p><ul class="compact-list">{different_html}</ul>'
            f'<p><strong>风险原因：</strong>{esc(rationale)}</p>'
            f'</div></div>'
        )
    return "\n".join(html_parts)


def build_image_stats(cards: list) -> str:
    """Build HTML for image source statistics (v4.1.0)."""
    if not cards:
        return '<p>图片来源统计：无比对对象</p>'
    real_count = 0
    svg_count = 0
    for card in cards:
        visual_type = card.get("visual_type", "")
        thumbnail = card.get("thumbnail", "")
        is_fallback = (
            visual_type in {"svg_schematic", "placeholder"}
            or (isinstance(thumbnail, str) and thumbnail.startswith("data:image/svg+xml"))
            or not thumbnail
        )
        if is_fallback:
            svg_count += 1
        else:
            real_count += 1
    return (
        f'<p>图片来源统计：<strong>{real_count}</strong> 张真实图片，'
        f'<strong>{svg_count}</strong> 张示意图</p>'
    )


def generate_report(data: dict, template: str) -> str:
    """Replace all placeholders in the template with data values."""
    # Validate scoring data before generating
    try:
        from validate_scores import validate_scores
        if data.get("scoring_rows"):
            errors = validate_scores(data)
            if errors:
                print("Score validation errors:", file=sys.stderr)
                for e in errors:
                    print(f"  - {e}", file=sys.stderr)
                sys.exit(1)
    except ImportError:
        pass

    # v5.0.0: Build brand fit badge (self-contained, no double nesting)
    raw_brand_fit = data.get("brand_language_score", "")
    brand_fit_badge = build_brand_fit_badge(raw_brand_fit)

    # v5.0.0: Build structured brand review HTML
    brand_review_data = data.get("brand_language_review", "")
    brand_reason = data.get("brand_language_reason", "")
    brand_review_html = build_brand_review_html(brand_review_data, brand_fit_badge, brand_reason)

    # v5.0.0: Build product images grid (multi-image or legacy single)
    product_images_html = build_product_images_grid(data)

    # v5.0.0: Build score summary
    design_score = data.get("design_score", "—")
    score_summary_html = build_score_summary(design_score)

    replacements = {
        "{{PROJECT_NAME}}": data.get("project_title", "未命名产品"),
        "{{DATE}}": data.get("date", datetime.now().strftime("%Y-%m-%d")),
        "{{CATEGORY}}": data.get("product_category", "未确认"),
        "{{CONFIDENCE}}": to_cn(data.get("confidence", "Medium")),
        "{{FINAL_DECISION}}": to_cn(data.get("verdict", "")),
        "{{NEXT_ACTION}}": data.get("next_action", ""),
        "{{DESIGN_SCORE}}": design_score,
        "{{BRAND_FIT}}": to_cn(raw_brand_fit),
        "{{PATENT_RISK_LEVEL}}": data.get("patent_risk_level", "未评估"),
        "{{ACTION_LABEL}}": to_cn(data.get("decision_label", "")),
        "{{REPORT_VERSION}}": data.get("version", "v1.0"),
        "{{EXECUTIVE_SUMMARY_ITEMS}}": build_executive_summary_items(data.get("executive_summary", [])),
        "{{IMAGE_RELATION_SUMMARY}}": data.get("image_relationship", "未确认"),
        "{{ASSUMPTION_SUMMARY}}": "; ".join(data.get("assumptions", ["无"])) if isinstance(data.get("assumptions"), list) else str(data.get("assumptions", "无")),
        # v5.0.0: Weighted list items
        "{{STRENGTH_ITEMS}}": build_weighted_list_items(data.get("strengths", [])),
        "{{CONCERN_ITEMS}}": build_weighted_list_items(data.get("concerns", [])),
        # v5.0.0: Structured brand review (full HTML, replaces both REVIEW and FIT_LABEL)
        "{{BRAND_LANGUAGE_REVIEW}}": brand_review_html,
        "{{BRAND_FIT_LABEL}}": brand_fit_badge,
        "{{BRAND_LANGUAGE_REASON}}": brand_reason,
        # v5.0.0: Score rows with --bar-w + summary
        "{{SCORE_ROWS}}": build_score_rows(data.get("scoring_rows", [])),
        "{{SCORE_SUMMARY}}": score_summary_html,
        "{{PATENT_RISK_SUMMARY}}": data.get("patent_risk_summary", ""),
        "{{PATENT_COMPARISON_CARDS}}": build_comparison_cards(data.get("patent_comparison_cards", [])),
        # v5.0.0: Priority-tagged recommendations
        "{{RECOMMENDATION_ITEMS}}": build_priority_list_items(data.get("recommendations", [])),
        "{{NEXT_REVIEW_MATERIALS}}": "; ".join(data.get("next_round_materials", ["无"])) if isinstance(data.get("next_round_materials"), list) else str(data.get("next_round_materials", "无")),
        # v5.0.0: Multi-image grid
        "{{PRODUCT_IMAGE}}": data.get("product_image", ""),
        "{{PRODUCT_IMAGES_GRID}}": product_images_html,
        "{{IMAGE_SOURCE_CAPTION}}": data.get("image_source_caption", "待评审产品图片"),
        "{{CONFIRMED_FACTS_ITEMS}}": build_weighted_list_items(data.get("confirmed_facts", [])),
        "{{NEEDS_CONFIRMATION_ITEMS}}": build_weighted_list_items(data.get("needs_confirmation", [])),
        "{{IMAGE_STATS}}": build_image_stats(data.get("patent_comparison_cards", [])),
    }

    result = template
    for placeholder, value in replacements.items():
        result = result.replace(placeholder, str(value))

    # Remove template variable guide comments (v4.1.0)
    result = re.sub(r'<!--\s*TEMPLATE_VAR_GUIDE_START.*?TEMPLATE_VAR_GUIDE_END\s*-->', '', result, flags=re.DOTALL)
    result = re.sub(r'<!--\s*Template Variable Guide:.*?-->', '', result, flags=re.DOTALL)
    result = re.sub(r'<!--\s*Template version:.*?-->', '', result, flags=re.DOTALL)

    # Warn about unreplaced placeholders
    remaining = re.findall(r"\{\{[A-Z_]+\}\}", result)
    if remaining:
        print(f"Warning: {len(set(remaining))} unreplaced placeholders: {', '.join(set(remaining))}", file=sys.stderr)

    return result


def convert_agent_output_to_report_data(agent_output: dict) -> dict:
    """Convert Report Builder Agent output JSON to Frozen Handoff Pack format.

    v5.0.0: Passes through structured brand_language_review, weighted strengths/concerns,
    and priority-tagged recommendations when available from the agent output.
    """
    report = agent_output.get("report", {})
    scoring_breakdown = agent_output.get("scoring_breakdown", [])

    # Convert scoring breakdown to scoring_rows format
    scoring_rows = []
    for item in scoring_breakdown:
        scoring_rows.append({
            "dimension": item.get("dimension", ""),
            "score": item.get("score", 0),
            "max": item.get("max", 10),
            "evidence": item.get("evidence", ""),
        })

    # v5.0.0: Pass through structured brand review if available
    brand_review = report.get("brand_language_review", "")

    # v5.0.0: Build product_images from input if available
    product_images = agent_output.get("input_images", report.get("product_images", []))
    product_image = report.get("product_image", "")

    return {
        "project_title": report.get("product_name", "未命名产品"),
        "date": report.get("date", datetime.now().strftime("%Y-%m-%d")),
        "product_category": report.get("category", "未确认"),
        "confidence": report.get("confidence", "中等"),
        "verdict": report.get("verdict", ""),
        "next_action": report.get("next_action", ""),
        "design_score": report.get("total_score", "—"),
        "brand_language_score": report.get("brand_consistency", "—"),
        "patent_risk_level": report.get("patent_risk", "未评估"),
        "decision_label": report.get("verdict", ""),
        "version": report.get("version", "v1.0"),
        "executive_summary": agent_output.get("executive_summary", []),
        "image_relationship": report.get("image_relationship", "未确认"),
        "assumptions": report.get("assumptions", ["无"]),
        "strengths": report.get("strengths", []),
        "concerns": report.get("concerns", []),
        "brand_language_review": brand_review,
        "brand_language_reason": report.get("brand_language_reason", ""),
        "scoring_rows": scoring_rows,
        "patent_risk_summary": report.get("patent_risk_summary", ""),
        "patent_comparison_cards": report.get("patent_comparison_cards", []),
        "recommendations": agent_output.get("recommendations", []),
        "next_round_materials": report.get("next_round_materials", ["无"]),
        "product_image": product_image,
        "product_images": product_images,
        "image_source_caption": report.get("image_source_caption", "待评审产品图片"),
        "confirmed_facts": report.get("confirmed_facts", []),
        "needs_confirmation": report.get("needs_confirmation", []),
    }


def main():
    parser = argparse.ArgumentParser(description="Generate HTML report from JSON data and template.")
    parser.add_argument("--data", help="Path to JSON data file (Frozen Handoff Pack format)")
    parser.add_argument("--from-agent-json", help="Path to Report Builder Agent output JSON (v4.0.0 agent mode)")
    parser.add_argument("--template", default="assets/report-template.html", help="Path to HTML template file")
    parser.add_argument("--output", required=True, help="Output HTML file path")
    args = parser.parse_args()

    if not args.data and not args.from_agent_json:
        print("Error: Either --data or --from-agent-json must be provided", file=sys.stderr)
        sys.exit(1)

    template = load_template(args.template)

    if args.from_agent_json:
        agent_output = load_data(args.from_agent_json)
        data = convert_agent_output_to_report_data(agent_output)
        print(f"Loaded agent JSON output, converted to report data format.", file=sys.stderr)
    else:
        data = load_data(args.data)

    html = generate_report(data, template)

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(html, encoding="utf-8")
    print(f"Report generated: {args.output}")


if __name__ == "__main__":
    main()
