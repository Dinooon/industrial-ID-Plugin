#!/usr/bin/env python3
"""Generate HTML report from report data JSON and template."""
import json, html
from pathlib import Path

SKILL_DIR = Path("/home/ubuntu/skill-analysis/product-design-evaluator-improved")
TEMPLATE_PATH = SKILL_DIR / "assets" / "report-template.html"
DATA_PATH = SKILL_DIR / "reports" / "report_data_smartwatch-tws-apple-language.json"
OUTPUT_PATH = SKILL_DIR / "reports" / "design-review_smartwatch-tws-apple-language_2026-07-08.html"

# Load data
data = json.loads(DATA_PATH.read_text(encoding="utf-8"))
template = TEMPLATE_PATH.read_text(encoding="utf-8")

# Build HTML fragments
def li_list(items):
    return "\n".join(f"<li>{html.escape(str(item))}</li>" for item in items)

executive_summary_items = li_list(data["executive_summary"])
confirmed_facts_items = li_list(data["confirmed_facts"])
needs_confirmation_items = li_list(data["needs_confirmation"])
strength_items = li_list(data["strengths"])
concern_items = li_list(data["concerns"])
recommendation_items = "\n".join(f"<li>{html.escape(str(item))}</li>" for item in data["recommendations"])

# Scoring rows
score_rows_html = ""
for row in data["scoring_rows"]:
    pct = int(row["score"] / row["max"] * 100)
    color = "#137333" if pct >= 70 else ("#9a6700" if pct >= 50 else "#b42318")
    bar_width = f"{pct}%"
    score_rows_html += f'''      <div class="score-row">
        <div>{html.escape(row["dimension"])}</div>
        <div>
          <div style="margin-bottom:4px;">{html.escape(row["evidence"])}</div>
          <div class="bar"><span style="width:{bar_width};background:{color};"></span></div>
        </div>
        <div style="text-align:right;font-weight:700;">{row["score"]}/{row["max"]}</div>
      </div>
'''

# Patent comparison cards
comparison_cards_html = ""
for card in data["patent_comparison_cards"]:
    visual_note = ""
    if card.get("visual_type") == "svg_schematic":
        visual_note = '<p class="image-source-note" style="margin-top:4px;">示意图基于公开信息绘制，建议后续补充实物图片进行精确比对。</p>'
    
    similar_html = "".join(f"<li>{html.escape(s)}</li>" for s in card["similar_points"])
    different_html = "".join(f"<li>{html.escape(d)}</li>" for d in card["different_points"])
    
    comparison_cards_html += f'''      <div class="compare-card">
        <div class="compare-media">
          <img src="{card["image"]}" alt="{html.escape(card["name"])}示意图">
        </div>
        <div class="compare-body">
          <h3>{html.escape(card["name"])}</h3>
          {visual_note}
          <div class="compare-actions">
            <a href="{html.escape(card["comparison_url"])}" target="_blank" rel="noopener">查看产品页 ↗</a>
            <a href="{html.escape(card["image_reference_url"])}" target="_blank" rel="noopener">图片来源 ↗</a>
          </div>
          <p><strong>相似点：</strong></p>
          <ul class="compact-list">{similar_html}</ul>
          <p style="margin-top:8px;"><strong>差异点：</strong></p>
          <ul class="compact-list">{different_html}</ul>
          <p style="margin-top:8px;color:var(--muted);font-size:12px;">{html.escape(card["risk_reason"])}</p>
        </div>
      </div>
'''

# Assumptions summary
assumption_summary = "；".join(data["assumptions"])

# Next review materials
next_materials = "；".join(data["next_round_materials"])

# Replace all template variables
replacements = {
    "{{PROJECT_NAME}}": html.escape(data["project_title"]),
    "{{DATE}}": data["date"],
    "{{CATEGORY}}": html.escape(data["product_category"]),
    "{{CONFIDENCE}}": data["confidence"],
    "{{FINAL_DECISION}}": data["verdict"],
    "{{NEXT_ACTION}}": html.escape(data["next_action"]),
    "{{DESIGN_SCORE}}": data["design_score"] + "/100",
    "{{BRAND_FIT}}": data["brand_language_score"],
    "{{PATENT_RISK_LEVEL}}": data["patent_risk_level"],
    "{{ACTION_LABEL}}": data["decision_label"],
    "{{EXECUTIVE_SUMMARY_ITEMS}}": executive_summary_items,
    "{{IMAGE_RELATION_SUMMARY}}": html.escape(data["image_relationship"]),
    "{{ASSUMPTION_SUMMARY}}": html.escape(assumption_summary),
    "{{STRENGTH_ITEMS}}": strength_items,
    "{{CONCERN_ITEMS}}": concern_items,
    "{{BRAND_LANGUAGE_REVIEW}}": html.escape(data["brand_language_review"]),
    "{{BRAND_FIT_LABEL}}": data["brand_language_score"],
    "{{BRAND_LANGUAGE_REASON}}": html.escape(data["brand_language_reason"]),
    "{{SCORE_ROWS}}": score_rows_html,
    "{{PATENT_RISK_SUMMARY}}": html.escape(data["patent_risk_summary"]),
    "{{PATENT_COMPARISON_CARDS}}": comparison_cards_html,
    "{{RECOMMENDATION_ITEMS}}": recommendation_items,
    "{{NEXT_REVIEW_MATERIALS}}": html.escape(next_materials),
    "{{REPORT_VERSION}}": data["version"],
    "{{PRODUCT_IMAGE}}": data["product_image"],
    "{{CONFIRMED_FACTS_ITEMS}}": confirmed_facts_items,
    "{{NEEDS_CONFIRMATION_ITEMS}}": needs_confirmation_items,
    "{{IMAGE_SOURCE_CAPTION}}": html.escape(data["image_source_caption"]),
}

output = template
for key, value in replacements.items():
    output = output.replace(key, value)

# Add extra product images section (all 3 images)
extra_images_html = '''
    <h2>全部产品图片</h2>
    <section class="panel">
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:14px;">
'''
captions = [
    "图片1：智能手表背部（PPG传感器区域）",
    "图片2：TWS耳机充电盒（正面颗粒纹理按键）",
    "图片3：智能手表正面（卡通击掌UI壁纸）"
]
for i, img_data in enumerate(data["product_images"]):
    extra_images_html += f'        <div class="compare-card"><div class="compare-media"><img src="{img_data}" alt="{captions[i]}" style="object-fit:cover;"></div><div class="compare-body"><p style="text-align:center;font-size:13px;color:var(--muted);">{captions[i]}</p></div></div>\n'
extra_images_html += '''      </div>
    </section>
'''

# Insert extra images after the single product image section
insert_marker = '    <h2>执行摘要</h2>'
output = output.replace(insert_marker, extra_images_html + "\n" + insert_marker)

OUTPUT_PATH.write_text(output, encoding="utf-8")
print(f"Report generated: {OUTPUT_PATH}")
print(f"File size: {len(output.encode('utf-8'))} bytes")

# Verify no unreplaced placeholders remain
import re
unreplaced = re.findall(r'\{\{[A-Z_]+\}\}', output)
if unreplaced:
    print(f"WARNING: Unreplaced placeholders: {set(unreplaced)}")
else:
    print("All placeholders replaced successfully.")

# Verify no English labels in key fields
english_check_terms = ["Proceed", "Rework direction", "Hold for IP", "Contradictory", "Strong", "Moderate", "Weak", "High", "Medium", "Low"]
found_english = []
for term in english_check_terms:
    if term in output:
        # Check if it's in a context where it should be Chinese
        found_english.append(term)
if found_english:
    print(f"WARNING: English terms found: {found_english}")
else:
    print("No problematic English labels found.")
