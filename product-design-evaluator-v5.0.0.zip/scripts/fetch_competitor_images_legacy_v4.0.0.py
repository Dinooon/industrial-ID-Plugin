#!/usr/bin/env python3
"""
fetch_competitor_images.py — Automated competitor image acquisition for patent/design comparison.

Attempts to download real competitor product images from public sources.
Falls back to SVG schematic generation when downloads fail.
Each result includes visual_type (real/svg_schematic) and comparison_url fields.

Usage:
    python fetch_competitor_images.py --category robot-vacuum --output-dir compare_images/ --format base64

Output:
    A JSON file (competitor_images.json) containing base64-encoded image data URIs
    for each comparison object, with visual_type and comparison_url metadata.
"""

import argparse
import base64
import json
import os
import subprocess
import sys
from pathlib import Path


# SVG schematic templates for common product types
SVG_TEMPLATES = {
    "round_robot_no_lidar": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 280" width="300" height="280">
  <defs><radialGradient id="g" cx="50%" cy="40%"><stop offset="0%" stop-color="#2c2c2c" stop-opacity="0.95"/><stop offset="100%" stop-color="#3a3a3a"/></radialGradient></defs>
  <rect width="300" height="280" fill="#f5f5f5"/>
  <circle cx="150" cy="130" r="100" fill="url(#g)" stroke="#555" stroke-width="2"/>
  <circle cx="150" cy="130" r="75" fill="none" stroke="#555" stroke-width="1.5" opacity="0.5"/>
  <circle cx="150" cy="105" r="22" fill="#1a1a1a" stroke="#444" stroke-width="1"/>
  <circle cx="150" cy="105" r="14" fill="#0a0a0a"/>
  <circle cx="150" cy="185" r="8" fill="#555" stroke="#777" stroke-width="1"/>
  <text x="150" y="260" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="#888">{label}</text>
</svg>''',

    "round_robot_with_lidar": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 280" width="300" height="280">
  <defs><radialGradient id="g" cx="50%" cy="40%"><stop offset="0%" stop-color="#333" stop-opacity="0.95"/><stop offset="100%" stop-color="#444"/></radialGradient></defs>
  <rect width="300" height="280" fill="#f5f5f5"/>
  <circle cx="150" cy="135" r="100" fill="url(#g)" stroke="#555" stroke-width="2"/>
  <circle cx="150" cy="100" r="30" fill="#222" stroke="#555" stroke-width="1.5"/>
  <circle cx="150" cy="100" r="20" fill="#111"/>
  <circle cx="150" cy="100" r="12" fill="#333" stroke="#555" stroke-width="1"/>
  <circle cx="150" cy="195" r="8" fill="#555" stroke="#777" stroke-width="1"/>
  <text x="150" y="260" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="#888">{label}</text>
</svg>''',

    "d_shape_robot": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 280" width="300" height="280">
  <defs><radialGradient id="g" cx="50%" cy="40%"><stop offset="0%" stop-color="#2a2a2a" stop-opacity="0.95"/><stop offset="100%" stop-color="#3a3a3a"/></radialGradient></defs>
  <rect width="300" height="280" fill="#f5f5f5"/>
  <path d="M 100 80 L 200 80 Q 250 80 250 130 Q 250 200 150 220 Q 50 200 50 130 Q 50 80 100 80 Z" fill="url(#g)" stroke="#555" stroke-width="2"/>
  <circle cx="150" cy="120" r="28" fill="#222" stroke="#555" stroke-width="1.5"/>
  <circle cx="150" cy="120" r="18" fill="#111"/>
  <text x="150" y="260" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="#888">{label}</text>
</svg>''',

    "base_station": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 280" width="300" height="280">
  <rect width="300" height="280" fill="#f5f5f5"/>
  <rect x="80" y="50" width="140" height="200" rx="20" ry="20" fill="#454545" stroke="#555" stroke-width="2"/>
  <rect x="90" y="60" width="120" height="60" rx="10" fill="#3a3a3a" stroke="#555" stroke-width="1"/>
  <rect x="115" y="180" width="70" height="30" rx="3" fill="#1a1a1a" stroke="#333" stroke-width="1"/>
  <rect x="120" y="186" width="60" height="18" rx="2" fill="#0a1520"/>
  <rect x="105" y="220" width="90" height="25" rx="5" fill="#1a1a1a" stroke="#333" stroke-width="1"/>
  <text x="150" y="265" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="#888">{label}</text>
</svg>''',

    "stick_vacuum": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 280" width="300" height="280">
  <rect width="300" height="280" fill="#f5f5f5"/>
  <rect x="130" y="30" width="40" height="60" rx="15" fill="#3a3a3a" stroke="#555" stroke-width="2"/>
  <rect x="140" y="85" width="20" height="120" fill="#555" stroke="#666" stroke-width="1"/>
  <ellipse cx="150" cy="225" rx="50" ry="20" fill="#333" stroke="#555" stroke-width="2"/>
  <text x="150" y="265" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="#888">{label}</text>
</svg>''',

    "phone": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 280" width="300" height="280">
  <rect width="300" height="280" fill="#f5f5f5"/>
  <rect x="100" y="40" width="100" height="200" rx="18" ry="18" fill="#3a3a3a" stroke="#555" stroke-width="2"/>
  <rect x="108" y="48" width="84" height="160" rx="6" fill="#1a1a2e" stroke="#333" stroke-width="1"/>
  <rect x="120" y="220" width="60" height="12" rx="6" fill="#222"/>
  <text x="150" y="265" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="#888">{label}</text>
</svg>''',

    "earbuds_case": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 280" width="300" height="280">
  <rect width="300" height="280" fill="#f5f5f5"/>
  <rect x="90" y="100" width="120" height="80" rx="40" ry="40" fill="#3a3a3a" stroke="#555" stroke-width="2"/>
  <line x1="90" y1="140" x2="210" y2="140" stroke="#555" stroke-width="1.5"/>
  <circle cx="150" cy="165" r="4" fill="#0a0a0a"/>
  <text x="150" y="210" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="#888">{label}</text>
</svg>''',

    "headphones": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 280" width="300" height="280">
  <rect width="300" height="280" fill="#f5f5f5"/>
  <path d="M 80 180 Q 80 60 150 60 Q 220 60 220 180" fill="none" stroke="#555" stroke-width="6" stroke-linecap="round"/>
  <ellipse cx="80" cy="190" rx="28" ry="35" fill="#3a3a3a" stroke="#555" stroke-width="2"/>
  <ellipse cx="220" cy="190" rx="28" ry="35" fill="#3a3a3a" stroke="#555" stroke-width="2"/>
  <text x="150" y="260" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="#888">{label}</text>
</svg>''',

    "speaker": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 280" width="300" height="280">
  <rect width="300" height="280" fill="#f5f5f5"/>
  <rect x="110" y="50" width="80" height="180" rx="12" fill="#3a3a3a" stroke="#555" stroke-width="2"/>
  <circle cx="150" cy="120" r="22" fill="#1a1a1a" stroke="#444" stroke-width="1"/>
  <circle cx="150" cy="120" r="12" fill="#0a0a0a"/>
  <circle cx="150" cy="180" r="14" fill="#222" stroke="#444" stroke-width="1"/>
  <text x="150" y="260" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="#888">{label}</text>
</svg>''',

    "smartwatch": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 280" width="300" height="280">
  <rect width="300" height="280" fill="#f5f5f5"/>
  <rect x="115" y="80" width="70" height="70" rx="18" fill="#3a3a3a" stroke="#555" stroke-width="2"/>
  <rect x="122" y="87" width="56" height="56" rx="10" fill="#1a1a2e" stroke="#333" stroke-width="1"/>
  <rect x="135" y="50" width="30" height="30" fill="#444" stroke="#555" stroke-width="1"/>
  <rect x="135" y="150" width="30" height="30" fill="#444" stroke="#555" stroke-width="1"/>
  <text x="150" y="210" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="#888">{label}</text>
</svg>''',

    "hair_dryer": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 280" width="300" height="280">
  <rect width="300" height="280" fill="#f5f5f5"/>
  <rect x="100" y="70" width="90" height="50" rx="20" fill="#3a3a3a" stroke="#555" stroke-width="2"/>
  <circle cx="180" cy="95" r="22" fill="none" stroke="#555" stroke-width="2"/>
  <circle cx="180" cy="95" r="15" fill="#222" stroke="#444" stroke-width="1"/>
  <rect x="120" y="120" width="25" height="80" rx="10" fill="#444" stroke="#555" stroke-width="1.5"/>
  <text x="150" y="260" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="#888">{label}</text>
</svg>''',

    "electric_toothbrush": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 280" width="300" height="280">
  <rect width="300" height="280" fill="#f5f5f5"/>
  <rect x="130" y="30" width="40" height="40" rx="6" fill="#555" stroke="#666" stroke-width="1"/>
  <rect x="135" y="70" width="30" height="140" rx="12" fill="#3a3a3a" stroke="#555" stroke-width="2"/>
  <circle cx="150" cy="140" r="6" fill="#1a1a1a" stroke="#444" stroke-width="1"/>
  <rect x="133" y="210" width="34" height="10" rx="3" fill="#222" stroke="#444" stroke-width="1"/>
  <text x="150" y="260" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="#888">{label}</text>
</svg>''',

    "shaver": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 280" width="300" height="280">
  <rect width="300" height="280" fill="#f5f5f5"/>
  <rect x="115" y="40" width="70" height="40" rx="15" fill="#3a3a3a" stroke="#555" stroke-width="2"/>
  <circle cx="135" cy="60" r="8" fill="#555" stroke="#666" stroke-width="1"/>
  <circle cx="165" cy="60" r="8" fill="#555" stroke="#666" stroke-width="1"/>
  <rect x="125" y="80" width="50" height="120" rx="20" fill="#444" stroke="#555" stroke-width="2"/>
  <text x="150" y="260" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="#888">{label}</text>
</svg>''',

    "generic_device": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 280" width="300" height="280">
  <rect width="300" height="280" fill="#f5f5f5"/>
  <rect x="80" y="60" width="140" height="160" rx="15" ry="15" fill="#3a3a3a" stroke="#555" stroke-width="2"/>
  <text x="150" y="150" text-anchor="middle" font-family="Arial,sans-serif" font-size="14" fill="#888">产品示意图</text>
  <text x="150" y="260" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="#888">{label}</text>
</svg>''',
}

# Candidate download URLs for each comparison object type.
# Uses generic category terms only — no brand or product names for confidentiality.
# Google Patents search URLs are public and safe to use.
CANDIDATE_URLS = {
    "robot-vacuum": [
        ("comp_round_no_lidar", "round_robot_no_lidar", "圆形机身 · 顶部平整 · 无LiDAR塔",
         ["https://patents.google.com/?q=robot+vacuum+round+no+lidar",
          "https://www.amazon.com/s?k=robot+vacuum+round+flat+top"]),
        ("comp_round_with_lidar", "round_robot_with_lidar", "圆形机身 · 顶部有LiDAR塔",
         ["https://patents.google.com/?q=robot+vacuum+lidar+tower",
          "https://www.amazon.com/s?k=robot+vacuum+lidar+navigation"]),
        ("comp_d_shape", "d_shape_robot", "D形机身 · 顶部有LiDAR塔 · 沿边清洁导向",
         ["https://patents.google.com/?q=robot+vacuum+D-shaped",
          "https://www.amazon.com/s?k=robot+vacuum+D+shape"]),
        ("comp_base_station", "base_station", "自动集尘基站 · 圆润形态 · LCD屏幕",
         ["https://patents.google.com/?q=robot+vacuum+base+station+dock",
          "https://www.amazon.com/s?k=robot+vacuum+auto+empty+station"]),
    ],
    "cleaning-appliances": [
        ("comp_round_no_lidar", "round_robot_no_lidar", "圆形机身 · 顶部平整 · 无LiDAR塔",
         ["https://patents.google.com/?q=robot+vacuum+round+no+lidar",
          "https://www.amazon.com/s?k=robot+vacuum+round+flat+top"]),
        ("comp_round_with_lidar", "round_robot_with_lidar", "圆形机身 · 顶部有LiDAR塔",
         ["https://patents.google.com/?q=robot+vacuum+lidar+tower",
          "https://www.amazon.com/s?k=robot+vacuum+lidar+navigation"]),
        ("comp_d_shape", "d_shape_robot", "D形机身 · 顶部有LiDAR塔 · 沿边清洁导向",
         ["https://patents.google.com/?q=robot+vacuum+D-shaped",
          "https://www.amazon.com/s?k=robot+vacuum+D+shape"]),
        ("comp_base_station", "base_station", "自动集尘基站 · 圆润形态 · LCD屏幕",
         ["https://patents.google.com/?q=robot+vacuum+base+station+dock",
          "https://www.amazon.com/s?k=robot+vacuum+auto+empty+station"]),
    ],
    "stick-vacuum": [
        ("comp_stick", "stick_vacuum", "手持/杆式吸尘器示意图",
         ["https://patents.google.com/?q=stick+vacuum+cleaner+design",
          "https://www.amazon.com/s?k=stick+vacuum+cleaner"]),
        ("comp_base_station", "base_station", "充电基站示意图",
         ["https://patents.google.com/?q=vacuum+cleaner+charging+dock",
          "https://www.amazon.com/s?k=vacuum+charging+dock"]),
    ],
    "floor-washer": [
        ("comp_stick", "stick_vacuum", "洗地机示意图",
         ["https://patents.google.com/?q=floor+washer+wet+dry+vacuum",
          "https://www.amazon.com/s?k=floor+washer+wet+dry"]),
        ("comp_base_station", "base_station", "充电基站示意图",
         ["https://patents.google.com/?q=floor+washer+base+station",
          "https://www.amazon.com/s?k=floor+washer+station"]),
    ],
    "consumer-electronics": [
        ("comp_phone", "phone", "智能手机示意图",
         ["https://patents.google.com/?q=phone+design+patent",
          "https://www.amazon.com/s?k=smartphone+design"]),
        ("comp_earbuds", "earbuds_case", "真无线耳机充电盒示意图",
         ["https://patents.google.com/?q=wireless+earbuds+charging+case",
          "https://www.amazon.com/s?k=wireless+earbuds+case"]),
        ("comp_headphones", "headphones", "头戴式耳机示意图",
         ["https://patents.google.com/?q=headphones+design+patent",
          "https://www.amazon.com/s?k=over+ear+headphones"]),
        ("comp_speaker", "speaker", "智能音箱示意图",
         ["https://patents.google.com/?q=smart+speaker+design",
          "https://www.amazon.com/s?k=smart+speaker"]),
    ],
    "earbuds-headphones": [
        ("comp_earbuds", "earbuds_case", "真无线耳机充电盒示意图",
         ["https://patents.google.com/?q=wireless+earbuds+charging+case",
          "https://www.amazon.com/s?k=wireless+earbuds+case"]),
        ("comp_headphones", "headphones", "头戴式耳机示意图",
         ["https://patents.google.com/?q=headphones+design+patent",
          "https://www.amazon.com/s?k=over+ear+headphones"]),
    ],
    "personal-care": [
        ("comp_hair_dryer", "hair_dryer", "吹风机示意图",
         ["https://patents.google.com/?q=hair+dryer+design+patent",
          "https://www.amazon.com/s?k=hair+dryer"]),
        ("comp_toothbrush", "electric_toothbrush", "电动牙刷示意图",
         ["https://patents.google.com/?q=electric+toothbrush+design",
          "https://www.amazon.com/s?k=electric+toothbrush"]),
        ("comp_shaver", "shaver", "剃须刀示意图",
         ["https://patents.google.com/?q=electric+shaver+design",
          "https://www.amazon.com/s?k=electric+shaver"]),
    ],
}


def try_download_image(url: str, output_path: str, timeout: int = 10) -> bool:
    """Attempt to download an image from a URL. Returns True on success."""
    try:
        result = subprocess.run(
            ["curl", "--connect-timeout", "5", "--max-time", str(timeout),
             "-L", "-o", output_path, url,
             "-H", "User-Agent: Mozilla/5.0",
             "-H", "Accept: image/*",
             "-s", "-w", "%{http_code}"],
            capture_output=True, text=True, timeout=timeout + 5
        )
        if result.returncode != 0:
            return False
        # Check if downloaded file is actually an image
        file_result = subprocess.run(
            ["file", "--mime-type", output_path],
            capture_output=True, text=True
        )
        mime = file_result.stdout.lower()
        return any(t in mime for t in ["image/jpeg", "image/png", "image/webp", "image/gif"])
    except Exception:
        return False


def image_to_base64(filepath: str, max_size: int = 800) -> str:
    """Resize and convert image to base64 data URI."""
    try:
        from PIL import Image
        import io
        img = Image.open(filepath)
        if img.mode == "RGBA":
            pass  # Keep RGBA for PNG
        else:
            img = img.convert("RGB")
        img.thumbnail((max_size, max_size), Image.LANCZOS)
        buf = io.BytesIO()
        img.save(buf, format="PNG", optimize=True)
        b64 = base64.b64encode(buf.getvalue()).decode()
        return f"data:image/png;base64,{b64}"
    except ImportError:
        # Fallback if PIL is not available
        with open(filepath, "rb") as f:
            b64 = base64.b64encode(f.read()).decode()
        ext = Path(filepath).suffix.lower().lstrip(".")
        mime = f"image/{ext}" if ext in ["jpeg", "jpg", "png", "webp", "gif"] else "image/png"
        return f"data:{mime};base64,{b64}"
    except Exception:
        return ""


def svg_to_base64(svg_content: str) -> str:
    """Convert SVG string to base64 data URI."""
    b64 = base64.b64encode(svg_content.encode("utf-8")).decode()
    return f"data:image/svg+xml;base64,{b64}"


def generate_svg_schematic(template_key: str, label: str = "") -> str:
    """Generate an SVG schematic for a given product type."""
    template = SVG_TEMPLATES.get(template_key, SVG_TEMPLATES["generic_device"])
    return svg_to_base64(template.format(label=label))


def fetch_images_for_category(category: str, output_dir: str) -> dict:
    """
    Main function: attempt to fetch real images, fall back to SVG schematics.
    Returns a dict with image data, visual_type, and comparison_url for each object.
    """
    os.makedirs(output_dir, exist_ok=True)
    results = {}

    # Get comparison objects for the requested category
    comparisons = CANDIDATE_URLS.get(category, [
        ("comp_generic_1", "generic_device", "竞品示意图1",
         ["https://patents.google.com/"]),
        ("comp_generic_2", "generic_device", "竞品示意图2",
         ["https://patents.google.com/"]),
    ])

    download_attempts = 0
    download_successes = 0

    for key, svg_template, label, candidate_urls in comparisons:
        real_image = None
        best_url = candidate_urls[0] if candidate_urls else ""

        # Try real image download from candidate URLs
        for url in candidate_urls:
            download_attempts += 1
            temp_path = os.path.join(output_dir, f"{key}_temp.jpg")
            print(f"  Trying: {url[:80]}...", file=sys.stderr)
            if try_download_image(url, temp_path):
                real_image = image_to_base64(temp_path)
                if os.path.exists(temp_path):
                    os.remove(temp_path)
                if real_image:
                    download_successes += 1
                    print(f"  ✅ Downloaded real image for {key}", file=sys.stderr)
                    break
                else:
                    print(f"  ⚠️ Download succeeded but base64 conversion failed for {key}", file=sys.stderr)
            else:
                print(f"  ❌ Download failed for {key} from {url[:60]}", file=sys.stderr)
                if os.path.exists(temp_path):
                    os.remove(temp_path)

        if real_image:
            results[key] = {
                "image": real_image,
                "visual_type": "real",
                "comparison_url": best_url,
            }
        else:
            results[key] = {
                "image": generate_svg_schematic(svg_template, label),
                "visual_type": "svg_schematic",
                "comparison_url": best_url,
                "label": label,
            }

    # Save results to JSON
    output_json = os.path.join(output_dir, "competitor_images.json")
    with open(output_json, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    print(f"\nGenerated {len(results)} comparison images "
          f"({download_successes} real, {len(results) - download_successes} SVG fallback)", file=sys.stderr)
    print(f"Download attempts: {download_attempts}, successes: {download_successes}", file=sys.stderr)
    print(f"Output: {output_json}", file=sys.stderr)
    return results


def fetch_from_agent_input(input_path: str, output_dir: str) -> str:
    """Fetch competitor images based on Patent Scout Agent input JSON (v4.0.0).
    
    Reads the agent input JSON, extracts product category and comparison object names,
    calls fetch_images_for_category, and writes results to output_dir.
    Returns the path to the JSON results file.
    """
    input_data = json.loads(Path(input_path).read_text(encoding="utf-8"))
    
    # Extract category from agent input
    product_context = input_data.get("product_context", {})
    category = product_context.get("category", "unknown")
    
    # Map internal category keys to script category names
    category_map = {
        "cleaning_appliances": "cleaning-appliances",
        "consumer_electronics": "consumer-electronics",
        "personal_care": "personal-care",
    }
    script_category = category_map.get(category, category)
    
    # Also extract subcategory from image_analysis if available
    image_analysis = input_data.get("image_analysis", {})
    product_id = image_analysis.get("product_identification", {})
    subcategory = product_id.get("subcategory", "")
    
    # Adjust category based on subcategory
    if subcategory == "robot_vacuum":
        script_category = "robot-vacuum"
    elif subcategory == "earbuds_headphones":
        script_category = "earbuds-headphones"
    elif subcategory == "toothbrush_steriliser":
        script_category = "personal-care"
    
    # Fetch images
    results = fetch_images_for_category(script_category, output_dir)
    
    # Write results to file
    output_path = Path(output_dir) / "competitor_images.json"
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    
    return str(output_path)


def main():
    parser = argparse.ArgumentParser(description="Fetch competitor images for patent comparison.")
    parser.add_argument("--category", 
                        help="Product category (robot-vacuum, cleaning-appliances, consumer-electronics, "
                             "earbuds-headphones, personal-care, etc.)")
    parser.add_argument("--from-agent-input", 
                        help="Path to Patent Scout Agent input JSON (v4.0.0 mode)")
    parser.add_argument("--output-dir", default="compare_images", help="Output directory for images")
    parser.add_argument("--format", choices=["base64", "file"], default="base64", help="Output format")
    args = parser.parse_args()

    if args.from_agent_input:
        # v4.0.0 agent mode
        output_path = fetch_from_agent_input(args.from_agent_input, args.output_dir)
        print(f"Competitor images JSON written to: {output_path}", file=sys.stderr)
        # Also output to stdout for parsing
        results = json.loads(Path(output_path).read_text(encoding="utf-8"))
        print(json.dumps(results, ensure_ascii=False, indent=2))
    elif args.category:
        results = fetch_images_for_category(args.category, args.output_dir)
        if args.format == "base64":
            print(json.dumps(results, ensure_ascii=False, indent=2))
    else:
        print("Error: Either --category or --from-agent-input must be provided", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
