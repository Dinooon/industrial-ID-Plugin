#!/usr/bin/env python3
"""
agent_input_generator.py — Generate input JSON files for each sub-agent.

Reads the coordinator's input and produces individual input JSON files
for Image Analyst, Patent Scout, Brand Judge, and Report Builder agents.

Usage:
    python agent_input_generator.py --coordinator-input coordinator_input.json --session-dir /tmp/review_session_xxx --step [1|2|3|4]

    Step 1: Generate Image Analyst input
    Step 2: Generate Patent Scout input (requires step1 output)
    Step 3: Generate Brand Judge input (requires step1 output)
    Step 4: Generate Report Builder input (requires step1-3 outputs)
"""

import argparse
import json
import sys
from pathlib import Path


def load_json(path: str) -> dict:
    p = Path(path)
    if not p.exists():
        print(f"Error: File not found: {path}", file=sys.stderr)
        sys.exit(1)
    return json.loads(p.read_text(encoding="utf-8"))


def save_json(path: str, data: dict):
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Generated: {path}")


def get_category_file(category: str) -> str:
    mapping = {
        "cleaning_appliances": "references/category/cleaning-appliances.md",
        "consumer_electronics": "references/category/consumer-electronics.md",
        "personal_care": "references/category/personal-care.md",
    }
    return mapping.get(category, "references/categories.yaml")


def get_brand_language_files(category: str) -> list:
    mapping = {
        "cleaning_appliances": ["references/brand-language/cleaning-appliances.md"],
        "consumer_electronics": ["references/brand-language/consumer-electronics.md"],
        "personal_care": ["references/brand-language/personal-care.md"],
    }
    return ["references/brand-language/shared-principles.md"] + mapping.get(category, [])


def get_patent_search_file(category: str) -> str:
    mapping = {
        "cleaning_appliances": "references/patent-risk/cleaning-appliances-search.md",
        "consumer_electronics": "references/patent-risk/consumer-electronics-search.md",
        "personal_care": "references/patent-risk/personal-care-search.md",
    }
    return mapping.get(category, "")


def generate_image_analyst_input(coordinator: dict, session_dir: str) -> dict:
    """Step 1: Generate Image Analyst input."""
    ctx = coordinator.get("user_context", {})
    category_hint = ctx.get("category_hint", "uncertain")
    category_key = {
        "cleaning_appliance": "cleaning_appliances",
        "consumer_electronic": "consumer_electronics",
        "personal_care": "personal_care",
    }.get(category_hint, "uncertain")

    return {
        "image_paths": coordinator.get("image_paths", []),
        "user_context": {
            "category_hint": category_hint,
            "brand_reference": ctx.get("brand_reference"),
            "additional_notes": ctx.get("additional_notes", ""),
        },
        "reference_files": [get_category_file(category_key)] if category_key != "uncertain" else ["references/categories.yaml"],
    }


def generate_patent_scout_input(coordinator: dict, step1_output: dict, session_dir: str) -> dict:
    """Step 2: Generate Patent Scout input (requires step1 output)."""
    ctx = coordinator.get("user_context", {})
    category = step1_output.get("product_identification", {}).get("category", "uncertain")

    patent_file = get_patent_search_file(category)
    ref_files = ["references/patent-risk/risk-rubric.md"]
    if patent_file:
        ref_files.append(patent_file)
    if ctx.get("target_market", "").startswith("中国") or ctx.get("target_market") == "中国大陆":
        ref_files.append("references/patent-risk/legal-framework-cn.md")

    return {
        "image_analysis": step1_output,
        "product_context": {
            "category": category,
            "target_market": ctx.get("target_market", "中国大陆"),
            "brand_name": ctx.get("brand_reference"),
        },
        "reference_files": ref_files,
        "image_acquisition_script": "scripts/fetch_competitor_images.py",
        "pre_searched_results": {
            "search_performed": False,
        },
    }


def generate_brand_judge_input(coordinator: dict, step1_output: dict, session_dir: str) -> dict:
    """Step 3: Generate Brand Judge input (requires step1 output)."""
    ctx = coordinator.get("user_context", {})
    category = step1_output.get("product_identification", {}).get("category", "uncertain")

    return {
        "image_analysis": step1_output,
        "brand_reference": {
            "brand_name": ctx.get("brand_reference"),
            "reference_files": get_brand_language_files(category),
        },
        "product_context": {
            "category": category,
            "target_market": ctx.get("target_market", "中国大陆"),
            "price_tier": ctx.get("price_tier", "中端"),
        },
    }


def generate_report_builder_input(coordinator: dict, step1: dict, step2: dict, step3: dict, session_dir: str) -> dict:
    """Step 4: Generate Report Builder input (requires steps 1-3 outputs)."""
    ctx = coordinator.get("user_context", {})
    category = step1.get("product_identification", {}).get("category", "uncertain")

    product_name = step1.get("product_identification", {}).get("product_type", "product")
    from datetime import datetime
    date_str = datetime.now().strftime("%Y-%m-%d")
    # Sanitize product name for filename
    safe_name = product_name.replace(" ", "-").replace("/", "-")

    return {
        "image_analysis": step1,
        "brand_review": step3,
        "patent_risk": step2,
        "scoring_context": {
            "rubric_file": "references/scoring-rubric.md",
            "category_file": get_category_file(category),
            "user_context": {
                "target_market": ctx.get("target_market", "中国大陆"),
                "price_tier": ctx.get("price_tier", "中端"),
                "concept_stage": ctx.get("concept_stage", "early_concept"),
                "brand_name": ctx.get("brand_reference"),
            },
        },
        "report_config": {
            "template": "assets/report-template.html",
            "output_path": f"reports/design-review_{safe_name}_{date_str}.html",
            "frontend_workflow": "references/frontend-design-workflow.md",
            "quality_gate": "references/quality-gate.md",
            "generate_script": "scripts/generate_report.py",
            "quality_check_script": "scripts/quality_check.py",
            "product_image_paths": coordinator.get("image_paths", []),
        },
        # v5.0.0: structured output guidance
        "output_schema_hints": {
            "brand_language_review": "Output as structured object: brand_dna_summary, brand_dna_points[], product_diagnosis, critical_gaps[{issue,severity}], key_conclusion",
            "strengths": "Output as array of {point, weight: normal|highlight}",
            "concerns": "Output as array of {point, weight: critical|high|medium|normal}",
            "recommendations": "Output as array of {action, priority: P0|P1|P2, rationale}",
        },
    }


def main():
    parser = argparse.ArgumentParser(description="Generate sub-agent input JSON files.")
    parser.add_argument("--coordinator-input", required=True, help="Path to coordinator_input.json")
    parser.add_argument("--session-dir", required=True, help="Session directory path")
    parser.add_argument("--step", required=True, type=int, choices=[1, 2, 3, 4],
                        help="Step number: 1=ImageAnalyst, 2=PatentScout, 3=BrandJudge, 4=ReportBuilder")
    parser.add_argument("--step1-output", help="Path to step1 output (for steps 2-4)")
    parser.add_argument("--step2-output", help="Path to step2 output (for step 4)")
    parser.add_argument("--step3-output", help="Path to step3 output (for step 4)")
    args = parser.parse_args()

    coordinator = load_json(args.coordinator_input)
    session = args.session_dir

    if args.step == 1:
        data = generate_image_analyst_input(coordinator, session)
        save_json(f"{session}/input_image_analyst.json", data)

    elif args.step == 2:
        if not args.step1_output:
            print("Error: --step1-output required for step 2", file=sys.stderr)
            sys.exit(1)
        step1 = load_json(args.step1_output)
        data = generate_patent_scout_input(coordinator, step1, session)
        save_json(f"{session}/input_patent_scout.json", data)

    elif args.step == 3:
        if not args.step1_output:
            print("Error: --step1-output required for step 3", file=sys.stderr)
            sys.exit(1)
        step1 = load_json(args.step1_output)
        data = generate_brand_judge_input(coordinator, step1, session)
        save_json(f"{session}/input_brand_judge.json", data)

    elif args.step == 4:
        if not all([args.step1_output, args.step2_output, args.step3_output]):
            print("Error: --step1-output, --step2-output, --step3-output required for step 4", file=sys.stderr)
            sys.exit(1)
        step1 = load_json(args.step1_output)
        step2 = load_json(args.step2_output)
        step3 = load_json(args.step3_output)
        data = generate_report_builder_input(coordinator, step1, step2, step3, session)
        save_json(f"{session}/input_report_builder.json", data)


if __name__ == "__main__":
    main()
