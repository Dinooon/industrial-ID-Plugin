#!/usr/bin/env python3
"""Generate the complete review report data for the smartwatch/TWS evaluation against Apple brand language."""
import base64, json
from pathlib import Path
from datetime import datetime

# Load product images as base64
def img_to_base64(path):
    data = Path(path).read_bytes()
    ext = path.split('.')[-1].lower()
    mime = {'jpg': 'image/jpeg', 'jpeg': 'image/jpeg', 'png': 'image/png'}.get(ext, 'image/jpeg')
    return f"data:{mime};base64,{base64.b64encode(data).decode()}"

product_images = [
    img_to_base64("/home/ubuntu/upload/Industrial Design Trends, Online Courses and Jobs - leManoosh.jpg"),
    img_to_base64("/home/ubuntu/upload/Industrial Design Trends, Online Courses and Jobs - leManoosh_1.jpg"),
    img_to_base64("/home/ubuntu/upload/Industrial Design Trends, Online Courses and Jobs - leManoosh_2.jpg"),
]

# Load comparison SVGs as base64
def svg_to_base64(path):
    data = Path(path).read_bytes()
    return f"data:image/svg+xml;base64,{base64.b64encode(data).decode()}"

comparison_svgs_dir = Path("/tmp/apple_comparison_svgs")

# Build comparison cards
comparison_cards = [
    {
        "name": "Apple Watch Series",
        "image": svg_to_base64(str(comparison_svgs_dir / "apple_watch_series.svg")),
        "visual_type": "svg_schematic",
        "comparison_url": "https://www.apple.com/apple-watch-series-11/",
        "image_reference_url": "https://www.apple.com/shop/buy-watch",
        "similar_points": [
            "圆角矩形表盘轮廓（Squircle）与Apple Watch的几何语言一致",
            "屏幕显示时间格式（09:41）与Apple风格的时间排版相似"
        ],
        "different_points": [
            "产品为智能手环，尺寸更小，无实体数码表冠（Digital Crown）",
            "薄荷绿配色与Apple Watch的中性/金属色调完全不同",
            "卡通击掌UI壁纸与Apple的极简表盘设计语言完全矛盾",
            "缺乏Apple标志性的铝合金/不锈钢表壳质感和精确倒角"
        ],
        "risk_reason": "仅几何轮廓属于品类通用语言，整体视觉印象与Apple Watch存在显著差异"
    },
    {
        "name": "Apple Watch SE",
        "image": svg_to_base64(str(comparison_svgs_dir / "apple_watch_se.svg")),
        "visual_type": "svg_schematic",
        "comparison_url": "https://www.apple.com/apple-watch-se-3/",
        "image_reference_url": "https://www.apple.com/shop/buy-watch/apple-watch-se",
        "similar_points": [
            "圆角方形表盘外形轮廓",
            "侧面有按键/旋钮位置（但产品仅有普通侧键，非数码表冠）"
        ],
        "different_points": [
            "产品定位为儿童智能手环，材质为硅胶/PC，非Apple的铝合金/玻璃",
            "薄荷绿+黑色撞色与Apple Watch SE的午夜色/星光色完全不同",
            "UI采用卡通风格壁纸，与Apple的SF字体+极简表盘形成根本矛盾",
            "无Force Touch、无Taptic Engine等Apple核心交互特征"
        ],
        "risk_reason": "品类通用轮廓的相似性有限，核心视觉识别元素完全不重叠"
    },
    {
        "name": "AirPods 充电盒",
        "image": svg_to_base64(str(comparison_svgs_dir / "airpods_case.svg")),
        "visual_type": "svg_schematic",
        "comparison_url": "https://www.apple.com/airpods/",
        "image_reference_url": "https://www.apple.com/shop/buy-airpods",
        "similar_points": [
            "充电盒的圆角矩形轮廓与AirPods充电盒有形态上的类比",
            "正面有功能指示区域"
        ],
        "different_points": [
            "产品为薄荷绿色哑光硅胶外壳，AirPods为纯白高光塑料",
            "正面颗粒纹理按键与AirPods的隐藏式LED指示灯完全不同",
            "尺寸比例更修长（立式），与AirPods Pro的方形盒体不同",
            "缺乏Apple充电盒的磁吸开盖机构和精确铰链设计"
        ],
        "risk_reason": "充电盒仅为附属配件，且CMF和开盖机构与AirPods存在根本差异"
    },
    {
        "name": "Apple Watch Ultra",
        "image": svg_to_base64(str(comparison_svgs_dir / "apple_watch_ultra.svg")),
        "visual_type": "svg_schematic",
        "comparison_url": "https://www.apple.com/apple-watch-ultra-3/",
        "image_reference_url": "https://www.apple.com/shop/buy-watch/apple-watch-ultra",
        "similar_points": [
            "同为可穿戴设备品类"
        ],
        "different_points": [
            "Apple Watch Ultra采用钛合金平边表壳+蓝宝石玻璃，产品为硅胶/PC材质",
            "Ultra有标志性橙色操作按钮和大型数码表冠，产品仅有普通侧键",
            "Ultra的49mm大屏+平边设计与产品的圆润儿童手环造型完全不同",
            "定位完全不同：Ultra面向极限运动，产品面向儿童"
        ],
        "risk_reason": "两个产品在尺寸、材质、定位和核心识别特征上完全不重叠"
    }
]

# Scoring breakdown
scoring_rows = [
    {
        "dimension": "用户场景与概念方向契合度",
        "score": 6,
        "max": 15,
        "evidence": "面向儿童健康监测场景清晰，但缺乏Apple品牌语境下的使用场景定义"
    },
    {
        "dimension": "形态比例与产品识别度",
        "score": 8,
        "max": 15,
        "evidence": "圆角矩形轮廓比例协调，但识别度来自卡通UI而非硬件形态本身"
    },
    {
        "dimension": "品牌设计语言一致性",
        "score": 4,
        "max": 20,
        "evidence": "薄荷绿配色、卡通UI、硅胶材质三方面与Apple极简/精密/金属设计语言存在根本矛盾"
    },
    {
        "dimension": "CMF与感知品质",
        "score": 5,
        "max": 12,
        "evidence": "哑光硅胶+薄荷绿体现一定品质感，但缺乏Apple标志性的材质对比和精密感"
    },
    {
        "dimension": "品类专属体验假设",
        "score": 7,
        "max": 12,
        "evidence": "心率/血氧传感器布局合理，IP68防护可信，但交互层级缺乏Apple式的精确性"
    },
    {
        "dimension": "交互、人因与使用风险可见性",
        "score": 5,
        "max": 10,
        "evidence": "侧键和充电触点可见，但缺乏Apple式的触觉反馈层级和交互意图表达"
    },
    {
        "dimension": "创新与差异化",
        "score": 4,
        "max": 8,
        "evidence": "儿童手环+TWS组合是品类常见做法，缺乏Apple品牌语境下的创新表达"
    },
    {
        "dimension": "早期结构/工艺风险预警",
        "score": 2,
        "max": 3,
        "evidence": "硅胶一体成型工艺成熟，无明显结构风险"
    },
    {
        "dimension": "方案表达完整性",
        "score": 4,
        "max": 5,
        "evidence": "三张图片提供了背面、充电盒、正面三个视角，信息充分但无尺寸标注"
    }
]

total_score = sum(r["score"] for r in scoring_rows)  # Should be 45

report_data = {
    "project_title": "智能手环+TWS耳机充电盒",
    "date": "2026-07-08",
    "product_category": "消费电子 > 可穿戴设备/TWS耳机",
    "confidence": "中等",
    "verdict": "重做方向",
    "next_action": "需重新定义Apple品牌语境下的设计方向，调整CMF策略、UI语言和交互逻辑",
    "design_score": str(total_score),
    "brand_language_score": "矛盾",
    "patent_risk_level": "低",
    "decision_label": "重做方向",
    "version": "v1.0",
    "product_images": product_images,
    "image_source_caption": "待评审产品图片（来源：leManoosh工业设计趋势）",
    "confirmed_facts": [
        "产品包含智能手环（Noise Champ 3）和TWS耳机充电盒两个组件",
        "手环背部有心率传感器和血氧传感器，防护等级IP68",
        "手环屏幕为1.4英寸TFT，支持蓝牙5.3",
        "TWS充电盒为薄荷绿哑光质感，正面有颗粒纹理功能按键",
        "手环正面显示卡通击掌壁纸，时间显示09:41",
        "目标品牌参考：Apple（苹果）",
        "目标市场：中国大陆",
        "专利检索区域：中国区"
    ],
    "needs_confirmation": [
        "该产品是否为概念设计稿，还是市售成品改编？",
        "是否需要将两个组件（手环+TWS）作为统一的Apple配件生态来设计？",
        "目标价格区间是否对标Apple产品线？"
    ],
    "image_relationship": "同一产品系列的不同组件：图片1为手环背面，图片2为TWS充电盒，图片3为手环正面",
    "assumptions": [
        "产品为概念设计阶段，非市售成品",
        "Apple品牌参考涵盖Apple Watch和AirPods两条产品线",
        "评审关注整体造型和品牌一致性，不限单一品类"
    ],
    "executive_summary": [
        "产品由智能手环和TWS耳机充电盒组成，整体采用薄荷绿+黑色撞色策略和卡通化UI语言，与Apple品牌的极简精密设计哲学存在根本性方向偏离",
        "品牌一致性评估为'矛盾'：薄荷绿配色、卡通UI壁纸、硅胶/PC材质三个方面与Apple的金属精密/极简留白/SF字体体系形成直接冲突",
        "专利风险评估为'低'：圆角矩形表盘和充电盒轮廓属于品类通用语言，核心视觉识别元素与Apple产品存在显著差异，不构成近似",
        "总分45/100，判定为'重做方向'，需在CMF策略、UI设计语言和材质选择三个维度进行根本性调整"
    ],
    "strengths": [
        "圆角矩形（Squircle）表盘轮廓比例协调，与Apple Watch几何语言有潜在对接可能",
        "传感器布局（心率+血氧）功能化且合理，符合可穿戴设备的品类逻辑",
        "TWS充电盒的哑光质感和颗粒纹理按键体现了一定的CMF探索意识",
        "IP68防护等级和蓝牙5.3规格在技术参数上达到主流水平"
    ],
    "concerns": [
        "薄荷绿（Mint Green）主色调与Apple品牌色彩体系完全矛盾——Apple Watch以中性金属色为主，AirPods以纯白为核心",
        "卡通击掌壁纸UI与Apple的极简表盘设计语言形成根本冲突——Apple使用SF字体+几何表盘+渐进色环",
        "硅胶/PC哑光材质缺乏Apple标志性的铝合金/不锈钢精密加工质感和材质对比",
        "手环正面无品牌标识位置，缺乏Apple产品必备的品牌表达区",
        "TWS充电盒的颗粒纹理按键过于装饰化，与Apple'形式追随功能'的设计原则矛盾",
        "时间显示09:41是对Apple的刻意模仿，但在完全不同的设计语言中显得不协调"
    ],
    "brand_language_review": "矛盾",
    "brand_language_reason": "产品在三个核心维度与Apple品牌设计语言形成直接矛盾：(1) CMF策略——薄荷绿+黑色撞色与Apple的中性金属/纯白极简完全不同；(2) UI语言——卡通击掌壁纸与Apple的SF字体+几何表盘极简主义根本冲突；(3) 材质表达——硅胶/PC哑光与Apple的铝合金/不锈钢/蓝宝石玻璃精密质感形成落差。圆角矩形轮廓虽与Apple Watch有品类层面的相似，但这属于可穿戴设备的通用语言，不构成品牌一致性。总体而言，该产品更接近Noise/小米/华为等品牌的设计语言，而非Apple的精密极简美学。",
    "scoring_rows": scoring_rows,
    "patent_risk_summary": "外观专利风险等级：低。产品虽在圆角矩形表盘轮廓上与Apple Watch有品类层面的相似，但这种Squircle形态属于智能手表/手环的通用设计语言。在核心识别元素（CMF、UI、材质、交互方式）上与Apple产品存在显著差异，整体视觉印象不构成近似。TWS充电盒的薄荷绿配色和颗粒纹理按键与AirPods的纯白极简充电盒在视觉上差异明显。中国区外观专利检索未发现与该产品高度近似的有效设计专利。",
    "patent_comparison_cards": comparison_cards,
    "recommendations": [
        "CMF重构：将薄荷绿撞色策略调整为Apple式的中性色系（银色/深空灰/星光色/午夜色），保持单一主色调+少量点缀色",
        "UI语言对齐：移除卡通壁纸，改用SF风格字体+几何表盘+极简信息层级，建立与Apple Watch视觉语言的家族连接",
        "材质升级：将硅胶/PC哑光替换为铝合金表壳+2.5D玻璃面板，增加材质对比和精密加工质感",
        "品牌标识：在表盘正面或表冠位置预留Apple Logo表达区，确保品牌识别度",
        "交互简化：将颗粒纹理按键替换为Apple式的隐藏式触控或精密物理按键，遵循'减法美学'",
        "生态一致性：确保手环与TWS充电盒在CMF和设计语言上保持统一，形成Apple配件生态的家族感",
        "移除09:41时间显示或将其置于Apple式极简表盘框架内，避免脱离语境的元素堆砌"
    ],
    "next_round_materials": [
        "调整后的CMF方案（建议提供3个配色方案）",
        "Apple式极简UI表盘设计稿",
        "铝合金表壳+玻璃面板的材质效果图",
        "手环与TWS充电盒的生态统一性设计说明",
        "产品尺寸标注图"
    ],
    "product_image": product_images[2],  # Front view as main image
}

# Save report data
output_path = Path("/home/ubuntu/skill-analysis/product-design-evaluator-improved/reports/report_data_smartwatch-tws-apple-language.json")
output_path.write_text(json.dumps(report_data, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"Report data saved to: {output_path}")
print(f"Total score: {total_score}")
print(f"Product images: {len(product_images)}")
print(f"Comparison cards: {len(comparison_cards)}")
