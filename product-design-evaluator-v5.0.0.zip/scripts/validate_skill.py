#!/usr/bin/env python3
"""
validate_skill.py — Validate Product Design Evaluator skill directory structure.

Checks that the skill directory has all required files, valid frontmatter,
and correct reference file organization.

Usage:
    python validate_skill.py <skill-directory-path>

Exit codes:
    0 — All validations passed
    1 — One or more validation errors found
"""

import re
import sys
from pathlib import Path


REQUIRED_FILES = [
    "SKILL.md",
    "CHANGELOG.md",
    "assets/report-template.html",
    "assets/developer-log-template.md",
    "references/categories.yaml",
    "references/scoring-rubric.md",
    "references/intake-and-clarification.md",
    "references/task-boundaries.md",
    "references/risk-boundaries.md",
    "references/quality-gate.md",
    "references/report-ui-guidelines.md",
    "references/report-rendering-handoff.md",
    "references/frontend-design-workflow.md",
    "references/missing-info-checklist.md",
    "references/execution-trace.md",
    "references/feedback-loop.md",
    "references/new-category-guide.md",
    "references/image-acquisition-guide.md",
    "references/brand-language/shared-principles.md",
    "references/brand-language/cleaning-appliances.md",
    "references/brand-language/consumer-electronics.md",
    "references/brand-language/personal-care.md",
    "references/category/cleaning-appliances.md",
    "references/category/consumer-electronics.md",
    "references/category/personal-care.md",
    "references/patent-risk/risk-rubric.md",
    "references/patent-risk/legal-framework-cn.md",
    "references/patent-risk/cleaning-appliances-search.md",
    "references/patent-risk/consumer-electronics-search.md",
    "references/patent-risk/personal-care-search.md",
    "scripts/generate_report.py",
    "scripts/quality_check.py",
    "scripts/validate_skill.py",
    "scripts/validate_scores.py",
    "scripts/fetch_competitor_images.py",
    "scripts/__init__.py",
    "evals/evals.json",
    "evals/run_tests.py",
    "agents/openai.yaml",
    # v4.0.0 Multi-Agent files
    "agents/image-analyst/SOUL.md",
    "agents/image-analyst/README.md",
    "agents/brand-judge/SOUL.md",
    "agents/brand-judge/README.md",
    "agents/patent-scout/SOUL.md",
    "agents/patent-scout/README.md",
    "agents/report-builder/SOUL.md",
    "agents/report-builder/README.md",
    "references/multi-agent-protocol.md",
    "scripts/orchestrate_review.py",
    "scripts/agent_input_generator.py",
    "scripts/agent_output_parser.py",
    "evals/multi_agent_evals.json",
]

OPTIONAL_FILES = [
    "LICENSE.txt",
    "LICENSE.frontend-design.txt",
]


def validate_frontmatter(skill_md_content: str) -> list:
    """Validate SKILL.md frontmatter."""
    errors = []
    fm_match = re.match(r"^---\n(.*?)\n---", skill_md_content, re.DOTALL)
    if not fm_match:
        errors.append("SKILL.md: Missing YAML frontmatter")
        return errors

    fm = fm_match.group(1)
    if "name:" not in fm:
        errors.append("SKILL.md frontmatter: Missing 'name' field")
    if "description:" not in fm:
        errors.append("SKILL.md frontmatter: Missing 'description' field")
    else:
        # Check description is not empty
        desc_match = re.search(r"description:\s*(.+)", fm)
        if desc_match and len(desc_match.group(1).strip()) < 20:
            errors.append("SKILL.md frontmatter: Description is too short (< 20 chars)")

    return errors


def validate_template_placeholders(template_content: str) -> list:
    """Check that report template has expected placeholders."""
    errors = []
    expected_placeholders = [
        "{{PROJECT_NAME}}", "{{DATE}}", "{{CATEGORY}}", "{{CONFIDENCE}}",
        "{{FINAL_DECISION}}", "{{DESIGN_SCORE}}", "{{BRAND_FIT}}",
        "{{PATENT_RISK_LEVEL}}", "{{REPORT_VERSION}}",
        "{{PRODUCT_IMAGE}}", "{{IMAGE_SOURCE_CAPTION}}", "{{CONFIRMED_FACTS_ITEMS}}", "{{NEEDS_CONFIRMATION_ITEMS}}",
    ]
    for ph in expected_placeholders:
        if ph not in template_content:
            errors.append(f"report-template.html: Missing placeholder {ph}")

    # Check for feedback buttons
    for btn in ["满意", "一般", "不满意"]:
        if btn not in template_content:
            errors.append(f"report-template.html: Missing feedback button '{btn}'")

    return errors


def load_categories_yaml(skill_dir: Path):
    """Load categories from categories.yaml if available.
    Returns a dict of {category_slug: {display_name, refs...}} or None if unavailable."""
    yaml_path = skill_dir / "references" / "categories.yaml"
    if not yaml_path.exists():
        return None
    try:
        import yaml
        data = yaml.safe_load(yaml_path.read_text(encoding="utf-8"))
        return data.get("categories", {})
    except ImportError:
        # PyYAML not available — return None to signal fallback
        return None


def validate_category_files(skill_dir: Path, categories: dict) -> list:
    """Validate that all category reference files listed in categories.yaml exist."""
    errors = []
    for slug, info in categories.items():
        for ref_key in ("category_ref", "brand_language_ref", "patent_search_ref"):
            ref_path = info.get(ref_key)
            if ref_path:
                full_path = skill_dir / ref_path
                if not full_path.exists():
                    errors.append(f"categories.yaml: {slug}.{ref_key} points to missing file: {ref_path}")
    return errors


def main():
    if len(sys.argv) < 2:
        print("Usage: python validate_skill.py <skill-directory-path>", file=sys.stderr)
        sys.exit(1)

    skill_dir = Path(sys.argv[1])
    if not skill_dir.is_dir():
        print(f"Error: Directory not found: {skill_dir}", file=sys.stderr)
        sys.exit(1)

    print("=" * 60)
    print("Product Design Evaluator — Skill Validation")
    print("=" * 60)
    print(f"\nSkill directory: {skill_dir}\n")

    all_errors = []

    # Check required files
    print("--- FILE STRUCTURE ---\n")
    for f in REQUIRED_FILES:
        path = skill_dir / f
        exists = path.exists()
        status = "✅" if exists else "❌"
        print(f"  {status} {f}")
        if not exists:
            all_errors.append(f"Missing required file: {f}")

    # Check optional files
    print("\n--- OPTIONAL FILES ---\n")
    for f in OPTIONAL_FILES:
        path = skill_dir / f
        exists = path.exists()
        status = "✅" if exists else "—"
        print(f"  {status} {f}")

    # Validate SKILL.md frontmatter
    print("\n--- FRONTMATTER VALIDATION ---\n")
    skill_md_path = skill_dir / "SKILL.md"
    if skill_md_path.exists():
        fm_errors = validate_frontmatter(skill_md_path.read_text(encoding="utf-8"))
        if fm_errors:
            for e in fm_errors:
                print(f"  ❌ {e}")
                all_errors.append(e)
        else:
            print("  ✅ Frontmatter is valid (name and description present)")
    else:
        print("  ❌ SKILL.md not found")
        all_errors.append("SKILL.md not found")

    # Validate template placeholders
    print("\n--- TEMPLATE VALIDATION ---\n")
    template_path = skill_dir / "assets/report-template.html"
    if template_path.exists():
        tpl_errors = validate_template_placeholders(template_path.read_text(encoding="utf-8"))
        if tpl_errors:
            for e in tpl_errors:
                print(f"  ❌ {e}")
                all_errors.append(e)
        else:
            print("  ✅ All expected placeholders and feedback buttons present")
    else:
        print("  ❌ report-template.html not found")
        all_errors.append("report-template.html not found")

    # Validate categories.yaml and category files
    print("\n--- CATEGORY VALIDATION ---\n")
    categories = load_categories_yaml(skill_dir)
    if categories:
        print(f"  ✅ categories.yaml loaded — {len(categories)} categories registered")
        for slug, info in categories.items():
            print(f"     • {slug}: {info.get('display_name', '?')}")
        cat_errors = validate_category_files(skill_dir, categories)
        if cat_errors:
            for e in cat_errors:
                print(f"  ❌ {e}")
                all_errors.append(e)
        else:
            print("  ✅ All category reference files exist")
    else:
        print("  ⚠ categories.yaml not found or PyYAML unavailable — using hardcoded REQUIRED_FILES list")

    # List all files in directory
    print("\n--- DIRECTORY TREE ---\n")
    for item in sorted(skill_dir.rglob("*")):
        if item.is_file():
            rel = item.relative_to(skill_dir)
            print(f"  {rel}")

    # Summary
    print("\n" + "=" * 60)
    if not all_errors:
        print("✅ ALL VALIDATIONS PASSED — Skill structure is complete.")
        sys.exit(0)
    else:
        print(f"❌ {len(all_errors)} VALIDATION ERROR(S):")
        for e in all_errors:
            print(f"   • {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
