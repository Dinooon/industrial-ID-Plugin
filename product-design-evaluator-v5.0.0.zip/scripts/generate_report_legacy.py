#!/usr/bin/env python3
"""
generate_report.py — Automated report generation for Product Design Evaluator.

Reads a JSON data file and an HTML template, replaces all {{PLACEHOLDER}}
variables, and writes the final HTML report.

Usage:
    python generate_report.py --data report_data.json --template assets/report-template.html --output design-review_product_2026-07-07.html

The JSON data file should follow the Frozen Handoff Pack schema defined in
references/report-rendering-handoff.md.
"""

import argparse
import html as html_lib
import json
import re
import sys
from datetime import datetime
from pathlib import Path


def load_template(template_path: str) -> str:
    """Load the HTML template file."""
    path = Path(template_path)
    if not path.exists():
        print(f"Error: Template file not found: {template_path}", file=sys.stderr)
        sys.exit(1)
    return path.read_text(encoding="utf-8")


def load_data(data_path: str) -> dict:
    """Load the JSON data file."""
    path = Path(data_path)
    if not path.exists():
        print(f"Error: Data file not found: {data_path}", file=sys.stderr)
        sys.exit(1)
    return json.loads(path.read_text(encoding="utf-8"))


def build_executive_summary_items(bullets: list) -> str:
    """Convert list of strings into HTML <li> items."""
    if not bullets:
        return "<li>（无摘要内容）</li>"
    return "\n".join(f"<li>{b}</li>" for b in bullets)


def build_list_items(items: list) -> str:
    """Convert list of strings into HTML <li> items."""
    if not items:
        return "<li>（无）</li>"
    return "\n".join(f"<li>{item}</li>" for item in items)


def build_ordered_list_items(items: list) -> str:
    """Convert list of strings into HTML <li> items for <ol>."""
    if not items:
        return "<li>（无）</li>"
    return "\n".join(f"<li>{item}</li>" for item in items)


def esc(value) -> str:
    """Escape small text values used inside generated card markup."""
    return html_lib.escape(str(value or ""), quote=True)


def build_score_rows(scoring_rows: list) -> str:
    """Build HTML for scoring table rows with progress bars."""
    if not scoring_rows:
        return "<p>（无评分数据）</p>"
    html_parts = []
    for row in scoring_rows:
        dimension = row.get("dimension", "")
        score = row.get("score", 0)
        max_score = row.get("max", 100)
        evidence = row.get("evidence", "")
        percentage = (score / max_score * 100) if max_score > 0 else 0
        html_parts.append(
            f'<div class="score-row">'
            f'<div><strong>{dimension}</strong></div>'
            f'<div><div class="bar"><span style="width: {percentage:.0f}%"></span></div>'
            f'<p style="font-size:13px; color:var(--muted); margin:4px 0 0;">{evidence}</p></div>'
            f'<div style="text-align:right; font-weight:700;">{score}/{max_score}</div>'
            f'</div>'
        )
    return "\n".join(html_parts)


def build_comparison_cards(cards: list) -> str:
    """Build HTML for patent comparison cards."""
    if not cards:
        return "<p>（无比对对象）</p>"
    html_parts = []
    for i, card in enumerate(cards, 1):
        name = card.get("object_name", f"Comparison Object {i}")
        source = card.get("source", "")
        thumbnail = card.get("thumbnail")
        visual_type = card.get("visual_type", "")
        comparison_url = card.get("comparison_url") or card.get("source_url") or card.get("url") or ""
        image_reference_url = card.get("image_reference_url") or ""
        similar = card.get("similar_points", [])
        different = card.get("different_points", [])
        rationale = card.get("risk_rationale", "")

        is_fallback = (
            visual_type in {"svg_schematic", "placeholder"}
            or (isinstance(thumbnail, str) and thumbnail.startswith("data:image/svg+xml"))
            or not thumbnail
        )

        media_html = f'<img src="{esc(thumbnail)}" alt="{esc(name)}">' if thumbnail else "image unavailable"
        link_html = []
        if comparison_url:
            link_html.append(f'<a href="{esc(comparison_url)}" target="_blank" rel="noopener">查看公开对象</a>')
        if image_reference_url and image_reference_url != comparison_url:
            link_html.append(f'<a href="{esc(image_reference_url)}" target="_blank" rel="noopener">查看图片来源</a>')
        if is_fallback and not link_html:
            link_html.append('<span class="source-missing">缺少可跳转来源链接</span>')
        actions_html = f'<div class="compare-actions">{"".join(link_html)}</div>' if link_html else ""

        similar_html = "".join(f"<li>{esc(s)}</li>" for s in similar) if similar else "<li>（无）</li>"
        different_html = "".join(f"<li>{esc(d)}</li>" for d in different) if different else "<li>（无）</li>"

        html_parts.append(
            f'<div class="compare-card">'
            f'<div class="compare-media">{media_html}</div>'
            f'<div class="compare-body">'
            f'<h3>{esc(name)}</h3>'
            f'<p><strong>来源：</strong>{esc(source)}</p>'
            f'{actions_html}'
            f'<p><strong>相似点：</strong></p><ul>{similar_html}</ul>'
            f'<p><strong>差异点：</strong></p><ul>{different_html}</ul>'
            f'<p><strong>风险原因：</strong>{esc(rationale)}</p>'
            f'</div></div>'
        )
    return "\n".join(html_parts)


def generate_report(data: dict, template: str) -> str:
    """Replace all placeholders in the template with data values."""
    # Validate scoring data before generating (skip if scoring_rows is intentionally empty)
    try:
        from validate_scores import validate_scores
        if data.get("scoring_rows"):
            errors = validate_scores(data)
            if errors:
                print("Score validation errors:", file=sys.stderr)
                for e in errors:
                    print(f"  - {e}", file=sys.stderr)
                sys.exit(1)
    except ImportError:
        pass  # validate_scores.py not available, skip validation
    replacements = {
        "{{PROJECT_NAME}}": data.get("project_title", "未命名产品"),
        "{{DATE}}": data.get("date", datetime.now().strftime("%Y-%m-%d")),
        "{{CATEGORY}}": data.get("product_category", "未确认"),
        "{{CONFIDENCE}}": data.get("confidence", "Medium"),
        "{{FINAL_DECISION}}": data.get("verdict", ""),
        "{{NEXT_ACTION}}": data.get("next_action", ""),
        "{{DESIGN_SCORE}}": data.get("design_score", "—"),
        "{{BRAND_FIT}}": data.get("brand_language_score", "—"),
        "{{PATENT_RISK_LEVEL}}": data.get("patent_risk_level", "未评估"),
        "{{ACTION_LABEL}}": data.get("decision_label", ""),
        "{{REPORT_VERSION}}": data.get("version", "v1.0"),
        "{{EXECUTIVE_SUMMARY_ITEMS}}": build_executive_summary_items(data.get("executive_summary", [])),
        "{{IMAGE_RELATION_SUMMARY}}": data.get("image_relationship", "未确认"),
        "{{ASSUMPTION_SUMMARY}}": "; ".join(data.get("assumptions", ["无"])) if isinstance(data.get("assumptions"), list) else str(data.get("assumptions", "无")),
        "{{STRENGTH_ITEMS}}": build_list_items(data.get("strengths", [])),
        "{{CONCERN_ITEMS}}": build_list_items(data.get("concerns", [])),
        "{{BRAND_LANGUAGE_REVIEW}}": data.get("brand_language_review", ""),
        "{{BRAND_FIT_LABEL}}": data.get("brand_language_score", ""),
        "{{BRAND_LANGUAGE_REASON}}": data.get("brand_language_reason", ""),
        "{{SCORE_ROWS}}": build_score_rows(data.get("scoring_rows", [])),
        "{{PATENT_RISK_SUMMARY}}": data.get("patent_risk_summary", ""),
        "{{PATENT_COMPARISON_CARDS}}": build_comparison_cards(data.get("patent_comparison_cards", [])),
        "{{RECOMMENDATION_ITEMS}}": build_ordered_list_items(data.get("recommendations", [])),
        "{{NEXT_REVIEW_MATERIALS}}": "; ".join(data.get("next_round_materials", ["无"])) if isinstance(data.get("next_round_materials"), list) else str(data.get("next_round_materials", "无")),
        "{{PRODUCT_IMAGE}}": data.get("product_image", ""),
        "{{IMAGE_SOURCE_CAPTION}}": data.get("image_source_caption", "待评审产品图片"),
        "{{CONFIRMED_FACTS_ITEMS}}": build_list_items(data.get("confirmed_facts", [])),
        "{{NEEDS_CONFIRMATION_ITEMS}}": build_list_items(data.get("needs_confirmation", [])),
    }

    result = template
    for placeholder, value in replacements.items():
        result = result.replace(placeholder, str(value))

    # Warn about unreplaced placeholders
    remaining = re.findall(r"\{\{[A-Z_]+\}\}", result)
    if remaining:
        print(f"Warning: {len(set(remaining))} unreplaced placeholders: {', '.join(set(remaining))}", file=sys.stderr)

    return result


def main():
    parser = argparse.ArgumentParser(description="Generate HTML report from JSON data and template.")
    parser.add_argument("--data", required=True, help="Path to JSON data file (Frozen Handoff Pack format)")
    parser.add_argument("--template", default="assets/report-template.html", help="Path to HTML template file")
    parser.add_argument("--output", required=True, help="Output HTML file path")
    args = parser.parse_args()

    template = load_template(args.template)
    data = load_data(args.data)
    html = generate_report(data, template)

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(html, encoding="utf-8")
    print(f"Report generated: {args.output}")


if __name__ == "__main__":
    main()
