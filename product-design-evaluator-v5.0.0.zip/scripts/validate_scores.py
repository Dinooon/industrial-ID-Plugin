#!/usr/bin/env python3
"""
validate_scores.py — Validate scoring data in a report handoff JSON.

Checks that:
1. All 9 scoring dimensions are present.
2. Each dimension's score is within its max score.
3. Total score equals the sum of dimension scores (with rounding tolerance).
4. Total score does not exceed the Low-confidence cap (79) when confidence is Low.
5. Patent risk is qualitative (not numeric).

Usage:
    from validate_scores import validate_scores
    errors = validate_scores(data_dict)

    # Or via command line:
    python validate_scores.py --data report_data.json
"""

import json
import re
import sys
from pathlib import Path


# Expected scoring dimensions and their max points (must match scoring-rubric.md)
EXPECTED_DIMENSIONS = [
    ("User scenario and concept direction fit", 15),
    ("Form proportion and product recognizability", 15),
    ("Brand design language consistency", 20),
    ("CMF and perceived quality", 12),
    ("Category-specific experience hypothesis", 12),
    ("Interaction, ergonomics, and use-risk visibility", 10),
    ("Innovation and differentiation", 8),
    ("Early structure/process risk alerts", 3),
    ("Proposal expression completeness", 5),
]

EXPECTED_TOTAL = sum(max_score for _, max_score in EXPECTED_DIMENSIONS)  # 100

# Allowed qualitative patent risk labels
VALID_PATENT_RISK_LABELS = {"未评估", "低", "中", "中高", "高", "极高"}

# Allowed confidence labels
VALID_CONFIDENCE_LABELS = {"High", "Medium", "Low"}


def validate_scores(data: dict) -> list:
    """
    Validate the scoring data in a report handoff JSON dict.
    Returns a list of error strings (empty list = all valid).
    """
    errors = []

    scoring_rows = data.get("scoring_rows", [])
    if not scoring_rows:
        errors.append("scoring_rows is empty — at least one scoring row is required")
        return errors

    # Check dimension count
    if len(scoring_rows) != len(EXPECTED_DIMENSIONS):
        errors.append(
            f"Expected {len(EXPECTED_DIMENSIONS)} scoring dimensions, found {len(scoring_rows)}"
        )

    # Check each dimension
    total_score = 0
    for i, row in enumerate(scoring_rows):
        dimension_name = row.get("dimension", "")
        score = row.get("score", 0)
        max_score = row.get("max", 0)

        # Find expected max for this dimension (by partial name match)
        expected_max = None
        for exp_name, exp_max in EXPECTED_DIMENSIONS:
            if exp_name.lower() in dimension_name.lower() or dimension_name.lower() in exp_name.lower():
                expected_max = exp_max
                break

        if expected_max is not None and max_score != expected_max:
            errors.append(
                f"Dimension '{dimension_name}': max score is {max_score}, expected {expected_max}"
            )

        if score < 0:
            errors.append(f"Dimension '{dimension_name}': score {score} is negative")
        if max_score > 0 and score > max_score:
            errors.append(
                f"Dimension '{dimension_name}': score {score} exceeds max {max_score}"
            )

        total_score += score

    # Check total score matches reported design_score
    design_score_str = str(data.get("design_score", ""))
    design_score_match = re.search(r"(\d+)", design_score_str)
    if design_score_match:
        reported_total = int(design_score_match.group(1))
        if abs(reported_total - total_score) > 1:
            errors.append(
                f"Reported design_score ({reported_total}) does not match "
                f"sum of dimension scores ({total_score})"
            )

    if total_score > EXPECTED_TOTAL:
        errors.append(
            f"Total dimension scores ({total_score}) exceed maximum possible ({EXPECTED_TOTAL})"
        )

    # Check Low confidence score cap
    confidence = data.get("confidence", "")
    if confidence == "Low":
        if design_score_match:
            reported_total = int(design_score_match.group(1))
            if reported_total > 79:
                errors.append(
                    f"Score {reported_total} exceeds Low-confidence cap of 79"
                )

    # Check patent risk is qualitative
    patent_risk = str(data.get("patent_risk_level", ""))
    if patent_risk and patent_risk not in VALID_PATENT_RISK_LABELS:
        # Check if it's numeric
        if re.match(r"^\d+(\.\d+)?(/100)?$", patent_risk.strip()):
            errors.append(
                f"Patent risk level '{patent_risk}' is numeric — must be qualitative "
                f"(one of: {', '.join(sorted(VALID_PATENT_RISK_LABELS))})"
            )

    return errors


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Validate scoring data in a report handoff JSON.")
    parser.add_argument("--data", required=True, help="Path to JSON data file")
    args = parser.parse_args()

    data = json.loads(Path(args.data).read_text(encoding="utf-8"))
    errors = validate_scores(data)

    if errors:
        print(f"❌ {len(errors)} validation error(s):")
        for e in errors:
            print(f"  • {e}")
        sys.exit(1)
    else:
        print("✅ All score validations passed.")
        sys.exit(0)


if __name__ == "__main__":
    main()
