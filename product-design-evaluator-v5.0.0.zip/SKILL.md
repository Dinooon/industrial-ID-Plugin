---
name: product-design-evaluator
description: Enterprise internal concept-stage product design evaluation for cleaning appliances and consumer electronics. Use when reviewing one or more product concept images, confirming whether images show the same product, asking for missing context before scoring, scoring industrial design proposals, checking brand design language consistency, flagging appearance patent/design patent risk, quality-gating the output, applying the integrated frontend-design presentation workflow after evaluation content is frozen, using an independent reviewer/subagent when available, and producing a polished HTML review report. Trigger on requests such as "评价产品方案", "工业设计评分", "清洁类家电评审", "消费电子方案评审", "品牌设计语言一致性", "外观专利风险", "方案打分", "审核设计评审质量", "生成设计评审HTML报告", "帮我看看这个产品设计", "评审一下这个方案", "这个设计能打多少分", "帮我做个设计评审", "concept design review", "design critique", or "industrial design evaluation".
---

# Product Design Evaluator

## Overview

Evaluate early concept-stage industrial design proposals for enterprise internal review. Focus on direction, brand fit, visible design quality, concept risk, and next-round recommendations rather than late-stage engineering feasibility.

Use this skill primarily for:

- Cleaning appliances: robot vacuums, floor washers, vacuum cleaners, mite removers, window-cleaning robots, purification/cleaning hardware, bases, docks, and accessories.
- Consumer electronics: phones, earbuds, headphones, speakers, wearables, smart desktop devices, handheld devices, connected hardware, and accessories.
- Personal care: hair dryers, electric toothbrushes, shavers, facial cleansing devices, massagers, and other personal grooming/care devices.

The full list of supported categories is in `references/categories.yaml`. Read it when you need to confirm whether a product fits a supported category or when extending to a new category.

## Language Rules

- SKILL.md instructions and reference files are written in English for consistency.
- User-facing output (HTML report, chat summary, clarification questions) defaults to Chinese (zh-CN) unless the user explicitly requests another language.
- **All evaluation text, verdicts, recommendations, concerns, strengths, and analysis MUST be in Chinese.** Only the following exceptions are permitted in Chinese text:
  - Brand names: eufy, iRobot, Roborock, Ecovacs, Neato, Dyson, Samsung, etc.
  - Technical terms that have no widely accepted Chinese equivalent: LiDAR, LCD, CMF, vSLAM, ABS, LED, USB-C, etc.
  - Product model numbers and identifiers (e.g., S1 Pro, S2, E25).
  - Acronyms widely used as-is in Chinese industry context: AI, IP, ToF, dToF.
- Patent-risk legal terminology follows the target jurisdiction's official language conventions.
- When the user communicates in English or another language, match their language for all user-facing output.
- **Do not use English words where a Chinese equivalent is standard and widely understood.** For example, use "建议修改后推进" not "Proceed with revisions"; use "中等" not "Moderate".

## Confidentiality Rules

- Treat all input images, product names, and context as confidential internal material.
- Do not include product names, images, or identifying details in any external-facing search query or tool call.
- When performing patent-risk searches, use generic category terms (e.g., "robot vacuum design") rather than specific product names or brand identifiers.
- Do not retain or reference confidential input in the developer log beyond what is necessary for process audit.

## Operating Rules

- Treat the review as an internal design critique, not a client pitch.
- Separate `confirmed`, `image-based inference`, and `needs confirmation`.
- Do not overstate what images can prove. Ask for missing text information before scoring when it materially affects category, brand fit, patent risk, or core experience judgment.
- **Image Recognition Verification**: Before finalizing any analysis, perform a dedicated second-pass verification of the product's core visual attributes (body shape, silhouette, sensor layout, key features). If any attribute is ambiguous, explicitly ask the user to confirm. This prevents critical identification errors (e.g., misidentifying a round body as D-shaped) that would invalidate downstream conclusions.
- **Product Image Embedding**: The final HTML report MUST embed the original product image(s) being reviewed. Convert images to base64 data URIs for self-contained reports. Place the product image in a dedicated "产品图片" section near the top of the report, below the header and above the executive summary. Include a caption noting the image source and view angle.
- **Text Conciseness**: All list items in the report (strengths, concerns, recommendations, confirmed facts, needs-confirmation) should be concise — ideally one sentence per item, maximum two. Avoid dense paragraphs. Use the `compact-list` CSS class for tighter spacing. Evidence text in scoring rows should be one sentence.
- For two or more images, always confirm whether they show the same product, different usage states, size variants, design variants, accessories, or separate concepts before final scoring.
- When more than 8 images are provided, ask the user to select the 4-6 most representative views for primary evaluation. Evaluate remaining images as supplementary reference only.
- Do not force a product into cleaning appliances or consumer electronics when the category is unclear. Use `category uncertain` and ask for confirmation; if the user requests immediate output, mark the category as an assumption and lower confidence.
- Score the design proposal on a 100-point concept design rubric.
- Evaluate appearance patent/design risk qualitatively, not with a numeric score. Use `未评估`, `低`, `中`, `中高`, `高`, or `极高`.
- **Patent Comparison Images**: The patent/design risk section MUST include visual comparison images for each comparison object. Follow the image acquisition strategy in `references/image-acquisition-guide.md`. When real competitor images cannot be obtained, generate SVG schematic illustrations as fallback and include a clickable public comparison-object, source, or image-search link on that card so the user can inspect the reference. Never leave comparison cards without any visual element or fallback-source link.
- State that patent-risk output is an internal preliminary screen, not legal advice.
- Default to creating a self-contained HTML report for image-based enterprise reviews unless the user explicitly asks for chat-only output.
- For HTML reports, always run the integrated frontend-design workflow in `references/frontend-design-workflow.md` after evaluation content is frozen. This skill owns scoring, evidence, brand-language judgment, patent/design-risk language, and report boundaries; the frontend-design workflow owns visual hierarchy, layout, responsive HTML, accessibility, and presentation polish. If a separate frontend/report design skill or capability is also available, use it only as an implementation aid after loading the local workflow.
- Do not deliver the report until it passes the quality gate in `references/quality-gate.md`. Use an independent subagent/reviewer when available; otherwise run the self-review checklist and state that independent review was unavailable.
- Keep task boundaries, risk boundaries, execution trace, human review workflow, and quality-gate details out of the user-facing report. Save them in a separate developer log using `assets/developer-log-template.md`.
- End each user-facing report with feedback controls: `满意`, `一般`, `不满意`, plus a short comment field. The feedback buttons are visual-only in the HTML report; the user must send feedback back in chat for the skill to capture and act on it.
- If image quality is too poor to make any reliable judgment (blurred, extremely low resolution, or obscured product), state this clearly and ask for better images rather than forcing a low-confidence evaluation.
- When the user submits a revised version of a previously evaluated concept, reference the prior evaluation findings and focus on what changed, what improved, and what remains unresolved. Use the developer log from the prior evaluation to track iteration progress.
- If no images are provided but the user describes a concept verbally, evaluate based on the text description with reduced confidence (`Low`) and note that visual analysis was not possible. Ask whether images can be provided for a more reliable assessment.

## Reference Loading

Load only the references needed for the current task. If context window is limited, prioritize loading in this order: scoring-rubric > intake-and-clarification > quality-gate > task-boundaries > risk-boundaries > category-specific > brand-language > patent-risk > report-ui-guidelines > frontend-design-workflow > others.

- Always read `references/scoring-rubric.md`.
- Always read `references/intake-and-clarification.md` before scoring image inputs.
- Always read `references/task-boundaries.md`, `references/risk-boundaries.md`, and `references/quality-gate.md`.
- Always read `references/report-ui-guidelines.md` before producing an HTML report.
- Always read `references/frontend-design-workflow.md` before producing or visually polishing an HTML report.
- Read `references/report-rendering-handoff.md` when an HTML report is required, when a frontend/report design skill is available, or when the user mentions `frontend-design`.
- Read `references/missing-info-checklist.md` when images are the main input or key context is missing.
- Read `references/execution-trace.md` and `references/feedback-loop.md` when producing a report or updating the skill.
- For cleaning appliances, read `references/category/cleaning-appliances.md` and `references/brand-language/cleaning-appliances.md`.
- For consumer electronics, read `references/category/consumer-electronics.md` and `references/brand-language/consumer-electronics.md`.
- For personal care, read `references/category/personal-care.md` and `references/brand-language/personal-care.md`.
- Read `references/brand-language/shared-principles.md` for any brand-language consistency review.
- For appearance patent risk, read `references/patent-risk/risk-rubric.md` plus the relevant category search file (cleaning-appliances-search.md, consumer-electronics-search.md, or personal-care-search.md). If category is uncertain, load all category search files and use the closest match. For China-focused risk, also read `references/patent-risk/legal-framework-cn.md`. For non-China markets, apply general design-right principles and recommend local IP counsel review.
- Read `references/image-acquisition-guide.md` before attempting to obtain competitor/patent comparison images.
- Read `references/new-category-guide.md` when the product does not fit cleaning appliances or consumer electronics and the user wants to extend the skill to a new category.
- Read `references/multi-agent-protocol.md` when multi-agent mode is active or when `acp_agent_exec` is available.
- Read the relevant `agents/*/SOUL.md` files when preparing sub-agent task descriptions for multi-agent mode.

## Multi-Agent Architecture (v4.0.0)

This skill supports a **multi-agent architecture** (Architecture A) that distributes the evaluation workload across 4 specialized sub-agents coordinated by the main agent. When `acp_agent_exec` is available, the coordinator delegates evaluation tasks to sub-agents. When multi-agent mode is unavailable, the system falls back to the single-agent workflow described below.

### Sub-Agents

| Agent | Role | SOUL.md | Input Dependency |
|-------|------|---------|-----------------|
| Image Analyst | Product image recognition, visual attribute extraction, recognition verification, category confirmation | `agents/image-analyst/SOUL.md` | Product images + user context |
| Patent Scout | Appearance patent risk screening, competitor image acquisition, visual comparison | `agents/patent-scout/SOUL.md` | Image Analyst output (Mode B) or images directly (Mode A) |
| Brand Judge | Brand design language consistency evaluation | `agents/brand-judge/SOUL.md` | Image Analyst output |
| Report Builder | Score calculation, HTML report generation, embedded quality-gate self-check | `agents/report-builder/SOUL.md` | All three previous agents' outputs |

### Execution Sequence

1. **Coordinator** performs intake and clarification (Steps 1-2 below)
2. **Image Analyst** analyzes images and outputs structured JSON (Step 3)
3. **Patent Scout** + **Brand Judge** run in parallel (Steps 5-6)
4. **Report Builder** generates report and runs quality-gate self-check (Steps 4, 7-8)
5. **Coordinator** performs outer quality-gate review and delivers

### Communication Protocol

See `references/multi-agent-protocol.md` for the full inter-agent communication protocol, including:
- Session directory structure
- JSON file schemas for each agent's input and output
- Error handling and atomic fallback strategy
- Orchestration log format

### Orchestration Scripts

- `scripts/orchestrate_review.py` — State-machine driven orchestrator
- `scripts/agent_input_generator.py` — Generates input JSON for each sub-agent
- `scripts/agent_output_parser.py` — Parses and validates sub-agent output with fault tolerance

### Fallback to Single-Agent Mode

When `acp_agent_exec` is unavailable or any sub-agent fails (timeout, unparseable output, error), the coordinator immediately falls back to the complete single-agent workflow described below. The fallback is **atomic** — no partial results from failed multi-agent attempts are used.

In fallback mode, the developer log must note: `多Agent架构不可用，已回退到单Agent模式`.

---

## Workflow

### Multi-Agent Mode (when acp_agent_exec is available)

When multi-agent mode is active, the coordinator follows this modified workflow:

1. Run intake and task-boundary confirmation (same as single-agent Step 1).
2. Ask clarification questions (same as single-agent Step 2).
3. **Delegate to Image Analyst Agent**: Call `acp_agent_exec` with the task description from `references/multi-agent-protocol.md`. The agent reads `agents/image-analyst/SOUL.md`, analyzes images, and writes structured JSON output. Coordinator parses the output using `scripts/agent_output_parser.py`.
4. *(Scoring is delegated to Report Builder in Step 7.)*
5. **Delegate to Patent Scout Agent**: Call `acp_agent_exec` with Image Analyst's output as input. The agent reads `agents/patent-scout/SOUL.md`, acquires comparison images, and writes structured JSON.
6. **Delegate to Brand Judge Agent**: Call `acp_agent_exec` with Image Analyst's output as input. The agent reads `agents/brand-judge/SOUL.md`, evaluates brand consistency, and writes structured JSON. Steps 5 and 6 may run in parallel.
7. **Delegate to Report Builder Agent**: Call `acp_agent_exec` with all three previous outputs as input. The agent reads `agents/report-builder/SOUL.md`, calculates scores using `references/scoring-rubric.md`, generates the HTML report using `scripts/generate_report.py`, and runs `scripts/quality_check.py` as an embedded self-check.
8. **Outer quality-gate review**: The coordinator reviews the Report Builder's quality-gate result and performs additional checks. If any Critical check failed, the coordinator requests the Report Builder to fix and re-check. When `acp_agent_exec` is available for an independent reviewer, use it for a final independent review.

### Single-Agent Mode (fallback)

1. Run intake and task-boundary confirmation:
   - Product category and subcategory.
   - One or more product images and view angles.
   - Whether multiple images show the same product, different usage states, variants, accessories, or separate concepts.
   - Brand/series and target brand design language references.
   - Target market or jurisdiction for patent risk. Default to China mainland if unspecified.
   - Concept stage, target user, price tier, and intended launch context if available.
   - Output requirement: HTML report, chat summary, or both. Default to HTML plus concise chat summary for enterprise image reviews.
   - If this is a revised submission, ask for the prior evaluation reference or developer log.
   - Set time expectation: "This evaluation typically involves analyzing each image, consulting 3-5 reference files, and generating a structured report. If you need a quick preliminary view, let me know."

2. Ask clarification questions before final scoring:
   - Ask the shortest set of questions needed to confirm image relationship, product category, target brand language, and missing information.
   - If all minimum context fields are already provided in the initial request, skip the clarification step and proceed directly to analysis. State that all required context was received.
   - If only one question can be asked, prioritize image relationship confirmation.
   - If the user has not answered and the task cannot be judged responsibly, pause.
   - If the user explicitly asks for an immediate preliminary review, continue with clearly labeled assumptions.

3. Analyze images with recognition verification:
   - Describe each view separately: silhouette, proportion, volume split, key interaction areas, CMF cues, visible functional elements, seams, openings, wheels, handles, screens, buttons, docks, ports, sensors, and accessories.
   - **Recognition Verification Pass**: After initial description, perform a dedicated second pass focusing on the product's most critical visual attributes. For each attribute, state the observation and confidence level. If any critical attribute (e.g., body shape, sensor presence, material finish) has less than high confidence, add it to the user confirmation list.
   - Combine observations across views into a single product-level judgment.
   - Note inconsistencies between views instead of silently resolving them.
   - If image quality is insufficient for reliable judgment in any view, flag it and exclude that view from scoring rather than guessing.

4. Evaluate concept design only after category handling:
   - Apply the 100-point rubric from `references/scoring-rubric.md`.
   - Use evidence from images and text. If evidence is weak, reduce confidence rather than inventing facts.
   - If category remains uncertain, do not apply category-specific scoring as fact; use a preliminary cross-category review and state what would change after confirmation.
   - Steps 5 and 6 (brand language and patent risk) are independent and may be processed in parallel when subagents are available.

5. Evaluate brand design language:
   - Compare the proposal against shared brand-language principles and category-specific norms.
   - If the user supplied brand references, prioritize those over generic category guidance. If user-provided references are incomplete or contradictory, note the gaps and evaluate against the most reliable subset.
   - Flag whether the proposal looks like a coherent brand family extension, a generic category product, or a competitor-like expression.
   - Consider whether the concept represents a natural evolution of the brand language (positive) or an unexplained departure (risk signal).

6. Evaluate appearance patent risk with comparison images:
   - Use available patent/design references, official databases, user-provided patent packages, or search results when browsing is available and appropriate.
   - **Obtain comparison images**: Follow `references/image-acquisition-guide.md` to acquire real competitor product images or patent drawings. When `scripts/fetch_competitor_images.py` is available, use it to automate image acquisition. If real images cannot be obtained (network restrictions, anti-scraping, etc.), generate SVG schematic illustrations as fallback and keep a clickable comparison/detail/image-search URL for the object — never leave comparison cards without visuals or fallback-source links.
   - Compare overall visual impression first, then visible design features.
   - Report qualitative risk level, similar points, different points, risk reasons, and design-around suggestions.
   - Do not output a numeric patent-risk score.
   - Include comparison thumbnails next to comparison-object names. Prioritize real images; use SVG schematics as fallback; use `image unavailable` placeholder only as last resort. For SVG schematic or placeholder cards, include `comparison_url` or `image_reference_url` and render it as a visible jump link.
   - If no specific patent/design registration or comparable product image is available, mark the risk as `未评估` or `视觉相似信号`, not as a final patent conclusion.
   - Require legal/IP-team review for `中高`, `高`, or `极高` risk.
   - For non-China markets, apply general design-right principles and clearly recommend local IP counsel review.

7. Create report artifacts:
   - Freeze the evaluation content before visual production: verdict, scores, confidence, image relationship, assumptions, findings, patent/design-risk level, comparison objects, recommendations, sources, and feedback controls.
   - Run the integrated frontend-design workflow from `references/frontend-design-workflow.md`: create a compact design plan (color tokens, type roles, layout concept, signature element, and one justified aesthetic risk), critique it against generic AI-design defaults, then build the HTML from the revised plan.
   - If a separate frontend/report design skill or capability is available, hand off the frozen content using `references/report-rendering-handoff.md` and the local frontend-design workflow. Require the frontend/report design skill to improve layout and HTML presentation without changing substantive judgments, scores, risk levels, or legal boundaries.
   - If no frontend/report design skill is available, use `assets/report-template.html` plus `references/report-ui-guidelines.md`. Consider using `scripts/generate_report.py` to automate template variable replacement.
   - Create an HTML report by default using `assets/report-template.html`.
   - Report file name format: `design-review_{product-name-or-identifier}_{YYYY-MM-DD}.html`.
   - Also provide a concise chat summary with the file path when a file is created.
   - Include in the user-facing report: prominent verdict, concise executive summary, input confirmation, design score, brand-language fit, key risks, patent/design risk, prioritized recommendations, short materials-to-add list, and feedback controls.
   - Include a version number (e.g., v1.0) in the report header. If this is an iteration, note the prior version and what changed.
   - Create a separate developer log using `assets/developer-log-template.md` for execution trace, quality-gate result, task boundaries, risk boundaries, and user feedback notes.
   - Log the frontend-design plan, self-critique result, and whether a separate frontend/report design skill was used or the integrated workflow was applied with the local template.

8. Quality-gate before delivery:
   - Run the acceptance checklist in `references/quality-gate.md`. Run each check item by item; for each check, record pass/fail and evidence.
   - If any Critical check fails, return to the relevant workflow step and revise before re-checking.
   - When subagents are available and the report is substantial, ask an independent reviewer/subagent to review the report against the acceptance checklist without giving away intended conclusions.
   - Verify the visual QA checks from `references/frontend-design-workflow.md`, including first-viewport hierarchy, stable image/card dimensions, mobile text fit, print styles, and dark-mode contrast.
   - Revise the report until all Critical must-pass checks pass or clearly state any remaining gaps. Consider using `scripts/quality_check.py` for automated verification.
   - After all checks pass, deliver the report with a concise chat summary.

## Output Structure

Use this order for the user-facing HTML report:

1. Hero verdict, version number, and next action
2. Key indicators: design score, brand-language fit, patent/design risk level, confidence
3. **Product image**: embedded original product image with source caption
4. Executive summary: 2-3 short bullets
5. Input confirmation: image relationship, confirmed facts, assumptions, needs-confirmation items
6. Main findings: strengths, concerns, top risks
7. Brand design language consistency
8. Scoring table with evidence (one sentence per row)
9. Appearance patent/design risk initial screen with comparison images (real images or SVG schematics)
10. Priority recommendations (concise, one sentence per item)
11. Materials to add next time
12. Feedback controls: `满意`, `一般`, `不满意`, comment box

Create a separate developer log for:

- Execution trace
- Human review workflow
- Quality-gate result
- Task and risk boundaries
- User feedback classification
- Version and iteration tracking

## Decision Labels

Use one of these design decisions:

- `Proceed`: Strong direction with manageable risks.
- `Proceed with revisions`: Direction is viable, but specific issues should be corrected before the next review.
- `Rework direction`: Core direction, brand fit, or category logic is weak.
- `Hold for IP/legal review`: Patent/design-right risk is high enough to require specialist review before further visual commitment.

Use one of these confidence labels:

- `High`: multiple views and enough product/brand context.
- `Medium`: enough visual evidence, but some context is inferred.
- `Low`: limited image angles, missing brand/category context, no patent comparison basis, or text-only input.

## Skill Version

Current version: **5.0.0**

## Changelog

See `CHANGELOG.md` for the full version history. Key changes in v5.0.0:

- **Report Visual Overhaul**: Complete rewrite of `assets/report-template.html` and `scripts/generate_report.py` to address 18 identified visual issues (排版混乱/图示缺失/结构不明显/重点不突出).
- **Structured Brand Review**: `brand_language_review` upgraded from plain string to structured object with `brand_dna_summary`, `brand_dna_points[]`, `product_diagnosis`, `critical_gaps[{issue, severity}]`, `key_conclusion`, and optional `annotation_images[]`. Backward compatible with string format.
- **Weighted Findings**: `strengths`/`concerns` upgraded from string arrays to `[{point, weight}]` objects with severity-colored borders (critical=red, high=orange, medium=yellow). Backward compatible.
- **Priority Recommendations**: `recommendations` upgraded from string arrays to `[{action, priority, rationale}]` objects with P0/P1/P2 color-coded borders. Backward compatible.
- **Score Progress Bar Fix**: Unified CSS variable `--bar-w` (was inconsistent between `--w` and `width:`). Added `max-width: 100%` cap to prevent overflow.
- **Score Summary Row**: Total score displayed at the bottom of the scoring section.
- **Multi-Image Support**: `product_images[]` array support with responsive grid layout.
- **Non-Symmetric Findings Grid**: Strengths:concerns = 2:3 ratio to emphasize problems.
- **H2 Auto-Numbering**: CSS counter-based automatic section numbering.
- **Patent Risk Separation**: Badge and summary text on separate lines.
- **Comparison Grid**: Responsive `auto-fill` layout (was fixed 3-column). Lists use ✓/✗ markers.
- **Badge Nesting Fix**: Eliminated double `<span class="badge">` nesting.
- **Global Typography**: Increased line-height (1.52→1.65), paragraph spacing (8px→10px), panel padding (14px→18px), H2 size (18px→20px) with accent border-bottom.
- **Quality Gate**: New Critical checks #22-24 (progress bar CSS variable, score summary, findings grid). New Recommended checks for H2 numbering, brand review component, patent risk separation, comparison grid auto-fill.
- **New Tests**: 4 new test cases in `run_tests.py` for structured brand review, weighted lists, priority recommendations, and multi-image grid.

Key changes in v4.1.0:

- **Image Acquisition Overhaul**: Rewrote `fetch_competitor_images.py` with PIL-based image validation (replaces `file` command dependency), web page image candidate extraction (og:image, twitter:image, JSON-LD, srcset, lazy-load), relative URL to absolute conversion, complete browser HTTP headers, and invalid image filtering (logo/favicon/tracking pixel/small images).
- **Unified Output Data Structure**: Every comparison object now includes `source_type`, `visual_type`, `source_url`, `comparison_url`, `image_reference_url`, `source_note`, `download_status`, and `failure_reason` fields for full traceability.
- **Download Failure Classification**: Failures are classified into 5 categories: `network_restricted`, `http_error`, `not_an_image`, `validation_failed`, `script_error`.
- **SVG Watermark**: All SVG schematics now include a "示意图" watermark in the top-right corner.
- **Report Template Upgrades**: Real image cards display "真实图片" badge with green border; SVG cards display "示意图" badge with yellow border; image source statistics panel added; template variable guide comments auto-removed from final HTML.
- **Quality Gate Expansion**: New Critical checks #20 (image source statistics present) and #21 (no template residue in report).
- **Reference Sync**: `image-acquisition-guide.md` fully rewritten; `quality-gate.md`, `report-rendering-handoff.md`, and Patent Scout `SOUL.md` updated with v4.1.0 output fields.
- **New Test Cases**: 2 new evals (PIL validation + SVG watermark) added to `evals.json`.

Key changes in v4.0.0:

- **Multi-Agent Architecture (Architecture A)**: Upgraded from single-agent to coordinator + 4 specialized sub-agents (Image Analyst, Brand Judge, Patent Scout, Report Builder). Each sub-agent has an independent context window and focused responsibility.
- **Sub-Agent Definitions**: New `agents/` directory with 4 SOUL.md files defining each agent's identity, input/output JSON schemas, rules, and example interactions.
- **Multi-Agent Communication Protocol**: New `references/multi-agent-protocol.md` defines session directory structure, JSON file schemas, execution sequence, error handling, and atomic fallback strategy.
- **Orchestration Scripts**: New `scripts/orchestrate_review.py` (state-machine orchestrator), `scripts/agent_input_generator.py` (input JSON generator), `scripts/agent_output_parser.py` (fault-tolerant output parser).
- **Dual-Layer Quality Gate**: Report Builder performs embedded self-check (Layer 1); coordinator performs outer review (Layer 2). Independent Review is now available when `acp_agent_exec` is available.
- **Atomic Fallback**: When any sub-agent fails, the system atomically falls back to the complete v3.1.0 single-agent workflow. No partial results are used.
- **Script Enhancements**: `generate_report.py` supports `--from-agent-json` mode; `fetch_competitor_images.py` supports `--from-agent-input` mode; `quality_check.py` supports `--from-report-builder` mode.
- **Multi-Agent Test Suite**: New `evals/multi_agent_evals.json` with 6 test cases covering normal flow, fallback, JSON parse failure, parallel timing, and Chinese label consistency.

Key changes in v3.0.0:

- **Personal Care Category**: New category support for hair dryers, toothbrushes, shavers, etc.
- **Category Registry**: `references/categories.yaml` as single source of truth for supported categories.
- **Score Validation**: New `scripts/validate_scores.py` validates scoring data before report generation.
- **Executable Tests**: `evals/run_tests.py` with 10 automated tests.
- **Patent Search SOP**: Step-by-step search procedure added to patent-risk reference files.
- **Weight Rationale**: Comprehensive weight design rationale added to scoring-rubric.md.
- **Bug Fix**: `fetch_competitor_images.py` now attempts real downloads before SVG fallback.
- **Bug Fix**: Removed hardcoded Windows path from frontend-design-workflow.md.
- **Bug Fix**: Template image caption parameterized with `{{IMAGE_SOURCE_CAPTION}}`.
