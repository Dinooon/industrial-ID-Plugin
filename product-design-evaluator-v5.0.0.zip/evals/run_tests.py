#!/usr/bin/env python3
"""
run_tests.py — Executable test suite for Product Design Evaluator SKILL.

Tests are structured as automated assertions that verify:
1. File structure completeness (all required files exist).
2. Template placeholder integrity (all expected placeholders present).
3. Scoring rubric consistency (dimension count, point totals, weight sum).
4. Report generation pipeline (placeholder replacement works).
5. Score validation logic (validate_scores catches common errors).
6. Category registry consistency (categories.yaml matches files on disk).

Usage:
    python evals/run_tests.py [--skill-dir <path>]

Exit codes:
    0 — All tests passed
    1 — One or more tests failed
"""

import json
import os
import re
import subprocess
import sys
from pathlib import Path

# Add parent scripts dir to path for imports
SCRIPT_DIR = Path(__file__).parent.parent / "scripts"
sys.path.insert(0, str(SCRIPT_DIR))


class TestResult:
    def __init__(self, name: str, passed: bool, message: str = ""):
        self.name = name
        self.passed = passed
        self.message = message

    def __str__(self):
        status = "✅ PASS" if self.passed else "❌ FAIL"
        msg = f" — {self.message}" if self.message else ""
        return f"  {status}: {self.name}{msg}"


def run_test(name: str, test_fn) -> TestResult:
    """Run a test function and catch exceptions."""
    try:
        result = test_fn()
        if isinstance(result, TestResult):
            return result
        elif result is True:
            return TestResult(name, True)
        elif result is False:
            return TestResult(name, False, "Test returned False")
        else:
            return TestResult(name, True, str(result))
    except AssertionError as e:
        return TestResult(name, False, str(e))
    except Exception as e:
        return TestResult(name, False, f"Exception: {e}")


def get_skill_dir() -> Path:
    """Get the skill directory path."""
    if len(sys.argv) > 2 and sys.argv[1] == "--skill-dir":
        return Path(sys.argv[2])
    return Path(__file__).parent.parent


# --- Test: File Structure Completeness ---

def test_required_files_exist():
    """All required files listed in validate_skill.py must exist."""
    skill_dir = get_skill_dir()
    from validate_skill import REQUIRED_FILES
    missing = []
    for f in REQUIRED_FILES:
        if not (skill_dir / f).exists():
            missing.append(f)
    assert not missing, f"Missing required files: {', '.join(missing)}"
    return TestResult("Required files exist", True, f"{len(REQUIRED_FILES)} files checked")


# --- Test: Template Placeholder Integrity ---

def test_template_placeholders():
    """Report template must contain all expected placeholders."""
    skill_dir = get_skill_dir()
    from validate_skill import validate_template_placeholders
    template_path = skill_dir / "assets" / "report-template.html"
    template_content = template_path.read_text(encoding="utf-8")
    errors = validate_template_placeholders(template_content)
    assert not errors, f"Template validation errors: {'; '.join(errors)}"
    return TestResult("Template placeholders valid", True)


# --- Test: Scoring Rubric Consistency ---

def test_scoring_dimensions():
    """Scoring rubric must define exactly 9 dimensions totaling 100 points."""
    skill_dir = get_skill_dir()
    rubric_path = skill_dir / "references" / "scoring-rubric.md"
    rubric_content = rubric_path.read_text(encoding="utf-8")

    # Extract dimension table rows
    # Pattern: | Dimension | Points | ... |
    dimension_pattern = r"\|[^|]+\|\s*(\d+)\s*\|"
    matches = re.findall(dimension_pattern, rubric_content)

    assert len(matches) == 9, f"Expected 9 scoring dimensions, found {len(matches)}"
    total = sum(int(m) for m in matches)
    assert total == 100, f"Scoring dimensions total {total}, expected 100"
    return TestResult("Scoring dimensions valid", True, f"9 dimensions, total {total}")


# --- Test: Score Validation Logic ---

def test_validate_scores_valid_data():
    """validate_scores should pass for valid scoring data."""
    from validate_scores import validate_scores, EXPECTED_DIMENSIONS

    valid_data = {
        "scoring_rows": [
            {"dimension": exp_name, "score": exp_max // 2, "max": exp_max, "evidence": "测试证据"}
            for exp_name, exp_max in EXPECTED_DIMENSIONS
        ],
        "design_score": str(sum(exp_max // 2 for _, exp_max in EXPECTED_DIMENSIONS)),
        "confidence": "Medium",
        "patent_risk_level": "低",
    }
    errors = validate_scores(valid_data)
    assert not errors, f"Valid data should not produce errors: {errors}"
    return TestResult("validate_scores accepts valid data", True)


def test_validate_scores_low_confidence_cap():
    """validate_scores should flag scores > 79 with Low confidence."""
    from validate_scores import validate_scores, EXPECTED_DIMENSIONS

    # Create data where total is 85 but confidence is Low
    scores = [15, 15, 20, 12, 10, 8, 3, 2, 0]  # total = 85
    data = {
        "scoring_rows": [
            {"dimension": exp[0], "score": scores[i], "max": exp[1], "evidence": "测试"}
            for i, exp in enumerate(EXPECTED_DIMENSIONS)
        ],
        "design_score": "85/100",
        "confidence": "Low",
        "patent_risk_level": "低",
    }
    errors = validate_scores(data)
    assert any("Low-confidence cap" in e for e in errors), \
        f"Should flag Low confidence score > 79, got errors: {errors}"
    return TestResult("validate_scores flags Low confidence cap violation", True)


def test_validate_scores_numeric_patent_risk():
    """validate_scores should flag numeric patent risk scores."""
    from validate_scores import validate_scores, EXPECTED_DIMENSIONS

    data = {
        "scoring_rows": [
            {"dimension": exp[0], "score": 0, "max": exp[1], "evidence": "测试"}
            for exp in EXPECTED_DIMENSIONS
        ],
        "design_score": "0/100",
        "confidence": "High",
        "patent_risk_level": "75/100",
    }
    errors = validate_scores(data)
    assert any("numeric" in e.lower() for e in errors), \
        f"Should flag numeric patent risk, got errors: {errors}"
    return TestResult("validate_scores flags numeric patent risk", True)


# --- Test: Report Generation Pipeline ---

def test_report_generation():
    """generate_report should replace all placeholders without leftovers."""
    skill_dir = get_skill_dir()
    sys.path.insert(0, str(skill_dir / "scripts"))
    from generate_report import generate_report

    template = (skill_dir / "assets" / "report-template.html").read_text(encoding="utf-8")
    test_data = {
        "project_title": "测试产品",
        "date": "2026-07-08",
        "product_category": "测试品类",
        "confidence": "Medium",
        "verdict": "测试结论",
        "next_action": "测试下一步",
        "design_score": "75/100",
        "brand_language_score": "一致",
        "patent_risk_level": "低",
        "decision_label": "推进",
        "version": "v1.0",
        "executive_summary": ["摘要1", "摘要2"],
        "image_relationship": "单张图片",
        "assumptions": ["假设1"],
        "strengths": ["优势1"],
        "concerns": ["问题1"],
        "brand_language_review": "品牌评审文本",
        "brand_language_reason": "品牌原因",
        "scoring_rows": [],
        "patent_risk_summary": "专利风险摘要",
        "patent_comparison_cards": [],
        "recommendations": ["建议1"],
        "next_round_materials": ["材料1"],
        "product_image": "",
        "image_source_caption": "测试图片来源说明",
        "confirmed_facts": ["已确认1"],
        "needs_confirmation": ["待确认1"],
    }

    result = generate_report(test_data, template)

    # Check that no {{PLACEHOLDER}} remains (except in HTML comments)
    html_without_comments = re.sub(r"<!--.*?-->", "", result, flags=re.DOTALL)
    remaining = re.findall(r"\{\{[A-Z_]+\}\}", html_without_comments)
    assert not remaining, f"Unreplaced placeholders: {', '.join(set(remaining))}"

    # Check key content is present
    assert "测试产品" in result, "Project name not in report"
    assert "测试结论" in result, "Verdict not in report"
    assert "测试图片来源说明" in result, "Image source caption not in report"

    # v5.0.0: Check new template features
    assert "--bar-w" in result, "Missing --bar-w CSS variable (v5.0.0)"
    assert "score-summary" in result, "Missing score-summary (v5.0.0)"
    assert "findings-grid" in result, "Missing findings-grid (v5.0.0)"
    assert "counter-reset" in result, "Missing counter-reset for H2 numbering (v5.0.0)"
    assert "patent-risk-header" in result, "Missing patent-risk-header (v5.0.0)"
    assert "auto-fill" in result, "Missing auto-fill in comparison grid (v5.0.0)"
    assert "brand-review" in result, "Missing brand-review structured component (v5.0.0)"

    return TestResult("Report generation produces valid HTML", True)


# --- Test: Category Registry Consistency ---

def test_category_registry():
    """categories.yaml entries must match files on disk."""
    skill_dir = get_skill_dir()
    yaml_path = skill_dir / "references" / "categories.yaml"

    if not yaml_path.exists():
        return TestResult("categories.yaml exists", False, "File not found")

    try:
        import yaml
    except ImportError:
        return TestResult("categories.yaml validation", True, "PyYAML not available — skipped")

    data = yaml.safe_load(yaml_path.read_text(encoding="utf-8"))
    categories = data.get("categories", {})

    assert len(categories) >= 3, f"Expected at least 3 categories, found {len(categories)}"

    missing_files = []
    for slug, info in categories.items():
        for ref_key in ("category_ref", "brand_language_ref", "patent_search_ref"):
            ref_path = info.get(ref_key)
            if ref_path:
                full_path = skill_dir / ref_path
                if not full_path.exists():
                    missing_files.append(f"{slug}.{ref_key}: {ref_path}")

    assert not missing_files, f"Missing category reference files: {'; '.join(missing_files)}"
    return TestResult("Category registry consistent", True, f"{len(categories)} categories validated")


# --- Test: Fetch Competitor Images Script ---

def test_fetch_competitor_images():
    """fetch_competitor_images.py should produce SVG fallback output."""
    skill_dir = get_skill_dir()
    script_path = skill_dir / "scripts" / "fetch_competitor_images.py"
    output_dir = skill_dir / "tmp_test_images"

    result = subprocess.run(
        [sys.executable, str(script_path),
         "--category", "personal-care",
         "--output-dir", str(output_dir)],
        capture_output=True, text=True, timeout=120
    )

    assert result.returncode == 0, f"Script failed with return code {result.returncode}: {result.stderr}"

    json_path = output_dir / "competitor_images.json"
    assert json_path.exists(), "competitor_images.json not created"

    data = json.loads(json_path.read_text(encoding="utf-8"))
    assert len(data) >= 2, f"Expected at least 2 comparison objects, got {len(data)}"

    for key, obj in data.items():
        assert "image" in obj, f"Missing 'image' field in {key}"
        assert "visual_type" in obj, f"Missing 'visual_type' field in {key}"
        assert "comparison_url" in obj, f"Missing 'comparison_url' field in {key}"
        assert obj["visual_type"] in ("real", "svg_schematic"), \
            f"Invalid visual_type '{obj['visual_type']}' in {key}"
        assert obj["comparison_url"], f"Empty comparison_url in {key}"
        # v4.1.0: unified output structure fields
        assert "source_type" in obj, f"Missing 'source_type' field in {key} (v4.1.0)"
        assert obj["source_type"] in ("real", "svg"), f"Invalid source_type '{obj['source_type']}' in {key}"
        assert "source_note" in obj, f"Missing 'source_note' field in {key} (v4.1.0)"
        assert "download_status" in obj, f"Missing 'download_status' field in {key} (v4.1.0)"
        assert "label" in obj, f"Missing 'label' field in {key} (v4.1.0)"
        # v4.1.0: SVG fallback must have failure_reason
        if obj["source_type"] == "svg":
            assert "failure_reason" in obj, f"Missing 'failure_reason' for SVG fallback in {key} (v4.1.0)"
            assert obj["failure_reason"], f"Empty failure_reason for SVG fallback in {key} (v4.1.0)"
        # v4.1.0: SVG images must contain 示意图 watermark
        if obj["visual_type"] == "svg_schematic":
            import base64 as b64mod
            svg_b64 = obj["image"].split(",", 1)[1] if "," in obj["image"] else obj["image"]
            svg_text = b64mod.b64decode(svg_b64).decode("utf-8")
            assert "示意图" in svg_text, f"SVG schematic missing '示意图' watermark in {key} (v4.1.0)"

    # Cleanup
    import shutil
    if output_dir.exists():
        shutil.rmtree(output_dir)

    return TestResult("fetch_competitor_images.py works", True, f"{len(data)} objects generated")


# --- Test: openai.yaml Version Match ---

def test_openai_yaml_version():
    """openai.yaml version should match SKILL.md version."""
    skill_dir = get_skill_dir()
    try:
        import yaml
    except ImportError:
        return TestResult("openai.yaml version match", True, "PyYAML not available — skipped")

    yaml_data = yaml.safe_load((skill_dir / "agents" / "openai.yaml").read_text(encoding="utf-8"))
    yaml_version = yaml_data.get("metadata", {}).get("version", "")

    skill_md = (skill_dir / "SKILL.md").read_text(encoding="utf-8")
    version_match = re.search(r"Current version:\s*\*?\*?([\d.]+)\*?\*?", skill_md)
    skill_version = version_match.group(1) if version_match else ""

    assert yaml_version == skill_version, \
        f"Version mismatch: openai.yaml={yaml_version}, SKILL.md={skill_version}"
    return TestResult("openai.yaml version matches SKILL.md", True, f"v{skill_version}")


# --- v5.0.0 Tests: Structured Brand Review ---

def test_structured_brand_review():
    """Structured brand_language_review (dict) should render DNA list, diagnosis, gap cards."""
    skill_dir = get_skill_dir()
    sys.path.insert(0, str(skill_dir / "scripts"))
    from generate_report import generate_report, build_brand_review_html

    test_data = {
        "project_title": "测试产品",
        "date": "2026-07-09",
        "product_category": "消费电子",
        "confidence": "中等",
        "verdict": "重做方向",
        "next_action": "重新设计",
        "design_score": "42/100",
        "brand_language_score": "矛盾",
        "patent_risk_level": "高",
        "decision_label": "重做方向",
        "version": "v5.0.0",
        "executive_summary": ["摘要"],
        "image_relationship": "单图",
        "assumptions": ["无"],
        "strengths": [],
        "concerns": [],
        "brand_language_review": {
            "brand_dna_summary": "品牌DNA概述",
            "brand_dna_points": ["DNA原则1", "DNA原则2"],
            "product_diagnosis": "产品诊断文本",
            "critical_gaps": [
                {"issue": "关键差距1", "severity": "high"},
                {"issue": "关键差距2", "severity": "medium"},
            ],
            "key_conclusion": "核心结论"
        },
        "brand_language_reason": "理由",
        "scoring_rows": [],
        "patent_risk_summary": "风险摘要",
        "patent_comparison_cards": [],
        "recommendations": [],
        "next_round_materials": ["无"],
        "product_image": "",
        "image_source_caption": "说明",
        "confirmed_facts": [],
        "needs_confirmation": [],
    }

    template = (skill_dir / "assets" / "report-template.html").read_text(encoding="utf-8")
    result = generate_report(test_data, template)

    assert "brand-dna-list" in result, "Missing brand-dna-list"
    assert "brand-diagnosis-section" in result, "Missing brand-diagnosis-section"
    assert "gap-cards" in result, "Missing gap-cards"
    assert "gap-card severity-high" in result, "Missing high severity gap card"
    assert "brand-verdict-bar" in result, "Missing brand-verdict-bar"
    assert "brand-conclusion" in result, "Missing brand-conclusion"
    assert "核心结论" in result, "Missing key_conclusion text"

    return TestResult("Structured brand review renders correctly", True)


# --- v5.0.0 Tests: Weighted List Items ---

def test_weighted_list_items():
    """Weighted strengths/concerns should render with weight classes."""
    skill_dir = get_skill_dir()
    sys.path.insert(0, str(skill_dir / "scripts"))
    from generate_report import build_weighted_list_items

    items = [
        {"point": "严重问题", "weight": "critical"},
        {"point": "高问题", "weight": "high"},
        {"point": "中问题", "weight": "medium"},
        {"point": "普通项", "weight": "normal"},
        "纯字符串项",
    ]
    html = build_weighted_list_items(items)
    assert "weight-critical" in html, "Missing weight-critical class"
    assert "weight-high" in html, "Missing weight-high class"
    assert "weight-medium" in html, "Missing weight-medium class"
    assert "严重问题" in html, "Missing critical item text"
    assert "纯字符串项" in html, "Missing plain string item"

    # Test backward compatibility with plain string arrays
    plain_items = ["项1", "项2"]
    plain_html = build_weighted_list_items(plain_items)
    assert "项1" in plain_html and "项2" in plain_html, "Plain string items not rendered"
    assert "weight-" not in plain_html, "Plain items should not have weight class"

    return TestResult("Weighted list items render correctly", True)


# --- v5.0.0 Tests: Priority Recommendations ---

def test_priority_recommendations():
    """Priority-tagged recommendations should render with P0/P1/P2 classes."""
    skill_dir = get_skill_dir()
    sys.path.insert(0, str(skill_dir / "scripts"))
    from generate_report import build_priority_list_items

    items = [
        {"action": "紧急建议", "priority": "P0", "rationale": "原因1"},
        {"action": "重要建议", "priority": "P1", "rationale": "原因2"},
        {"action": "普通建议", "priority": "P2", "rationale": "原因3"},
        "纯字符串建议",
    ]
    html = build_priority_list_items(items)
    assert "rec-p0" in html, "Missing rec-p0 class"
    assert "rec-p1" in html, "Missing rec-p1 class"
    assert "rec-p2" in html, "Missing rec-p2 class"
    assert "rec-priority-tag" in html, "Missing priority tag"
    assert "rec-rationale" in html, "Missing rationale"
    assert "紧急建议" in html, "Missing P0 action text"

    # Test backward compatibility
    plain_items = ["建议1", "建议2"]
    plain_html = build_priority_list_items(plain_items)
    assert "建议1" in plain_html, "Plain string recommendations not rendered"
    assert "rec-" not in plain_html, "Plain items should not have priority class"

    return TestResult("Priority recommendations render correctly", True)


# --- v5.0.0 Tests: Multi-Image Grid ---

def test_multi_image_grid():
    """Multi-image product showcase should render grid layout."""
    skill_dir = get_skill_dir()
    sys.path.insert(0, str(skill_dir / "scripts"))
    from generate_report import build_product_images_grid

    # Test multi-image mode
    data_multi = {
        "product_images": [
            {"path": "data:image/png;base64,AAAA", "caption": "正面"},
            {"path": "data:image/png;base64,BBBB", "caption": "背面"},
        ]
    }
    html = build_product_images_grid(data_multi)
    assert "product-images-grid" in html, "Missing product-images-grid class"
    assert html.count("<img") == 2, f"Expected 2 images, found {html.count('<img')}"

    # Test single image (legacy)
    data_single = {"product_image": "data:image/png;base64,XXXX"}
    html_single = build_product_images_grid(data_single)
    assert "<img" in html_single, "Single image not rendered"
    assert "product-images-grid" not in html_single, "Single image should not use grid"

    # Test no images
    data_empty = {}
    html_empty = build_product_images_grid(data_empty)
    assert "未提供产品图片" in html_empty, "Empty state not handled"

    return TestResult("Multi-image grid renders correctly", True)


# --- Main Test Runner ---

def main():
    skill_dir = get_skill_dir()
    print("=" * 60)
    print("Product Design Evaluator — Test Suite")
    print("=" * 60)
    print(f"Skill directory: {skill_dir}\n")

    tests = [
        ("File structure completeness", test_required_files_exist),
        ("Template placeholder integrity", test_template_placeholders),
        ("Scoring rubric consistency", test_scoring_dimensions),
        ("Score validation — valid data", test_validate_scores_valid_data),
        ("Score validation — Low confidence cap", test_validate_scores_low_confidence_cap),
        ("Score validation — numeric patent risk", test_validate_scores_numeric_patent_risk),
        ("Report generation pipeline", test_report_generation),
        ("Category registry consistency", test_category_registry),
        ("Fetch competitor images script", test_fetch_competitor_images),
        ("openai.yaml version match", test_openai_yaml_version),
        ("v5.0.0 structured brand review", test_structured_brand_review),
        ("v5.0.0 weighted list items", test_weighted_list_items),
        ("v5.0.0 priority recommendations", test_priority_recommendations),
        ("v5.0.0 multi-image grid", test_multi_image_grid),
    ]

    results = []
    for name, test_fn in tests:
        result = run_test(name, test_fn)
        results.append(result)
        print(result)

    passed = sum(1 for r in results if r.passed)
    failed = sum(1 for r in results if not r.passed)

    print("\n" + "=" * 60)
    print(f"Results: {passed} passed, {failed} failed, {len(results)} total")

    if failed > 0:
        print(f"\n❌ {failed} test(s) FAILED")
        sys.exit(1)
    else:
        print(f"\n✅ ALL TESTS PASSED")
        sys.exit(0)


if __name__ == "__main__":
    main()
