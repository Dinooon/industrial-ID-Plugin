# Product Design Evaluator SKILL v2.1.0 更新说明

## 更新背景

基于对 eufy 扫地机器人产品图片的实际设计评审案例，用户提出了5个关键反馈问题点。本次更新针对这些问题点进行系统性改进，同时解决了专利评估中真实图片抓取的难题。

## 本次评审案例暴露的5个问题点

### 问题1：产品图片未植入报告
**现象**：生成的HTML报告中没有嵌入用户上传的原始产品图片。
**根因**：SKILL.md 和报告模板中缺少产品图片嵌入的强制规则。
**解决方案**：
- SKILL.md 新增 "Product Image Embedding" 规则，要求报告必须以 base64 data URI 嵌入原始产品图片
- 报告模板新增 `{{PRODUCT_IMAGE}}` 占位符和 "产品图片" 展示区
- 报告结构调整为在 KPI 和执行摘要之间插入产品图片区
- 质量门禁新增 Critical 检查项：产品图片嵌入验证

### 问题2：报告中存在英文词语
**现象**：评审文本中使用了 "Proceed with revisions"、"Moderate" 等英文表述。
**根因**：Language Rules 仅说明默认使用中文，但未明确禁止英文词汇的使用范围。
**解决方案**：
- Language Rules 新增详细的中文输出规则
- 明确定义允许保留英文的4类例外：品牌名、无中文等价的技术术语、型号编号、行业通用缩写
- 提供具体示例："建议修改后推进" 而非 "Proceed with revisions"
- 质量门禁新增检查项（通过脚本自动检测）

### 问题3：未提问缺失信息即开始评分
**现象**：未向用户确认目标市场、品牌参考、导航方案等关键信息就直接开始评分。
**根因**：Workflow 中的确认步骤不够强制，缺少明确的"必须确认"清单。
**解决方案**：
- intake-and-clarification.md 新增 "Recognition Verification Gate" 章节
- 定义必须确认的核心属性清单：机身形状、导航传感器类型、材质处理、产品关系、品牌身份
- Workflow 第3步改为 "Analyze images with recognition verification"，要求二次验证
- 报告新增 "已确认信息" 和 "待确认事项" 两个模块
- 质量门禁新增2个 Critical 检查项

### 问题4：文字排布过密
**现象**：报告中的列表项文字过长，段落密集，可读性差。
**根因**：缺少文字精简规则和紧凑排版样式。
**解决方案**：
- SKILL.md 新增 "Text Conciseness" 规则：每项一句话，最多两句
- 评分行的证据文字限制为一句话
- 报告模板新增 `compact-list` CSS 类和 `image-source-note` 样式
- 质量门禁新增 Recommended 检查项：列表项长度≤300字符

### 问题5：产品识别错误（D形→圆形）
**现象**：将完整圆形机身误识别为D形，将顶部完全平整误识别为有凸起传感器塔。
**根因**：缺少识别验证机制，初次分析结果直接用于后续所有判断。
**解决方案**：
- SKILL.md 新增 "Image Recognition Verification" 规则
- intake-and-clarification.md 新增完整的 "Recognition Verification Gate" 流程
- 定义常见误识别风险清单（圆形/D形混淆、平整/有塔混淆、光泽/哑光混淆等）
- scoring-rubric.md 新增 "Recognition verification impact" 规则：核心属性纠正后必须重新计算所有受影响的维度分数
- 误识别发现后必须重新计算评分，不允许在错误识别基础上修正

## 专利评估真实图片抓取方案

### 问题分析

在评审案例中，尝试获取竞品实物图片用于专利对比时遇到以下障碍：
- Web search 工具额度用尽
- 直接 curl 下载品牌官网图片因 SSL/反爬虫机制失败
- 电商页面返回 HTML 而非图片数据

### 解决方案：多策略图片获取体系

#### 1. 新建 `references/image-acquisition-guide.md`
完整的图片获取策略指南，按优先级定义7层获取路径：
1. 用户提供图片（最优先）
2. 公司内部专利库
3. 官方专利数据库（CNIPA、Espacenet、WIPO、Google Patents）
4. 品牌官方网站
5. 电商平台产品页
6. Web 搜索图片结果
7. SVG 示意图回退（最终保底）

包含 Web Scraping 策略、图片处理流程（验证→缩放→base64编码）、SVG 回退方案指南。

#### 2. 新建 `scripts/fetch_competitor_images.py`
自动化图片获取脚本，功能包括：
- 尝试从公开来源下载真实竞品图片（curl + User-Agent 伪装）
- 验证下载文件是否为有效图片格式
- 使用 PIL 进行图片缩放和 base64 编码
- 内置6种 SVG 示意图模板（圆形无塔、圆形有塔、D形、基站、杆式、通用）
- 自动回退到 SVG 示意图生成
- 输出 JSON 格式的 base64 数据 URI

#### 3. 更新专利风险相关参考文件
- `risk-rubric.md`：强化 Comparison Image Rule，要求每张对比卡必须有视觉元素
- `cleaning-appliances-search.md`：新增 "Comparison Image Acquisition" 章节
- `consumer-electronics-search.md`：同上

## 完整改进清单

### 新增文件（2个）
| 文件 | 用途 |
|---|---|
| `references/image-acquisition-guide.md` | 专利比对图片获取策略指南 |
| `scripts/fetch_competitor_images.py` | 竞品图片自动获取脚本（含SVG回退） |

### 修改文件（12个）
| 文件 | 主要修改内容 |
|---|---|
| `SKILL.md` | 新增图片植入规则、全中文规则、识别验证机制、文字精简规范、专利对比图片要求、版本号v2.1.0、Changelog |
| `references/intake-and-clarification.md` | 新增 Recognition Verification Gate 章节、必须确认项清单 |
| `references/scoring-rubric.md` | 新增识别验证影响规则、证据文字中文要求 |
| `references/quality-gate.md` | 新增7个检查项（5 Critical + 2 Recommended） |
| `references/feedback-loop.md` | 新增已知问题记录章节 |
| `references/patent-risk/risk-rubric.md` | 强化 Comparison Image Rule |
| `references/patent-risk/cleaning-appliances-search.md` | 新增图片获取指引 |
| `references/patent-risk/consumer-electronics-search.md` | 新增图片获取指引 |
| `references/report-rendering-handoff.md` | JSON 结构新增 product_image 字段，强化 thumbnail 要求 |
| `scripts/quality_check.py` | 新增7个自动化检查项 |
| `scripts/validate_skill.py` | 新增2个必需文件、3个模板占位符验证 |
| `assets/report-template.html` | 新增 image-source-note 样式、模板版本注释 |
| `agents/openai.yaml` | 版本号更新至2.1.0、新增关键规则说明 |
| `evals/evals.json` | 新增第6个评估用例（图片植入和中文输出验证） |

### 质量门禁检查项变化
| 级别 | v2.0.0 数量 | v2.1.0 数量 | 新增项 |
|---|---|---|---|
| Critical | 13 | 17 | 产品图片嵌入、已确认信息区、待确认事项区、对比卡视觉元素、产品图片区 |
| Recommended | 6 | 8 | 列表项精简度、对比图片类型追踪 |

## 验证结果

- ✅ 30/30 必需文件全部存在
- ✅ 模板占位符验证通过（12个占位符 + 3个反馈按钮）
- ✅ fetch_competitor_images.py 运行成功，生成4个SVG示意图
- ✅ 质量检查脚本正确识别17个Critical + 8个Recommended检查项
- ✅ 所有新检查项在v2评审报告上验证通过

## 技能版本

**当前版本**：v2.1.0  
**更新日期**：2026-07-07  
**基于案例**：eufy 扫地机器人产品图片设计评审
