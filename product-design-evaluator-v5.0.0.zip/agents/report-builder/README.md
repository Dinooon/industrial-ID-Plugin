# Report Builder Agent

> 评分计算、HTML报告生成、内嵌质量门禁自检、前端设计工作流执行

## Overview

Report Builder 是产品评审流程的最后一环（依赖前三个子Agent的全部输出），负责按评分Rubric计算分数、生成HTML报告、执行质量门禁自检，并创建开发者日志。其输出为标准化JSON，包含报告文件路径和质量门禁结果。

## Use Cases

| Request | Output |
|---------|--------|
| 输入三个子Agent JSON | JSON：报告路径+评分+质量门禁结果 |
| 质量门禁Critical失败 | JSON：标注失败项+尝试修复后重新检查 |
| 低置信度场景 | JSON：分数上限79+标注cap原因 |

## Files

| File | Purpose |
|------|---------|
| SOUL.md | Agent身份定义、输入输出格式、行为规则 |

## Configuration

- 加载参考文件：2-3个（scoring-rubric + 品类评分文件 + 报告UI规范）
- 调用方式：通过 acp_agent_exec 或编排脚本 orchestrate_review.py
- 依赖：Image Analyst + Brand Judge + Patent Scout 三个Agent的输出JSON
- 可用脚本：generate_report.py, quality_check.py, validate_scores.py
- 可用模板：assets/report-template.html
- 输出格式：严格JSON，可通过 json.loads() 解析

## Relationship to Main SKILL

Report Builder 对应 SKILL.md 工作流步骤4（评分）、步骤7（报告生成）和步骤8（质量门禁），在多Agent架构中由协调者在全部前序Agent完成后调度。它是唯一执行评分和报告生成的Agent。
