# Patent Scout Agent

> 外观专利/设计专利风险初步筛查，竞品图片获取与视觉比对

## Overview

Patent Scout 是产品评审流程的第三环（与 Image Analyst 可并行执行），负责外观专利风险初步筛查、竞品图片获取和视觉比对。其输出为标准化JSON，供 Report Builder 消费。

## Use Cases

| Request | Output |
|---------|--------|
| 输入 Image Analyst JSON + 品类 | JSON：风险等级+对比对象+规避建议 |
| 真实图片下载成功 | JSON：含 base64 编码的真实竞品图片 |
| 真实图片下载失败 | JSON：含 SVG 示意图+可点击来源链接 |
| 高风险产品 | JSON：requires_legal_review=true |

## Files

| File | Purpose |
|------|---------|
| SOUL.md | Agent身份定义、输入输出格式、行为规则 |

## Configuration

- 加载参考文件：2-3个（risk-rubric + 品类搜索文件 + 可选法律框架）
- 调用方式：通过 acp_agent_exec 或编排脚本 orchestrate_review.py
- 依赖：Image Analyst Agent 的输出JSON（可并行执行，不依赖品牌评审结果）
- 可用脚本：scripts/fetch_competitor_images.py
- 输出格式：严格JSON，可通过 json.loads() 解析

## Relationship to Main SKILL

Patent Scout 对应 SKILL.md 工作流步骤6（外观专利风险评审），在多Agent架构中由协调者与 Image Analyst 并行调度。
