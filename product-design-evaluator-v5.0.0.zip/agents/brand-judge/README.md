# Brand Judge Agent

> 品牌设计语言一致性评审，判断产品是否属于品牌家族的合理延伸

## Overview

Brand Judge 是产品评审流程的第二环（依赖 Image Analyst 输出），负责将产品的视觉属性与目标品牌的设计语言进行系统对比，输出一致性等级、优点、偏离点和改进建议。其输出为标准化JSON，供 Report Builder 消费。

## Use Cases

| Request | Output |
|---------|--------|
| 输入 Image Analyst JSON + 品牌参考 | JSON：一致性等级+优点+偏离+风险信号+建议 |
| 品牌参考不完整 | JSON：标注参考缺口+基于最可靠子集评估 |
| 无品牌参考 | JSON：标注"无品牌参考"+按通用品类规范评估 |

## Files

| File | Purpose |
|------|---------|
| SOUL.md | Agent身份定义、输入输出格式、行为规则 |

## Configuration

- 加载参考文件：2个（shared-principles.md + 品类品牌语言文件）
- 调用方式：通过 acp_agent_exec 或编排脚本 orchestrate_review.py
- 依赖：Image Analyst Agent 的输出JSON
- 输出格式：严格JSON，可通过 json.loads() 解析

## Relationship to Main SKILL

Brand Judge 对应 SKILL.md 工作流步骤5（品牌设计语言评审），在多Agent架构中由协调者在 Image Analyst 完成后调度。
