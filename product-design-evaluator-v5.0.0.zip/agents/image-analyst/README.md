# Image Analyst Agent

> 产品图片识别、核心视觉属性提取、二次验证门禁、品类确认

## Overview

Image Analyst 是产品评审流程的第一环，负责从产品图片中提取结构化的视觉属性数据，执行二次识别验证，并确认产品品类。其输出为标准化JSON，供后续子Agent（Brand Judge、Patent Scout、Report Builder）消费。

## Use Cases

| Request | Output |
|---------|--------|
| 输入产品图片+品类提示 | JSON：产品识别+视觉属性+验证结果+待确认项 |
| 输入多张图片 | JSON：含图片关系判断（同一产品/不同角度/不同方案） |
| 输入模糊图片 | JSON：标注低置信度属性+列出待确认项 |

## Files

| File | Purpose |
|------|---------|
| SOUL.md | Agent身份定义、输入输出格式、行为规则 |

## Configuration

- 加载参考文件：1-2个（品类参考文件 + 可选的categories.yaml）
- 调用方式：通过 acp_agent_exec 或编排脚本 orchestrate_review.py
- 输出格式：严格JSON，可通过 json.loads() 解析

## Relationship to Main SKILL

Image Analyst 对应 SKILL.md 工作流步骤3（图片分析与识别验证），在多Agent架构中由协调者调度，替代主Agent的图片识别职责。
