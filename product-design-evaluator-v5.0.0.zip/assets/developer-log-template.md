# Developer Log — Product Design Review

> Copy this template for each evaluation. Fill in the factual fields only.
> Do not include private reasoning, hidden deliberation, or irrelevant tool logs.

## Project Meta

- **Project name**: {{project_name}}
- **Date**: {{date}}
- **Evaluator version**: {{skill_version}} (report v{{report_version}})
- **Prior evaluation reference**: {{prior_eval_ref or "N/A (first evaluation)"}}

## Execution Trace

### Input

- Images received: {{image_count}}
- Image relationship: {{image_relationship or "not confirmed"}}
- Image quality assessment: {{image_quality or "not assessed"}}
- Text context received: {{text_context_summary or "minimal"}}
- Product category confirmed: {{category or "uncertain"}}

### Clarifications

- Questions asked: {{questions_asked}}
- User confirmations: {{confirmations_received or "none"}}
- Assumptions made: {{assumptions_made}}

### References Loaded

- Scoring rubric: yes
- Category guide: {{category_guide_loaded}}
- Brand-language guide: {{brand_guide_loaded}}
- Patent-risk guide: {{patent_guide_loaded}}
- Other: {{other_references or "none"}}

### Evaluation Scope

- What was scored: {{scored_items}}
- What was excluded: {{excluded_items or "none"}}

### Output

- Chat summary: yes/no
- HTML report: {{html_report_path or "not generated"}}
- Patent-risk section: {{patent_section_status or "not assessed"}}
- Other artifacts: {{other_artifacts or "none"}}

### Frontend Design Pass

- Integrated frontend-design workflow used: {{frontend_design_workflow_used or "no"}}
- Separate frontend/report design skill used: {{separate_frontend_skill_used or "no"}}
- Design plan summary: {{frontend_design_plan or "N/A"}}
- Self-critique result: {{frontend_design_critique or "N/A"}}
- Visual QA caveats: {{frontend_visual_qa_caveats or "none"}}

### Quality Gate

- Independent review performed: yes/no
- Self-review performed: yes/no
- Quality-gate result: {{gate_result}}
- Unresolved caveats: {{caveats or "none"}}

## Time Tracking

- Intake and clarification: {{time_intake or "not tracked"}} min
- Image analysis: {{time_analysis or "not tracked"}} min
- Scoring: {{time_scoring or "not tracked"}} min
- Brand review: {{time_brand or "not tracked"}} min
- Patent review: {{time_patent or "not tracked"}} min
- Report creation: {{time_report or "not tracked"}} min
- Quality gate: {{time_gate or "not tracked"}} min

## Key Findings Summary

- Design score: {{design_score}}/100
- Confidence: {{confidence}}
- Brand-language fit: {{brand_fit}}
- Patent risk level: {{patent_risk}}
- Top strengths: {{top_strengths}}
- Top concerns: {{top_concerns}}
- Top risks: {{top_risks}}

## Feedback Received

- User feedback: {{user_feedback or "not yet received"}}
- Feedback tags: {{feedback_tags or "none"}}

## Suggested Skill Update

If this evaluation revealed a recurring issue or missing capability:

- Issue: {{skill_issue or "none identified"}}
- Suggested update: {{skill_update_suggestion or "none"}}

## Notes

{{additional_notes or "none"}}
