# Risk Boundaries

Use this file to avoid overconfident or unsafe outputs.

## Legal And Patent Risk Boundary

- Appearance patent risk is only a preliminary internal screen.
- Do not state that a design infringes, does not infringe, is valid, invalid, patentable, or legally safe.
- If no patent search or patent references were used, say: `No patent comparison basis was provided or searched; patent-risk score is not assessed.`
- If patent risk is medium-high or above, recommend IP/legal review before external disclosure or further visual commitment.
- Identify what evidence is missing for a stronger patent review.

## Brand Confidentiality Boundary

- Do not use specific product names, brand identifiers, or internal project names in any external search query or tool call.
- When performing patent-risk searches, use generic category terms (e.g., "robot vacuum design patent") rather than brand-specific queries.
- Do not reference confidential input images or product details in external-facing communications.
- In the developer log, use generic identifiers rather than full confidential product names when possible.

## Image Interpretation Boundary

- Images cannot confirm actual weight, material feel, tactile quality, noise, thermal behavior, battery life, water resistance, cleaning performance, motor performance, structural strength, or manufacturing cost.
- Mark these as `needs confirmation` unless text evidence is provided.
- Do not infer hidden internal architecture from attractive exterior renderings.

## Category Boundary

- If product category is unclear, do not choose a category for final scoring.
- If a closest category is used for preliminary review, label it as an assumption.
- Do not apply cleaning-appliance-specific criteria to a non-cleaning product unless the user confirms that branch.

## Brand Boundary

- If no official brand guideline is provided, evaluate against general public-facing product-family cues only.
- Avoid claiming official brand compliance.
- Use phrasing such as `appears aligned with`, `partially recalls`, or `does not strongly support`.

## Output Boundary

- The report supports internal decision-making; it is not a launch approval.
- Scores are directional and should be revisited after additional images, specs, usage flow, and brand references are provided.
- When confidence is Low, the score is capped at 79 and should be revisited with better input.
