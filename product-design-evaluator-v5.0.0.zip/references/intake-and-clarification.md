# Intake And Clarification Gate

Run this gate before final scoring. The goal is to prevent premature category selection, unsupported assumptions, and incomplete image interpretation.

## Fast Path

If all minimum context fields are already provided in the initial request (product category, image relationship, target brand, output mode, and target market for patent risk), skip the clarification step and proceed directly to analysis. State: "所有必要信息已收到，直接进入分析阶段。" This avoids unnecessary delays when the user provides a well-structured brief.

## Multi-Image Relationship

When the user provides two or more images, ask or confirm:

- Are these images the same product from different angles?
- Are they the same product in different usage states?
- Are they different size variants in one product family?
- Are they different design alternatives to compare?
- Are any images accessories, packaging, docks, blades, charging cases, or service parts?

Do not merge images into one product-level judgment until this relationship is confirmed or explicitly marked as an assumption.

## Category Confirmation

Before loading category-specific scoring as fact, classify confidence:

- `confirmed`: user names the product category or the image clearly shows it.
- `probable`: visual evidence strongly suggests a category, but user has not confirmed.
- `uncertain`: product category or use scenario is unclear.

If `probable` or `uncertain`, ask a direct question:

`请确认该产品是什么品类/用途？我目前只能初步判断为 [assumption]，确认后才能进入正式评分。`

If the user asks for immediate output, continue only as a preliminary review and label category assumptions in the report.

## Minimum Context Before Final Scoring

Require these fields for final scoring:

- Product category and use scenario.
- Whether multiple images are same product, states, variants, or alternatives.
- Target brand or brand family to compare.
- Target market if patent risk is requested.
- Output mode: HTML report, chat summary, or both.

If these are missing, ask concise questions first. If the user declines or says to proceed, lower confidence and list all assumptions.

## Clarification Question Limit

Ask no more than 3 Must-Have questions + 2 optional questions at once (maximum 5 total). Use the question priority matrix below to select which questions to ask when context is limited.

### Question Priority Matrix

| Priority | Question | When to Ask | Skip If |
|---|---|---|---|
| 1 (Must-Have) | Image relationship: same product, different views, variants, or separate concepts? | 2+ images provided | Only 1 image provided |
| 2 (Must-Have) | Product category and use scenario | Category not stated by user | User explicitly states category |
| 3 (Must-Have) | Target brand or brand family for comparison | Brand not mentioned | User says "no brand reference" |
| 4 (Optional) | Target market for patent risk | Patent risk is requested and market not specified | User says "no patent risk needed" |
| 5 (Optional) | Any single high-impact Nice-to-Have from missing-info-checklist | All Must-Have answered, useful context still missing | All useful context provided |

### Selection Rules

1. If only one question can be asked, prioritize image relationship confirmation.
2. If all Must-Have fields are already provided in the initial request, skip the clarification step entirely. State: "所有必要信息已收到，直接进入分析阶段。"
3. If the user explicitly asks for an immediate preliminary review, continue with clearly labeled assumptions. Do not block.
4. Nice-to-Have items from `missing-info-checklist.md` should only be asked if all Must-Have items are already confirmed or assumed. Never lead with Nice-to-Have questions.
5. When the Recognition Verification Gate identifies low-confidence attributes, those become additional Must-Have questions for the second round (after initial analysis).

## Non-Image Input Handling

If no images are provided but the user describes a concept verbally:

- Evaluate based on the text description with confidence set to `Low`.
- Note in the report: "本次评审基于文字描述，未进行视觉分析。提供图片后可获得更可靠的评估。"
- Ask whether images can be provided for a more reliable assessment.
- Do not assign scores above 79 (see scoring-rubric.md Confidence-Based Score Cap).
- Focus the evaluation on concept direction, scenario fit, and brand language logic rather than form proportion or CMF, which require visual evidence.

## Image Quality Assessment

Before proceeding with detailed analysis, assess image quality:

- `sufficient`: Images are clear enough to identify silhouette, proportions, key features, and CMF cues.
- `marginal`: Images are usable but some details are unclear (low resolution, partial obstruction, poor lighting). Note which details are unreliable.
- `insufficient`: Images are too blurred, low resolution, or obscured to make any reliable judgment. State this clearly: "图片质量不足以进行可靠评审，请提供更清晰的图片。" Do not force a low-confidence evaluation with insufficient images.

If some views are sufficient and others are insufficient, proceed with the sufficient views and exclude the insufficient ones from scoring.

## Recognition Verification Gate

After initial image analysis, perform a dedicated **Recognition Verification Pass** before finalizing any conclusions. This gate prevents critical identification errors that would invalidate downstream scoring, brand-language, and patent-risk conclusions.

### Procedure

1. List the product's core visual attributes (e.g., body shape, sensor tower presence, material finish, color, key features).
2. For each attribute, state the observation and confidence level (high/medium/low).
3. If any critical attribute has less than high confidence, add it to the user confirmation list.
4. Common misidentification risks:
   - Round body misidentified as D-shaped (or vice versa) — verify by checking if the entire outer edge is a continuous curve.
   - Flat top misidentified as having a sensor tower — verify by checking for any protrusion above the main body plane.
   - Glossy finish misidentified as matte (or vice versa) — verify by checking light reflections and highlights.
   - Single product misidentified as multiple products — verify by checking if components are physically connected or part of the same system.
5. If a misidentification is discovered after initial analysis, **recalculate all affected scores and conclusions** before generating the report.

### Mandatory Confirmation Items

When the following attributes cannot be determined with high confidence from images alone, they MUST be included in the user confirmation questions:

- Body shape (round, D-shaped, square, other)
- Navigation sensor type (LiDAR tower, camera/vision, infrared, ultrasonic, none visible)
- Primary material finish (glossy, matte, textured)
- Product relationship (same product different views, product + accessory, separate products)
- Brand identity (if logo is unclear or ambiguous)
