# Task Boundaries

Use this skill for early concept-stage internal design evaluation. Keep the boundary explicit.

## In Scope

- Product concept image review.
- Multi-angle image interpretation.
- Confirmation of whether images are same product, different states, variants, or alternatives.
- Cleaning appliance and consumer electronics concept scoring.
- Adjacent handheld electronic tools when the user explicitly requests the same evaluation logic.
- Brand design language consistency review.
- Missing-information prompts for hidden product details.
- Early appearance patent-risk screening when references or search access are available.
- HTML report generation for internal review.
- Quality-gate review and user feedback capture.
- Iteration evaluation (revised concept follow-up review).
- Text-only concept description evaluation (with reduced confidence).

## Out Of Scope Unless Explicitly Requested

- Final engineering feasibility validation.
- Detailed cost/BOM calculation.
- Certified ergonomics or safety compliance.
- Full patent freedom-to-operate opinion.
- Final legal conclusion on infringement, validity, or registrability.
- Market sales forecast.
- Manufacturing process release decision.

## Frequently Requested But Out Of Scope

These are common requests that fall outside the skill's scope. Handle them by stating the boundary and providing a preliminary design-facing view:

- **"Can you tell me if this design will sell well?"** — Market sales forecast is out of scope. Provide a design-quality view only and recommend product management or market research for sales validation.
- **"Can you verify the structural integrity of this design?"** — Engineering feasibility is out of scope. Flag visible structural risks as early alerts only and recommend engineering review.
- **"Can you confirm this design doesn't infringe any patent?"** — Full freedom-to-operate opinion is out of scope. Provide preliminary visual-similarity screening only and recommend IP/legal review.
- **"Can you calculate the manufacturing cost?"** — Cost/BOM calculation is out of scope. Note visible complexity signals and recommend cost engineering review.
- **"Can you certify this design is ergonomically safe?"** — Certified ergonomics compliance is out of scope. Flag visible ergonomic concerns and recommend UX research or ergonomics certification.

## Boundary Handling

If a task falls outside scope:

- State the boundary plainly.
- Provide a preliminary design-facing view if useful.
- Recommend the responsible reviewer: engineering, UX research, CMF specialist, product management, IP/legal, or supplier/manufacturing.

## Adjacent Category Handling

If the product is not a cleaning appliance or standard consumer electronics but is an adjacent powered consumer product:

- Ask the user whether to evaluate it using the closest branch.
- Use `adjacent powered consumer product` as the category until confirmed.
- Do not pretend the category-specific rubric fully applies.

## Adding a New Category

When the product does not fit cleaning appliances or consumer electronics and the user wants to extend the skill:

1. Confirm the new category name and scope with the user.
2. Create a new reference file at `references/category/{category-name}.md` following the same structure as existing category files (Product Types, Sub-Category Focus, Core Concept Questions, Image Evidence, Concept Risks, Cross-Category Handling, Recommendations).
3. Create a new brand-language reference at `references/brand-language/{category-name}.md` following the same structure (Category Brand Cues, Visual Elements, Strong Brand Fit Signals, High-Risk Signals, Competitor Patterns, Sub-Category Brand Focus).
4. Create a patent-risk search reference at `references/patent-risk/{category-name}-search.md` with search keywords, recommended databases, comparison features, and common high-risk patterns.
5. Update SKILL.md to include the new category in the Overview and Reference Loading sections.
6. Test the new category with 2-3 evaluation cases before finalizing.
