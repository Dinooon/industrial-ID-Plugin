# Personal Care Patent Search Guidance

Use this guidance when screening hair dryers, electric toothbrushes, shavers, facial cleansing devices, massagers, and similar personal care products.

## Search Keywords

Use Chinese and English terms as needed. Use generic category terms only; do not include brand or product names in search queries to maintain confidentiality:

- 吹风机, 电吹风, 电动牙刷, 剃须刀, 电动剃须刀, 洁面仪, 按摩仪, 美容仪
- 手柄, 刷头, 刀头, 喷嘴, 充电底座, 旅行盒
- hair dryer, electric toothbrush, shaver, electric razor, facial cleansing brush, massager, beauty device, charging base, travel case

## Step-by-Step Search SOP

Follow this procedure for each patent-risk screening session. Record each step's results in the developer log.

### Step 1: Define Comparison Scope

- List 3-5 comparison objects based on the evaluated product's category and visible features.
- For each object, note the key visual feature that makes it a relevant comparison (e.g., "L-shaped hair dryer with ring motor housing", "cylindrical toothbrush with colored accent ring").
- Prioritize objects that share the most visible design features with the evaluated product.

### Step 2: Search Official Patent Databases

- **CNIPA** (China mainland focus):
  1. Open http://pss-system.cponline.cnipa.gov.cn
  2. Search by Locarno Classification: 07-02 (hair care appliances), 28-03 (cosmetics/toiletries), 23-01 (body care devices)
  3. Add keyword filters using generic terms (e.g., "hair dryer design")
  4. Browse result thumbnails, noting registration numbers and images of visually similar designs
  5. Record patent number, title, filing date, legal status, and thumbnail URL

- **Espacenet / WIPO** (international focus):
  1. Open https://worldwide.espacenet.com
  2. Use Advanced Search with design classification codes
  3. Filter by filing date (last 5 years for active patents, last 15 years for design-right reference)
  4. Record relevant results

### Step 3: Search Google Patents

- Use `info_search_web` with query: `"hair dryer" OR "electric toothbrush" OR "shaver" design patent site:patents.google.com`
- Visit top 3-5 results using `info_reader_web`
- Extract design patent drawings as comparison images where available
- Record patent numbers and direct URLs

### Step 4: Acquire Comparison Images

Follow `references/image-acquisition-guide.md` priority order:
1. If user provided internal patent images → use directly
2. If patent database thumbnails are accessible → download via curl
3. If web search returns product images → download and validate
4. If all downloads fail → generate SVG schematics with `scripts/fetch_competitor_images.py`
5. For every fallback card, preserve at least one public lookup URL

### Step 5: Compare and Assess

For each comparison object:
- Compare overall visual impression first (would a consumer confuse them at a glance?)
- Then compare specific features: body geometry, grip zone, control placement, charging interface
- Note similar points and different points
- Assign qualitative risk level: 低/中/中高/高/极高
- If risk is 中高 or above, recommend IP/legal team review

### Step 6: Record Results

Use the Search Result Format below to record each comparison object. Include all fields even if "not available".

## Recommended Databases

- **China**: CNIPA Patent Search (http://pss-system.cponline.cnipa.gov.cn) — search by Locarno Classification for personal care categories.
- **International**: Espacenet (https://worldwide.espacenet.com), WIPO Hague Express (https://www3.wipo.int/hague/en/).
- **Company internal**: Prioritize company-internal patent pools and prior design files when available.

## Compare These Features

- Overall body geometry: cylindrical, capsule, L-shaped, angular, pebble, ring
- Grip zone: material, texture, transition line, diameter, length
- Control interface: button type (physical, capacitive, hidden), placement, size, feedback
- Functional end: brush head, nozzle, cutting head, contact surface — connection type and visual integration
- Charging solution: inductive base, USB port, contacts — placement and visual treatment
- Color and material strategy: body color, accent color, material transitions
- LED/indicator: type (dot, ring, strip), placement, visibility from use posture
- Accessory integration: travel case, charging stand, attachment holder

## Common High-Risk Patterns

- Hair dryer body geometry closely matching a market leader's distinctive silhouette (e.g., ring motor housing, L-shaped handle)
- Electric toothbrush body diameter and accent ring placement closely matching a registered design
- Shaver head geometry and body contour closely matching a competitor's registered design
- Facial cleansing device full-body silicone treatment and form factor matching a market leader
- Charging base/stand design closely matching a registered design patent

## Design-Around Levers

- Change the primary body silhouette rather than only surface details
- Rework the grip zone treatment (material, texture, transition line)
- Redesign the control interface (different button type, placement, or feedback mechanism)
- Alter the functional end connection language
- Create a distinctive charging solution rather than copying the category standard
- Develop a brand-specific color/material strategy that differentiates from market leaders

## Comparison Image Acquisition

For each comparison object, obtain a visual reference following `references/image-acquisition-guide.md`:

1. **Try real images first**: Download from official brand websites, e-commerce pages, or patent databases.
2. **Use web reader tools**: Fetch product pages to extract image URLs, then download.
3. **Fall back to SVG schematics**: Generate stylized illustrations representing the key visual features of each comparison object type.
4. **Never leave a comparison card without a visual or fallback link**: Every card must have either a real image, an SVG schematic, or a clearly labeled placeholder with source note. SVG schematic and placeholder cards must also include a public comparison/source/image lookup URL.

Common comparison object types for personal care and their SVG templates:
- Hair dryer (L-shaped body, motor housing, handle, nozzle)
- Electric toothbrush (cylindrical body, brush head, button)
- Shaver (capsule body, cutting head, body contour)
- Charging base/stand

Use `scripts/fetch_competitor_images.py` to automate this process.

## Search Result Format

Format each search result for the report:

```
Comparison Object [N]:
- Name/Title: [patent title or generic product description]
- Source: [database, URL, or "user-provided"]
- Comparison URL: [public patent/detail/product/search URL]
- Image Reference URL: [direct image/source URL, or "not available"]
- Patent Number: [number, or "not available"]
- Legal Status: [active / expired / unknown]
- Category: [Locarno class, or "not available"]
- Thumbnail: [image, or "image unavailable"]
- Similar Points: [list]
- Different Points: [list]
- Risk Rationale: [explanation]
```
