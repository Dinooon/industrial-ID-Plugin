# Consumer Electronics Patent Search Guidance

Use this guidance when screening phones, earbuds, headphones, speakers, wearables, smart desktop devices, handheld electronics, connected hardware, cases, docks, and accessories.

## Search Keywords

Use Chinese and English terms as needed. Use generic category terms only; do not include brand or product names in search queries to maintain confidentiality:

- 手机, 平板, 耳机, 蓝牙耳机, 头戴耳机, 音箱, 智能手表, 智能手环, 智能戒指, 摄像头, 智能音箱, 充电盒, 充电座
- phone, tablet, earbuds, headphones, speaker, wearable, smartwatch, smart ring, smart band, charging case, dock, smart hub, camera

## Step-by-Step Search SOP

Follow this procedure for each patent-risk screening session. Record each step's results in the developer log.

### Step 1: Define Comparison Scope

- List 3-5 comparison objects based on the evaluated product's category and visible features.
- For each object, note the key visual feature that makes it a relevant comparison (e.g., "stem-type earbud with charging case", "over-ear headphones with rounded cups").
- Prioritize objects that share the most visible design features with the evaluated product.

### Step 2: Search Official Patent Databases

- **CNIPA** (China mainland focus):
  1. Open http://pss-system.cponline.cnipa.gov.cn
  2. Search by Locarno Classification: 06-01 (audio equipment), 14-02 (data processing), 14-03 (telecommunications)
  3. Add keyword filters using generic terms (e.g., "wireless earbuds charging case")
  4. Browse result thumbnails, noting registration numbers and images of visually similar designs
  5. Record patent number, title, filing date, legal status, and thumbnail URL

- **Espacenet / WIPO** (international focus):
  1. Open https://worldwide.espacenet.com
  2. Use Advanced Search with design classification codes
  3. Filter by filing date (last 5 years for active patents, last 15 years for design-right reference)
  4. Record relevant results

### Step 3: Search Google Patents

- Use `info_search_web` with query: `"wireless earbuds" OR "headphones" design patent site:patents.google.com`
- Visit top 3-5 results using `info_reader_web`
- Extract design patent drawings as comparison images where available
- Record patent numbers and direct URLs

### Step 4: Acquire Comparison Images

Follow `references/image-acquisition-guide.md` priority order:
1. If user provided internal patent images → use directly
2. If patent database thumbnails are accessible → download via curl
3. If web search returns product images → download and validate
4. If all downloads fail → generate SVG schematics with `scripts/fetch_competitor_images.py`
5. For every fallback card, preserve at least one public lookup URL

### Step 5: Compare and Assess

For each comparison object:
- Compare overall visual impression first (would a consumer confuse them at a glance?)
- Then compare specific features: body geometry, dominant face, edge language, CMF
- Note similar points and different points
- Assign qualitative risk level: 低/中/中高/高/极高
- If risk is 中高 or above, recommend IP/legal team review

### Step 6: Record Results

Use the Search Result Format below to record each comparison object. Include all fields even if "not available".

## Recommended Databases

- **China**: CNIPA Patent Search (http://pss-system.cponline.cnipa.gov.cn) — search by Locarno Classification for consumer electronics categories.
- **International**: Espacenet (https://worldwide.espacenet.com), WIPO Hague Express (https://www3.wipo.int/hague/en/).
- **Company internal**: Prioritize company-internal patent pools and prior design files when available.

## Compare These Features

- Main geometry: slab, capsule, pebble, cylinder, puck, band, ring, shell, clamshell.
- Dominant face: screen, grille, camera/sensor array, button/touch area, LED zone.
- Edge and corner language: radius size, chamfer, layered frame, raised rim, continuous glass, metal band.
- Openings and details: speaker holes, mic holes, port, hinge, strap lug, charging contacts.
- Accessory logic: case, dock, charging cradle, straps, cable exits, lid expression.
- Wear/hold/contact surfaces: ear tips, headband, wrist underside, palm grip, desk contact area.

## Common High-Risk Patterns

- Earbud stem/body/case proportions strongly matching a market leader.
- Phone or wearable front layout with close camera/sensor/screen arrangement.
- Speaker grille pattern and cylindrical proportion closely matching an active design.
- Charging case with matching hinge, lid split, cavity layout, and front indicator placement.

## Design-Around Levers

- Redesign the dominant front or top view, not only rear details.
- Change the relationship between body, interface zone, and accessory.
- Rework the recognizable edge/radius system.
- Create a brand-specific detail hierarchy for openings and controls.
- Ensure the product remains clearly different from competitor hero products in normal viewing angles.

## Comparison Image Acquisition

For each comparison object, obtain a visual reference following `references/image-acquisition-guide.md`:

1. **Try real images first**: Download from official brand websites, e-commerce pages, or patent databases.
2. **Use web reader tools**: Fetch product pages to extract image URLs, then download.
3. **Fall back to SVG schematics**: Generate stylized illustrations representing the key visual features of each comparison object type.
4. **Never leave a comparison card without a visual or fallback link**: Every card must have either a real image, an SVG schematic, or a clearly labeled placeholder with source note. SVG schematic and placeholder cards must also include a public comparison/source/image lookup URL.

Common comparison object types for consumer electronics and their SVG templates:
- Phone (rounded rectangle, camera module, screen area)
- Earbuds case (rounded rectangle, lid line, LED indicator)
- Headphones (headband, ear cups)
- Speaker (cylinder, grille pattern)
- Smartwatch (rounded square, band attachments)

Use `scripts/fetch_competitor_images.py` to automate this process.

## Search Result Format

Format each search result for the report:

```
Comparison Object [N]:
- Name/Title: [patent title or generic product description]
- Source: [database, URL, or "user-provided"]
- Comparison URL: [public patent/detail/product/search URL]
- Image Reference URL: [direct image/source URL, or "not available"]
- Patent Number: [number, or "not available"]
- Legal Status: [active / expired / unknown]
- Category: [Locarno class, or "not available"]
- Thumbnail: [image, or "image unavailable"]
- Similar Points: [list]
- Different Points: [list]
- Risk Rationale: [explanation]
```
