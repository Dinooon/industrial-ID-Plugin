# Appearance Patent/Design Risk Rubric

Use qualitative levels for appearance patent/design risk. Do not output a numeric score.

| Risk Level | Meaning |
|---|---|
| 未评估 | No specific patent/design registration, comparable product image, or search basis is available. |
| 低 | Similarity is limited to common category elements; overall visual impression differs clearly. |
| 中 | Some visible features overlap with known designs; key recognition points need adjustment. |
| 中高 | Same/similar product category and several prominent visual features overlap; IP review is recommended before external disclosure. |
| 高 | Overall visual impression is close to one or more relevant known designs; IP/legal review is required before further visual commitment. |
| 极高 | Core silhouette, proportions, feature layout, and visible details strongly overlap with a relevant active design; stop visual commitment until IP/legal review. |

## Comparison Dimensions

Use these dimensions and report evidence:

- Product category proximity: identical, similar, adjacent, or unrelated.
- Overall silhouette and volume proportion.
- Dominant feature layout visible in normal use.
- Front/side/top/back view similarity.
- Key recognition details: handle, base, dock, screen, camera, grille, sensor, brush, tank, nozzle, charging case, ports, wheels, hinge, strap.
- CMF similarity when color, pattern, or ornamentation is part of the registered design or visually distinctive market expression.
- Design-space context: whether category constraints make differences more or less meaningful.
- Patent status and market relevance, if known.

## Risk Adjustment

Increase risk when:

- Similar patent is in the same product category and target market.
- Similarity appears across multiple views, not one angle only.
- The matching features are prominent and memorable.
- The similar patent belongs to a major competitor or active market player.
- The proposal copies a distinctive visual solution rather than generic category constraints.

Decrease risk when:

- Similarity is limited to functional necessities or industry-standard elements.
- Overall proportions and feature hierarchy differ clearly.
- The reviewed concept has distinctive alternative visual logic.
- Patent status is expired, abandoned, invalidated, or outside target market, if verified.

## International Market Handling

For non-China target markets, apply these general principles:

- **EU**: Reference the Community Design Regulation and EUIPO design database (https://www.tmdn.org/tmdsview-web/). Emphasize the "informed user" standard and overall impression test.
- **US**: Reference US design patent law and USPTO design patent database (https://patents.google.com/?type=DESIGN). Emphasize the "ordinary observer" test.
- **Japan**: Reference Japan Design Act and J-PlatPat (https://www.j-platpat.inpit.go.jp/). Emphasize similarity judgment under Japanese design examination guidelines.
- **Global**: Reference WIPO Hague System international registrations.

For all non-China markets:
- Clearly recommend local IP counsel review for medium-high risk and above.
- Note that risk levels may differ across jurisdictions due to different legal standards.
- If no jurisdiction-specific reference file exists, use the general design-right principles from this rubric and the China framework as a reference, clearly noting the jurisdictional difference.

## Required Report Fields

- Qualitative risk level only.
- Search/comparison scope (including jurisdiction).
- Most relevant similar designs, patents, or products.
- Comparison object thumbnail or placeholder/source note.
- Comparison/source URL for each comparison object; required when the visual is an SVG schematic or placeholder.
- Similar points.
- Different points.
- Risk rationale.
- Design-around recommendations.
- Questions for IP/legal team.

## Comparison Image Rule

- **Every comparison card MUST include a visual element** — no exceptions.
- Priority order for visual sources:
  1. Real competitor product image (downloaded from official sources)
  2. Patent drawing (from official databases)
  3. SVG schematic illustration (generated as fallback)
  4. `image unavailable` placeholder with source note (last resort only)
- Follow `references/image-acquisition-guide.md` for image acquisition strategies.
- Use `scripts/fetch_competitor_images.py` to automate image acquisition when available.
- When using SVG schematics, note in the report: "示意图基于公开信息绘制，建议后续补充实物图片进行精确比对。"
- SVG schematic or `image unavailable` placeholder cards MUST render a clickable `comparison_url` or `image_reference_url`. If no direct detail page is available, use a public search-result URL and label it as a lookup link.
- Do not imply that a public product image is a patent drawing.
- Do not imply that an SVG schematic is a real product photo.
