# China Appearance Patent Risk Framework

> **Legal Currency Check**: This reference cites the Patent Law of the PRC amended in 2020 (effective 2021-06-01) and Implementing Regulations revised in 2024 (effective 2024-01-20). Before using this framework, verify that these laws and regulations have not been further amended. Patent law and regulations may have been updated since this file was last reviewed.

This reference supports preliminary internal design-right risk screening for China mainland. It is not legal advice. Require review by qualified IP counsel or the company's IP team before commercial release or external disclosure when risk is medium-high or above.

## Legal Sources To Consider

- Patent Law of the People's Republic of China, current law amended in 2020 and effective from 2021-06-01.
- Implementing Regulations of the Patent Law of the People's Republic of China, current revision effective from 2024-01-20.
- CNIPA patent examination guidance and official patent/design publication records.
- Court and administrative practice on design-patent similarity, especially overall visual effect, ordinary consumer viewpoint, and design space.

## Recommended Patent Databases

For China-focused appearance patent / design patent searches:

- **CNIPA Patent Search**: http://pss-system.cponline.cnipa.gov.cn — Official Chinese patent database for design patent search.
- **CNIPA Design Patent Database**: Use the design patent classification (Locarno Classification) to narrow searches.
- **Espacenet (EPO)**: https://worldwide.espacenet.com — For cross-referencing international design registrations that may affect China market entry.
- **WIPO Hague Express**: https://www3.wipo.int/hague/en/ — For international design registrations designating China.
- **Company internal patent databases**: Prioritize company-internal patent pools and prior design files when available.

When using these databases, search with generic category terms (not specific brand or product names) to maintain confidentiality. See SKILL.md Confidentiality Rules.

## Working Principles For Screening

- Focus on the product's appearance, not technical function.
- Compare products in the same or similar category first.
- Compare overall visual impression before isolated details.
- Consider the ordinary consumer or informed user who is familiar with the product category.
- Give more weight to design features that are visually prominent in normal use.
- Give less weight to features determined mainly by function, hidden use, or generic category constraints.
- Consider design space: when the category has narrow design freedom, smaller differences may matter; when design freedom is broad, similar distinctive features create more risk.
- Separate patent infringement risk from patentability/novelty risk.

## Evidence Required For Stronger Assessment

- Patent number, title, applicant, application date, publication/authorization status, and legal status.
- Patent drawings from multiple views.
- Product category and Locarno/classification information where available.
- Target market and sales channel.
- Comparison images at equivalent angles.
- Public disclosure timing for the reviewed concept.

## Standardized Search Result Format

When presenting patent/design search results in the report, use this format for each comparison object:

```
Comparison Object [N]:
- Name/Title: [patent title or product name]
- Source: [database name, URL, or "user-provided"]
- Comparison URL: [public patent/detail/product/search URL]
- Image Reference URL: [direct image/source URL, or "not available"]
- Patent/Registration Number: [number, or "not available"]
- Applicant/Owner: [name, or "not available"]
- Application Date: [date, or "not available"]
- Legal Status: [active / expired / unknown]
- Category (Locarno): [class, or "not available"]
- Thumbnail: [image path, or "image unavailable"]
- Similar Points: [list]
- Different Points: [list]
- Risk Rationale: [explanation]
```

## Output Limits

Use language such as:

- "Preliminary risk signal"
- "Needs IP-team verification"
- "Possible visual-overlap area"
- "Design-around recommendation"

Avoid language such as:

- "Definitely infringing"
- "Legally safe"
- "Patent invalid"
- "No risk"
