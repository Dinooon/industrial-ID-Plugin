# New Category Extension Guide

Use this guide when the product does not fit cleaning appliances or consumer electronics and the user wants to extend the skill to a new category.

## When To Use This Guide

- The product is clearly outside cleaning appliances and consumer electronics (e.g., kitchen appliances, personal care devices, outdoor equipment, automotive interior accessories).
- The user explicitly asks to extend the evaluation to a new product category.
- The product is an adjacent powered consumer product that does not fit either existing category well.

## Extension Steps

### Step 1: Confirm Category Scope

- Confirm the category name and scope with the user.
- Identify the main product types within the category.
- Determine whether the category has distinct sub-categories that need separate focus areas.

### Step 2: Create Category Reference File

Create `references/category/{category-name}.md` following this structure:

1. **Product Types**: List the main product types in the category.
2. **Sub-Category Focus**: For each sub-category, define focus areas, key questions, and common risks.
3. **Core Concept Questions**: 3-5 questions specific to the category.
4. **Image Evidence To Inspect**: List the visual elements to examine.
5. **Concept Risks**: Common design risks for the category.
6. **Cross-Category Handling**: How to handle products that span this category and another.
7. **Recommendations To Prefer**: Category-specific recommendation patterns.

### Step 3: Create Brand-Language Reference File

Create `references/brand-language/{category-name}.md` following this structure:

1. **Category Brand Cues**: 3-5 brand-defining qualities for the category.
2. **Visual Elements To Compare**: Key visual elements for brand comparison.
3. **Strong Brand Fit Signals**: Positive brand-consistency indicators.
4. **High-Risk Signals**: Brand-inconsistency warning signs.
5. **Common Competitor Design Language Patterns**: Recognizable competitor archetypes to watch for.
6. **Sub-Category Brand Focus**: Brand-language priorities for each sub-category.

### Step 4: Create Patent-Risk Search Reference File

Create `references/patent-risk/{category-name}-search.md` following this structure:

1. **Search Keywords**: Chinese and English terms (generic only, no brand names).
2. **Recommended Databases**: CNIPA, Espacenet, WIPO, and company internal databases.
3. **Compare These Features**: Category-specific visual comparison points.
4. **Common High-Risk Patterns**: Known patent-risk patterns in the category.
5. **Design-Around Levers**: Strategies for reducing visual similarity.
6. **Search Result Format**: Standardized format for presenting results.

### Step 5: Update SKILL.md

- Add the new category to the Overview section.
- Add loading rules in the Reference Loading section.
- Add the new category to any relevant workflow steps.

### Step 6: Test

- Run 2-3 evaluation cases using the new category.
- Verify that the scoring rubric applies meaningfully.
- Check that brand-language and patent-risk references provide useful guidance.
- Adjust based on test results before finalizing.

## Category Weight Adjustment

When creating a new category, define which scoring dimensions should be weighted more heavily:

- Identify 2-3 dimensions from the scoring rubric that are most critical for the category.
- Document the emphasis in the category reference file.
- Ensure the emphasis is compatible with the existing 100-point rubric (do not change point allocations).
