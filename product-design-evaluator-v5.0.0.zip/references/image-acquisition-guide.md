# 图片抓取与验证指南 (Image Acquisition & Validation Guide)

本指南描述竞品实物图片和专利图纸的获取策略，以及图片验证、过滤、输出数据结构规范。所有外部搜索必须遵守 SKILL.md 中的保密规则，不得在搜索查询中包含保密产品名或品牌标识。

> 版本: v4.1.0 | 更新日期: 2026-07-09 | 同步指导文件: image-acquisition-guidance-for-skills.md v1.0

---

## 一、获取优先级

按以下优先级顺序获取图片，仅当上一级失败时才进入下一级：

| 优先级 | 来源 | 说明 |
|--------|------|------|
| P1 | 用户提供图片 | 用户直接提供竞品参考图或专利图，直接使用 |
| P2 | 内部专利库 | 用户确认拥有内部专利数据库时，用于权威比对 |
| P3 | 官方专利数据库 | CNIPA、Espacenet、WIPO Hague Express、Google Patents |
| P4 | 品牌官网 | 制造商官方产品页面（公开图片） |
| P5 | 电商产品页 | Amazon、JD、天猫商品列表图片（可能有反爬） |
| P6 | Web 搜索结果 | 使用搜索工具查找公开产品图片 |
| P7 | SVG 示意图回退 | 所有真实图片来源失败时，生成 SVG 风格化示意图 |

每个比对对象必须保留至少一个公开查询链接：
- `comparison_url`：专利/详情/产品页面 URL
- `image_reference_url`：图片来源页面或图片搜索结果 URL
- 若无稳定详情页，使用最佳公开搜索结果 URL 并明确标注

---

## 二、图片验证（PIL 优先）

### 2.1 验证规则

下载后的图片必须通过以下全部检查：

1. **PIL 可打开**：使用 `Pillow` 的 `Image.open()` + `verify()` 验证文件完整性
2. **格式合规**：仅接受 JPEG、PNG、WebP、GIF 四种格式
3. **尺寸达标**：宽度和高度均 ≥ 100px（过滤图标、favicon、tracking pixel）
4. **文件非空**：文件大小 > 0

### 2.2 实现代码

```python
from PIL import Image

def validate_image(filepath, min_size=100):
    """PIL 验证图片，返回 (is_valid, mime_or_error)。"""
    try:
        img = Image.open(filepath)
        img.verify()  # 验证完整性
        img = Image.open(filepath)  # 重新打开以获取属性
        w, h = img.size
        if w < min_size or h < min_size:
            return False, f"image_too_small:{w}x{h}"
        fmt = img.format.upper()
        mime_map = {"JPEG": "image/jpeg", "PNG": "image/png",
                    "WEBP": "image/webp", "GIF": "image/gif"}
        mime = mime_map.get(fmt)
        if not mime:
            return False, f"unsupported_format:{fmt}"
        return True, mime
    except ImportError:
        # 降级：PIL 不可用时使用 file 命令
        import subprocess
        result = subprocess.run(["file", "--mime-type", filepath],
                                capture_output=True, text=True)
        for t in ["image/jpeg", "image/png", "image/webp", "image/gif"]:
            if t in result.stdout.lower():
                return True, t
        return False, "pil_unavailable_and_file_failed"
    except Exception as e:
        return False, f"validation_error:{str(e)[:100]}"
```

### 2.3 降级策略

当 `Pillow` 不可用时，降级为 `file --mime-type` 命令验证。降级时无法检查图片尺寸，可能导致小图标通过验证——因此优先安装 Pillow。

---

## 三、网页图片候选提取

### 3.1 提取优先级

从网页 HTML 中提取图片候选 URL，按以下优先级排序：

| 优先级 | 来源 | 提取方式 |
|--------|------|----------|
| 1 | `og:image` | `meta[property="og:image"]` 的 content 属性 |
| 2 | `twitter:image` | `meta[name="twitter:image"]` 的 content 属性 |
| 3 | JSON-LD | `"image": "url"` 字段 |
| 4 | `<source srcset>` | srcset 属性，优先取最大尺寸 |
| 5 | `<img srcset>` | srcset 属性，优先取最大尺寸 |
| 6 | `<img src>` | img 标签的 src 属性 |
| 7 | 懒加载属性 | `data-src`、`data-original`、`data-lazy-src`、`data-image` |

### 3.2 srcset 解析

srcset 格式为 `url1 1x, url2 2x` 或 `url1 300w, url2 600w`。解析时按描述符数值降序排列，优先下载最大尺寸。

### 3.3 相对 URL 补全

所有提取到的相对 URL 必须转换为绝对 URL：

```python
from urllib.parse import urljoin, urlparse

absolute_url = urljoin(page_url, relative_url)
```

### 3.4 候选数量上限

每个页面最多提取 10 个候选 URL，按优先级排序后截断。

---

## 四、无效图片过滤

下载前对候选 URL 进行预过滤，跳过以下 URL：

- 包含 `logo`、`favicon`、`icon` 关键词
- 包含 `pixel`、`track`、`beacon`、`sprite` 关键词
- 包含 `button`、`arrow`、`breadcrumb`、`placeholder` 关键词
- `blank.gif`、`blank.png`、`transparent` 等透明占位图
- `1x1` 尺寸的 tracking pixel
- base64 data URI 且长度 < 500（小图标）
- 非 http/https 协议的 URL

```python
INVALID_PATTERNS = [
    r'logo', r'favicon', r'icon[\._\-/]', r'pixel', r'track', r'beacon',
    r'sprite', r'button', r'arrow', r'breadcrumb', r'placeholder',
    r'blank\.(gif|png|jpg)', r'transparent', r'1x1',
]

def is_valid_image_candidate(url):
    """检查 URL 是否值得下载。"""
    if not url:
        return False
    if url.startswith("data:image/"):
        return len(url) >= 500
    url_lower = url.lower()
    for pattern in INVALID_PATTERNS:
        if re.search(pattern, url_lower):
            return False
    parsed = urlparse(url)
    return parsed.scheme in ("http", "https", "")
```

---

## 五、HTTP 请求头

所有 HTTP 请求必须携带完整的浏览器请求头，降低被拦截概率：

```
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36
Accept: image/avif,image/webp,image/apng,image/*,*/*;q=0.8
Accept-Language: en-US,en;q=0.9,zh-CN;q=0.8
```

网页页面请求时 Accept 头替换为：
```
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
```

---

## 六、下载失败原因分类

每次下载失败时，必须记录分类后的失败原因：

| 分类 | 说明 | 典型场景 |
|------|------|----------|
| `network_restricted` | 网络权限问题 | 超时、DNS 解析失败、连接被拒、SSL 握手失败 |
| `http_error` | HTTP 错误状态 | 403/401 拦截、404/410 不存在、500 服务器错误 |
| `not_an_image` | 下载内容非图片 | HTML 错误页、验证码页面、重定向到登录页 |
| `validation_failed` | 下载成功但验证失败 | 图片过小、格式不支持、文件损坏 |
| `script_error` | 脚本逻辑异常 | 未预期的异常 |

```python
def classify_download_failure(url, error_msg, http_code=""):
    err_lower = (error_msg or "").lower()
    # 网络级失败
    for ind in ["timeout", "connection refused", "could not resolve",
                "ssl", "network is unreachable"]:
        if ind in err_lower:
            return "network_restricted"
    # HTTP 错误码
    if http_code in ("403", "401", "404", "410") or http_code.startswith("5"):
        return "http_error"
    # 非图片内容
    for ind in ["text/html", "not_an_image", "captcha"]:
        if ind in err_lower:
            return "not_an_image"
    # 验证失败
    if "image_too_small" in err_lower:
        return "validation_failed"
    return "script_error"
```

---

## 七、统一输出数据结构

每个比对对象的输出必须包含以下字段：

| 字段 | 类型 | 说明 |
|------|------|------|
| `image` | string | base64 data URI（真实图片或 SVG） |
| `source_type` | `"real"` \| `"svg"` | 图片来源类型 |
| `visual_type` | `"real"` \| `"svg_schematic"` | 视觉元素类型 |
| `source_url` | string | 实际下载 URL（仅真实图片有值） |
| `comparison_url` | string | 公开比对页面 URL |
| `image_reference_url` | string | 备用图片来源 URL |
| `source_note` | string | 人工可读的来源说明 |
| `download_status` | string | 下载状态（MIME 类型或失败描述） |
| `failure_reason` | string | 分类后的失败原因（仅 SVG 回退时有值） |
| `label` | string | 产品描述标签 |

### 真实图片输出示例

```json
{
  "image": "data:image/png;base64,iVBORw0KG...",
  "source_type": "real",
  "visual_type": "real",
  "source_url": "https://example.com/product.jpg",
  "comparison_url": "https://patents.google.com/?q=robot+vacuum",
  "image_reference_url": "https://www.amazon.com/s?k=robot+vacuum",
  "source_note": "已抓取真实图片并转为 base64。",
  "download_status": "image/jpeg",
  "label": "圆形机身 · 顶部平整 · 无LiDAR塔"
}
```

### SVG 回退输出示例

```json
{
  "image": "data:image/svg+xml;base64,PHN2ZyB4...",
  "source_type": "svg",
  "visual_type": "svg_schematic",
  "comparison_url": "https://patents.google.com/?q=robot+vacuum+round+no+lidar",
  "image_reference_url": "https://www.amazon.com/s?k=robot+vacuum+round+flat+top",
  "source_note": "未能下载真实图片，已使用示意图；请点击来源链接查看公开实物/专利图片。",
  "download_status": "no downloadable image among 4 candidates",
  "label": "圆形机身 · 顶部平整 · 无LiDAR塔",
  "failure_reason": "network_restricted"
}
```

---

## 八、SVG 示意图规范

### 8.1 基本规则

- viewBox 统一为 `0 0 300 280`
- 背景色 `#f5f5f5`
- 主体使用深灰渐变 `#2c2c2c` → `#3a3a3a`
- 底部标注产品描述文字
- **必须包含「示意图」水印**（右上角，`opacity="0.6"`）

### 8.2 SVG 水印

每个 SVG 示意图必须在右上角添加「示意图」水印：

```xml
<text x="285" y="18" text-anchor="end" font-family="Arial,sans-serif"
      font-size="9" fill="#bbb" opacity="0.6">示意图</text>
```

### 8.3 模板清单

脚本内置以下 SVG 模板（详见 `fetch_competitor_images.py` 中 `SVG_TEMPLATES`）：

- `round_robot_no_lidar`：圆形机身 · 顶部平整
- `round_robot_with_lidar`：圆形机身 · LiDAR塔
- `d_shape_robot`：D形机身
- `base_station`：自动集尘基站
- `stick_vacuum`：手持/杆式吸尘器
- `phone`：智能手机
- `earbuds_case`：真无线耳机充电盒
- `headphones`：头戴式耳机
- `speaker`：智能音箱
- `smartwatch`：智能手表
- `hair_dryer`：吹风机
- `electric_toothbrush`：电动牙刷
- `shaver`：剃须刀
- `generic_device`：通用设备

---

## 九、动态候选 URL 构建

根据品类和产品视觉属性动态构建搜索 URL：

1. 从 `CANDIDATE_URLS` 获取该品类的静态候选
2. 从视觉属性（`body_shape`、`material`）提取关键词
3. 拼接 Google Patents 搜索 URL：`https://patents.google.com/?q={base_term}+{feature}`
4. 拼接电商搜索 URL：`https://www.amazon.com/s?k={base_term}+{feature}`

**保密规则**：搜索词仅使用通用品类描述（如 "robot vacuum round design"），绝不包含保密产品名或品牌标识。

---

## 十、报告中的图片展示规范

### 10.1 真实图片与示意图区分

报告模板中每个比对卡片必须标注来源类型：

- 真实图片卡片：`data-source-type="real"`，显示「真实图片」徽章，绿色边框
- SVG 回退卡片：`data-source-type="svg"`，显示「示意图」徽章，黄色边框

### 10.2 图源统计

报告底部必须显示图源统计信息：

> 图片来源统计：X 张真实图片，Y 张示意图

### 10.3 模板注释清理

最终报告中不得残留模板注释（如 `Template Variable Guide`、`TEMPLATE_VAR_GUIDE_START` 等）。`generate_report.py` 在生成报告时会自动清理这些注释。

### 10.4 来源链接

每个 SVG 回退卡片必须包含至少一个可点击的公开来源链接（`comparison_url` 或 `image_reference_url`），让评审者可以查看公开专利/产品/搜索结果。

---

## 十一、自动化脚本

使用 `scripts/fetch_competitor_images.py` 自动化图片获取：

```bash
# 品类模式
python scripts/fetch_competitor_images.py \
  --category "robot-vacuum" \
  --output-dir compare_images/ \
  --format base64

# 多Agent模式（v4.0.0+）
python scripts/fetch_competitor_images.py \
  --from-agent-input input_patent_scout.json \
  --output-dir compare_images/
```

脚本执行流程：
1. 构建候选 URL 列表（静态 + 动态）
2. 对每个 URL 尝试直接下载图片
3. 若直接下载失败，抓取页面 HTML 并提取图片候选
4. 对每个候选 URL 下载并 PIL 验证
5. 全部失败时生成 SVG 示意图
6. 输出统一结构的 JSON 文件，含完整溯源字段

---

## 十二、保密合规

- 搜索查询中使用通用品类描述，绝不包含保密产品名或品牌标识
- 从品牌官网下载时直接访问公开产品页，不传输保密信息
- `compare_images/` 目录为临时目录，报告生成后应清理
- 不得在 SKILL 目录中持久化竞品图片
