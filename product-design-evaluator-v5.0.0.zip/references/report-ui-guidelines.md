# User-Facing Report UI Guidelines

Use these guidelines when creating HTML reports for end users. They are adapted for internal product-design review reports and informed by open design-system practices from Ant Design, Material Design, and IBM Carbon.

For HTML reports, also read `references/frontend-design-workflow.md` after evaluation content is frozen. This file defines the required subject-grounded design-plan and self-critique pass before writing or polishing the final HTML.

Reference sources:

- Ant Design: enterprise product design values, feedback, data display, layout, and button patterns. https://ant.design/docs/spec/introduce/
- Material Design 3: layout, color, typography, components, and interaction patterns. https://m3.material.io/
- IBM Carbon Design System: open-source enterprise design system, reusable components, accessibility, and product UI guidance. https://carbondesignsystem.com/

## User Report Priorities

Design the report for quick user decision-making:

1. Put the final verdict, top score, brand-fit rating, and patent-risk level above the fold.
2. Include a version badge (e.g., v1.0) next to the report title.
3. Keep the executive summary to 2-3 short bullets or one short paragraph.
4. Use plain product-review language; avoid process-heavy, engineering-heavy, or legalistic phrasing in the user-facing report.
5. Make high-impact risks visually prominent with color, badges, or compact callouts.
6. Keep supporting details available below the summary, not before it.
7. Use tables only for comparison and scoring; use cards or callouts for conclusions.

## Recommended Page Structure

Use this order for user-facing HTML reports:

1. Hero verdict: product name, version, final decision, confidence, date.
2. Key score cards: design score, brand-language fit, patent-risk level, next action.
3. One-screen executive summary: 2-3 bullets.
4. Input confirmation: image relationship and product category.
5. Main findings: strengths, weak points, top risks.
6. Brand-language consistency: structured rendering with verdict bar, DNA list, diagnosis, gap cards (v5.0.0).
7. Scoring table with progress bars (using `--bar-w` CSS variable) and total summary row (v5.0.0).
8. Appearance patent/design-risk initial screen: badge on separate line from summary text (v5.0.0).
9. Priority recommendations: tagged with P0/P1/P2 color-coded borders and rationale (v5.0.0).
10. Materials to add next time.
11. Feedback buttons and comment box.

Do not include execution trace, quality-gate status, task boundaries, risk-boundary boilerplate, or human-review workflow in the user-facing report. Put those in a separate developer log.

## Visual Style Rules

- Use restrained enterprise UI: clear background, readable text, neutral panels, purposeful accent colors, and clear status colors.
- Derive palette, type roles, layout signature, and visual emphasis from the product subject and review context rather than from generic dashboard/report defaults.
- Take at most one justified aesthetic risk, then keep the rest of the report disciplined and scannable.
- Support dark mode via `prefers-color-scheme` media query for users who prefer dark interfaces.
- Avoid long grey paragraphs. Prefer short cards, bullet lists, badges, and compact tables.
- Use CSS counters for automatic H2 numbering to improve visual structure (v5.0.0).
- Use a non-symmetric findings grid (strengths:concerns = 2:3) to emphasize problems over strengths (v5.0.0).
- Use severity-colored left borders for weighted list items: critical=red, high=orange, medium=yellow (v5.0.0).
- Use priority-colored left borders for recommendations: P0=red, P1=yellow, P2=blue (v5.0.0).
- Use the `--bar-w` CSS variable for progress bars, capped at 100% to prevent overflow (v5.0.0).
- Use responsive auto-fill grids for comparison cards and product images (v5.0.0).
- Use consistent spacing and alignment. Keep report width between 1040px and 1180px.
- Use strong contrast for verdict and risk labels.
- Keep cards shallow and functional; do not nest cards inside cards.
- Avoid decorative gradients, ornamental numbers, or repeated card patterns unless they encode real report information.
- Use responsive layout so key cards stack cleanly on mobile.
- Use button controls for feedback: `满意`, `一般`, `不满意`, plus a short comment field.
- Include a "打印 / 导出PDF" toolbar button using `window.print()` for users who need to save or print the report.

## Print Optimization

Add `@media print` styles to ensure the report prints cleanly:

- Hide toolbar, feedback buttons, and comment box when printing.
- Use black text on white background regardless of screen theme.
- Set panels and cards to avoid page-break-inside.
- Ensure headings do not break from their content.
- Use simple borders instead of colored backgrounds.

## Dark Mode Guidelines

- Use CSS custom properties (variables) for all colors so dark mode can be toggled via `prefers-color-scheme`.
- In dark mode: use dark panel backgrounds (#1e293b), light text (#e2e8f0), muted accent colors.
- Ensure badges and status colors maintain sufficient contrast in both light and dark modes.
- Test patent-risk badges specifically — red/yellow/green must be distinguishable in dark mode.

## Writing Rules

- Replace long explanations with direct judgments.
- Use `结论`, `原因`, `建议` labels when a section risks becoming wordy.
- Keep each risk or recommendation to one sentence where possible.
- Use qualitative labels for patent risk: `低`, `中`, `中高`, `高`, `极高`, or `未评估`.
- Do not show a numeric patent-risk score.
- For design scores, show number and level, but avoid overexplaining the math in the hero.

## Patent Comparison UI

When patent/design-risk comparison is included:

- Show comparison objects as compact cards or a table with image thumbnails.
- Use a responsive auto-fill grid (`repeat(auto-fill, minmax(320px, 1fr))`) for comparison cards (v5.0.0).
- Include object name, source, relationship, similar points (with ✓ prefix), differences (with ✗ prefix), and qualitative risk level (v5.0.0).
- Use the `compact-list` class on all comparison card lists for consistent styling (v5.0.0).
- If a card uses an SVG schematic or placeholder instead of a real image/patent drawing, include a visible link such as `查看公开对象` or `查看图片来源` that opens the public patent/detail/product/search reference.
- If no specific patent/design registration is available, write `未取得具体外观/设计登记编号，本轮仅做视觉相似信号判断`.
