# Brand Language Consistency For Consumer Electronics

Use this for phones, earbuds, headphones, speakers, wearables, smart desktop devices, handheld electronics, connected hardware, and accessories.

## Category Brand Cues

- Precision: seams, radii, apertures, and transitions should feel intentional and controlled.
- Interaction clarity: screens, touch zones, buttons, LEDs, ports, and microphones should be legible.
- Personal fit: handheld, wearable, or desktop posture should match the product's role.
- Ecosystem fit: charging, pairing, docking, carrying, and accessory logic should feel coherent.
- Price-tier expression: material and detail density should match the intended market level.

## Visual Elements To Compare

- Primary geometric language: slab, pebble, capsule, puck, cylinder, band, shell, or hybrid.
- Edge treatment: chamfer, radius, bevel, flush surface, raised rim, or layered frame.
- Interface zone placement and hierarchy.
- Speaker grille, camera, sensor, mic, hinge, button, port, or charging contact expression.
- Wear/hold/contact surfaces.
- Case, dock, strap, cable, charging cradle, or accessory family.

## Strong Brand Fit Signals

- Clear family resemblance without copying a single existing product.
- Precise integration of functional openings and interface features.
- CMF choices reinforce the brand's tier and emotional tone.
- Details feel manufacturable and consistent across views.
- Accessories share the same line, proportion, and material logic.

## High-Risk Signals

- Generic rounded electronics form without a defensible identity.
- A front/sensor/speaker layout that strongly recalls a competitor.
- Unclear interaction hierarchy hidden behind a beautiful shell.
- Excessive decorative seams or color breaks that weaken precision.
- Rendered material effects that imply quality the form cannot support.

## Common Competitor Design Language Patterns To Watch For

When evaluating brand fit, be aware of common competitor patterns that may inadvertently influence the concept:

- **Earbuds**: Stem-and-bud silhouette with charging case matching proportions. If the concept follows this dominant archetype, check whether the stem length, tip shape, or case opening mechanism adds brand distinction.
- **Smartwatches / wearables**: Squircle or round face with digital crown / side button. If the concept closely follows a market leader's layout, flag whether the bezel treatment, lug design, or crown expression differentiates the brand.
- **Speakers**: Cylindrical fabric-wrapped body with top control surface. If the concept matches this pattern, evaluate whether the top control layout and bottom base treatment carry brand identity.
- **Phones / tablets**: Slab with camera module arrangement. If the concept follows a common camera island or matrix layout, check whether the module shape, edge treatment, or back material creates brand differentiation.
- **Charging cases / docks**: Clamshell or puck form with hinge or magnetic alignment. If the concept follows a common archetype, evaluate whether the opening mechanism, indicator placement, or exterior finish carries the brand.

Flag any concept that closely follows a competitor's recognizable archetype without adding brand-specific visual differentiation.

## Sub-Category Brand Focus

Different consumer electronics sub-categories have different brand-language priorities:

**Phone / tablet:**
- Focus on camera module arrangement and back panel treatment as the primary brand signature.
- Evaluate edge language (radius, chamfer, frame material) for brand consistency.
- Check whether the front layout is distinguishable from competitors.

**Earbuds / headphones:**
- Focus on stem/body proportion and case silhouette as the primary brand expression.
- Evaluate ear-tip or headband contact surface treatment.
- Check whether the charging case opening mechanism is brand-specific.

**Speaker / audio device:**
- Focus on grille pattern and body proportion as the primary brand cue.
- Evaluate top control surface layout and material contrast.
- Check whether the form avoids generic cylindrical or rectangular patterns.

**Wearable (watch / band / ring):**
- Focus on case silhouette and lug/strap attachment as the primary brand signature.
- Evaluate side button / crown expression and back sensor layout.
- Check whether the wearable form carries the brand even at small scale.

**Desktop device / hub / camera:**
- Focus on footprint proportion and front face expression.
- Evaluate whether the device communicates its function while maintaining brand identity.
- Check whether the accessory ecosystem (cables, mounts) shares brand language.
