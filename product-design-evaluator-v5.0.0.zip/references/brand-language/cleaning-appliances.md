# Brand Language Consistency For Cleaning Appliances

Use this for robot vacuums, floor washers, vacuum cleaners, mite removers, window cleaners, purification/cleaning hardware, bases, docks, and related accessories.

## Category Brand Cues

- Cleanliness: forms should communicate hygiene, order, and easy maintenance.
- Trust: sensor zones, water/dust handling, and moving parts should feel controlled and safe.
- Domestic fit: proportions should work visually in kitchens, bathrooms, living rooms, and storage spaces.
- Functional honesty: dust bins, water tanks, rollers, brushes, handles, bases, and filters should be visually understandable.
- Maintenance dignity: dirty-touch areas should be contained or separated from clean-touch areas.

## Visual Elements To Compare

- Main body silhouette and height/width balance.
- Handle geometry, grip direction, and hand approach.
- Tank/dustbin visibility and removal logic.
- Roller/brush/suction-mouth expression.
- Base station volume, docking posture, and floor footprint.
- Sensor and navigation feature zones.
- Wheel, foot, bumper, hinge, latch, and release-button treatment.
- Clean/dirty side separation by color, material, line, or form.

## Strong Brand Fit Signals

- Consistent family-level radius, line tension, and volume softness.
- Clear hierarchy between main body, service parts, and interaction controls.
- Brand-specific clean-surface treatment rather than generic white appliance styling.
- Maintenance areas that look approachable and contained.
- Base/accessory language that matches the main unit.

## High-Risk Signals

- Looks like a direct remix of a market-leading competitor.
- Dirty maintenance areas are visually hidden but operationally unavoidable.
- Body is attractive in renderings but unclear in actual use posture.
- Dock/base dominates the product without brand logic.
- Decorative split lines make the product harder to clean or visually less hygienic.

## Common Competitor Design Language Patterns To Watch For

When evaluating brand fit, be aware of common competitor patterns that may inadvertently influence the concept:

- **Robot vacuums**: Round body with centered LiDAR tower (common across multiple brands); D-shaped front with flat-front cleaning edge; top-loading dustbin with hinged lid. If the concept closely follows one of these archetypes, check whether it adds brand-specific differentiation or remains generic.
- **Floor washers**: Dual-tank visible split with handle running through the center; angled cleaning head with roller guard. If the concept matches this layout closely, flag whether the brand identity is distinguishable from category leaders.
- **Stick vacuums**: Inline motor-battery-handle-dustbin massing; trigger grip angle. If the concept follows this dominant layout, evaluate whether the silhouette and CMF create brand distinction.
- **Base stations**: Tall tower with front door; rectangular flat dock. Check whether the base station design has brand-specific logic or is a generic utility box.

Flag any concept that closely follows a competitor's recognizable archetype without adding brand-specific visual differentiation.

## Sub-Category Brand Focus

Different cleaning appliance sub-categories have different brand-language priorities:

**Robot vacuum / mop robot:**
- Focus on top silhouette and sensor tower expression as the primary brand signature.
- Evaluate navigation feature zone integration and bumper segmentation.
- Check whether the top view is distinctive from competitors.

**Floor washer / wet-dry vacuum:**
- Focus on handle line and tank split as the primary brand expression.
- Evaluate cleaning-head silhouette and dirty-water zone treatment.
- Check whether the standing posture communicates the brand's quality tier.

**Handheld / stick vacuum:**
- Focus on the inline massing relationship and trigger/grip geometry.
- Evaluate dustbin visibility and battery/handle proportion.
- Check whether the side profile is recognizable as the brand.

**Mite remover / window-cleaning robot:**
- Focus on compact form and contact-surface expression.
- Evaluate whether the small form still carries brand DNA or becomes generic.

**Base station / dock / accessory:**
- Focus on whether the dock shares the main unit's design language.
- Evaluate footprint, docking posture, and material consistency.
- Check whether the dock reinforces or dilutes the brand presence.
