# Shared Brand Design Language Principles

Use these principles to evaluate whether a concept fits a brand family. Replace generic assumptions with user-provided brand references whenever available.

## Brand Reference Priority

When evaluating brand fit, follow this priority order:

1. User-provided brand design guidelines or manuals (highest authority).
2. User-provided existing product family images.
3. User-provided brand keywords or verbal descriptions.
4. General public-facing product-family cues from market knowledge (lowest authority).

If user-provided brand references are incomplete or contradictory, note the gaps explicitly and evaluate against the most reliable subset. State which references were used and which were missing.

Avoid claiming official brand compliance unless official brand guidelines were provided. Use phrasing such as `appears aligned with`, `partially recalls`, or `does not strongly support`.

## Evidence To Compare

- Primary silhouette: the most recognizable outer contour from front, side, and three-quarter views.
- Proportion language: tall/slim, low/wide, compact/dense, soft/rounded, precise/geometric, modular/stacked.
- Signature feature zones: screens, buttons, handles, sensors, docks, grilles, speakers, ports, base stations, lenses, hinges.
- Surface transition: soft fillets, chamfers, crisp edges, continuous skin, floating panels, layered shells.
- Parting and segmentation: where parts split, how panels meet, whether seams feel intentional.
- CMF logic: color blocking, material hierarchy, contrast level, texture, gloss, translucency, metallic cues.
- Brand emotion: professional, friendly, technical, domestic, premium, rugged, minimal, warm, playful, medical-clean, or performance-driven.

## Brand Language Evolution

When evaluating brand fit, consider whether the concept represents:

- **Natural evolution**: The concept extends the brand language with a coherent new expression. This is positive and expected as product lines grow.
- **Deliberate departure**: The concept intentionally explores a new direction. This can be valid for a new sub-line or youth variant, but should be acknowledged as a departure.
- **Unexplained departure**: The concept drifts from the brand language without clear rationale. This is a risk signal and should be flagged.

## Consistency Levels

- Strong: The concept clearly extends known brand proportions, feature logic, and CMF while adding a useful new expression.
- Moderate: Some brand cues are present, but silhouette, CMF, or key feature zones feel generic or inconsistent.
- Weak: The product could belong to many brands, or its dominant features resemble a competitor more than the stated brand.
- Contradictory: The concept conflicts with core brand qualities, price tier, or existing family logic.

## Common Brand Fit Risks

- Using category clichés instead of brand-specific visual decisions.
- Mixing multiple brand moods in one concept.
- Overusing decorative lines that do not support function or brand hierarchy.
- Treating color as the only brand cue while ignoring proportion and feature placement.
- Making the new concept too close to an existing competitor's recognizable silhouette.

## Competitor Pattern Awareness

When evaluating brand fit, also check whether the concept inadvertently resembles a competitor's design language more than the stated brand:

- Does the silhouette, proportion, or feature layout strongly recall a specific competitor product?
- Are the CMF choices more typical of a competitor's tier or market positioning?
- Would an informed consumer confuse this product with a competitor's offering?

If competitor resemblance is detected, flag it as a brand-fit risk and a potential patent/design-right risk.

## Review Prompt

Always answer:

- Which visible details most support brand consistency?
- Which visible details weaken brand consistency?
- Does the design look like a natural family extension?
- Would a customer or internal reviewer recognize the brand without a logo?
- What should change first to improve brand fit?
- Does the concept represent natural evolution, deliberate departure, or unexplained departure?
