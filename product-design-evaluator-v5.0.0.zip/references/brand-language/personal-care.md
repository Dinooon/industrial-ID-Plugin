# Personal Care Brand Language Reference

Use this reference for brand-language consistency evaluation of personal care products: hair dryers, electric toothbrushes, shavers, facial cleansing devices, massagers, and similar products.

## Category Brand Cues

1. **Tactile identity**: The product's grip zone defines its brand personality — soft-touch rubber signals care-focused, polished metal signals premium, textured plastic signals utility.
2. **Body geometry language**: Cylindrical with gradual taper vs. capsule with flat sides vs. angular with defined edges — each communicates a different brand positioning.
3. **Color discipline**: Personal care brands typically use 1-2 body colors with a single accent for controls. Multi-color or gradient bodies are rare in premium positioning.
4. **Control expression**: Button size, shape, and material communicate brand confidence in usability. Minimalist controls signal design confidence; multiple buttons signal feature-rich positioning.
5. **Integration quality**: How the functional end (brush head, nozzle, cutting head) connects to the body signals engineering maturity and brand standards.

## Visual Elements To Compare

- Overall body silhouette and proportion ratio (length to diameter)
- Grip zone definition and material transition line
- Control button(s): size, shape, material, placement relative to grip
- Charging interface: type, placement, visual integration
- Color palette and material contrast strategy
- Attachment/connection point design language
- LED/indicator expression (dot, ring, strip, hidden)
- Brand logo placement and treatment

## Strong Brand Fit Signals

- The grip zone material and texture immediately communicate the brand's tactile identity
- The body proportion language is consistent with other products in the brand family
- Control expression follows the brand's interface design rules (same button style, same feedback pattern)
- The charging solution matches the brand's typical approach (e.g., inductive base for premium, USB-C for accessible)
- Color treatment follows brand palette without unexplained additions
- The attachment system uses the brand's characteristic connection language

## High-Risk Signals

- The grip zone uses a material or texture that is inconsistent with the brand's tactile identity
- The body proportion ratio is noticeably different from other products in the family
- Controls use a different style (shape, material, feedback) than established brand patterns
- A decorative element (gradient, pattern, light strip) that does not appear in any other brand product
- The charging solution feels like a cost-down compromise inconsistent with brand positioning
- The attachment system looks borrowed from a competitor rather than following brand connection language
- Color choices that conflict with the brand's established palette without a clear rationale

## Common Competitor Design Language Patterns

### Dyson-style hair care
- Ring/circular motor housing with hollow center
- Magenta/copper accent on dark body
- Distinctive cylindrical trigger grip
- Magnetic attachment system

### Philips-style grooming
- Clean capsule silhouette with soft transitions
- Blue/white accent on neutral body
- Intuitive single-button control
- Click-on attachment system

### Oral-B-style oral care
- White body with colored accent ring
- Visible brush head connection
- Multiple mode indicators
- Inductive charging glass/base

### Foreo-style skincare
- Full-body silicone with no hard plastic
- Organic, pebble-like form
- Single-button hidden under silicone
- USB charging (no base)

### Panasonic-style grooming
- Linear, architectural body geometry
- Silver/dark metallic finish
- Sliding switches rather than buttons
- Linear charging dock

## Sub-Category Brand Focus

### Hair Dryers
- Brand differentiation is primarily through body geometry and motor housing design
- Nozzle attachment system is a secondary brand cue
- Premium brands tend to use distinctive silhouettes (ring, L-shape, cylinder)

### Electric Toothbrushes
- Brand differentiation is subtle — body diameter, grip pattern, accent color
- The brush head connection is a shared standard, so brand identity lives in the body
- Charging solution (glass, base, USB) is a strong brand differentiator

### Shavers
- Head geometry (rotary vs. foil) is the primary category differentiator, not brand
- Brand identity lives in body contour, grip treatment, and control style
- Cleaning stations are strong brand signals when included
