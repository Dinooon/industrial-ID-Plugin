# Feedback Loop For Skill Iteration

Every substantial review should end with a short feedback request. Capture feedback in the chat and use it to update the skill when the user asks.

## User-Facing Feedback

The user-facing HTML report must include three feedback buttons:

- `满意`
- `一般`
- `不满意`

Also include a short comment box. The page stores the selected value in localStorage for persistence across page refreshes, but the user must send the feedback back in chat for the skill to update itself.

## Follow-Up Questions

When the user provides feedback, ask only if needed:

- Was the category handling correct?
- Did the missing-information questions cover the right gaps?
- Was the brand-language critique too strict, too loose, or useful?
- Were the risk boundaries clear enough?
- Did the HTML report include the sections needed for internal review?
- What should be added to the rubric for the next case?

## Feedback Tags

When the user responds, classify feedback into:

- `intake`: image relationship, category confirmation, missing context.
- `rubric`: scoring dimensions, weights, rating bands.
- `brand-language`: reference quality, brand-specific interpretation.
- `patent-risk`: legal boundary, search scope, risk scoring.
- `output`: HTML format, structure, visual hierarchy.
- `quality-gate`: acceptance criteria, reviewer workflow.

## Feedback Aggregation Rule

When multiple feedback instances are collected:

- Track recurring themes across evaluations (e.g., if multiple users report "brand-language critique too strict", flag it as a systematic issue).
- Categorize feedback by tag and track frequency.
- Prioritize updates that address recurring issues over one-off comments.
- If the same feedback tag appears 3+ times across different evaluations, flag it as a high-priority skill update candidate.

## Known Issues From Real Case Feedback (v2.1.0)

The following issues were identified during the eufy robot vacuum evaluation case and have been addressed in v2.1.0:

1. **Product image not embedded in report** → Fixed: SKILL.md now mandates product image embedding as base64 data URI in a dedicated section.
2. **English words in Chinese report** → Fixed: Language Rules now specify that all evaluation text must be in Chinese with explicit exception list.
3. **Missing information not asked before scoring** → Fixed: Added mandatory confirmation step in workflow and intake-and-clarification.md.
4. **Text too dense in report** → Fixed: Added Text Conciseness rule and compact-list CSS class. Quality gate checks list item length.
5. **Product identification error (round body identified as D-shaped)** → Fixed: Added Recognition Verification Gate with mandatory second-pass verification.
6. **Patent comparison lacked visual images** → Fixed: Created image-acquisition-guide.md and fetch_competitor_images.py. SKILL.md mandates visual elements in all comparison cards.

## Skill Update Rule

When feedback reveals a recurring or high-impact issue:

- Update the relevant reference file rather than only changing one output.
- Add a concrete rule, example, or checklist item.
- Keep user-specific brand secrets out of generic references unless the user explicitly wants a private brand reference added.
- Document the update in the developer log under "Suggested skill update" for future reference.
