# Execution Trace And Human Review Workflow

Include a concise execution trace in each substantial report. This is for process transparency and future skill iteration, not for exposing private chain-of-thought.

## Execution Trace Fields

Use short factual bullets:

- Input received: number of images, image relationship status, text context received, image quality assessment.
- Clarifications asked: questions asked before scoring.
- User confirmations: answers received, if any.
- Assumptions used: assumptions made because information was missing.
- References loaded: rubric, category guide, brand-language guide, patent-risk guide.
- Evaluation scope: what was scored and what was excluded.
- Output generated: chat summary, HTML report, patent-risk section, or other artifact.
- Quality gate: independent review, self-review, pass/fail, and unresolved caveats.
- Time tracking: approximate time spent on each major step (intake, analysis, scoring, brand review, patent review, report creation, quality gate).
- Version: report version number and whether this is an iteration.
- Prior evaluation reference: if this is an iteration, reference to the prior evaluation's developer log.

## Human Review Workflow

Include the recommended human workflow:

1. Designer confirms image relationship and product category.
2. Design lead reviews brand-language fit and priority revisions.
3. Product/UX owner confirms target user, use scenario, interaction flow, and hidden functional assumptions.
4. Engineering representative reviews visible structure/process risks if needed.
5. IP/legal representative reviews patent-risk findings when risk is medium-high or above.
6. Team records feedback on whether the report was useful, too strict, too vague, or missing criteria.

## Trace Boundaries

- Do not include private reasoning or hidden deliberation.
- Do not include irrelevant tool logs.
- Do not claim a subagent reviewed the work if it did not.
- Do not claim patent search was performed unless it actually was performed or user provided patent references.
- Do not include confidential product names or identifying details beyond what is necessary for process audit.
