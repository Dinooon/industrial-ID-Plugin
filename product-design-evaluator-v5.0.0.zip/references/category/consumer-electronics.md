# Consumer Electronics Concept Review

Use this category guide in addition to the scoring rubric.

## Product Types

- Phone or tablet
- Earbuds, headphones, speakers, microphones, or audio devices
- Smart watch, ring, band, or wearable
- Smart home controller, hub, camera, or sensor
- Desktop device, handheld device, charging accessory, or connected hardware

## Sub-Category Focus

Different sub-categories have different evaluation emphases:

**Phone / tablet:**
- Focus on: camera module arrangement, back panel material and texture, edge language (radius, chamfer, frame).
- Key question: Is the back view distinctive without a logo?
- Common risk: Camera module layout closely follows a market leader's arrangement.

**Earbuds / headphones:**
- Focus on: stem/body proportion, ear-tip or cushion form, charging case silhouette and opening mechanism.
- Key question: Is the side profile recognizable as the brand at a glance?
- Common risk: Stem-and-bud proportion matching a dominant competitor.

**Speaker / audio device:**
- Focus on: grille pattern and texture, body proportion, top control surface, base treatment.
- Key question: Does the form avoid generic cylindrical or rectangular patterns?
- Common risk: Fabric-wrapped cylinder indistinguishable from multiple competitors.

**Wearable (watch / band / ring):**
- Focus on: case silhouette, lug/strap attachment, side button or crown, back sensor layout, display bezel treatment.
- Key question: Does the wearable carry brand identity at small scale?
- Common risk: Squircle face with side crown closely following a market leader.

**Desktop device / hub / camera:**
- Focus on: footprint proportion, front face expression, indicator/LED placement, material treatment.
- Key question: Does the device communicate its function while maintaining brand identity?
- Common risk: Generic puck or box form without brand treatment.

**Charging accessory / dock:**
- Focus on: form coherence with main product, material consistency, cable management expression, indicator placement.
- Key question: Does the accessory feel like part of the same family?
- Common risk: Accessory solves function but dilutes brand identity.

## Core Concept Questions

- Does the form support the primary hardware function?
- Is the interaction hierarchy visible and credible?
- Does the design feel precise enough for the intended price tier?
- Are holding, wearing, docking, charging, and carrying scenarios resolved?
- Does the accessory ecosystem feel like part of the same family?

## Image Evidence To Inspect

- Screen, button, slider, touch area, LED, display, camera, sensor, grille, port, hinge, strap, or dock.
- Main radius/chamfer language and consistency across edges.
- Seams, parting lines, fastener hints, opening treatment, and fit precision.
- Weight distribution and contact surfaces for hand, ear, wrist, desk, or pocket.
- Charging contacts, case, cable management, and accessory placement.
- Heat, speaker/mic direction, signal windows, or waterproofing clues when visible.

## Concept Risks

- Beautiful shell lacks visible interaction logic.
- Interface zones feel accidental or under-hierarchized.
- Detail quality does not match claimed price tier.
- Product resembles a strong competitor silhouette.
- Wear/hold ergonomics are assumed but not evidenced.
- Accessories solve function but dilute brand identity.

## Cross-Category Handling

Some consumer electronics have cleaning appliance attributes (e.g., a smart speaker with air purification, a wearable with UV sterilization). When a product spans both categories:

- Determine which category dominates the primary use scenario and physical form.
- Use the dominant category's evaluation framework for scoring.
- Use the secondary category's framework for supplementary checks.
- Note the cross-category nature in the report and explain which framework was primary.

If the product genuinely sits between categories, use `category uncertain` and ask the user which evaluation framework to prioritize.

## Recommendations To Prefer

- Strengthen the primary interaction zone.
- Simplify visible parting and detail logic.
- Use CMF to separate touch, display, acoustic, and structural areas.
- Make accessory and charging interactions part of the concept story.
- Create one memorable product-recognition feature that remains brand-consistent.
