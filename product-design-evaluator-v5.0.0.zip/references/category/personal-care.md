# Personal Care Category Review Guide

Use this guide for personal care products: hair dryers, electric toothbrushes, shavers, facial cleansing devices, massagers, and similar personal grooming/care devices.

## Product Types

- **Hair dryers**: Handheld drying devices with motor, heating element, and airflow path. Key differentiators: body geometry (L-shaped, cylindrical, ring-shaped), nozzle design, handle angle, weight distribution.
- **Electric toothbrushes**: Cylindrical or capsule body with brush head. Key differentiators: body diameter, grip texture, button placement, LED indicator, charging method (inductive base vs. USB).
- **Shavers/trimmers**: Rectangular or capsule body with cutting head. Key differentiators: head geometry (rotary vs. foil), body contour, grip ergonomics, travel lock mechanism.
- **Facial cleansing devices**: Compact handheld with silicone or brush contact surface. Key differentiators: contact surface texture, body shape, vibration pattern indicators, charging method.
- **Massagers**: Handheld or wearable with motorized nodes. Key differentiators: node layout, body form, grip design, intensity control placement.

## Sub-Category Focus

### Hair Dryers
- **Core questions**: Does the body geometry support comfortable one-handed operation? Is the airflow path visually readable? Does the nozzle attachment system feel integrated?
- **Key risks**: Handle angle causing wrist strain, motor housing proportions suggesting poor balance, nozzle attachment appearing fragile.
- **Image evidence**: Side profile showing handle-to-body angle, three-quarter view showing airflow exit, detail of control placement.

### Electric Toothbrushes
- **Core questions**: Is the body diameter appropriate for average hand grip? Is the brush head connection clearly readable? Does the charging base feel integrated?
- **Key risks**: Body too thick for comfortable grip, button placement causing accidental activation during brushing, charging indicator not visible during use.
- **Image evidence**: Full body side view, grip detail, charging base if included.

### Shavers
- **Core questions**: Does the head-to-body proportion suggest precision or power? Is the grip secure for wet/dry use? Is the travel lock intuitive?
- **Key risks**: Head geometry appearing generic, body contour not supporting thumb control, cleaning station (if included) looking like an afterthought.
- **Image evidence**: Front and side views, head detail, cleaning station if included.

## Core Concept Questions

1. What is the primary usage posture (held in hand, placed on face/body, worn)?
2. Is the product designed for wet environments (bathroom, shower)?
3. What is the intended daily use duration and frequency?
4. How does the product communicate status (battery, mode, intensity) without a screen?
5. What is the cleaning/maintenance sequence?

## Image Evidence To Inspect

- Overall body proportion and silhouette from primary viewing angles
- Grip zone definition and texture treatment
- Button/control placement and size relative to grip
- Charging interface (base, contacts, USB port) and its visual integration
- Material transitions between grip zone and functional zone
- LED/indicator placement and visibility from use posture
- Attachment/connection points (brush head, nozzle, cutting head)
- Travel/storage state if applicable (folding, caps, cases)

## Concept Risks

- Body proportions that look good in render but would cause fatigue in actual use
- Material choices that conflict with wet-environment use (glossy surfaces becoming slippery)
- Control placement that requires grip change during operation
- Charging interface that appears fragile or difficult to align
- Attachment system that looks insecure or difficult to operate with one hand
- Travel/storage solution that adds bulk without clear benefit

## Cross-Category Handling

- Products combining personal care and cleaning appliance functions (e.g., beauty device with sanitizing base): evaluate primary function first, note the secondary category reference
- Products spanning personal care and consumer electronics (e.g., smart mirror with skin analysis): use consumer electronics for electronics behavior, personal care for contact surface and ergonomics
- For uncertain products, ask the user to confirm the primary use scenario before selecting a framework

## Recommendations To Prefer

- Recommend ergonomic validation if grip or weight distribution appears uncertain
- Recommend CMF testing for wet-environment safety if materials suggest slip risk
- Recommend user testing for control placement if button position appears ambiguous
- Prioritize maintenance/cleaning sequence clarity over decorative surface treatment
- Prefer integrated charging solutions over add-on cables when the product is bathroom-dwelling
