# Cleaning Appliance Concept Review

Use this category guide in addition to the scoring rubric.

## Product Types

- Robot vacuum or mop robot
- Floor washer or wet-dry vacuum
- Handheld/stick vacuum
- Mite remover
- Window-cleaning robot
- Base station, dock, cleaning accessory, or air/purification cleaning device

## Sub-Category Focus

Different sub-categories have different evaluation emphases:

**Robot vacuum / mop robot:**
- Focus on: navigation sensor zone (LiDAR tower, camera, bumper), top silhouette, docking logic, base station footprint.
- Key question: Is the top view distinctive and brand-recognizable?
- Common risk: Generic round body with centered sensor tower indistinguishable from market leaders.

**Floor washer / wet-dry vacuum:**
- Focus on: handle ergonomics (angle, grip, trigger), tank visibility and removal path, roller/brush access, dirty-water zone treatment.
- Key question: Is the maintenance sequence readable from the design?
- Common risk: Attractive body with unclear tank removal or hidden dirty-water access.

**Handheld / stick vacuum:**
- Focus on: motor/battery/handle massing, dustbin orientation, trigger grip angle, weight distribution cues.
- Key question: Does the inline massing relationship create a brand-distinctive side profile?
- Common risk: Generic stick vacuum proportion without brand differentiation.

**Mite remover:**
- Focus on: compact form, contact-surface expression, dust collection visibility, grip for repetitive motion.
- Key question: Does the small form still carry brand DNA?
- Common risk: Generic handheld tool appearance without brand identity.

**Window-cleaning robot:**
- Focus on: suction pad layout, body footprint, safety tether expression, frame-edge navigation cues.
- Key question: Is the form recognizable on a glass surface?
- Common risk: utilitarian box form without brand treatment.

**Base station / dock / accessory:**
- Focus on: footprint, docking posture, water/dust exchange zones, lid/door expression, material consistency with main unit.
- Key question: Does the dock reinforce the brand or feel like a generic utility box?
- Common risk: Dock visually disconnected from the main product's design language.

## Core Concept Questions

- Does the visible form support the cleaning task and user posture?
- Are clean and dirty interactions separated?
- Is the maintenance sequence readable from the design?
- Does the product look easy to store, move, and clean after use?
- Are the base, dock, accessories, and consumables visually integrated?

## Image Evidence To Inspect

- Cleaning head, suction mouth, roller, brush, mop, pad, or nozzle.
- Dustbin, water tank, dirty-water tank, filter, latch, and removal direction.
- Handle height, grip size, wrist angle, center-of-gravity cues.
- Wheel, bumper, sensor, navigation, obstacle crossing, and edge-cleaning logic.
- Docking direction, footprint, cable/charging area, water/dust exchange area.
- Surfaces likely to collect dirt, fingerprints, hair, or water stains.

## Concept Risks

- Attractive shell hides unclear maintenance.
- Product looks compact but suggests low capacity or poor service access.
- Handle or body proportions imply fatigue.
- Cleaning interface appears too small, blocked, or visually secondary.
- Water/electric/dust zones are visually confused.
- Base station is visually disconnected from the product.

## Cross-Category Handling

Some cleaning appliances have consumer electronics attributes (e.g., a smart air purifier with app connectivity, a robot vacuum with voice assistant). When a product spans both categories:

- Determine which category dominates the primary use scenario and physical form.
- Use the dominant category's evaluation framework for scoring.
- Use the secondary category's framework for supplementary checks (e.g., interaction hierarchy, ecosystem fit).
- Note the cross-category nature in the report and explain which framework was primary.

If the product genuinely sits between categories (e.g., a smart home hub that also functions as an air quality monitor), use `category uncertain` and ask the user which evaluation framework to prioritize.

## Recommendations To Prefer

- Clarify clean-touch versus dirty-touch zones.
- Strengthen the core cleaning interface as a product identity element.
- Make service parts visually intentional rather than afterthoughts.
- Use CMF to signal hygiene, durability, and maintenance confidence.
- Align base/accessory language with the main unit.
