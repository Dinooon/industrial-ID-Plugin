# Concept Design Scoring Rubric

Use this 100-point rubric for enterprise internal concept-stage reviews. Emphasize direction, brand fit, visible concept quality, and risk discovery. Do not overweight late-stage engineering feasibility.

| Dimension | Points | Evaluate |
|---|---:|---|
| User scenario and concept direction fit | 15 | Target user clarity, scenario credibility, design intent, problem-solution match |
| Form proportion and product recognizability | 15 | Silhouette, volume balance, visual hierarchy, iconicity, category recognizability |
| Brand design language consistency | 20 | Brand family fit, proportion language, feature lines, interaction-area expression, CMF consistency, price-tier expression |
| CMF and perceived quality | 12 | Material logic, finish contrast, color blocking, premium/utility cues, cleanliness, durability impression |
| Category-specific experience hypothesis | 12 | Whether the visible concept supports the category's core use assumptions |
| Interaction, ergonomics, and use-risk visibility | 10 | Touchpoints, handles, buttons, display areas, status feedback, safety cues, misuse risk |
| Innovation and differentiation | 8 | Meaningful novelty, non-generic expression, defensible difference from competitors |
| Early structure/process risk alerts | 3 | Visible assembly, parting, openings, mechanisms, manufacturing ambiguity, but only as an early warning |
| Proposal expression completeness | 5 | Multi-view completeness, rendering clarity, scale cues, scenario/context clarity |

## Weight Design Rationale

The 100-point allocation is designed for enterprise internal concept-stage reviews where direction, brand fit, and visible design quality matter more than late-stage engineering feasibility. Each dimension's weight reflects its impact on go/no-go decisions at the concept stage:

- **Brand design language consistency (20 points)**: Enterprise internal reviews prioritize brand continuation. A concept that contradicts brand DNA is likely to be rejected regardless of other merits. This dimension has the highest weight because brand fit is the primary gate for concept approval.
- **User scenario and concept direction fit (15 points)**: Direction-level judgment — whether the concept addresses a real user need and scenario — is the second most critical decision factor. A concept solving the wrong problem cannot be saved by good execution.
- **Form proportion and product recognizability (15 points)**: Visual first impression is the core carrier of design identity. Silhouette and proportion decisions made at concept stage are difficult to change later without full redesign.
- **CMF and perceived quality (12 points)**: Material and finish choices influence perceived price tier and emotional tone, but are more flexible than form direction and can evolve between concept and production.
- **Category-specific experience hypothesis (12 points)**: Whether the visible concept supports the category's core use assumptions. Important, but some functional details are resolved after concept approval.
- **Interaction, ergonomics, and use-risk visibility (10 points)**: Concept-stage renders often lack precise interaction detail. This dimension rewards visible intent but does not penalize unresolved late-stage ergonomics.
- **Innovation and differentiation (8 points)**: Meaningful novelty is valuable at concept stage but difficult to quantify objectively. Moderate weight prevents innovation from overshadowing execution quality.
- **Early structure/process risk alerts (3 points)**: Reduced from 5 to 3 in v2.1.0. Concept-stage renders rarely show enough manufacturing detail for reliable structural risk assessment. This dimension serves as an early warning, not a gate.
- **Proposal expression completeness (5 points)**: Increased from 3 to 5 in v2.1.0. Evaluates the quality of the input itself — multi-view completeness, rendering clarity, and scale cues. Higher weight than structural risk because input quality directly affects the reliability of all other dimension scores.

### v2.0 → v2.1 Weight Adjustment History

- Early structure/process risk alerts: 5 → 3 (concept stage lacks manufacturing detail for reliable assessment)
- Proposal expression completeness: 3 → 5 (input quality directly impacts all other scores' reliability)

## Category Weight Adjustment Matrix

Different categories require different evaluation rigor. Apply these adjustments to scoring emphasis (not to point allocation). "↑ stricter" means apply more critical judgment; "standard" means use baseline rigor.

| Dimension | Cleaning Appliances | Consumer Electronics | Personal Care |
|---|---|---|---|
| User scenario and concept direction fit | standard | standard | standard |
| Form proportion and product recognizability | standard | ↑ stricter | ↑ stricter |
| Brand design language consistency | standard | standard | standard |
| CMF and perceived quality | standard | ↑ stricter | ↑ stricter |
| Category-specific experience hypothesis | ↑ stricter | standard | ↑ stricter |
| Interaction, ergonomics, and use-risk visibility | ↑ stricter | ↑ stricter | ↑ stricter |
| Innovation and differentiation | standard | standard | standard |
| Early structure/process risk alerts | standard | standard | standard |
| Proposal expression completeness | standard | standard | standard |

**Rationale for category-specific adjustments:**

- Cleaning appliances: Category experience (maintenance, clean/dirty separation) and ergonomics (grip, storage) are critical for user acceptance. Penalize designs that hide maintenance access.
- Consumer electronics: Form precision and CMF quality are primary brand differentiators. Penalize unclear interface zones and excessive decorative seams.
- Personal care: Products have intimate physical contact with users. Form proportion, CMF quality (skin-safe materials, hygiene), and ergonomics (repetitive motion comfort) are critical.

## Rating Bands

- 90-100: Excellent concept direction. Ready for deeper refinement and validation.
- 80-89: Strong direction. Proceed with targeted revisions.
- 70-79: Viable but uneven. Needs visible correction before next gate.
- 60-69: Weak concept maturity. Rework core design logic.
- Below 60: Not recommended for continuation in current form.

## Confidence-Based Score Cap

When confidence is `Low` (limited image angles, missing brand/category context, no patent comparison basis, or text-only input), cap the final score at 79. Add a note: "评分受限于输入信息不足，补充材料后评分可能显著变化。" This prevents overconfident high scores when evidence is weak.

## Category Weight Adjustment

Different categories require different evaluation rigor. See the Category Weight Adjustment Matrix above for specific dimension-category combinations.

**For cleaning appliances:**
- Weight maintenance visibility and clean/dirty separation more heavily in the "Category-specific experience" and "Interaction, ergonomics" dimensions.
- Penalize designs that hide maintenance access or mix clean/dirty zones visually.
- Reward clear service-part intentionality and base/accessory integration.

**For consumer electronics:**
- Weight interaction hierarchy and precision more heavily in the "Form proportion" and "Interaction, ergonomics" dimensions.
- Penalize designs with unclear interface zones or excessive decorative seams.
- Reward precise integration of functional openings and consistent edge language.

**For personal care:**
- Weight body proportion, grip zone treatment, and material safety more heavily in the "Form proportion", "CMF and perceived quality", and "Interaction, ergonomics" dimensions.
- Penalize designs with grip zones that conflict with wet-environment use or control placement requiring grip change during operation.
- Reward integrated charging solutions, clear maintenance sequence, and tactile consistency.

**For adjacent or uncertain categories:**
- Use a general evaluation without category-specific emphasis.
- Note in the report which category-specific criteria were not applied.

## Scoring Examples

Use these examples to calibrate scoring consistency:

**User scenario and concept direction fit:**
- High score example: Target user (young urban renter) and scenario (small apartment daily cleaning) are clearly addressed; the concept solves a specific storage and quick-deploy problem.
- Low score example: The concept could serve many users and scenarios without clear focus; no specific problem-solution match is visible.

**Form proportion and product recognizability:**
- High score example: Clear, confident silhouette with balanced proportions; immediately recognizable as a premium robot vacuum from three-quarter view.
- Low score example: Ambiguous shape that could be any category; no memorable or iconic visual signature.

**Brand design language consistency:**
- High score example: Proportion language, radius system, and CMF treatment clearly extend the brand family; a customer could identify the brand without a logo.
- Low score example: The product could belong to many brands; dominant features resemble a competitor more than the stated brand.

**CMF and perceived quality:**
- High score example: Material hierarchy is logical (soft-touch handle, matte body, glossy accent); finish contrast reinforces premium positioning.
- Low score example: Random material choices without hierarchy; finish level does not match the implied price tier.

**Category-specific experience hypothesis:**
- High score example (floor washer): Handle angle, tank visibility, and roller access all support credible cleaning use; maintenance sequence is readable.
- Low score example (floor washer): Attractive shell but tank removal path is unclear; cleaning interface appears secondary.

**Interaction, ergonomics, and use-risk visibility:**
- High score example: Button placement follows natural thumb position; status LEDs are visible from normal use posture; misuse risk is minimized through form.
- Low score example: Controls are hidden or ambiguous; no visible feedback for key states; form invites incorrect grip.

**Innovation and differentiation:**
- High score example: A novel docking architecture that is both functional and brand-distinctive; no direct competitor uses this approach.
- Low score example: Generic category form with no defensible visual difference from market leaders.

**Early structure/process risk alerts:**
- High score example: Parting lines are intentional and minimal; assembly logic is visible and clean; no manufacturing red flags.
- Low score example: Complex multi-part shell with ambiguous seams; visible mechanisms suggest assembly difficulty.

**Proposal expression completeness:**
- High score example: Multiple clear views (front, side, three-quarter, detail); scale cues present; usage context shown.
- Low score example: Single ambiguous view; no scale reference; rendering obscures key features.

## Scoring Discipline

- Assign each dimension a numeric score and one sentence of evidence.
- Penalize missing evidence only when that missing information materially blocks judgment.
- Use confidence labels for each major judgment: high, medium, or low.
- Keep comments specific: name the exact silhouette, split line, interface zone, CMF decision, handle, dock, sensor zone, screen area, or accessory causing the score.
- When a dimension score is below 60% of its maximum, the evidence sentence must explicitly state what is wrong and what would need to change.
- **Recognition verification impact**: If a core visual attribute was misidentified during initial analysis and later corrected, all dimension scores must be recalculated. Common impacts:
  - Body shape correction (e.g., D-shaped → round) significantly affects "Form proportion and product recognizability" and "Brand design language consistency" scores.
  - Navigation sensor correction (e.g., has LiDAR → no LiDAR) affects "Category-specific experience hypothesis" and "Innovation and differentiation" scores.
  - Material finish correction affects "CMF and perceived quality" score.
- **Evidence text must be in Chinese** (one sentence per scoring row), using only brand names and technical terms in English as permitted by SKILL.md Language Rules.
