# Missing Information Checklist

Use this checklist when evaluating images. Ask only the highest-impact questions; do not overwhelm the user.

Items are marked **[Must-Have]** (required for responsible final scoring) or **[Nice-to-Have]** (improves evaluation quality but not blocking).

## Core Project Context

- **[Must-Have]** Product name, product type, and intended subcategory.
- **[Must-Have]** Target user, usage scenario, and expected environment.
- **[Must-Have]** Target market and jurisdiction for patent risk.
- **[Nice-to-Have]** Price tier and brand/series positioning.
- **[Nice-to-Have]** Concept stage: sketch exploration, selected concept, CMF proposal, or pre-development review.

## Brand Design Language

- **[Must-Have]** Brand design language reference, brand keywords, or series guideline.
- **[Nice-to-Have]** Existing product family images or design manuals.
- **[Nice-to-Have]** Desired relationship to brand: continuation, premium upgrade, youth variant, professional variant, or new sub-line.
- **[Nice-to-Have]** Forbidden forms, colors, or competitor references.

## Product Experience

- **[Nice-to-Have]** Approximate dimensions, weight, and intended holding/placement posture.
- **[Nice-to-Have]** Interaction flow: buttons, display, app, lights, sound, gestures, or physical controls.
- **[Nice-to-Have]** Key functional architecture: airflow/water path, sensors, speakers, battery, dock, charging, dust/water handling, wearing/holding method.
- **[Nice-to-Have]** Maintenance and cleaning process where relevant.

## Patent Risk

- **[Must-Have]** Target markets: China mainland, EU, US, Japan, or global.
- **[Nice-to-Have]** Known competitor products or patents to compare.
- **[Nice-to-Have]** Company internal patent pool, prior design files, or earlier concept versions.
- **[Nice-to-Have]** Whether public release has occurred or is planned.
- **[Nice-to-Have]** Whether the review should focus on freedom-to-operate risk, novelty risk, or both.

## Reporting Choice

- **[Must-Have]** Whether to create a concise internal review memo or a full HTML report.
- **[Nice-to-Have]** Whether the report should include images, patent thumbnails, or only text summaries.
- **[Nice-to-Have]** If this is an iteration, the prior evaluation reference or developer log.

## Priority When Context Is Limited

If the user provides minimal context and cannot answer all questions, prioritize in this order:

1. Product category and use scenario [Must-Have]
2. Image relationship confirmation [Must-Have]
3. Target brand family/reference [Must-Have]
4. Target market for patent risk [Must-Have]
5. Output mode [Must-Have]
6. All other items [Nice-to-Have] — proceed with assumptions and lower confidence.
