# Multi-Agent Communication Protocol

> Architecture A: Coordinator + 4 Specialized Agents

## Overview

This document defines the communication protocol between the Coordinator (main agent) and four specialized sub-agents (Image Analyst, Brand Judge, Patent Scout, Report Builder) in the multi-agent architecture.

## Data Transfer Mechanism

All inter-agent communication uses **JSON files** written to a session directory:

```
/tmp/review_session_{YYYYMMDD_HHMMSS}/
├── coordinator_input.json          ← Coordinator's assembled raw input
├── input_image_analyst.json        ← Input for Image Analyst Agent
├── input_patent_scout.json         ← Input for Patent Scout Agent
├── input_brand_judge.json          ← Input for Brand Judge Agent (generated after step1)
├── input_report_builder.json       ← Input for Report Builder Agent (generated after step1-3)
├── step1_image_analysis.json       ← Image Analyst output
├── step2_patent_scout.json         ← Patent Scout output
├── step3_brand_judge.json          ← Brand Judge output
├── step4_report_builder.json       ← Report Builder output
└── orchestration_log.jsonl         ← Orchestration log (one entry per step)
```

## Execution Sequence

### Phase 1: Parallel Execution (Image Analyst + Patent Scout)

Both agents can run in parallel because:
- Image Analyst only needs product images and user context
- Patent Scout only needs product images and category information (does not depend on Image Analyst's detailed output for initial comparison)

**However**, Patent Scout benefits from Image Analyst's structured output for more accurate comparison. Two modes are supported:

**Mode A (Full Parallel):** Patent Scout receives only image paths and category hint, runs simultaneously with Image Analyst. Faster but less precise comparison.

**Mode B (Semi-Parallel):** Patent Scout waits for Image Analyst to complete, then uses the structured output for more accurate comparison. Slower but more precise.

The coordinator chooses Mode A when speed is critical and Mode B when precision is critical. Default: **Mode B** (precision-first).

### Phase 2: Sequential (Brand Judge)

Brand Judge depends on Image Analyst's output. It must wait for step1 to complete.

### Phase 3: Sequential (Report Builder)

Report Builder depends on all three previous agents. It must wait for steps 1-3 to complete.

### Timing Diagram (Mode B - Default)

```
Time →
Coordinator    Image Analyst    Patent Scout    Brand Judge    Report Builder
  │                │               │               │               │
  │── Intake ──→   │               │               │               │
  │── Gen Input ─→ │               │               │               │
  │── acp call ──→ │               │               │               │
  │                │ (executing)   │               │               │
  │←── JSON ──────│               │               │               │
  │                │               │               │               │
  │── Gen Input ──────────────────→│               │               │
  │── Gen Input ─────────────────────────────────→ │               │
  │── acp call ──────────────────→│               │               │
  │── acp call ──────────────────────────────────→│               │
  │                │               │ (executing)   │ (executing)   │
  │                │               │               │               │
  │←── JSON ─────────────────────│               │               │
  │←── JSON ────────────────────────────────────│               │
  │                │               │               │               │
  │── Gen Input ────────────────────────────────────────────────→│
  │── acp call ────────────────────────────────────────────────→│
  │                │               │               │   (executing)  │
  │←── JSON ──────────────────────────────────────────────────│
  │                │               │               │               │
  │── QA Review ──│               │               │               │
  │── Deliver ───→│               │               │               │
  ▼                ▼               ▼               ▼               ▼
```

## JSON File Schemas

### coordinator_input.json

```json
{
  "session_id": "20260708_143022",
  "image_paths": ["/absolute/path/to/image1.png"],
  "user_context": {
    "category_hint": "cleaning_appliance",
    "brand_reference": "eufy",
    "target_market": "中国大陆",
    "price_tier": "中端",
    "concept_stage": "early_concept",
    "additional_notes": "电商页面截图"
  },
  "output_requirement": "html_report",
  "is_iteration": false,
  "prior_evaluation_ref": null
}
```

### input_image_analyst.json

See `agents/image-analyst/SOUL.md` Input Format section.

### input_patent_scout.json

See `agents/patent-scout/SOUL.md` Input Format section. When using Mode B, the `image_analysis` field is populated with step1 output.

### input_brand_judge.json

See `agents/brand-judge/SOUL.md` Input Format section. The `image_analysis` field is populated with step1 output.

### input_report_builder.json

See `agents/report-builder/SOUL.md` Input Format section. The `image_analysis`, `brand_review`, and `patent_risk` fields are populated with step1-3 outputs.

## Error Handling

### Atomic Fallback Strategy

If ANY sub-agent fails (acp_agent_exec error, timeout, or unparseable output), the coordinator immediately falls back to single-agent mode:

1. Log the failure in `orchestration_log.jsonl`
2. Discard all partial results from the session directory
3. Execute the full v3.1.0 single-agent workflow from SKILL.md
4. Note in the developer log: "多Agent架构不可用，已回退到单Agent模式"

**No partial fallback.** If Image Analyst succeeds but Brand Judge fails, the system does NOT use Image Analyst's result and then manually do brand evaluation. It falls back entirely to single-agent mode.

### Timeout

Each sub-agent call has a timeout of **180 seconds (3 minutes)**. If a sub-agent does not return within this period:
- The call is considered failed
- The coordinator logs the timeout
- Atomic fallback is triggered

### JSON Parse Failure

If a sub-agent returns output that cannot be parsed as JSON:
1. The `agent_output_parser.py` script attempts multiple extraction strategies (direct parse, code-block extraction, regex extraction)
2. If all strategies fail, the sub-agent is considered failed
3. Atomic fallback is triggered

## Orchestration Log Format

Each log entry is a JSONL line in `orchestration_log.jsonl`:

```json
{"timestamp": "2026-07-08T14:30:22Z", "step": "intake", "status": "success", "details": "User context received"}
{"timestamp": "2026-07-08T14:30:25Z", "step": "input_generation", "status": "success", "details": "Generated input_image_analyst.json"}
{"timestamp": "2026-07-08T14:30:25Z", "step": "agent_call", "agent": "image_analyst", "status": "started"}
{"timestamp": "2026-07-08T14:33:10Z", "step": "agent_call", "agent": "image_analyst", "status": "success", "duration_seconds": 165}
{"timestamp": "2026-07-08T14:33:12Z", "step": "agent_call", "agent": "patent_scout", "status": "started"}
{"timestamp": "2026-07-08T14:33:12Z", "step": "agent_call", "agent": "brand_judge", "status": "started"}
{"timestamp": "2026-07-08T14:35:30Z", "step": "agent_call", "agent": "patent_scout", "status": "success", "duration_seconds": 138}
{"timestamp": "2026-07-08T14:36:00Z", "step": "agent_call", "agent": "brand_judge", "status": "success", "duration_seconds": 168}
{"timestamp": "2026-07-08T14:36:02Z", "step": "agent_call", "agent": "report_builder", "status": "started"}
{"timestamp": "2026-07-08T14:40:15Z", "step": "agent_call", "agent": "report_builder", "status": "success", "duration_seconds": 253}
{"timestamp": "2026-07-08T14:40:17Z", "step": "complete", "status": "success", "total_duration_seconds": 595}
```

## Coordinator Responsibilities Summary

| Step | Action | Input | Output |
|------|--------|-------|--------|
| 0 | Intake & Clarification | User request | coordinator_input.json |
| 1 | Generate Image Analyst input | coordinator_input.json | input_image_analyst.json |
| 2 | Call Image Analyst via acp_agent_exec | input_image_analyst.json | step1_image_analysis.json |
| 3 | Generate Patent Scout + Brand Judge inputs | coordinator_input + step1 | input_patent_scout.json + input_brand_judge.json |
| 4 | Call Patent Scout + Brand Judge (parallel) | respective input JSONs | step2_patent_scout.json + step3_brand_judge.json |
| 5 | Generate Report Builder input | steps 1-3 outputs | input_report_builder.json |
| 6 | Call Report Builder via acp_agent_exec | input_report_builder.json | step4_report_builder.json |
| 7 | Quality-gate outer review | step4 output | QA result |
| 8 | Deliver to user | step4 output + QA result | Chat summary + HTML report path |

## Sub-Agent Invocation

Sub-agents are invoked via `acp_agent_exec`:

```
acp_agent_exec(
    task="<natural language task description referencing the input JSON file>",
    working_directory="/home/ubuntu/skill-analysis/product-design-evaluator-improved"
)
```

The task description should:
1. Reference the agent's SOUL.md for identity and rules
2. Specify the input JSON file path
3. Specify the output JSON file path
4. List the reference files to load

Example task for Image Analyst:
```
You are the Image Analyst Agent defined in agents/image-analyst/SOUL.md.
Read the input from /tmp/review_session_20260708_143022/input_image_analyst.json.
Analyze the product images and produce the structured JSON output defined in your SOUL.md.
Write your output to /tmp/review_session_20260708_143022/step1_image_analysis.json.
Load reference file: references/category/cleaning-appliances.md
```
