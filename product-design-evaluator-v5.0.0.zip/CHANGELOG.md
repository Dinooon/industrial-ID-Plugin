# Product Design Evaluator — Changelog

## v5.0.0 (2026-07-09)

### Report Visual Overhaul

Complete rewrite of report template and generation script to address 18 identified visual issues (排版混乱/图示缺失/结构不明显/重点不突出).

#### Breaking Data Structure Changes (with backward compatibility)

- `brand_language_review`: string → structured object `{brand_dna_summary, brand_dna_points[], product_diagnosis, critical_gaps[{issue, severity}], key_conclusion, annotation_images[]?}`. String inputs auto-degrade to `<p>` rendering.
- `strengths`/`concerns`: string[] → `[{point, weight}]` arrays. String elements auto-wrap as `{point: str, weight: "normal"}`.
- `recommendations`: string[] → `[{action, priority, rationale}]` arrays. String elements auto-wrap as `{action: str, priority: "P2"}`.
- New field: `product_images[]` for multi-image grid (replaces single `product_image` when multiple images exist).

#### Template Changes (assets/report-template.html)

- CSS variables: `--ok-bg`, `--warn-bg`, `--risk-bg`, `--high-bg`, `--high-border`, `--medium-bg`, `--medium-border`, `--p0-color`, `--p1-color`, `--p2-color`
- Typography: `line-height` 1.52→1.65, `p` margin 8px→10px, panel padding 14px→18px, `h2` 18px→20px with `border-bottom` accent line, `h3` 15px→16px
- H2 auto-numbering via CSS `counter-reset: h2-counter` / `counter-increment: h2-counter`
- New CSS classes: `.brand-review`, `.brand-verdict-bar`, `.brand-conclusion`, `.brand-dna-section`, `.brand-diagnosis-section`, `.section-subtitle`, `.brand-dna-list`, `.gap-cards`, `.gap-card`, `.gap-card.severity-high/medium/low`, `.findings-grid` (2:3 non-symmetric), `.weight-critical/high/medium/highlight`, `.rec-p0/p1/p2`, `.rec-priority-tag`, `.rec-rationale`, `.score-summary`, `.product-images-grid`, `.patent-risk-header`, `.patent-risk-text`, `.compact-list`
- Progress bar: unified `var(--bar-w, 0%)` + `max-width: 100%`
- Comparison grid: `repeat(auto-fill, minmax(320px, 1fr))` (was fixed 3-column)
- HTML brand review section restructured as structured component with verdict bar, DNA list, diagnosis, gap cards

#### Script Changes (scripts/generate_report.py)

- New functions: `build_brand_review_html()`, `build_weighted_list_items()`, `build_priority_list_items()`, `build_score_summary()`, `build_product_images_grid()`, `build_brand_fit_badge()`, `to_cn()`
- Backward compatibility: auto-detection of string vs dict/array-of-objects for all upgraded fields
- Score progress bar: unified `--bar-w` CSS variable

#### Quality Gate Changes

- New Critical checks: #22 (progress bar uses `--bar-w`), #23 (score summary row present), #24 (findings grid non-symmetric layout)
- New Recommended checks: H2 auto-numbering, brand review structured component, patent risk badge separation, comparison grid auto-fill

#### New Tests

- `run_tests.py`: 4 new tests (structured brand review, weighted list items, priority recommendations, multi-image grid)
- `evals.json`: 3 new test cases (#9 brand structured rendering, #10 multi-image + score summary, #11 weighted lists + priority recommendations)

#### Files Modified

- `assets/report-template.html` — full rewrite (v5.0.0)
- `scripts/generate_report.py` — full rewrite (v5.0.0)
- `scripts/quality_check.py` — new checks #22-24 + recommended checks
- `scripts/agent_input_generator.py` — output_schema_hints for v5.0.0 structured fields
- `scripts/agent_output_parser.py` — support dict format for brand_language_review
- `agents/report-builder/SOUL.md` — structured output schema for v5.0.0 fields
- `references/report-rendering-handoff.md` — v5.0.0 data structure schema + rendering rules
- `references/quality-gate.md` — new v5.0.0 critical + recommended checks
- `references/report-ui-guidelines.md` — v5.0.0 UI component guidance
- `evals/evals.json` — 3 new test cases
- `evals/run_tests.py` — 4 new test functions
- `SKILL.md` — version bump + changelog
- `agents/openai.yaml` — version bump
- Backups: `assets/report-template-v4.1.0.html`, `scripts/generate_report_legacy_v4.1.0.py`

## v4.1.0 (2026-07-09)

### Image Acquisition Overhaul

Based on `image-acquisition-guidance-for-skills.md` v1.0, performed a comprehensive rewrite of the image acquisition pipeline with 18 gap fixes (11 Critical + 7 Recommended).

#### Core Script Rewrite (`fetch_competitor_images.py`)

- **C-01**: PIL-based image validation replaces `file` command dependency. Validates format (JPEG/PNG/WebP/GIF), dimensions (≥100px), and file integrity. Graceful degradation to `file` command when Pillow unavailable.
- **C-02**: Web page image candidate extraction. Parses `og:image`, `twitter:image`, JSON-LD `image` fields, `<source srcset>`, `<img srcset>`, `<img src>`, and lazy-load attributes (`data-src`, `data-original`, `data-lazy-src`, `data-image`).
- **C-03**: Relative URL to absolute URL conversion using `urljoin()`. All extracted URLs are converted before download attempt.
- **C-04**: Complete browser HTTP headers (User-Agent, Accept, Accept-Language) on all curl requests.
- **C-05/C-06**: Unified output data structure with full traceability fields: `source_type`, `visual_type`, `source_url`, `comparison_url`, `image_reference_url`, `source_note`, `download_status`, `failure_reason`, `label`.
- **C-07**: Report template includes image source statistics panel (real count vs SVG count).
- **C-08**: Report template distinguishes real image cards (`data-source-type="real"`, green border, "真实图片" badge) from SVG fallback cards (`data-source-type="svg"`, yellow border, "示意图" badge).
- **C-09**: Template variable guide comments auto-removed from final report HTML by `generate_report.py`.
- **C-10**: Invalid image candidate filtering. Skips URLs containing `logo`, `favicon`, `icon`, `pixel`, `track`, `beacon`, `sprite`, `button`, `arrow`, `breadcrumb`, `placeholder`, `blank`, `transparent`, `1x1`.
- **C-11**: Download failure reason classification into 5 categories: `network_restricted`, `http_error`, `not_an_image`, `validation_failed`, `script_error`.
- **R-01**: Dynamic candidate URL construction based on category and visual attributes.
- **R-02**: Image-to-base64 conversion validates minimum dimensions before processing.
- **R-04**: SVG schematics include "示意图" watermark in top-right corner.
- **R-05**: Two-phase download strategy: Phase 1 tries direct URL download, Phase 2 fetches page HTML and extracts image candidates.

#### Reference File Updates

- `references/image-acquisition-guide.md` — Fully rewritten with 12 sections covering validation, extraction, filtering, HTTP headers, failure classification, output structure, SVG specs, dynamic URLs, report display rules, and confidentiality.
- `references/quality-gate.md` — Added Critical checks #20 (image source statistics) and #21 (no template residue).
- `references/report-rendering-handoff.md` — JSON schema updated with v4.1.0 output fields and report display rules.
- `agents/patent-scout/SOUL.md` — Output schema updated with unified traceability fields.

#### Quality Check Enhancements

- `scripts/quality_check.py` — New checks: image source statistics present, no template residue, real image cards labeled, SVG fallback cards labeled.
- `scripts/generate_report.py` — New `build_image_stats()` function; template comment auto-removal; comparison cards include `data-source-type` attribute and source badge.

#### New Test Cases

- `evals/evals.json` — 2 new evals: #7 (PIL validation + unified output structure), #8 (SVG watermark + image source statistics + template residue check).

#### Backups

- `scripts/fetch_competitor_images_legacy_v4.0.0.py` — v4.0.0 original script backup.
- `assets/report-template-v4.0.0.html` — v4.0.0 original template backup.

## v4.0.0 (2026-07-08)

### Architecture Upgrade: Multi-Agent (Architecture A)

- **Multi-Agent Architecture**: Upgraded from single-agent to coordinator + 4 specialized sub-agents. Each sub-agent has an independent context window and focused responsibility.
  - **Image Analyst** (`agents/image-analyst/`): Product image recognition, visual attribute extraction, recognition verification (二次验证), category confirmation, multi-image relationship judgment.
  - **Patent Scout** (`agents/patent-scout/`): Appearance patent risk screening, competitor image acquisition (7-level priority), SVG fallback generation, visual comparison with source links.
  - **Brand Judge** (`agents/brand-judge/`): Brand design language consistency evaluation, family-extension judgment, deviation analysis, recommendation generation.
  - **Report Builder** (`agents/report-builder/`): Score calculation (100-point rubric), HTML report generation, embedded quality-gate self-check, developer log creation.

### New Files

- `agents/image-analyst/SOUL.md` — Image Analyst Agent definition (JSON Schema + 2 examples)
- `agents/image-analyst/README.md`
- `agents/brand-judge/SOUL.md` — Brand Judge Agent definition (JSON Schema + 2 examples)
- `agents/brand-judge/README.md`
- `agents/patent-scout/SOUL.md` — Patent Scout Agent definition (JSON Schema + 2 examples)
- `agents/patent-scout/README.md`
- `agents/report-builder/SOUL.md` — Report Builder Agent definition (JSON Schema + 1 example)
- `agents/report-builder/README.md`
- `references/multi-agent-protocol.md` — Inter-agent communication protocol, session directory structure, JSON schemas, execution sequence, error handling, atomic fallback strategy, orchestration log format
- `scripts/orchestrate_review.py` — State-machine driven orchestrator (INIT→IMAGE_ANALYST→PARALLEL→REPORT_BUILDER→COMPLETE/FALLBACK)
- `scripts/agent_input_generator.py` — Generates input JSON for each sub-agent based on coordinator input and prior agent outputs
- `scripts/agent_output_parser.py` — Fault-tolerant output parser (3 strategies: direct parse, codeblock extraction, brace matching) with default fallback structures
- `evals/multi_agent_evals.json` — 6 multi-agent test cases (normal flow, timeout fallback, JSON parse failure, parallel timing, Chinese labels, low-confidence cap)

### Modified Files

- `SKILL.md` — Added Multi-Agent Architecture section, dual-mode workflow (multi-agent + single-agent fallback), version 4.0.0, updated reference loading instructions
- `agents/openai.yaml` — Version 4.0.0, mode `multi_agent`, sub-agent configuration block, fallback specification, rate limits updated
- `references/quality-gate.md` — Added dual-layer quality gate (Layer 1: Report Builder embedded self-check, Layer 2: coordinator outer review), multi-agent output format validation checks
- `scripts/generate_report.py` — Added `--from-agent-json` mode to accept Report Builder Agent output JSON, `convert_agent_output_to_report_data()` function
- `scripts/generate_report_legacy.py` — Backup of pre-v4.0.0 generate_report.py
- `scripts/fetch_competitor_images.py` — Added `--from-agent-input` mode to accept Patent Scout Agent input JSON, `fetch_from_agent_input()` function
- `scripts/quality_check.py` — Added `--from-report-builder` mode, `check_chinese_labels()` function (v4.0.0 Critical check #19), independent verification mode

### Key Design Decisions

- **Atomic Fallback**: When any sub-agent fails (timeout, parse error, acp_agent_exec unavailable), the coordinator atomically falls back to the complete v3.1.0 single-agent workflow. No partial results are used.
- **Precision-First Parallel**: Patent Scout and Brand Judge run in parallel only after Image Analyst completes (Mode B), ensuring Patent Scout has structured output for accurate comparison.
- **Dual-Layer Quality Gate**: Layer 1 (embedded) catches report-level issues; Layer 2 (outer) catches cross-agent consistency issues.
- **Chinese Label Enforcement**: New Critical quality check #19 verifies all user-facing labels are in Chinese, preventing the v3.1.0 English label leakage issue.

### Compatibility

- Single-agent mode (v3.1.0 workflow) remains fully supported as fallback
- All v3.x reports remain compatible with v4.0.0 quality checks
- Legacy `generate_report_legacy.py` preserved for backward compatibility

## v3.1.0 (2026-07-08)

### Fixes

- **Chinese Label Fix**: Systematically replaced all English Decision Labels (Proceed, Proceed with revisions, Rework direction, Hold for IP/legal review), Confidence Labels (High, Medium, Low), and Brand Consistency Labels (Strong, Moderate, Weak, Contradictory) with Chinese equivalents across 8 files: SKILL.md, shared-principles.md, report-rendering-handoff.md, report-template.html, generate_report.py, quality_check.py, validate_scores.py, and evals.json.

## v3.0.0 (2026-07-08)

### New Features

- **Personal Care Category**: Added full category support for hair dryers, electric toothbrushes, shavers, facial cleansing devices, and massagers. New reference files: `references/category/personal-care.md`, `references/brand-language/personal-care.md`, `references/patent-risk/personal-care-search.md`.
- **Category Registry**: Created `references/categories.yaml` as the single source of truth for supported categories. Scripts and SKILL.md reference this file instead of hardcoded lists.
- **Score Validation**: New `scripts/validate_scores.py` validates dimension count (9), point totals (100), score-to-max bounds, total consistency, Low-confidence cap (79), and qualitative patent risk enforcement. Integrated into `generate_report.py`.
- **Executable Test Suite**: New `evals/run_tests.py` with 10 automated tests covering file structure, template integrity, scoring consistency, score validation, report generation, category registry, competitor image script, and version sync.
- **Patent Search SOP**: Added step-by-step Search Standard Operating Procedure to both cleaning-appliances-search.md and consumer-electronics-search.md. Each has 6 steps: define scope → search CNIPA → search Espacenet/WIPO → search Google Patents → acquire images → compare and assess.
- **Weight Design Rationale**: Added comprehensive weight design rationale to scoring-rubric.md explaining why each dimension has its specific point allocation. Added Category Weight Adjustment Matrix showing which dimensions get stricter evaluation per category.
- **Category-Specific Visual Direction**: Added to frontend-design-workflow.md — palette tendency, type roles, signature ideas, and avoid-lists for cleaning appliances, consumer electronics, and personal care.
- **Dark Mode Image Handling**: Added CSS rules for dark mode image backgrounds in report-template.html to prevent white-background images from clashing with dark panels.
- **Image Source Caption Placeholder**: Added `{{IMAGE_SOURCE_CAPTION}}` placeholder to report-template.html, replacing hardcoded "来源：电商页面截图（Galaxus）" text.

### Bug Fixes

- **fetch_competitor_images.py Real Download**: The script's `try_download_image` function was implemented but never called in the main flow. Fixed: the script now iterates candidate URLs, attempts real downloads, validates downloaded files, and only falls back to SVG schematics when all download attempts fail. Added visual_type and comparison_url metadata to every result. Added SVG templates for personal care products (hair dryer, electric toothbrush, shaver), consumer electronics (phone, earbuds, headphones, speaker, smartwatch).
- **openai.yaml Inconsistency**: Fixed multiple inconsistencies between openai.yaml and SKILL.md: added missing recognition verification rule, personal care category, scoring validation mention, and fetch_competitor_images.py usage note.
- **Windows Path in Distribution**: Removed hardcoded Windows local path `C:\Users\DINO\Documents\Codex\...` from frontend-design-workflow.md.
- **D-Shape Bias in Scoring Example**: Replaced "Clean D-shaped silhouette" scoring example with neutral "Clear, confident silhouette with balanced proportions" to avoid biasing evaluators toward D-shaped forms.
- **Template Hardcoded Caption**: Replaced hardcoded image source caption with parameterized placeholder `{{IMAGE_SOURCE_CAPTION}}`.

### Improvements

- **Clarification Question Priority Matrix**: Added structured priority matrix to intake-and-clarification.md. Clarifies which questions to ask first (Must-Have: image relationship, category, brand) vs optional (market, nice-to-have items). Maximum 3 Must-Have + 2 optional = 5 total.
- **validate_skill.py Enhancement**: Added categories.yaml loading and validation. REQUIRED_FILES updated to include all new v3.0 files. Added IMAGE_SOURCE_CAPTION to template placeholder validation.
- **SKILL.md**: Added personal care category to Overview and reference loading rules. Version updated to 3.0.0. Changelog updated.

### Files Changed

| Action | File |
|---|---|
| New | `references/categories.yaml` |
| New | `references/category/personal-care.md` |
| New | `references/brand-language/personal-care.md` |
| New | `references/patent-risk/personal-care-search.md` |
| New | `scripts/validate_scores.py` |
| New | `evals/run_tests.py` |
| New | `CHANGELOG.md` |
| Modified | `SKILL.md` |
| Modified | `agents/openai.yaml` |
| Modified | `scripts/fetch_competitor_images.py` |
| Modified | `scripts/generate_report.py` |
| Modified | `scripts/validate_skill.py` |
| Modified | `assets/report-template.html` |
| Modified | `references/scoring-rubric.md` |
| Modified | `references/intake-and-clarification.md` |
| Modified | `references/frontend-design-workflow.md` |
| Modified | `references/patent-risk/cleaning-appliances-search.md` |
| Modified | `references/patent-risk/consumer-electronics-search.md` |

---

## v2.3.0 (2026-07-08)

- Fallback Comparison Link Requirement: SVG schematic or placeholder patent/design comparison cards must include a clickable public comparison-object, source, or image-search link.
- Report Generator Update: Added `visual_type`, `comparison_url`, and `image_reference_url` support to comparison-card rendering.
- Quality Gate Update: Added automated Critical check for fallback visual links.

## v2.2.0 (2026-07-07)

- Integrated Frontend Design Workflow: Added `references/frontend-design-workflow.md` as mandatory for HTML report creation.
- Report Rendering Handoff Update: Passes frozen content plus frontend-design workflow.
- Visual QA Expansion: Added checks for layout, mobile fit, print styles, dark mode.

## v2.1.0 (2026-07-07)

Based on real evaluation case feedback (eufy robot vacuum design review):
- Image Recognition Verification: Mandatory second-pass recognition verification gate.
- Product Image Embedding: HTML report must embed original product images as base64.
- Full Chinese Output: All evaluation text in Chinese (4 exceptions: brand names, technical terms, model numbers, acronyms).
- Text Conciseness: List items one sentence each (max two).
- Patent Comparison Images: Created image-acquisition-guide.md and fetch_competitor_images.py.
- Quality Gate Enhancement: 5 new Critical checks, 3 new Recommended checks.

## v2.0.0

Initial improved version with:
- Confidentiality rules, language rules, iteration review, image quality fallback
- Scoring rubric with examples, category weight adjustment, low confidence score cap
- Quality gate with Critical/Recommended check levels
- Report template with dark mode, print optimization, export PDF button, localStorage feedback
- Brand language and category reference enhancements
- Scripts: generate_report.py, quality_check.py, validate_skill.py
- Evals directory with test cases
